import { defineConfig } from "vite";

export default defineConfig({
  // No framework plugins needed — vanilla JS
  build: {
    outDir: "dist",
    // Increase chunk size warning limit — the modules are large by design
    chunkSizeWarningLimit: 2000,
  },
});
