import "./styles.css";
import { getContrastText, safeBrandText, getCompanyBrandColour, _isInheritedColour, renderAvatar } from "./modules/helpers.js";
import { DB, F, LP, S, SCOOBY_CONFIG } from "./modules/db.js";
import { AUTH } from "./modules/auth.js";
import { NAV, MODAL, AREA, CLIENT } from "./modules/ui.js";
import { ADMIN, REPORT, BUILDER, INTEL, OPPS, SNAPSHOT, TIMELINE, STRAT } from "./modules/reporting.js";
import { RV_DB, RV } from "./modules/review.js";

// Expose globals that modules reference via window (cross-module calls)
// This preserves compatibility with the existing codebase without a full rewrite
Object.assign(window, {
  getContrastText, safeBrandText, getCompanyBrandColour, _isInheritedColour, renderAvatar,
  DB, F, LP, S, SCOOBY_CONFIG,
  AUTH, NAV, MODAL, AREA, CLIENT,
  ADMIN, REPORT, BUILDER, INTEL, OPPS, SNAPSHOT, TIMELINE, STRAT,
  RV_DB, RV,
});

// Login button
document.addEventListener('DOMContentLoaded', function () {
  const btn = document.getElementById('login-submit-btn');
  if (btn) btn.addEventListener('click', function () { AUTH.login(); });

  // Keyboard shortcut: Enter on login screen
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
      const login = document.getElementById('login');
      if (login && login.style.display !== 'none') AUTH.login();
    }
  });
});
