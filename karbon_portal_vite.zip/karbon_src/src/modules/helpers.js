
// Global contrast helper
function getContrastText(hex){
  if(!hex||typeof hex!=='string') return '#fff';
  const c=hex.replace('#','');
  if(c.length!==6) return '#fff';
  const r=parseInt(c.slice(0,2),16),g=parseInt(c.slice(2,4),16),b=parseInt(c.slice(4,6),16);
  const lum=(0.299*r+0.587*g+0.114*b)/255;
  return lum>0.55?'#00192B':'#ffffff';
}
function safeBrandText(hex){ return getContrastText(hex); }

// Single source of truth for brand colour
function getCompanyBrandColour(coId){
  const cos=typeof DB!=='undefined'?DB.getCompanies():[];
  const clients=typeof DB!=='undefined'?DB.getParents().concat(DB.getParents().flatMap(p=>DB.getChildren(p.id))):[];
  // 1. Check as a company id
  const co=cos.find(c=>c.id===coId);
  if(co){
    if(co.colour) return co.colour; // explicit company colour
    // No explicit colour → check if this company's client is a child client → inherit parent
    const linkedClientId=co.clientIds?.[0];
    if(linkedClientId){
      const linkedClient=typeof DB!=='undefined'?DB.getClient(linkedClientId):null;
      if(linkedClient?.parent_id){
        // It's a child client — find parent company
        const parentCo=cos.find(c=>(c.clientIds||[]).includes(linkedClient.parent_id));
        if(parentCo?.colour) return parentCo.colour;
        // or check parent client directly
        const parentClient=typeof DB!=='undefined'?DB.getClient(linkedClient.parent_id):null;
        if(parentClient?.brand_colour) return parentClient.brand_colour;
      }
      if(linkedClient?.brand_colour) return linkedClient.brand_colour;
    }
  }
  // 2. Check as a client id directly
  const cl=typeof DB!=='undefined'?DB.getClient(coId):null;
  if(cl){
    if(cl.brand_colour&&!_isInheritedColour(cl)) return cl.brand_colour;
    if(cl.parent_id){
      // Child client — inherit from parent
      const parentCl=typeof DB!=='undefined'?DB.getClient(cl.parent_id):null;
      if(parentCl?.brand_colour) return parentCl.brand_colour;
    }
    if(cl.brand_colour) return cl.brand_colour;
  }
  return 'rgba(255,255,255,.15)';
}
function _isInheritedColour(cl){
  // A child client's brand_colour is "inherited" (not explicit) if it matches parent's
  if(!cl.parent_id) return false;
  const parentCl=typeof DB!=='undefined'?DB.getClient(cl.parent_id):null;
  return parentCl&&cl.brand_colour===parentCl.brand_colour;
}
function renderAvatar(bg, initials, extraStyle, extraClass){
  bg=bg||'rgba(255,255,255,.15)';
  const tx=getContrastText(bg);
  return '<div'+(extraClass?' class="'+extraClass+'"':'')+' style="background:'+bg+';color:'+tx+';'+(extraStyle||'')+'">'+(initials||'')+'</div>';
}


'use strict';

// ══════════════════════════════════════════════════════════════════════
// DATA LAYER
// Mirrors Supabase schema. Replace method bodies with API calls when
// connecting to Supabase. Component layer never changes.
// ══════════════════════════════════════════════════════════════════════

export { getContrastText, safeBrandText, getCompanyBrandColour, _isInheritedColour, renderAvatar };
