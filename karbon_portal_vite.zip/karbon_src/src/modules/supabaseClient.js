// Supabase client — wired once VITE_SUPABASE_URL + VITE_SUPABASE_ANON_KEY are set
// import { createClient } from "@supabase/supabase-js";
// export const supabase = createClient(
//   import.meta.env.VITE_SUPABASE_URL,
//   import.meta.env.VITE_SUPABASE_ANON_KEY
// );
export const supabase = null; // placeholder until Supabase is wired
