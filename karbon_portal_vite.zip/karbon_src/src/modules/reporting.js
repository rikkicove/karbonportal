import { DB, S, F, LP } from "./db.js";
import { getCompanyBrandColour, getContrastText } from "./helpers.js";

const ADMIN = {
  buildClients(){
    const clients=DB.getParents();
    const cards=document.getElementById('client-cards');
    const list=document.getElementById('client-list');
    if(!cards||!list) return;
    cards.innerHTML=clients.map(c=>{
      const logo=c.logo?`<img src="${c.logo}" style="width:36px;height:36px;object-fit:contain;border-radius:6px">`:`<div style="width:36px;height:36px;border-radius:8px;background:${c.brand_colour};display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:${c.brand_text}">${c.initials}</div>`;
      const ch=DB.getChildren(c.id);
      const yrs=DB.getYears(c.id);
      return`<div class="acard2" onclick="NAV.openReport('${c.id}')">
        <div class="ac2ico">${logo}</div>
        <div class="ac2t">${c.name}</div>
        <div class="ac2s">${yrs.length?yrs.slice(-1)[0]+' — '+DB.getMonths(c.id,yrs.slice(-1)[0]).length+' months':'No reports yet'}</div>
        <div style="margin-top:8px"><button class="btn btn-y btn-sm" style="font-size:10px;padding:3px 8px" onclick="event.stopPropagation();MODAL.addReport('${c.id}')">+ Add report</button></div>
        ${ch.length?`<div style="font-size:10.5px;color:var(--t1);margin-top:5px">${ch.map(x=>x.name).join(', ')}</div>`:''}
      </div>`;
    }).join('')+`<div class="acard2" onclick="MODAL.addReport(null)" style="border-style:dashed;opacity:.6"><div class="ac2ico" style="font-size:22px">+</div><div class="ac2t">Create Report</div><div class="ac2s">Add a report for any client</div></div>`;

    list.innerHTML=clients.map(c=>{
      const ch=DB.getChildren(c.id);
      return`<div class="crow">
        <div class="cinfo">
          <div class="cav" style="background:${getCompanyBrandColour(c.id)}" data-cid="${c.id}">${c.logo?`<img src="${c.logo}" alt="">`:`<span style="color:${c.brand_text}">${c.initials}</span>`}</div>
          <div>
            <div class="cn">${c.name}<span class="parent-chip">parent</span></div>
            <div class="ce">${c.contact_email}${ch.length?` · ${ch.map(x=>`<span class="parent-chip">${x.name}</span>`).join('')}`:''}</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
          <div class="sdot" style="width:6px;height:6px;border-radius:50%;background:var(--g)"></div>
          <button class="btn btn-y btn-sm" onclick="MODAL.addReport('${c.id}')">+ Add report</button>
          <button class="btn btn-g btn-sm" onclick="ADMIN.openClientSettings('${c.id}')">⚙ Settings</button>
          <button class="btn btn-g btn-sm" onclick="NAV.openReport('${c.id}')">View</button>
        </div>
      </div>`+ch.map(x=>`
      <div class="crow child-indent">
        <div class="cinfo">
          <div class="cav" style="background:${getCompanyBrandColour(x.id)||x.brand_colour};font-size:10px"><span style="color:${getContrastText(getCompanyBrandColour(x.id)||x.brand_colour)}ext}">${x.initials}</span></div>
          <div><div class="cn">${x.name}</div><div class="ce">Child of ${c.name}</div></div>
        </div>
        <div style="display:flex;gap:5px;flex-wrap:wrap">
          <button class="btn btn-y btn-sm" onclick="MODAL.addReport('${x.id}')">+ Add report</button>
          <button class="btn btn-g btn-sm" onclick="ADMIN.openClientSettings('${x.id}')">⚙ Settings</button>
          <button class="btn btn-g btn-sm" onclick="NAV.openReport('${x.id}')">View</button>
        </div>
      </div>`).join('');
    }).join('');
  },

  buildKpiBanner(){
    const el=document.getElementById('kpi-banner'); if(!el) return;
    const alerts=DB.getAllAlerts().filter(a=>a.health==='attn');
    if(!alerts.length){ el.innerHTML=''; return; }
    el.innerHTML=`<div class="ins w" style="margin-bottom:16px"><strong>⚑ ${alerts.length} KPI${alerts.length>1?'s':''} need attention</strong><p>${alerts.slice(0,3).map(a=>`${a.client_name} — ${a.label} (${a.act_pct}% vs ${a.exp_pct}% expected)`).join(' · ')}${alerts.length>3?` and ${alerts.length-3} more…`:''}</p></div>`;
  },

  buildKpiHealth(){
    const el=document.getElementById('kpi-acc'); if(!el) return;
    const all=DB.getAllAlerts();
    const byClient={};
    for(const a of all){ if(!byClient[a.client_id]) byClient[a.client_id]={name:a.client_name,rows:[],ahead:0,track:0,attn:0}; byClient[a.client_id].rows.push(a); byClient[a.client_id][a.health]++; }
    el.innerHTML=Object.entries(byClient).map(([cid,data])=>{
      const hpill=(n,cls,lbl)=>n?`<span class="badge ${cls}" style="font-size:10.5px">${n} ${lbl}</span>`:'';
      return`<div class="acc-item" id="acc-${cid}">
        <div class="acc-hd" onclick="ADMIN.toggleAcc('${cid}')">
          <div class="acc-name">${data.name}</div>
          <div style="display:flex;align-items:center;gap:6px">
            <div class="acc-pills">
              ${hpill(data.attn,'br','Needs Attention')}
              ${hpill(data.track,'ba','On Track')}
              ${hpill(data.ahead,'bg','Ahead')}
            </div>
            <span class="acc-arrow">▾</span>
          </div>
        </div>
        <div class="acc-body">
          ${data.rows.map(a=>{
            const barCol=a.health==='ahead'?'var(--g)':a.health==='track'?'var(--am)':'var(--r)';
            const hcls=a.health==='ahead'?'kh-a':a.health==='track'?'kh-t':'kh-r';
            const hlbl=a.health==='ahead'?'Ahead':a.health==='track'?'On Track':'Needs Attention';
            const barFill=Math.min(a.act_pct,100);
            const expFill=Math.min(a.exp_pct,100);
            return`<div style="padding:12px 0;border-bottom:1px solid var(--bd0)">
              <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:7px">
                <div>
                  <div style="font-size:13px;font-weight:600">${a.label}</div>
                  <div style="font-size:10.5px;color:var(--t1)">${a.month} ${a.year}</div>
                </div>
                <span class="khealth ${hcls}" style="display:block;flex-shrink:0">● ${hlbl}</span>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;font-size:11.5px;margin-bottom:8px">
                <div><div style="color:var(--t2);font-size:9px;text-transform:uppercase;letter-spacing:.6px;font-weight:600;margin-bottom:1px">Achieved</div><div style="font-weight:700;font-size:14px">${a.act_pct}%</div></div>
                <div><div style="color:var(--t2);font-size:9px;text-transform:uppercase;letter-spacing:.6px;font-weight:600;margin-bottom:1px">Expected</div><div style="font-weight:700;font-size:14px">${a.exp_pct}%</div></div>
                <div><div style="color:var(--t2);font-size:9px;text-transform:uppercase;letter-spacing:.6px;font-weight:600;margin-bottom:1px">Target</div><div style="font-weight:600;font-size:13px">${F.short(a.target,a.health==='attn'?'count':'count')}</div></div>
              </div>
              <div style="position:relative;background:var(--bg2);border-radius:4px;height:7px;overflow:hidden">
                <div style="position:absolute;left:0;top:0;height:100%;width:${barFill}%;background:${barCol};border-radius:4px;transition:width .6s ease"></div>
                <div style="position:absolute;top:-2px;height:calc(100% + 4px);width:2px;background:var(--t1);left:${expFill}%;border-radius:1px" title="Expected: ${expFill}%"></div>
              </div>
              <div style="display:flex;justify-content:space-between;font-size:9.5px;color:var(--t2);margin-top:3px">
                <span>${a.act_pct}% achieved</span><span style="display:flex;align-items:center;gap:3px">│ Expected: ${a.exp_pct}%</span>
              </div>
            </div>`;
          }).join('')}
        </div>
      </div>`;
    }).join('');
  },
  toggleAcc(cid){ document.getElementById('acc-'+cid)?.classList.toggle('open'); },

  buildUsers(){
    const el=document.getElementById('user-list'); if(!el) return;
    el.innerHTML=DB.getUsers().map(u=>{
      const _uco=(u.companies||[u.company].filter(Boolean))[0]||u.id;
      const _ubg=getCompanyBrandColour(_uco);
      const _utx=getContrastText(_ubg);
      return `<div class="crow">
        <div class="cinfo">
          <div class="uav" style="border-radius:8px;width:32px;height:32px;font-size:11px;background:${_ubg};color:${_utx}">${u.avatar?`<img src="${u.avatar}" alt="">`:`<span style="color:inherit">${u.initials}</span>`}</div>
          <div>
            <div class="cn">${u.name}</div>
            <div class="ce">${u.email} · ${u.role} · ${u.client_ids.map(id=>DB.getClient(id)?.name||id).join(', ')||'no clients'}</div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          ${u.role==='admin'?'<span class="ubadge">Admin</span>':'<span style="font-size:10.5px;background:var(--bg2);border:1px solid var(--bd0);border-radius:4px;padding:2px 7px;color:var(--t1)">Client</span>'}
          <button class="btn btn-g btn-sm" onclick="ADMIN.openClientSettings(this.dataset.cid)" data-cid="${u.client_ids[0]||''}">⚙ Settings</button>
        </div>
      </div>`;}).join('');
  },

  openClientSettings(clientId){
    if(!clientId) return;
    const c=DB.getClient(clientId); if(!c) return;
    const ch=DB.getChildren(clientId);
    document.getElementById('cs-title').textContent=c.name+' — Settings';
    const allMods=DB.MODO;
    document.getElementById('cs-content').innerHTML=`
      <div class="g2">
        <div class="card">
          <div class="card-hd"><div><div class="ctitle">Client info</div></div></div>
          <div class="fg"><label class="fl">Name</label><input class="fi" id="cset-n" value="${c.name}"></div>
          <div class="fg"><label class="fl">Contact email</label><input class="fi" id="cset-e" value="${c.contact_email||''}"></div>
          <div class="fg"><label class="fl">Brand colour</label><input class="fi" id="cset-col" value="${c.brand_colour}"></div>
          <div class="fg"><label class="fl">Reporting year start</label>
            <select class="fi" id="cset-yr">
              <option value="1" ${c.reporting_year_start===1?'selected':''}>January (calendar year)</option>
              <option value="4" ${c.reporting_year_start===4?'selected':''}>April (financial year)</option>
              <option value="7" ${c.reporting_year_start===7?'selected':''}>July</option>
              <option value="10" ${c.reporting_year_start===10?'selected':''}>October</option>
            </select>
          </div>
          <div class="fg"><label class="fl">Report frequency</label>
            <select class="fi" id="cset-freq">
              <option value="weekly" ${c.report_frequency==='weekly'?'selected':''}>Weekly</option>
              <option value="mid_month" ${c.report_frequency==='mid_month'?'selected':''}>Mid-month (twice monthly)</option>
              <option value="monthly" ${(c.report_frequency==='monthly'||!c.report_frequency)?'selected':''}>Monthly</option>
              <option value="quarterly" ${c.report_frequency==='quarterly'?'selected':''}>Quarterly</option>
            </select>
          </div>
          <div class="fg"><label class="fl">Email provider</label>
            <select class="fi" id="cset-ep">
              ${['manual','mailerlite','mailchimp','hubspot','brevo','klaviyo','campaign_monitor','other'].map(p=>`<option value="${p}" ${c.email_provider===p?'selected':''}>${{manual:'Manual only',mailerlite:'MailerLite',mailchimp:'Mailchimp',hubspot:'HubSpot',brevo:'Brevo (Sendinblue)',klaviyo:'Klaviyo',campaign_monitor:'Campaign Monitor',other:'Other / Custom'}[p]||p}</option>`).join('')}
            </select>
          </div>
          <div class="fg"><label class="fl">Logo (upload)</label>
            <input type="file" class="fi" id="cset-logo" accept="image/*" style="padding:6px" onchange="ADMIN.previewLogo('${c.id}',this)">
          </div>
          ${c.logo?`<div style="margin-bottom:12px"><img src="${c.logo}" style="height:44px;object-fit:contain;border-radius:4px"></div>`:''}
          <button class="btn btn-y btn-sm" onclick="ADMIN.saveClientSettings('${c.id}')">Save changes</button>
          <div id="cset-ok" style="font-size:11.5px;color:var(--g);display:none;margin-top:6px">✓ Saved</div>
        </div>
        <div>
          ${ch.length?`<div class="card" style="margin-bottom:14px">
            <div class="card-hd"><div><div class="ctitle">Parent report mode</div><div class="csub">How this parent client's report area works</div></div></div>
            <div style="display:flex;flex-direction:column;gap:8px">
              <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;padding:10px;border-radius:var(--rs);border:1px solid ${c.parent_report_mode==='summary'?'var(--y)':'var(--bd0)'}">
                <input type="radio" name="prm-${c.id}" value="summary" ${c.parent_report_mode!=='custom'?'checked':''} onchange="DB.updateClient('${c.id}',{parent_report_mode:'summary'});this.closest('.card').querySelectorAll('label').forEach(l=>l.style.borderColor=l.querySelector('input').checked?'var(--y)':'var(--bd0)')">
                <div><div style="font-size:13px;font-weight:600">Auto Summary Dashboard</div><div style="font-size:11.5px;color:var(--t1)">Automatically shows overview of all child account reports and KPIs.</div></div>
              </label>
              <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;padding:10px;border-radius:var(--rs);border:1px solid ${c.parent_report_mode==='custom'?'var(--y)':'var(--bd0)'}">
                <input type="radio" name="prm-${c.id}" value="custom" ${c.parent_report_mode==='custom'?'checked':''} onchange="DB.updateClient('${c.id}',{parent_report_mode:'custom'});this.closest('.card').querySelectorAll('label').forEach(l=>l.style.borderColor=l.querySelector('input').checked?'var(--y)':'var(--bd0)')">
                <div><div style="font-size:13px;font-weight:600">Custom Reports</div><div style="font-size:11.5px;color:var(--t1)">Build fully custom reports for this parent account independently.</div></div>
              </label>
            </div>
          </div>`:''}
          <div class="card">
            <div class="card-hd"><div><div class="ctitle">Report modules</div><div class="csub">Toggle visible sections</div></div></div>
            ${allMods.map(mod=>`
              <div style="display:flex;align-items:center;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--bd0)">
                <span style="font-size:13px">${DB.MODL[mod]}</span>
                <label class="tsw2"><input type="checkbox" ${c.modules[mod]?'checked':''} onchange="DB.toggleModule('${c.id}','${mod}',this.checked)"><div class="ttrack"></div><div class="tthumb"></div></label>
              </div>`).join('')}
          </div>
          ${ch.length?`<div class="card">
            <div class="card-hd"><div><div class="ctitle">Child clients</div></div></div>
            ${ch.map(x=>`
              <div style="display:flex;align-items:center;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--bd0)">
                <span style="font-size:12.5px;font-weight:500">${x.name}</span>
                <button class="btn btn-g btn-sm" onclick="ADMIN.openClientSettings('${x.id}')">Settings</button>
              </div>`).join('')}
          </div>`:''}
          <div class="card">
            <div class="card-hd"><div><div class="ctitle">Data sources</div><div class="csub">Configure per-client data connections (API integration coming later)</div></div>
              <button class="btn btn-g btn-sm" onclick="ADMIN.addDataSource('${c.id}')">+ Add source</button>
            </div>
            ${(c.data_sources.length?c.data_sources:[]).map((ds,di)=>`
              <div style="display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--bd0);font-size:12.5px;gap:8px;flex-wrap:wrap">
                <div style="display:flex;align-items:center;gap:9px">
                  <span class="badge ${ds.active?'bg':'bn'}">${ds.provider}</span>
                  <span>${ds.label}</span>
                  ${ds.api_key?'<span style="font-size:10px;color:var(--g)">● Credentials saved</span>':''}
                </div>
                <div style="display:flex;gap:5px">
                  <button class="btn btn-g btn-sm" onclick="ADMIN.editDataSource('${c.id}',${di})">Configure</button>
                  <button class="btn btn-r btn-sm" onclick="ADMIN.removeDataSource('${c.id}',${di})">Remove</button>
                </div>
              </div>`).join('')||'<p style="font-size:12.5px;color:var(--t1);padding:8px 0">No data sources configured. Click + Add source to connect a platform.</p>'}
          </div>
        </div>
      </div>`;
    NAV.go('clientsettings',null);
  },

  addDataSource(cid){
    document.getElementById('ds-modal-title').textContent='Add data source';
    document.getElementById('ds-provider').value='google_analytics_4';
    document.getElementById('ds-label').value='';
    document.getElementById('ds-key').value='';
    document.getElementById('ds-account').value='';
    document.getElementById('ds-notes').value='';
    document.getElementById('ds-client-id').value=cid;
    document.getElementById('ds-edit-idx').value='';
    MODAL.open('modal-datasource');
  },
  editDataSource(cid,idx){
    const c=DB.getClient(cid); if(!c) return;
    const ds=c.data_sources[idx]; if(!ds) return;
    document.getElementById('ds-modal-title').textContent='Edit data source';
    document.getElementById('ds-provider').value=ds.provider||'manual';
    document.getElementById('ds-label').value=ds.label||'';
    document.getElementById('ds-key').value=''; // never pre-fill API keys
    document.getElementById('ds-account').value=ds.account_id||'';
    document.getElementById('ds-notes').value=ds.notes||'';
    document.getElementById('ds-client-id').value=cid;
    document.getElementById('ds-edit-idx').value=idx;
    MODAL.open('modal-datasource');
  },
  saveDataSource(){
    const cid=document.getElementById('ds-client-id').value;
    const idx=document.getElementById('ds-edit-idx').value;
    const c=DB.getClient(cid); if(!c) return;
    const provider=document.getElementById('ds-provider').value;
    const label=document.getElementById('ds-label').value.trim(); if(!label) return;
    const key=document.getElementById('ds-key').value.trim();
    const account=document.getElementById('ds-account').value.trim();
    const notes=document.getElementById('ds-notes').value.trim();
    const data={provider,label,active:!!(key||account),api_key:key||null,api_secret:null,account_id:account||null,notes};
    if(idx!==''){
      const ds=c.data_sources[parseInt(idx)];
      if(ds) Object.assign(ds,data);
    } else {
      c.data_sources.push(data);
    }
    INTEL.record('Data source '+(idx!==''?'updated':'added'),label);
    MODAL.close('modal-datasource');
    this.openClientSettings(cid);
  },
  removeDataSource(cid,idx){
    const c=DB.getClient(cid); if(!c) return;
    c.data_sources.splice(idx,1);
    INTEL.record('Data source removed','');
    this.openClientSettings(cid);
  },
  previewLogo(cid,input){
    const f=input.files[0]; if(!f) return;
    const r=new FileReader();
    r.onload=e=>{ 
      DB.setClientLogo(cid,e.target.result); 
      DB.broadcastLogoUpdate(cid);
      this.buildClients(); 
      REPORT.updateLogos(); 
    };
    r.readAsDataURL(f);
  },

  saveClientSettings(cid){
    DB.updateClient(cid,{
      name:document.getElementById('cset-n').value||DB.getClient(cid)?.name,
      contact_email:document.getElementById('cset-e').value,
      brand_colour:document.getElementById('cset-col').value,
      brand_text:safeBrandText(document.getElementById('cset-col').value),
      email_provider:document.getElementById('cset-ep').value,
      report_frequency:document.getElementById('cset-freq')?.value||'monthly',
      reporting_year_start:parseInt(document.getElementById('cset-yr').value),
    });
    const ok=document.getElementById('cset-ok');
    if(ok){ ok.style.display='block'; setTimeout(()=>ok.style.display='none',2500); }
    this.buildClients();
  },
};

/* REPORT */
const REPORT = {
  buildMonthBtns(){
    const row=document.getElementById('mbtnrow');
    const yrSel=document.getElementById('yr-sel');
    if(!row||!yrSel) return;
    const yrs=DB.getYears(S.clientId);
    const isClient=S.user?.role==='client';
    // Clients only see years with published reports
    const visibleYrs=isClient?yrs.filter(yr=>DB.getMonths(S.clientId,yr).some(m=>DB.getReport(S.clientId,yr,m)?.status==='published')):yrs;
    yrSel.innerHTML=visibleYrs.map(y=>`<option value="${y}" ${y===S.year?'selected':''}>${y}</option>`).join('');
    const mons=DB.getMonths(S.clientId,S.year).filter(m=>isClient?DB.getReport(S.clientId,S.year,m)?.status==='published':true);
    row.innerHTML=mons.map(m=>`<button class="mbtn${m===S.month?' on':''}" onclick="REPORT.setMonth('${m}')">${m}</button>`).join('');
  },
  setMonth(m){ S.month=m; S.activeTab='overview'; this.buildMonthBtns(); this.render(); },
  onYrChange(){ S.year=+document.getElementById('yr-sel').value; const mons=DB.getMonths(S.clientId,S.year); S.month=mons[mons.length-1]||'Jan'; this.buildMonthBtns(); this.render(); },
  toggleCmp(){
    S.cmpActive=!S.cmpActive;
    const btn=document.getElementById('cmp-btn');
    const tag=document.getElementById('ctag');
    btn.textContent=S.cmpActive?'Disable':'Enable';
    btn.className=S.cmpActive?'btn btn-o btn-sm':'btn btn-g btn-sm';
    tag.textContent=S.cmpActive?'Comparing vs previous month':'';
    tag.classList.toggle('on',S.cmpActive);
    document.getElementById('rcp')?.classList.toggle('cmp-on',S.cmpActive);
    this.render();
  },
  setStatus(){
    const s=document.getElementById('status-sel').value;
    if(s==='published'){
      // Run validation before publishing
      const issues=this._validateReport();
      if(issues.length){
        const ok=confirm('Pre-publish checklist:\n\n' + issues.map(i=>`${i.ok?'✓':'⚠'} ${i.msg}`).join('\n') + '\n\nPublish anyway?');
        if(!ok) return;
      }
    }
    DB.setStatus(S.clientId,S.year,S.month,s);
    this._updatePill(s);
  },
  _validateReport(){
    const rep=DB.getReport(S.clientId,S.year,S.month); if(!rep) return[];
    const issues=[];
    const kpis=rep.metrics.filter(m=>m.is_kpi);
    issues.push({ok:kpis.length>0,msg:kpis.length>0?`${kpis.length} KPI metrics present`:'No KPI metrics set'});
    const emptyKpis=kpis.filter(m=>m.value_number===null&&!m.value_text);
    issues.push({ok:emptyKpis.length===0,msg:emptyKpis.length===0?'All KPIs have values':`${emptyKpis.length} KPI(s) missing values`});
    const insightCount=Object.values(rep.insights).filter(i=>i.text&&i.text.length>10).length;
    issues.push({ok:insightCount>0,msg:insightCount>0?`${insightCount} insight(s) written`:'No insights written'});
    issues.push({ok:rep.assets.length>0,msg:rep.assets.length>0?`${rep.assets.length} creative asset(s)`:'No creative assets uploaded'});
    const taskDone=rep.tasks.done?.length||0;
    issues.push({ok:taskDone>0,msg:taskDone>0?`${taskDone} completed tasks listed`:'No completed tasks listed'});
    return issues;
  },
  _updatePill(s){
    const p=document.getElementById('spill'); if(!p) return;
    const map={draft:['sp-draft','Draft'],review:['sp-review','Internal Review'],approved:['sp-approved','Approved'],published:['sp-published','Published']};
    const [cls,lbl]=map[s]||map.published;
    p.className=`spill ${cls}`; p.innerHTML=`<span class="sdot"></span>${lbl}`;
    const sel=document.getElementById('status-sel'); if(sel) sel.value=s;
  },

  updateLogos(){
    const c=DB.getClient(S.clientId); if(!c) return;
    const hl=document.getElementById('hero-logo');
    if(hl){ 
      hl.style.background=c.brand_colour;
      hl.innerHTML=c.logo?`<img src="${c.logo}" alt="">`:`<span style="color:${c.brand_text}">${c.initials}</span>`; 
    }
    // Update topbar avatar if viewing own client
    ADMIN.buildClients();
    DB.broadcastLogoUpdate(S.clientId);
  },

  render(){
    // Security: clients can only render their own reports
    if(S.user?.role==='client'){
      const allowed=S.user.client_ids||[];
      if(!allowed.includes(S.clientId)) S.clientId=allowed[0]||S.clientId;
    }
    CHARTS.destroyAll();
    const c=DB.getClient(S.clientId);
    const rep=DB.getReport(S.clientId,S.year,S.month);
    if(!c||!rep) return;

    // Check if parent — show parent dashboard overview
    const isParent = DB.getChildren(S.clientId).length > 0;
    if(isParent){
      // For parent clients, ensure overview + forecast modules are enabled
      c.modules.overview = true;
      c.modules.forecast = true;
    }
    // Update hero
    const hl=document.getElementById('hero-logo');
    if(hl){ hl.style.background=c.brand_colour; hl.innerHTML=c.logo?`<img src="${c.logo}" alt="">`:`<span style="color:${c.brand_text}">${c.initials}</span>`; }
    document.getElementById('htitle').innerHTML=`${DB.ML[S.month]} <span>${S.year}</span>`;
    document.getElementById('hsub').textContent=`Prepared for ${c.name} by Karbon Creative`;
    document.getElementById('hdate').textContent=F.date(rep.published_at);
    document.getElementById('footer-logo').innerHTML=LogoFaded(16);
    document.getElementById('footer-txt').textContent=`${c.name} — ${DB.ML[S.month]} ${S.year} · Confidential`;
    this._updatePill(rep.status);

    // Track report view
    USAGE.trackView(S.clientId,S.year,S.month);
    // Show AI assistant for clients, hide for admins (admin has dedicated intelligence panel)
    if(S.user?.role==='client') AI.show(); else AI.hide();
    // Video is now an overview section block — not in hero

    // Admin bar context
    if(S.user?.role==='admin') document.getElementById('abar-ctx').textContent=`${c.name} — ${DB.ML[S.month]} ${S.year}`;

    // Tabs — from enabled modules; parent summary mode restricts to overview+forecast only
    const isParentSummary = DB.getChildren(S.clientId).length > 0 && c.parent_report_mode !== 'custom';
    const mods = isParentSummary
      ? DB.MODO.filter(m=>['overview','forecast'].includes(m)&&c.modules[m!=='forecast'?m:'overview'])
      : DB.MODO.filter(m=>c.modules[m]);
    const tabsEl=document.getElementById('rtabs');
    const addBtn=tabsEl.querySelector('.rtab-add');
    tabsEl.innerHTML='';
    mods.forEach(m=>{
      const b=document.createElement('button');
      b.className='rtab'+(m===S.activeTab?' on':'');
      b.textContent=DB.MODL[m];
      b.onclick=()=>this.switchTab(m,b);
      tabsEl.appendChild(b);
    });
    if(addBtn){ addBtn.style.display=''; tabsEl.appendChild(addBtn); }

    // Section content
    CHARTS.destroyAll();
    const cp=document.getElementById('rcp');
    cp.classList.toggle('cmp-on',S.cmpActive);
    const isBlankReport = rep.metrics.length === 0 && rep.assets.length === 0 && Object.keys(rep.insights).length === 0;
    const isGT=S.clientId==='cl-gt';
    const isTD=S.clientId==='cl-td';
    cp.innerHTML=mods.map(mod=>`<div id="rs-${mod}" class="rs${mod===S.activeTab?' on':''}">${isBlankReport ? this._sectionBlank(mod) : (S.clientId==='cl-td'?this._sectionTD(mod,rep,c):isGT?this._sectionGT(mod,rep,c):this._sectionBL(mod,rep,c))}</div>`).join('');
    // Render video into the overview section's vid-area
    setTimeout(()=>{
      const va=document.getElementById('vid-area');
      if(va) this._buildVideo(rep,c,va);
      this._charts(rep,c);
    },60);
  },

  _buildVideo(rep,c,container){
    const isAdmin=S.user?.role==='admin'; // video available on all reports (parent + child)
    if(rep.video){
      // Video exists — all users see the player; admin also gets controls
      container.innerHTML=`<div class="vid-block">
        <div class="vid-title">📹 Report overview video</div>
        <video class="vid-player" controls src="${rep.video}" id="vid-player-el"></video>
        ${isAdmin?`<div class="vid-upload" style="margin-top:8px;display:flex;gap:5px;flex-wrap:wrap">
          <label class="vid-upload-btn" style="cursor:pointer" onclick="document.getElementById('vid-file-r').click()">Replace video</label>
          <input type="file" id="vid-file-r" accept="video/*" style="display:none" onchange="REPORT.uploadVideo(this)">
          <button class="vid-rec-btn" id="vid-rec" onclick="REPORT.toggleRecord()">⏺ Re-record</button>
          <button class="btn btn-r btn-sm" style="font-size:10.5px" onclick="REPORT.removeVideo()">Remove video</button>
        </div>
        <div id="vid-rec-area"></div>`:''}
      </div>`;
    } else if(isAdmin){
      // No video yet — admin can add one
      container.innerHTML=`<div class="vid-upload" style="display:flex;flex-direction:column;gap:6px;min-width:200px">
        <div style="font-size:10px;color:rgba(255,255,255,.4);font-weight:600;letter-spacing:.8px;text-transform:uppercase;margin-bottom:2px">Overview video (optional)</div>
        <div style="display:flex;gap:5px;flex-wrap:wrap">
          <label class="vid-upload-btn" style="cursor:pointer" onclick="document.getElementById('vid-file-u').click()">📁 Upload video</label>
          <input type="file" id="vid-file-u" accept="video/*" style="display:none" onchange="REPORT.uploadVideo(this)">
          <button class="vid-rec-btn" id="vid-rec" onclick="REPORT.toggleRecord()">⏺ Record video</button>
        </div>
        <div id="vid-rec-area"></div>
      </div>`;
    } else {
      // Client — no video, nothing to show
      container.innerHTML='';
    }
  },
  exportPDF(){
    const c=DB.getClient(S.clientId); const rep=DB.getReport(S.clientId,S.year,S.month);
    if(!rep||!c) return;
    const isClient=S.user?.role==='client';
    const title=c.name+' — '+(DB.ML[S.month]||S.month)+' '+S.year;

    // Loading overlay
    const loadEl=document.createElement('div');
    loadEl.style.cssText='position:fixed;inset:0;background:rgba(0,25,43,.88);z-index:9999;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;';
    loadEl.innerHTML='<div style="font-size:20px;color:#FFD600;font-weight:700">Preparing PDF…</div>'
      +'<div style="font-size:13px;color:rgba(255,255,255,.7)">Building charts and report content</div>'
      +'<div style="width:220px;height:4px;background:rgba(255,255,255,.12);border-radius:2px;overflow:hidden;margin-top:4px">'
      +'<div id="pdf-prog" style="width:0%;height:100%;background:#FFD600;transition:width .3s"></div></div>';
    document.body.appendChild(loadEl);
    const prog=(n)=>{ const p=document.getElementById('pdf-prog'); if(p) p.style.width=n+'%'; };

    const mods=DB.MODO.filter(m=>c.modules[m]);
    const clientMods=mods.filter(m=>!['client-health','workspace','strategy-pdfs'].includes(m));
    const mv=key=>rep.metrics.find(m=>m.key===key)?.value_number??null;
    const F2=(v,unit)=>{ if(v===null||v===undefined) return '—'; if(unit==='currency_gbp') return '£'+v.toLocaleString(); if(unit==='percentage') return v+'%'; if(v>=1000000) return (v/1000000).toFixed(1)+'M'; if(v>=1000) return (v/1000).toFixed(0)+'k'; return v.toLocaleString(); };

    // Helper: build a chart data table (HTML) from canvas chart data — text always rendered
    const chartTable=(title2,labels,datasets,opts={})=>{
      const isHoriz=opts.horizontal;
      const pctFn=opts.pct; // function to format value
      const fmt=pctFn||(v=>v===null||v===undefined?'—':typeof v==='number'?(v>=1000?(v/1000).toFixed(0)+'k':v.toLocaleString()):'—');
      const showPct=opts.showPct;
      let rows='';
      if(datasets.length===1){
        // Single dataset — one row per label
        rows=labels.map((lbl,i)=>{
          const val=datasets[0].data?.[i];
          return'<tr><td style="padding:5px 8px;border-bottom:1px solid #E2E8F0;font-size:12px">'+lbl+'</td>'
            +'<td style="padding:5px 8px;border-bottom:1px solid #E2E8F0;font-size:12px;font-weight:600;text-align:right">'+fmt(val)+'</td></tr>';
        }).join('');
      } else {
        // Multiple datasets — header row + data rows
        const hdrs=datasets.map(d=>'<th style="padding:5px 8px;background:#00192B;color:#fff;font-size:10px;text-transform:uppercase;letter-spacing:.5px;text-align:right">'+d.label+'</th>').join('');
        rows='<tr><th style="padding:5px 8px;background:#00192B;color:#fff;font-size:10px;text-transform:uppercase;letter-spacing:.5px"></th>'+hdrs+'</tr>'
          +labels.map((lbl,i)=>{
            const cells=datasets.map(d=>'<td style="padding:5px 8px;border-bottom:1px solid #E2E8F0;font-size:12px;font-weight:600;text-align:right">'+fmt(d.data?.[i])+'</td>').join('');
            return'<tr><td style="padding:5px 8px;border-bottom:1px solid #E2E8F0;font-size:12px">'+lbl+'</td>'+cells+'</tr>';
          }).join('');
      }
      return'<div style="margin-top:10px">'
        +(title2?'<div style="font-size:11px;font-weight:700;color:#64748B;text-transform:uppercase;letter-spacing:.6px;margin-bottom:6px">'+title2+'</div>':'')
        +'<table style="width:100%;border-collapse:collapse;font-family:inherit">'+rows+'</table></div>';
    };

    // Helper: donut progress table
    const donutTable=(items)=>{
      // items: [{label,value,max,unit}]
      return'<div style="margin-top:8px;display:flex;flex-direction:column;gap:6px">'+items.map(item=>{
        const pct=item.max>0?Math.min(100,Math.round((item.value/item.max)*100)):null;
        const col=pct===null?'#64748B':pct>=90?'#16A34A':pct>=60?'#D97706':'#E84545';
        return'<div style="display:flex;align-items:center;gap:8px">'
          +'<div style="font-size:11.5px;width:140px;flex-shrink:0;color:#00192B">'+item.label+'</div>'
          +'<div style="flex:1;background:#E2E8F0;border-radius:3px;height:6px;overflow:hidden">'
          +(pct!==null?'<div style="width:'+pct+'%;background:'+col+';height:100%"></div>':'')+'</div>'
          +'<div style="font-size:11.5px;font-weight:700;color:'+col+';min-width:90px;text-align:right">'
          +F2(item.value,item.unit)+(item.max?' / '+F2(item.max,item.unit):'')
          +(pct!==null?' ('+pct+'%)':'')+'</div>'
          +'</div>';
      }).join('')+'</div>';
    };

    prog(15);

    // Build comprehensive section HTML with both chart images AND data tables
    const isGT=S.clientId==='cl-gt';
    const isBlank=rep.metrics.length===0&&rep.assets.length===0&&Object.keys(rep.insights).length===0;

    // KPI summary
    const kpis=rep.metrics.filter(m=>m.is_kpi&&m.value_number!==null);
    const kpiCards=kpis.map(m=>{
      const pct=m.target?Math.round(m.lower?((m.target/m.value_number)*100):((m.value_number/m.target)*100)):null;
      const col=pct===null?'#64748B':pct>=95?'#16A34A':pct>=80?'#D97706':'#E84545';
      return'<div class="pkpi"><div class="pkpi-lbl">'+m.label+'</div>'
        +'<div class="pkpi-val" style="color:'+col+'">'+F.val(m)+'</div>'
        +(m.target?'<div class="pkpi-sub">'+(m.lower?'Target: < ':'Target: ')+F.short(m.target,m.unit)+(pct!==null?' · '+pct+'%':'')+'</div>':'')
        +'</div>';
    }).join('');

    // Per-section chart data tables
    const buildSectionHTML=(mod)=>{
      if(isBlank) return'';
      const ins=rep.insights?.[mod];
      const insHtml=ins?.text?'<div class="pins" style="border-color:'+(ins.tone==='g'?'#16A34A':ins.tone==='a'?'#D97706':'#E84545')+'">'+ins.text+'</div>':'';

      // Build data tables for each chart in this section
      let chartTables='';

      if(mod==='overview'||mod==='kpis'){
        // KPI progression table
        if(kpis.length){
          chartTables+='<div class="psec-chart">'
            +'<div class="pcht-title">KPI Achievement</div>'
            +donutTable(kpis.map(m=>({label:m.label,value:m.value_number,max:m.target,unit:m.unit})))
            +'</div>';
        }
        // Revenue trend table
        const revMons=DB.getMonths(S.clientId,S.year);
        const revVals=revMons.map(m=>DB.getReport(S.clientId,S.year,m)?.metrics.find(x=>x.key==='revenue_cch')?.value_number||0);
        if(revVals.some(v=>v>0)){
          chartTables+=chartTable('Revenue trend ('+S.year+')',revMons,[{label:'Revenue',data:revVals}],{pct:v=>'£'+(v>=1000?(v/1000).toFixed(0)+'k':v.toLocaleString())});
        }
      }

      if(mod==='social'){
        chartTables+=chartTable('Platform engagement',
          ['Facebook','Instagram','TikTok','LinkedIn'],
          [{label:'Engagement',data:[mv('fb_eng'),mv('ig_eng'),mv('tt_eng'),mv('li_eng')]}]);
        chartTables+=chartTable('Social reach',
          ['Facebook','Instagram','TikTok','LinkedIn'],
          [{label:'Impressions/Views',data:[mv('fb_imp'),mv('ig_imp'),mv('tt_views'),mv('li_imp')]}]);
      }

      if(mod==='website'){
        chartTables+=chartTable('Traffic by channel',
          ['Organic','Direct','Email','Referral','Paid'],
          [{label:'Sessions',data:[mv('ch_organic'),mv('ch_direct'),mv('ch_email'),mv('ch_ref'),mv('ch_paid')]}]);
        const webMons=DB.getMonths(S.clientId,S.year);
        const webVals=webMons.map(m=>DB.getReport(S.clientId,S.year,m)?.metrics.find(x=>x.key==='revenue_web')?.value_number||0);
        if(webVals.some(v=>v>0))
          chartTables+=chartTable('Revenue trend',webMons,[{label:'Revenue',data:webVals}],{pct:v=>'£'+(v>=1000?(v/1000).toFixed(0)+'k':v.toLocaleString())});
      }

      if(mod==='paid_advertising'){
        const spendKey=isGT?'meta_spend':'kk_spend';
        const revKey=isGT?'meta_visits':'kk_rev';
        chartTables+=chartTable('Paid advertising performance',
          ['Ad Spend','Revenue / Visits'],
          [{label:S.month,data:[mv(spendKey),mv(revKey)]}],
          {pct:v=>v===null?'—':'£'+v.toLocaleString()});
      }

      if(mod==='email'){
        chartTables+=chartTable('Email performance',
          ['Open Rate','CTR'],
          [{label:'Rate',data:[mv('cch_e_open')||mv('e_open'),mv('cch_e_ctr')||mv('e_ctr')]}],
          {pct:v=>v===null?'—':v+'%'});
      }

      if(mod==='forecast'){
        const fcKpis=kpis.filter(m=>m.target&&m.value_number!==null);
        if(fcKpis.length)
          chartTables+='<div class="psec-chart"><div class="pcht-title">KPI Forecasting</div>'
            +donutTable(fcKpis.map(m=>({label:m.label,value:m.value_number,max:m.target,unit:m.unit})))
            +'</div>';
      }

      // Tasks section
      if(mod==='tasks'){
        const done=rep.tasks?.done||[]; const upcoming=rep.tasks?.upcoming||[];
        return'<div class="ptask-sec">'
          +(done.length?'<div class="ptask-hd">Completed ('+done.length+')</div>'+done.map(t=>'<div class="ptask done">✓ '+t.t+'</div>').join(''):'')
          +(upcoming.length?'<div class="ptask-hd" style="margin-top:10px">Upcoming</div>'+upcoming.map(t=>'<div class="ptask">○ '+t.t+'</div>').join(''):'' )
          +'</div>';
      }

      // Assets section
      if(mod==='creative_assets'){
        const assets=rep.assets||[];
        if(!assets.length) return insHtml;
        return'<div class="passets">'+assets.map(a=>'<div class="passet">'
          +(a.img?'<div class="passet-img"><img src="'+a.img+'" alt="'+a.title+'"></div>':'<div class="passet-ico">'+(a.icon||'🖼')+'</div>')
          +'<div class="passet-info"><b>'+a.title+'</b><div style="color:#64748B">'+( a.brand||'')+'</div>'
          +((a.tags||[]).length?'<div class="passet-tags">'+a.tags.map(t=>'<span>'+t+'</span>').join('')+'</div>':'')
          +'</div></div>').join('')+'</div>'+insHtml;
      }

      // All metrics table for the section
      const sectionMetrics=rep.metrics.filter(m=>m.value_number!==null);
      const metTable=sectionMetrics.length?'<div class="psec-chart"><div class="pcht-title">All metrics</div>'
        +'<table class="ptbl"><thead><tr><th>Metric</th><th>Value</th><th>Target</th><th>Change</th></tr></thead><tbody>'
        +sectionMetrics.map(m=>{
          const pct=m.prev&&m.prev!==m.value_number?Math.round((m.value_number-m.prev)/Math.abs(m.prev)*100):null;
          const chg=pct!==null?'<span style="color:'+( ((m.lower&&pct<0)||(!m.lower&&pct>0))?'#16A34A':'#E84545')+'">'+(pct>0?'↑':'↓')+Math.abs(pct)+'%</span>':'—';
          return'<tr><td>'+m.label+'</td><td><b>'+F.val(m)+'</b></td><td>'+(m.target?(m.lower?'< ':'')+F.short(m.target,m.unit):'—')+'</td><td>'+chg+'</td></tr>';
        }).join('')+'</tbody></table></div>':'';

      return insHtml+chartTables+(mod==='overview'||mod==='kpis'?metTable:'');
    };

    // Build sections HTML
    const sectionsHTML=clientMods.map(mod=>{
      const label=DB.MODL[mod]||mod;
      const content=buildSectionHTML(mod);
      if(!content) return'';
      return'<div class="psec">'+label+'</div><div class="psec-content">'+content+'</div>';
    }).join('');

    prog(60);

    // Logo
    const logoHtml=c.logo?'<img src="'+c.logo+'" style="height:40px;object-fit:contain" alt="'+c.name+'">'
      :'<div style="background:'+c.brand_colour+';color:'+c.brand_text+';display:inline-flex;align-items:center;height:36px;padding:0 12px;border-radius:7px;font-weight:700;font-size:13px">'+c.name+'</div>';

    // Safiro font
    const getSafiroUrl=(weight)=>{ try{ const ss=document.styleSheets[0]; for(const r of ss.cssRules){ if(r.cssText&&r.cssText.includes('Safiro')&&r.cssText.includes(weight)){const m=r.cssText.match(/url\('([^']+)'\)/);if(m)return m[1];} } }catch(e){} return''; };

    const css=`<style>
@font-face{font-family:'Safiro';font-weight:400;src:url('${getSafiroUrl('400')}') format('woff2');}
@font-face{font-family:'Safiro';font-weight:600;src:url('${getSafiroUrl('600')}') format('woff2');}
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Safiro','DM Sans',system-ui,sans-serif;background:#fff;color:#00192B;font-size:13px;line-height:1.6;}
.page{max-width:840px;margin:0 auto;padding:36px 40px 60px;}
.hdr{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:28px;padding-bottom:18px;border-bottom:3px solid #FFD600;}
.rpt-title{font-size:24px;font-weight:600;margin-top:6px;}.rpt-sub{font-size:13px;color:#64748B;margin-top:3px;}
.hdr-r{text-align:right;font-size:11px;color:#94A3B8;}
.psec{font-size:15px;font-weight:600;margin:28px 0 10px;padding-bottom:6px;border-bottom:2px solid #FFD600;color:#00192B;page-break-after:avoid;}
.psec-content{margin-bottom:4px;}
.psec-chart{margin-top:12px;margin-bottom:14px;page-break-inside:avoid;}
.pcht-title{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.7px;color:#64748B;margin-bottom:8px;}
.pkpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(148px,1fr));gap:9px;margin-bottom:16px;}
.pkpi{background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:11px;page-break-inside:avoid;}
.pkpi-lbl{font-size:9px;color:#64748B;text-transform:uppercase;letter-spacing:.6px;font-weight:600;margin-bottom:3px;}
.pkpi-val{font-size:21px;font-weight:700;}.pkpi-sub{font-size:10px;color:#94A3B8;margin-top:2px;}
.pins{background:#F8FAFC;border-left:3px solid #FFD600;border-radius:0 6px 6px 0;padding:9px 13px;margin-bottom:10px;font-size:12.5px;line-height:1.7;}
.ptbl{width:100%;border-collapse:collapse;font-size:11.5px;margin-bottom:4px;}
.ptbl th{background:#00192B;color:#fff;font-size:9.5px;letter-spacing:.6px;text-transform:uppercase;padding:7px 10px;text-align:left;}
.ptbl td{padding:7px 10px;border-bottom:1px solid #E2E8F0;}.ptbl tr:nth-child(even) td{background:#F8FAFC;}
.ptask-sec{margin-bottom:8px;}.ptask-hd{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#64748B;margin:8px 0 4px;}
.ptask{padding:4px 0;border-bottom:1px solid #F1F5F9;font-size:12.5px;}.ptask.done{color:#16A34A;}
.passets{display:grid;grid-template-columns:repeat(auto-fill,minmax(145px,1fr));gap:8px;margin-bottom:8px;}
.passet{border:1px solid #E2E8F0;border-radius:7px;overflow:hidden;page-break-inside:avoid;}
.passet-img{height:80px;}.passet-img img{width:100%;height:100%;object-fit:cover;}
.passet-ico{height:80px;display:flex;align-items:center;justify-content:center;background:#F8FAFC;font-size:26px;}
.passet-info{padding:7px;font-size:11.5px;}.passet-tags{display:flex;flex-wrap:wrap;gap:3px;margin-top:4px;}
.passet-tags span{font-size:9px;background:#E2E8F0;border-radius:3px;padding:1px 5px;color:#64748B;}
.pftr{margin-top:40px;padding-top:12px;border-top:1px solid #E2E8F0;display:flex;justify-content:space-between;font-size:10.5px;color:#94A3B8;}
img{max-width:100%;height:auto;display:block;}
@media print{.no-print{display:none!important;}@page{margin:14mm;size:A4;}h1,h2,h3{page-break-after:avoid;}.psec-chart{page-break-inside:avoid;}}
</style>`;

    prog(85);

    const win=window.open('','_blank');
    if(!win){ document.body.removeChild(loadEl); return; }
    win.document.write('<!DOCTYPE html><html><head><meta charset="utf-8"><title>'+title+'</title>'+css+'</head><body>'
      +'<button class="no-print" onclick="window.print()" style="position:fixed;top:14px;right:14px;padding:8px 16px;background:#FFD600;border:none;border-radius:6px;font-weight:700;cursor:pointer;font-size:12.5px;z-index:999;color:#00192B;box-shadow:0 2px 8px rgba(0,0,0,.15)">🖨 Print / Save PDF</button>'
      +'<div class="page">'
      +'<div class="hdr"><div>'+logoHtml+'<div class="rpt-title">'+(DB.ML[S.month]||S.month)+' '+S.year+' Report</div>'
      +'<div class="rpt-sub">Prepared for '+c.name+' by Karbon Creative · Confidential</div></div>'
      +'<div class="hdr-r"><div>Published: '+(F.date(rep.published_at)||'Draft')+'</div></div></div>'
      +(kpis.length?'<div class="psec">Key Performance Indicators</div><div class="pkpis">'+kpiCards+'</div>':'')
      +sectionsHTML
      +'<div class="pftr"><span>Karbon Creative · <strong>karboncreative.co.uk</strong></span><span>'+title+' · Confidential</span></div>'
      +'</div></body></html>');
        win.document.close();
    prog(100);
    setTimeout(()=>document.body.removeChild(loadEl),400);
    INTEL.record('PDF exported',title);
  },
  removeVideo(){
    DB.setVideo(S.clientId,S.year,S.month,null);
    this.render();
  },

  _savedRecordingUrl:null,
  saveRecording(){
    const saveUrl=this._savedRecordingUrl||null;
    if(!saveUrl){ alert('No recording found.'); return; }
    DB.setVideo(S.clientId,S.year,S.month,saveUrl);
    this._savedRecordingUrl=null;
    this.render();
  },
  discardRecording(){
    if(this._savedRecordingUrl) URL.revokeObjectURL(this._savedRecordingUrl);
    this._savedRecordingUrl=null;
    this._mediaRecorder=null; this._chunks=[];
    this.render();
  },
  uploadVideo(input){
    const f=input.files[0]; if(!f) return;
    const r=new FileReader();
    r.onload=e=>{ DB.setVideo(S.clientId,S.year,S.month,e.target.result); this.render(); };
    r.readAsDataURL(f);
    input.value='';
  },

  _mediaStream:null, _mediaRecorder:null, _chunks:[],
  async toggleRecord(){
    const btn=document.getElementById('vid-rec');
    if(this._mediaRecorder&&this._mediaRecorder.state==='recording'){
      this._mediaRecorder.stop();
      btn.classList.remove('recording'); btn.textContent='⏺ Record';
      const lv=document.getElementById('vid-live-preview');
      if(lv) lv.style.display='none';
      return;
    }
    try{
      const stream=await navigator.mediaDevices.getUserMedia({video:true,audio:true});
      this._mediaStream=stream; this._chunks=[];
      // Show live preview
      let lv=document.getElementById('vid-live-preview');
      if(!lv){
        lv=document.createElement('video');
        lv.id='vid-live-preview';
        lv.style.cssText='width:100%;max-width:280px;border-radius:8px;background:#000;display:block;margin-top:8px;border:2px solid var(--r)';
        lv.muted=true; lv.autoplay=true; lv.playsInline=true;
        const container=btn.closest('[id^="vid-area"],.vid-upload,.vid-block')||btn.parentElement;
        container.appendChild(lv);
      }
      lv.srcObject=stream; lv.style.display='block';
      // Recording status indicator
      let status=document.getElementById('vid-rec-status');
      if(!status){
        status=document.createElement('div');
        status.id='vid-rec-status';
        status.style.cssText='font-size:11px;color:var(--r);font-weight:600;margin-top:4px;animation:pulse 1s infinite';
        btn.parentElement.appendChild(status);
      }
      status.textContent='● Recording in progress…';
      this._mediaRecorder=new MediaRecorder(stream);
      this._mediaRecorder.ondataavailable=e=>{if(e.data.size>0)this._chunks.push(e.data);};
      this._mediaRecorder.onstop=()=>{
        const blob=new Blob(this._chunks,{type:'video/webm'});
        const url=URL.createObjectURL(blob);
        this._savedRecordingUrl=url;
        // Show live preview with the recording
        if(lv){lv.srcObject=null;lv.src=url;lv.controls=true;lv.style.border='2px solid var(--g)';}
        stream.getTracks().forEach(t=>t.stop());
        // Show save/discard buttons — use data-action to avoid blob URL in onclick
        if(status){
          status.innerHTML='Recording complete — preview above.';
          const btnWrap=document.createElement('div');
          btnWrap.style.cssText='display:flex;gap:6px;margin-top:6px';
          const saveBtn=document.createElement('button');
          saveBtn.className='btn btn-y btn-sm';
          saveBtn.textContent='Save to report';
          saveBtn.onclick=()=>REPORT.saveRecording();
          const discBtn=document.createElement('button');
          discBtn.className='btn btn-r btn-sm';
          discBtn.textContent='Discard';
          discBtn.onclick=()=>REPORT.discardRecording();
          btnWrap.appendChild(saveBtn); btnWrap.appendChild(discBtn);
          status.parentElement?.appendChild(btnWrap);
        }
      };
      this._mediaRecorder.start();
      btn.classList.add('recording'); btn.textContent='⏹ Stop';
    }catch(e){ alert('Camera/mic access required for recording.'); }
  },

  switchTab(mod,btn){
    S.activeTab=mod;
    document.querySelectorAll('.rs').forEach(s=>s.classList.remove('on'));
    document.querySelectorAll('.rtab').forEach(b=>b.classList.remove('on'));
    document.getElementById('rs-'+mod)?.classList.add('on');
    if(btn) btn.classList.add('on');
    const rep=DB.getReport(S.clientId,S.year,S.month);
    const c=DB.getClient(S.clientId);
    if(rep&&c) setTimeout(()=>{
      // Force canvas dimensions so Chart.js can render in previously-hidden sections
      const sec=document.getElementById('rs-'+mod);
      if(sec) sec.querySelectorAll('canvas').forEach(cv=>{
        if(!cv.offsetWidth){ cv.style.width='100%'; cv.style.height=cv.parentElement?.style.height||'200px'; }
        const pw=cv.parentElement?.offsetWidth||cv.parentElement?.getBoundingClientRect().width||600;
        if(pw>10){ cv.width=Math.round(pw); cv.height=parseInt(cv.parentElement?.style.height||'200',10)||200; }
      });
      this._charts(rep,c);
    },80);
  },

  /* KPI CARD with inline edit + source link */
  _kpi(key,label,val,unit,o={}){
    const target=o.target, prev=o.prev, lower=o.lower;
    const h=target&&val!==null?DB.kpiHealth(S.clientId,{target,value_number:val,lower:!!lower},S.month):null;
    const hcls=h==='ahead'?'g':h==='track'?'a':h==='attn'?'r':'g';
    const hhtml=h?`<span class="khealth ${h==='ahead'?'kh-a':h==='track'?'kh-t':'kh-r'}">${h==='ahead'?'● Ahead':h==='track'?'● On Track':'● Needs Attention'}</span>`:'';
    let delta='';
    if(prev!==null&&prev!==undefined&&val!==null&&typeof val==='number'){
      const d=F.pct(val,prev);
      if(d!==null){ const good=lower?d<0:d>0; delta=`<div class="cdelta"><span class="dprev">Prev: ${F.short(prev,unit)}</span><span class="dchg ${good?'dp':'dn'}">${d>0?'↑':'↓'}${Math.abs(d)}%</span></div>`; }
    }
    const fv=val===null?'—':unit==='currency_gbp'?(val>=1e6?`£${(val/1e6).toFixed(2)}M`:val>=1000?`£${(val/1000).toFixed(0)}k`:`£${val.toLocaleString()}`):unit==='percentage'?`${val}%`:unit==='count'?(val>=1e6?`${(val/1e6).toFixed(1)}M`:val>=1000?`${(val/1000).toFixed(0)}k`:val.toLocaleString()):String(val);
    // Edit overlay — admin only, inline
    const editOverlay=`<div class="kpi-edit-overlay" id="kei-${key}">
      <input class="kei" id="kei-v-${key}" type="number" value="${val||0}" placeholder="Enter value">
      <div><button class="kesave" onclick="REPORT.saveKpiEdit('${key}','${unit}')">Save</button><button class="kecancel" onclick="document.getElementById('kei-${key}').style.display='none'">✕</button></div>
    </div>`;
    // Edit button visible on hover (CSS handles it)
    return`<div class="kpi ${hcls}" onclick="if(document.body.classList.contains('is-admin'))MODAL.editKpi('${key}','${label}',${val||0},'${unit}',${target||0},${prev||0},!!${lower},!!'${o.kpi}')">
      <div class="klbl">${label}</div>
      <div class="kval">${fv}</div>
      ${target?`<div class="ksub">${lower?'< ':''}${F.short(target,unit)}</div>`:''}
      ${hhtml}${delta}
    </div>`;
  },

  saveKpiEdit(key,unit){
    const v=parseFloat(document.getElementById('kei-v-'+key)?.value||0);
    DB.setMetric(S.clientId,S.year,S.month,key,v);
    this.render();
  },

  /* INSIGHT */
  _ins(section,rep,c){
    const ins=rep.insights[section]||{text:'',tone:'g'};
    const sid=`ins-${S.clientId}-${S.year}-${S.month}-${section}`;
    return`<div class="ins ${ins.tone}" id="${sid}">
      <button class="ins-edit-btn" onclick="REPORT.editIns('${sid}','${S.clientId}',${S.year},'${S.month}','${section}')">✎ Edit</button>
      <p id="${sid}-t">${ins.text}</p>
      <div class="ins-form" id="${sid}-f">
        <textarea class="ins-ta" id="${sid}-ta" rows="4">${ins.text}</textarea>
        <div class="ins-row">
          <select style="background:var(--inp);border:1px solid var(--inpb);border-radius:var(--rs);padding:4px 8px;font-size:11.5px;color:var(--t0)" id="${sid}-tone">
            <option value="g" ${ins.tone==='g'?'selected':''}>Positive</option>
            <option value="a" ${ins.tone==='a'?'selected':''}>Neutral/Amber</option>
            <option value="w" ${ins.tone==='w'?'selected':''}>Warning</option>
          </select>
          <button class="btn btn-y btn-sm" onclick="REPORT.saveIns('${sid}','${S.clientId}',${S.year},'${S.month}','${section}')">Save</button>
          <button class="btn btn-g btn-sm" onclick="REPORT.cancelIns('${sid}')">Cancel</button>
        </div>
      </div>
    </div>`;
  },
  editIns(sid){ document.getElementById(sid+'-t').style.display='none'; document.getElementById(sid+'-f').style.display='block'; document.querySelector(`#${sid} .ins-edit-btn`).style.display='none'; },
  saveIns(sid,cid,yr,mon,sec){ const txt=document.getElementById(sid+'-ta').value; const tone=document.getElementById(sid+'-tone').value; DB.setInsight(cid,+yr,mon,sec,txt,tone); document.getElementById(sid+'-t').textContent=txt; document.getElementById(sid).className=`ins ${tone}`; this.cancelIns(sid); },
  cancelIns(sid){ document.getElementById(sid+'-t').style.display=''; document.getElementById(sid+'-f').style.display='none'; const b=document.querySelector(`#${sid} .ins-edit-btn`); if(b) b.style.display=''; },

  saveMblk(keys,mid){ keys.forEach(k=>{ const el=document.getElementById(mid+'-'+k); if(el&&el.value) DB.setMetric(S.clientId,S.year,S.month,k,parseFloat(el.value)); }); const ok=document.getElementById(mid+'-ok'); if(ok){ok.style.display='block';setTimeout(()=>ok.style.display='none',2000);} this.render(); },

  /* CHILD ACCOUNT CARDS — shown in parent overview */
  _childCards(){
    const ch=DB.getChildren(S.clientId);
    if(!ch.length) return '';
    const cards=ch.map(child=>{
      const yrs=DB.getYears(child.id);
      const yr=yrs[yrs.length-1]||S.year;
      const mons=DB.getMonths(child.id,yr);
      const mon=mons[mons.length-1]||S.month;
      const r=DB.getReport(child.id,yr,mon);
      const mv=k=>r?.metrics.find(m=>m.key===k)?.value_number||0;
      const logoEl=child.logo
        ? '<img src="'+child.logo+'" style="width:100%;height:100%;object-fit:contain;border-radius:4px">'
        : '<span style="font-size:10px;font-weight:700;color:'+child.brand_text+'">'+child.initials+'</span>';
      return `<div style="background:var(--bg2);border:1px solid var(--bd0);border-radius:var(--rs);padding:13px;cursor:pointer;transition:border-color .15s" onclick="NAV.openReport('${child.id}')" onmouseenter="this.style.borderColor='var(--y)'" onmouseleave="this.style.borderColor='var(--bd0)'">
        <div style="display:flex;align-items:center;gap:9px;margin-bottom:10px">
          <div style="width:30px;height:30px;border-radius:7px;background:${child.brand_colour};display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden">${logoEl}</div>
          <div>
            <div style="font-size:13px;font-weight:600">${child.name}</div>
            <div style="font-size:10.5px;color:var(--t1)">${mon} ${yr}</div>
          </div>
        </div>
        ${r ? `<div style="font-size:11.5px;color:var(--g)">✓ Report available</div>` : '<div style="font-size:11.5px;color:var(--t2)">No report yet</div>'}
        <div style="font-size:11px;color:var(--o);margin-top:6px;font-weight:500">View full report →</div>
      </div>`;
    }).join('');
    return `<div class="card" style="margin-bottom:14px">
      <div class="card-hd"><div><div class="ctitle">Account overview</div><div class="csub">Your Blendini Motorsport accounts</div></div></div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px">${cards}</div>
    </div>`;
  },

  /* ADD BLOCK BUTTON */
  _addBlkBtn(section){
    return`<div id="blk-wrap-${section}" class="blk-wrap" style="margin-bottom:14px" 
      ondragover="event.preventDefault()" 
      ondrop="BUILDER.onDropZone(event,'${section}')" ondragover="event.preventDefault();this.classList.add('dragover')" ondragleave="this.classList.remove('dragover')"></div>
    <div class="add-block-row" onclick="BUILDER.openPicker('${section}')"><span style="font-size:12.5px;color:var(--t1)">+ Add block to this section</span></div>`;
  },

  /* BLANK REPORT — empty state with builder prompt */
  saveModule(){
    const name=document.getElementById('am-name')?.value?.trim(); if(!name) return;
    const type=document.getElementById('am-type')?.value||'custom';
    const icon=document.getElementById('am-icon')?.value||'';
    // Create a unique key for this module
    const key='custom_'+Date.now();
    // Add to client's modules
    const c=DB.getClient(S.clientId); if(!c) return;
    c.modules[key]=true;
    // Add to MODL/MODO dynamically
    DB.MODL[key]=icon+' '+name;
    if(!DB.MODO.includes(key)) DB.MODO.push(key);
    INTEL.record('Module added',name+' ('+key+')');
    MODAL.close('modal-add-module');
    // Re-render the tabs
    this.render();
  },
  _sectionBlank(mod){
    const labels={overview:'Overview',kpis:'KPIs',social:'Social Media',paid_advertising:'Paid Advertising',website:'Website',email:'Email Marketing',creative_assets:'Creative Assets',tasks:'Tasks',forecast:'Forecasting'};
    const icons={overview:'📊',kpis:'🎯',social:'📱',paid_advertising:'💰',website:'🌐',email:'✉️',creative_assets:'🖼',tasks:'✓',forecast:'📈'};
    return`<div style="padding:48px 0;text-align:center;max-width:480px;margin:0 auto">
      <div style="font-size:44px;margin-bottom:16px;opacity:.35">${icons[mod]||''}</div>
      <div style="font-size:20px;font-weight:700;color:var(--t0);margin-bottom:8px">${labels[mod]||mod} — Empty</div>
      <div style="font-size:13.5px;color:var(--t1);line-height:1.7;margin-bottom:24px">This is a blank report. Use the block builder below to add content — KPI cards, charts, insights, tables, and more.</div>
      ${S.user?.role==='admin'?`<button class="btn btn-y" onclick="BUILDER.openPicker('${mod}')">+ Add first block</button>
      <div style="margin-top:12px"><button class="btn btn-g btn-sm" onclick="MODAL.addReport(S.clientId)" style="font-size:11.5px">Or copy from another report</button></div>`:'<div style="font-size:12px;color:var(--t2)">No content available for this section yet.</div>'}
    </div>
    ${S.user?.role==='admin'?this._addBlkBtn(mod):''}`;
  },

  /* SECTIONS — BLENDINI */
  _sectionTD(mod,rep,c){
    const mv=k=>rep.metrics.find(m=>m.key===k)?.value_number??null;
    const mp=k=>rep.metrics.find(m=>m.key===k)?.prev??null;
    const fmt=(v,p)=>v===null?'—':p==='currency_gbp'?'£'+(v>=1000?(v/1000).toFixed(1)+'k':v.toLocaleString(undefined,{minimumFractionDigits:0,maximumFractionDigits:2})):p==='percentage'?v+'%':v>=1000?(v/1000).toFixed(0)+'k':v.toLocaleString();
    const chg=(v,p)=>{if(v===null||p===null)return'';const d=((v-p)/p*100);return(d>=0?'+':'')+d.toFixed(1)+'%';};
    if(mod==='overview') return`
      <div class="seye">Summary</div><div class="stitle">${DB.ML[S.month]} at a glance</div>
      <div id="vid-area" style="margin-bottom:${rep.video?'16px':'0'};max-width:${rep.video?'480px':'auto'}"></div>
      <div class="gauto">
        ${this._kpi('td_shop_rev','Shop Revenue',mv('td_shop_rev'),'currency_gbp',{target:10000,prev:mp('td_shop_rev')})}
        ${this._kpi('td_shop_orders','Shop Orders',mv('td_shop_orders'),'count',{target:100,prev:mp('td_shop_orders')})}
        ${this._kpi('td_decals_rev','Decals Revenue',mv('td_decals_rev'),'currency_gbp',{prev:mp('td_decals_rev')})}
        ${this._kpi('td_hs_contacts','New HubSpot Contacts',mv('td_hs_contacts'),'count',{target:2000,prev:mp('td_hs_contacts')})}
        ${this._kpi('td_hs_mkt','Marketing Contacts',mv('td_hs_mkt'),'count',{target:2000,prev:mp('td_hs_mkt')})}
        ${this._kpi('td_studio_spend','Studios Ad Spend',mv('td_studio_spend'),'currency_gbp',{lower:1,prev:mp('td_studio_spend')})}
      </div>
      <div class="g2">
        <div class="card"><div class="card-hd"><div><div class="ctitle">Revenue breakdown</div></div></div><div class="ch" style="height:200px"><canvas id="c-pie"></canvas></div></div>
        <div>${this._ins('overview',rep,c)}</div>
      </div>
      ${this._addBlkBtn(mod)}`;
    if(mod==='kpis') return`
      <div class="seye">KPI Tracking</div><div class="stitle">Monthly performance</div>
      <div class="gauto">
        ${this._kpi('td_shop_rev','Shop Revenue',mv('td_shop_rev'),'currency_gbp',{target:10000,prev:mp('td_shop_rev')})}
        ${this._kpi('td_shop_orders','Shop Orders',mv('td_shop_orders'),'count',{target:100,prev:mp('td_shop_orders')})}
        ${this._kpi('td_ig_fol','Instagram Followers',mv('td_ig_fol'),'count',{target:350000,prev:mp('td_ig_fol')})}
        ${this._kpi('td_yt_subs','YouTube Subscribers',mv('td_yt_subs'),'count',{target:250000,prev:mp('td_yt_subs')})}
        ${this._kpi('td_hs_contacts','New HubSpot Contacts',mv('td_hs_contacts'),'count',{target:2000,prev:mp('td_hs_contacts')})}
        ${this._kpi('td_web_users_s','Studio Website Users',mv('td_web_users_s'),'count',{target:12000,prev:mp('td_web_users_s')})}
      </div>
      <div class="g2">
        <div class="card"><div class="card-hd"><div><div class="ctitle">KPI progress vs targets</div></div></div><div class="ch" style="height:230px"><canvas id="c-kpi-rev"></canvas></div></div>
        <div>
          <div class="card"><div class="card-hd"><div><div class="ctitle">Instagram followers vs target</div></div></div><div class="ch" style="height:96px"><canvas id="c-kpi-soc"></canvas></div></div>
          <div class="card"><div class="card-hd"><div><div class="ctitle">YouTube subscribers vs target</div></div></div><div class="ch" style="height:96px"><canvas id="c-kpi-rat"></canvas></div></div>
        </div>
      </div>
      ${this._ins('kpis',rep,c)}
      ${this._addBlkBtn(mod)}`;
    if(mod==='social') return`
      <div class="seye">Social Media</div><div class="stitle">Platform analysis — all Topaz accounts</div>
      <div class="platg">
        ${this._platCard('Instagram','#E1306C',mv('td_ig_fol'),null,mv('td_ig_views'),mp('td_ig_fol'),null,mp('td_ig_views'),null,null,'All Topaz accounts combined.')}
        ${this._platCard('YouTube','#FF0000',mv('td_yt_subs'),null,mv('td_yt_views'),mp('td_yt_subs'),null,mp('td_yt_views'),null,null,mv('td_yt_watch')!==null?fmt(mv('td_yt_watch'),'count')+' watch hours this month':'')}
        ${this._platCard('Facebook','#1877F2',mv('td_fb_fol'),null,null,mp('td_fb_fol'),null,null,null,null,'All Topaz accounts combined.')}
        ${this._platCard('LinkedIn','#0A66C2',mv('td_li_fol'),mv('td_li_eng'),null,mp('td_li_fol'),mp('td_li_eng'),null,null,null,'All Topaz accounts combined.')}
      </div>
      <div class="card"><div class="card-hd"><div><div class="ctitle">Followers growth this month</div></div></div><div class="ch" style="height:200px"><canvas id="c-followers"></canvas></div></div>
      <div class="card"><div class="card-hd"><div><div class="ctitle">Views comparison</div></div></div><div class="ch" style="height:200px"><canvas id="c-soc-eng"></canvas></div></div>
      ${this._ins('social',rep,c)}
      ${this._addBlkBtn(mod)}`;
    if(mod==='paid_advertising') return`
      <div class="seye">Performance Marketing</div><div class="stitle">Studios &amp; Shop campaigns</div>
      <div class="g2">
        <div>
          <span class="apill o">Studios Advertising</span>
          <div class="gauto">
            ${this._kpi('td_studio_spend2','Ad Spend',mv('td_studio_spend2'),'currency_gbp',{lower:1,prev:mp('td_studio_spend2')})}
            ${this._kpi('td_paid_enq','Paid Social Enquiries',mv('td_paid_social_enq'),'count',{prev:mp('td_paid_social_enq')})}
            ${this._kpi('td_web_enq','Website Enquiries',mv('td_web_enq'),'count',{prev:mp('td_web_enq')})}
            ${this._kpi('td_phone_enq','Phone Enquiries',mv('td_phone_enq'),'count',{prev:mp('td_phone_enq')})}
          </div>
        </div>
        <div>
          <span class="apill o">Shop Advertising</span>
          <div class="gauto">
            ${this._kpi('td_shop_spend2','Ad Spend',mv('td_shop_spend2'),'currency_gbp',{lower:1,prev:mp('td_shop_spend2')})}
          </div>
        </div>
      </div>
      <div class="card"><div class="card-hd"><div><div class="ctitle">Ad spend vs enquiries</div></div></div><div class="ch" style="height:220px"><canvas id="c-paid-kk"></canvas></div></div>
      ${this._ins('paid_advertising',rep,c)}
      ${this._addBlkBtn(mod)}`;
    if(mod==='website') return`
      <div class="seye">Website</div><div class="stitle">Studio &amp; Shop performance</div>
      <div class="g2">
        <div>
          <span class="apill o">Studio Website</span>
          <div class="gauto">
            ${this._kpi('td_web_users_s','Users',mv('td_web_users_s'),'count',{target:12000,prev:mp('td_web_users_s')})}
            ${this._kpi('td_web_sess_s','Sessions',mv('td_web_sess_s'),'count',{prev:mp('td_web_sess_s')})}
            ${this._kpi('td_web_cvr_s','Conversion Rate',mv('td_web_cvr_s'),'percentage',{prev:mp('td_web_cvr_s')})}
          </div>
        </div>
        <div>
          <span class="apill o">Shop Website</span>
          <div class="gauto">
            ${this._kpi('td_web_users_sh','Users',mv('td_web_users_sh'),'count',{prev:mp('td_web_users_sh')})}
            ${this._kpi('td_web_sess_sh','Sessions',mv('td_web_sess_sh'),'count',{prev:mp('td_web_sess_sh')})}
            ${this._kpi('td_web_cvr_sh','Conversion Rate',mv('td_web_cvr_sh'),'percentage',{prev:mp('td_web_cvr_sh')})}
          </div>
        </div>
      </div>
      <div class="card"><div class="card-hd"><div><div class="ctitle">Studio vs Shop — users &amp; sessions</div></div></div><div class="ch" style="height:220px"><canvas id="c-web-chan"></canvas></div></div>
      ${this._ins('website',rep,c)}
      ${this._addBlkBtn(mod)}`;
    if(mod==='email') return`
      <div class="seye">Email Marketing</div><div class="stitle">Campaign performance</div>
      <div class="gauto">
        ${this._kpi('td_email_sent','Emails Sent',mv('td_email_sent'),'count',{prev:mp('td_email_sent')})}
        ${this._kpi('td_email_open','Open Rate',mv('td_email_open'),'percentage',{prev:mp('td_email_open')})}
        ${this._kpi('td_email_ctr','CTR',mv('td_email_ctr'),'percentage',{prev:mp('td_email_ctr')})}
      </div>
      <div class="card"><div class="card-hd"><div><div class="ctitle">Email performance metrics</div></div></div><div class="ch" style="height:200px"><canvas id="c-email-met"></canvas></div></div>
      ${this._ins('email',rep,c)}
      ${this._addBlkBtn(mod)}`;
    return'';
  },

  _sectionBL(mod,rep,c){
    const mv=k=>rep.metrics.find(m=>m.key===k)?.value_number??null;
    const mt=k=>rep.metrics.find(m=>m.key===k)?.value_text??null;
    const mp=k=>rep.metrics.find(m=>m.key===k)?.prev??null;
    if(mod==='overview') return`
      <div class="seye">Summary</div><div class="stitle">${DB.ML[S.month]} at a glance</div>
      ${DB.getChildren(S.clientId).length ? `<div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap">
        ${DB.getChildren(S.clientId).map(ch=>`<button class="mbtn" style="display:flex;align-items:center;gap:7px;padding:6px 13px" onclick="NAV.openReport('${ch.id}')">
          ${ch.logo?`<img src="${ch.logo}" style="width:18px;height:18px;object-fit:contain;border-radius:3px">`:`<div style="width:18px;height:18px;border-radius:4px;background:${ch.brand_colour};display:inline-flex;align-items:center;justify-content:center;font-size:8px;font-weight:700;color:${ch.brand_text}">${ch.initials}</div>`}
          ${ch.name} report →
        </button>`).join('')}
      </div>` : ''}
      ${this._childCards()}
            <div class="gauto">
        ${this._kpi('revenue_cch','CCH + UD Revenue',mv('revenue_cch'),'currency_gbp',{target:2292678,prev:mp('revenue_cch')})}
        ${this._kpi('conversion_rate','CCH Conversion Rate',mv('conversion_rate'),'percentage',{prev:mp('conversion_rate')})}
        ${this._kpi('revenue_kk_ytd','KK Revenue (YTD)',mv('revenue_kk_ytd'),'currency_gbp',{target:630000,prev:mp('revenue_kk_ytd')})}
        ${this._kpi('review_rating','Avg Review Rating',mv('review_rating'),'number',{target:4.2,prev:mp('review_rating')})}
        ${this._kpi('unsubscribes','Monthly Unsubscribes',mv('unsubscribes'),'count',{target:5600,prev:mp('unsubscribes'),lower:true})}
        ${this._kpi('social_views','Social Views (Group)',mv('social_views'),'count',{target:7500000,prev:mp('social_views')})}
      </div>
      <div class="g2">
        <div class="card"><div class="card-hd"><div><div class="ctitle">Services breakdown</div></div></div><div class="ch" style="height:200px"><canvas id="c-pie"></canvas></div></div>
        <div>${this._ins('overview',rep,c)}</div>
      </div>
      ${this._addBlkBtn(mod)}`;

    if(mod==='kpis') return`
      <div class="seye">Annual Tracking</div><div class="stitle">2026 KPIs</div>
      <p style="font-size:12.5px;color:var(--t1);margin-bottom:16px">Targets not yet formally agreed. Health based on expected pace through the reporting year — click any card to edit.</p>
      <div class="gauto">
        ${this._kpi('revenue_cch','CCH + UD Revenue',mv('revenue_cch'),'currency_gbp',{kpi:true,target:2292678,prev:mp('revenue_cch')})}
        ${this._kpi('revenue_kk_ytd','KK Revenue YTD',mv('revenue_kk_ytd'),'currency_gbp',{kpi:true,target:630000,prev:mp('revenue_kk_ytd')})}
        ${this._kpi('conversion_rate','CCH Conversion Rate',mv('conversion_rate'),'percentage',{prev:mp('conversion_rate')})}
        ${this._kpi('review_rating','Avg Review Rating',mv('review_rating'),'number',{kpi:true,target:4.2,prev:mp('review_rating')})}
        ${this._kpi('unsubscribes','Monthly Unsubscribes',mv('unsubscribes'),'count',{kpi:true,target:5600,prev:mp('unsubscribes'),lower:true})}
        ${this._kpi('social_views','Social Views',mv('social_views'),'count',{kpi:true,target:7500000,prev:mp('social_views')})}
        ${this._kpi('web_users','Website Users',mv('web_users'),'count',{prev:mp('web_users')})}
        ${this._kpi('cch_e_open','CCH Email Open Rate',mv('cch_e_open'),'percentage',{prev:mp('cch_e_open')})}
      </div>
      <div class="g2">
        <div class="card"><div class="card-hd"><div><div class="ctitle">Revenue vs targets</div></div></div><div class="ch" style="height:230px"><canvas id="c-kpi-rev"></canvas></div></div>
        <div>
          <div class="card"><div class="card-hd"><div><div class="ctitle">Social views progress</div></div></div><div class="ch" style="height:96px"><canvas id="c-kpi-soc"></canvas></div></div>
          <div class="card"><div class="card-hd"><div><div class="ctitle">Review rating progress</div></div></div><div class="ch" style="height:96px"><canvas id="c-kpi-rat"></canvas></div></div>
        </div>
      </div>
      <div class="card"><div class="card-hd"><div><div class="ctitle">Revenue trend — all months</div></div></div><div class="ch" style="height:180px"><canvas id="c-kpi-trend"></canvas></div></div>
      ${this._ins('kpis',rep,c)}
      ${this._addBlkBtn(mod)}`;

    if(mod==='social') return`
      <div class="seye">Social Media</div><div class="stitle">Platform analysis</div>
      <div class="card"><div class="card-hd"><div><div class="ctitle">Follower growth trend</div></div></div><div class="ch" style="height:170px"><canvas id="c-followers"></canvas></div></div>
      <div class="platg">
        ${this._platCard('Facebook','#1877F2',mv('fb_followers'),mv('fb_eng'),mv('fb_imp'),mp('fb_followers'),mp('fb_eng'),mp('fb_imp'),'fb_rate',mv('fb_rate'),'Vehicle-led visuals and track moments consistently outperform.')}
        ${this._platCard('Instagram','#E1306C',mv('ig_followers'),mv('ig_eng'),mv('ig_imp'),mp('ig_followers'),mp('ig_eng'),mp('ig_imp'),null,null,'Reels outperforming static. On-track driver moments convert best.')}
        ${this._platCard('TikTok','#FF0050',mv('tt_followers'),mv('tt_eng'),mv('tt_views'),mp('tt_followers'),mp('tt_eng'),mp('tt_views'),null,null,'Teams now aligned on content direction.')}
        ${this._platCard('LinkedIn','#0A66C2',mv('li_followers'),mv('li_eng'),mv('li_imp'),mp('li_followers'),mp('li_eng'),mp('li_imp'),null,null,'Human-led and event-focused content resonates most.')}
      </div>
      <div class="card"><div class="card-hd"><div><div class="ctitle">Engagements by platform</div></div></div><div class="ch" style="height:190px"><canvas id="c-soc-eng"></canvas></div></div>
      ${this._ins('social',rep,c)}
      ${this._addBlkBtn(mod)}`;

    if(mod==='paid_advertising') return`
      <div class="seye">Performance Marketing</div><div class="stitle">Paid advertising</div>
      <div class="g2">
        <div>
          <span class="apill">Car Chase Heroes — Meta</span>
          <div class="gauto">
            ${this._kpi('cch_spend','Ad Spend',mv('cch_spend'),'currency_gbp',{prev:mp('cch_spend')})}
            ${this._kpi('cch_fol','Gained Followers',mv('cch_fol'),'count',{prev:mp('cch_fol')})}
            ${this._kpi('cch_cpe','Cost/Engagement',mv('cch_cpe'),'currency_gbp',{prev:mp('cch_cpe'),lower:true})}
            ${this._kpi('cch_imp','Impressions',mv('cch_imp'),'count',{prev:mp('cch_imp')})}
          </div>
          <div class="ins g"><p>Focus on boosting high-performing organic content. Evergreen awareness and local event ads.</p></div>
        </div>
        <div>
          <span class="apill o">Kart Kingdom — PPC</span>
          <div class="gauto">
            ${this._kpi('kk_spend','Ad Spend',mv('kk_spend'),'currency_gbp',{prev:mp('kk_spend')})}
            ${this._kpi('kk_conv','Conversions',mv('kk_conv'),'count',{prev:mp('kk_conv')})}
            ${this._kpi('kk_rev','Revenue',mv('kk_rev'),'currency_gbp',{prev:mp('kk_rev')})}
            ${this._kpi('kk_cpc','Cost/Conversion',mv('kk_cpc'),'currency_gbp',{prev:mp('kk_cpc'),lower:true})}
          </div>
          <div class="ins g"><p>Performance Max leading. Strong intent-driven traffic from high-converting search terms.</p></div>
        </div>
      </div>
      <div class="g2">
        <div class="card"><div class="card-hd"><div><div class="ctitle">KK PPC — Spend vs Revenue</div></div></div><div class="ch" style="height:195px"><canvas id="c-paid-kk"></canvas></div></div>
        <div class="card"><div class="card-hd"><div><div class="ctitle">CCH Meta — Impressions &amp; Followers</div></div></div><div class="ch" style="height:195px"><canvas id="c-paid-cch"></canvas></div></div>
      </div>
      ${this._ins('paid_advertising',rep,c)}
      ${this._addBlkBtn(mod)}`;

    if(mod==='website') return`
      <div class="seye">Website</div><div class="stitle">Traffic &amp; conversions</div>
      <div class="gauto">
        ${this._kpi('web_users','Total Users',mv('web_users'),'count',{prev:mp('web_users')})}
        ${this._kpi('web_sessions','Sessions',mv('web_sessions'),'count',{prev:mp('web_sessions')})}
        ${this._kpi('web_bounce','Bounce Rate',mv('web_bounce'),'percentage',{prev:mp('web_bounce'),lower:true})}
        <div class="kpi g"><div class="klbl">Avg Session Duration</div><div class="kval">${mt('web_dur')||'—'}</div></div>
      </div>
      <div class="g2">
        <div class="card"><div class="card-hd"><div><div class="ctitle">Traffic by channel</div></div></div><div class="ch" style="height:220px"><canvas id="c-web-chan"></canvas></div></div>
        <div class="card"><div class="card-hd"><div><div class="ctitle">Top pages by users</div></div></div><div class="ch" style="height:220px"><canvas id="c-web-pages"></canvas></div></div>
      </div>
      <div class="card">
        <div class="card-hd"><div><div class="ctitle">Special offers &amp; vouchers</div></div></div>
        <div class="gauto" style="margin-bottom:0">
          ${this._kpi('v_sold','Vouchers Sold',mv('v_sold'),'count',{prev:mp('v_sold')})}
          ${this._kpi('v_rev','Vouchers Revenue',mv('v_rev'),'currency_gbp',{prev:mp('v_rev')})}
          ${this._kpi('carts','Add to Carts',mv('carts'),'count',{prev:mp('carts')})}
          ${this._kpi('conv_off','Conversion Rate',mv('conv_off'),'percentage',{prev:mp('conv_off')})}
        </div>
      </div>
      ${this._ins('website',rep,c)}
      ${this._addBlkBtn(mod)}`;

    if(mod==='email') return`
      <div class="seye">Email Marketing</div><div class="stitle">Campaign performance</div>
      <div class="g2">
        <div>
          <span class="apill">Car Chase Heroes — MailerLite</span>
          <div class="gauto">
            ${this._kpi('cch_e_cmp','Campaigns',mv('cch_e_cmp'),'count',{prev:mp('cch_e_cmp')})}
            ${this._kpi('cch_e_sent','Total Sent',mv('cch_e_sent'),'count',{prev:mp('cch_e_sent')})}
            ${this._kpi('cch_e_opens','Unique Opens',mv('cch_e_opens'),'count',{prev:mp('cch_e_opens')})}
            ${this._kpi('cch_e_open','Open Rate',mv('cch_e_open'),'percentage',{prev:mp('cch_e_open')})}
            ${this._kpi('cch_e_clicks','Unique Clicks',mv('cch_e_clicks'),'count',{prev:mp('cch_e_clicks')})}
            ${this._kpi('cch_e_ctr','CTR',mv('cch_e_ctr'),'percentage',{prev:mp('cch_e_ctr')})}
          </div>
        </div>
        <div>
          <span class="apill o">Kart Kingdom — MailerLite</span>
          ${mv('kk_e_cmp')>0?`<div class="gauto">
            ${this._kpi('kk_e_cmp','Campaigns',mv('kk_e_cmp'),'count',{prev:mp('kk_e_cmp')})}
            ${this._kpi('kk_e_sent','Total Sent',mv('kk_e_sent'),'count',{prev:mp('kk_e_sent')})}
            ${this._kpi('kk_e_open','Open Rate',mv('kk_e_open'),'percentage',{prev:mp('kk_e_open')})}
            ${this._kpi('kk_e_ctr','CTR',mv('kk_e_ctr'),'percentage',{prev:mp('kk_e_ctr')})}
          </div>`:` <div class="ins a"><p>No KK email campaigns sent this month.</p></div>`}
        </div>
      </div>
      <div class="card"><div class="card-hd"><div><div class="ctitle">Open rate &amp; CTR comparison</div></div></div><div class="ch" style="height:200px"><canvas id="c-email-met"></canvas></div></div>
      ${this._ins('email',rep,c)}
      ${this._addBlkBtn(mod)}`;

    if(mod==='creative_assets'){
      const assets=rep.assets||[];
      return`<div class="seye">Creative Assets</div><div class="stitle">${DB.ML[S.month]} deliverables</div>
      <div class="agrid">${assets.map((a,i)=>`
        <div class="acard">
          <div class="athumb">${a.img?`<img src="${a.img}" alt="${a.title}">`:`<span>${a.icon||'🖼'}</span>`}
            <div class="aover"><button class="aoBtn">View</button>${S.user?.role==='admin'?`<button class="aoBtn" onclick="REPORT.removeAsset(${i})">Remove</button>`:''}</div>
          </div>
          <div class="ainfo">
            <span class="apill n" style="font-size:9px;margin-bottom:5px">${a.brand}</span>
            ${(a.tags||[]).map(t=>`<span style="font-size:9px;background:rgba(59,130,246,.12);color:#93C5FD;border:1px solid rgba(59,130,246,.2);border-radius:3px;padding:1px 6px;margin-left:3px">${t}</span>`).join('')}
            <div class="atitle">${a.title}</div>
            <div class="adesc">${a.desc||'No description'}</div>
            ${S.user?.role==='admin'?`<button class="btn btn-g btn-sm" style="margin-top:7px;font-size:10.5px" onclick="REPORT.editAsset(${i})">✎ Edit</button>`:''}
          </div>
        </div>`).join('')}
      </div>
      <label class="aupload" onclick="this.querySelector('input').click()">
        <div style="font-size:24px;margin-bottom:5px">+</div>
        <div style="font-size:12.5px;color:var(--t1)">Upload asset — admin only</div>
        <input type="file" accept="image/*,application/pdf" onchange="REPORT.uploadAsset(this)">
      </label>`;
    }

    if(mod==='tasks'){
      const d=rep.tasks.done||[]; const u=rep.tasks.upcoming||[];
      const addTaskRow=(type)=>`<div style="display:flex;gap:6px;margin-top:10px" class="is-admin-only">
        <input class="fi" id="newtask-${type}" placeholder="Add task…" style="font-size:12px;padding:6px 9px" onkeydown="if(event.key==='Enter')REPORT.addTask('${type}',this)">
        <button class="btn btn-y btn-sm" onclick="REPORT.addTask('${type}',document.getElementById('newtask-${type}'))">Add</button>
      </div>`;
      return`<div class="seye">Work Log</div><div class="stitle">Tasks</div>
      <div class="g2">
        <div class="card"><div class="card-hd"><div class="ctitle">Completed this month (${d.length})</div></div>
          <ul class="tasklist" id="tasks-done">${d.map((t,i)=>`<li class="taskitem" draggable="true">
            <span class="tchk tdone">✓</span>
            <span style="flex:1">${t.t}</span>
            ${t.lb?`<span class="tlbl">${t.lb}</span>`:''}
            ${S.user?.role==='admin'?`<button onclick="REPORT.removeTask('done',${i})" style="background:none;border:none;color:var(--r);cursor:pointer;font-size:11px;padding:2px 5px;opacity:.6" title="Remove">✕</button>`:''}
          </li>`).join('')}</ul>
          ${S.user?.role==='admin'?addTaskRow('done'):''}
        </div>
        <div>
          <div class="card"><div class="card-hd"><div class="ctitle">Upcoming</div></div>
            <ul class="tasklist" id="tasks-upcoming">${u.map((t,i)=>`<li class="taskitem" draggable="true">
              <span class="tchk ttodo"></span>
              <span style="flex:1">${t.t}</span>
              ${t.lb?`<span class="tlbl">${t.lb}</span>`:''}
              ${S.user?.role==='admin'?`<button onclick="REPORT.removeTask('upcoming',${i})" style="background:none;border:none;color:var(--r);cursor:pointer;font-size:11px;padding:2px 5px;opacity:.6" title="Remove">✕</button>
              <button onclick="REPORT.moveTask('upcoming',${i},'done')" style="background:none;border:none;color:var(--g);cursor:pointer;font-size:11px;padding:2px 5px;opacity:.6" title="Mark done">✓</button>`:''}
            </li>`).join('')}</ul>
            ${S.user?.role==='admin'?addTaskRow('upcoming'):''}
          </div>
          <div class="card"><div class="ctitle" style="margin-bottom:10px">Completion</div><div class="ch" style="height:120px"><canvas id="c-tasks"></canvas></div>
            <div style="text-align:center;margin-top:8px;font-size:12px;color:var(--t1)">${d.length} task${d.length!==1?'s':''} completed this period</div>
            <div style="text-align:center;font-size:11px;color:var(--t2)">${u.length} upcoming (not counted)</div>
          </div>
        </div>
      </div>`;
    }
    if(mod==='forecast'){
      // Client-facing forecasting panel
      const kpis=rep.metrics.filter(m=>m.is_kpi&&m.target&&m.value_number!==null);
      if(!kpis.length) return`<div class="seye">Forecasting</div><div class="stitle">Performance Forecast</div><div class="ins a"><p>No KPI targets set for this report. Set targets on metrics to enable forecasting.</p></div>`;
      const cards=kpis.map(m=>{
        const exp=DB.kpiExpected(S.clientId,S.month);
        const progress=m.lower?Math.max(0,(m.target-m.value_number)/m.target+1):m.value_number/m.target;
        const pace=progress/Math.max(exp,0.001);
        const forecast=Math.round(m.lower?(m.target-(progress*m.target)):Math.min((progress/Math.max(exp,0.001))*m.target,m.target*4));
        const pct=Math.round(progress*100); const expPct=Math.round(exp*100);
        const status=pace>=0.95?'Ahead of target':pace>=0.8?'On track':'Needs attention';
        const barCol=pace>=0.95?'var(--g)':pace>=0.8?'var(--am)':'var(--r)';
        const scls=pace>=0.95?'bg':pace>=0.8?'ba':'br';
        return`<div class="card" style="margin-bottom:12px">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px">
            <div><div style="font-size:14px;font-weight:600">${m.label}</div><div style="font-size:11.5px;color:var(--t1)">${DB.ML[S.month]} ${S.year}</div></div>
            <span class="badge ${scls}">${status}</span>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:12px">
            <div style="background:var(--bg2);border-radius:var(--rs);padding:10px"><div style="font-size:9.5px;font-weight:600;color:var(--t2);text-transform:uppercase;letter-spacing:.6px;margin-bottom:4px">Current</div><div style="font-size:18px;font-weight:700">${F.val(m)}</div></div>
            <div style="background:var(--bg2);border-radius:var(--rs);padding:10px"><div style="font-size:9.5px;font-weight:600;color:var(--t2);text-transform:uppercase;letter-spacing:.6px;margin-bottom:4px">Target</div><div style="font-size:18px;font-weight:700">${F.short(m.target,m.unit)}</div></div>
            <div style="background:var(--bg2);border-radius:var(--rs);padding:10px;border:1px solid ${barCol}"><div style="font-size:9.5px;font-weight:600;color:var(--t2);text-transform:uppercase;letter-spacing:.6px;margin-bottom:4px">EOY Forecast</div><div style="font-size:18px;font-weight:700;color:${barCol}">${F.short(forecast,m.unit)}</div></div>
          </div>
          <div style="background:var(--bg2);border-radius:4px;height:8px;overflow:hidden;position:relative">
            <div style="height:100%;width:${Math.min(pct,100)}%;background:${barCol};border-radius:4px;transition:width .6s ease"></div>
            <div style="position:absolute;top:-2px;height:calc(100%+4px);width:2px;background:var(--t1);left:${Math.min(expPct,100)}%;border-radius:1px"></div>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--t2);margin-top:4px"><span>${pct}% achieved</span><span>Expected this month: ${expPct}%</span></div>
        </div>`;
      }).join('');
      return`<div class="seye">Annual Tracking</div><div class="stitle">Performance Forecast</div>
        <div class="ins g" style="margin-bottom:18px"><p>Based on your current pace through the ${c.reporting_year_start===1?'calendar':'financial'} year. The marker on each bar shows where you should be this month.</p></div>
        ${cards}`;
    }
    return'';
  },

  /* SECTIONS — GT TOWING */
  _sectionGT(mod,rep,c){
    const mv=k=>rep.metrics.find(m=>m.key===k)?.value_number??null;
    const mt=k=>rep.metrics.find(m=>m.key===k)?.value_text??null;
    if(mod==='overview') return`
      <div class="seye">Summary</div><div class="stitle">${DB.ML[S.month]} at a glance</div>
      <div id="vid-area" style="margin-bottom:${rep.video?'16px':'0'};max-width:${rep.video?'480px':'auto'}"></div>
            <div class="gauto">
        ${this._kpi('revenue_web','Website Revenue',mv('revenue_web'),'currency_gbp',{})}
        ${this._kpi('transactions','Transactions',mv('transactions'),'count',{})}
        ${this._kpi('avg_order','Avg Order Value',mv('avg_order'),'currency_gbp',{})}
        ${this._kpi('new_followers','New Followers (YTD)',mv('new_followers'),'count',{target:3007})}
        ${this._kpi('social_eng','Social Engagement (YTD)',mv('social_eng'),'count',{target:8500})}
        ${this._kpi('email_contacts','Email Contacts',mv('email_contacts'),'count',{target:20000})}
      </div>
      <div class="g2">
        <div class="card"><div class="card-hd"><div><div class="ctitle">Services breakdown</div></div></div><div class="ch" style="height:200px"><canvas id="c-pie"></canvas></div></div>
        <div>${this._ins('overview',rep,c)}</div>
      </div>
      ${this._addBlkBtn(mod)}`;
    if(mod==='kpis') return`
      <div class="seye">Annual Tracking</div><div class="stitle">2025/26 KPIs (Apr–Mar)</div>
      <div class="gauto">
        ${this._kpi('new_followers','New Followers (YTD)',mv('new_followers'),'count',{target:3007})}
        ${this._kpi('social_eng','Social Engagement (YTD)',mv('social_eng'),'count',{target:8500})}
        ${this._kpi('sessions_ytd','Website Sessions (YTD)',mv('sessions_ytd'),'count',{target:391000})}
        ${this._kpi('email_contacts','Email Contacts',mv('email_contacts'),'count',{target:20000})}
      </div>
      <div class="g2">
        <div class="card"><div class="card-hd"><div><div class="ctitle">KPI progress vs targets</div></div></div><div class="ch" style="height:230px"><canvas id="c-kpi-rev"></canvas></div></div>
        <div>
          <div class="card"><div class="card-hd"><div><div class="ctitle">New followers (88% of target)</div></div></div><div class="ch" style="height:96px"><canvas id="c-kpi-soc"></canvas></div></div>
          <div class="card"><div class="card-hd"><div><div class="ctitle">Email contacts (63% of target)</div></div></div><div class="ch" style="height:96px"><canvas id="c-kpi-rat"></canvas></div></div>
        </div>
      </div>
      ${this._ins('kpis',rep,c)}
      ${this._addBlkBtn(mod)}`;
    if(mod==='social') return`
      <div class="seye">Social Media</div><div class="stitle">Platform analysis</div>
      <div class="platg">
        ${this._platCard('Facebook','#1877F2',mv('fb_followers'),mv('fb_eng'),mv('fb_imp'),null,null,null,'fb_rate',mv('fb_rate'),'Views to 32.5K, unique viewers 16.1K. Visual and humour-led content performing strongly.')}
        ${this._platCard('Instagram','#E1306C',mv('ig_followers'),mv('ig_eng'),mv('ig_views'),null,null,null,null,null,'Significant growth. Humour-led workshop content driving discovery.')}
        ${this._platCard('LinkedIn','#0A66C2',mv('li_followers'),mv('li_eng'),mv('li_imp'),null,null,null,null,null,'7.4% avg engagement rate — outperforming platform benchmarks.')}
        ${this._platCard('X (Twitter)','#1DA1F2',mv('tw_followers'),mv('tw_eng'),null,null,null,null,null,null,'Passive channel. Maintain light-touch presence.')}
      </div>
      <div class="card"><div class="card-hd"><div><div class="ctitle">Platform engagement comparison</div></div></div><div class="ch" style="height:190px"><canvas id="c-soc-eng"></canvas></div></div>
      ${this._ins('social',rep,c)}
      ${this._addBlkBtn(mod)}`;
    if(mod==='paid_advertising') return`
      <div class="seye">Performance Marketing</div><div class="stitle">META Ads</div>
      <div class="g2">
        <div>
          <span class="apill o">META Advertisements</span>
          <div class="gauto">
            ${this._kpi('meta_spend','Ad Spend',mv('meta_spend'),'currency_gbp',{})}
            ${this._kpi('meta_fol','New Followers',mv('meta_fol'),'count',{})}
            ${this._kpi('meta_visits','Profile Visits',mv('meta_visits'),'count',{})}
            ${this._kpi('meta_imp','Impressions',mv('meta_imp'),'count',{})}
          </div>
          <div class="ins g"><p>Instagram awareness campaign highly cost-efficient: 15,021 impressions, 11,000+ reach, 733 profile visits at £0.06 per result.</p></div>
        </div>
        <div class="card"><div class="card-hd"><div><div class="ctitle">Ad performance</div></div></div><div class="ch" style="height:200px"><canvas id="c-paid-kk"></canvas></div></div>
      </div>
      ${this._ins('paid_advertising',rep,c)}
      ${this._addBlkBtn(mod)}`;
    if(mod==='website') return`
      <div class="seye">Website</div><div class="stitle">Traffic &amp; performance</div>
      <div class="gauto">
        ${this._kpi('web_users','Total Users',mv('web_users'),'count',{})}
        ${this._kpi('web_sessions','Sessions',mv('web_sessions'),'count',{})}
        ${this._kpi('web_bounce','Bounce Rate',mv('web_bounce'),'percentage',{lower:true})}
        <div class="kpi g"><div class="klbl">Session Duration</div><div class="kval">${mt('web_dur')||'—'}</div></div>
      </div>
      <div class="g2">
        <div class="card"><div class="card-hd"><div><div class="ctitle">Traffic by channel</div></div></div><div class="ch" style="height:220px"><canvas id="c-web-chan"></canvas></div></div>
        <div class="card"><div class="card-hd"><div><div class="ctitle">Revenue trend (Apr–Mar year)</div></div></div><div class="ch" style="height:220px"><canvas id="c-web-pages"></canvas></div></div>
      </div>
      <div class="card"><div class="card-hd"><div><div class="ctitle">Transactions</div></div></div><div class="gauto" style="margin-bottom:0">
        ${this._kpi('revenue_web','Revenue',mv('revenue_web'),'currency_gbp',{})}
        ${this._kpi('transactions','Transactions',mv('transactions'),'count',{})}
        ${this._kpi('avg_order','Avg Order Value',mv('avg_order'),'currency_gbp',{})}
        ${this._kpi('conv_rate','Conversion Rate',mv('conv_rate'),'percentage',{})}
      </div></div>
      ${this._ins('website',rep,c)}
      ${this._addBlkBtn(mod)}`;
    if(mod==='email') return`
      <div class="seye">Email Marketing</div><div class="stitle">Mailchimp campaigns</div>
      <div class="gauto">
        ${this._kpi('e_sends','Campaigns',mv('e_sends'),'count',{})}
        ${this._kpi('e_sent','Total Sent',mv('e_sent'),'count',{})}
        ${this._kpi('e_opens','Unique Opens',mv('e_opens'),'count',{})}
        ${this._kpi('e_open','Open Rate',mv('e_open'),'percentage',{})}
        ${this._kpi('e_clicks','Total Clicks',mv('e_clicks'),'count',{})}
        ${this._kpi('e_ctr','CTR',mv('e_ctr'),'percentage',{})}
      </div>
      <div class="ins g"><p>Resend strategy working well. "We Buy Your Trailer" and camping gear campaigns both achieved ~49% open rates.</p></div>
      <div class="card"><div class="card-hd"><div><div class="ctitle">Email performance metrics</div></div></div><div class="ch" style="height:200px"><canvas id="c-email-met"></canvas></div></div>
      ${this._ins('email',rep,c)}
      ${this._addBlkBtn(mod)}`;
    if(mod==='creative_assets'){
      const assets=rep.assets||[];
      return`<div class="seye">Creative Assets</div><div class="stitle">February deliverables</div>
      <div class="agrid">${assets.map(a=>`<div class="acard"><div class="athumb">${a.img?`<img src="${a.img}" alt="${a.title}">`:`<span>${a.icon||'🖼'}</span>`}<div class="aover"><button class="aoBtn">View</button></div></div><div class="ainfo"><span class="apill n" style="font-size:9px;margin-bottom:5px">${a.brand}</span><div class="atitle">${a.title}</div><div class="adesc">${a.desc}</div></div></div>`).join('')}</div>
      <label class="aupload" onclick="this.querySelector('input').click()"><div style="font-size:24px;margin-bottom:5px">+</div><div style="font-size:12.5px;color:var(--t1)">Upload asset — admin only</div><input type="file" accept="image/*,application/pdf" onchange="REPORT.uploadAsset(this)"></label>`;
    }
    if(mod==='tasks'){
      const d=rep.tasks.done||[]; const u=rep.tasks.upcoming||[];
      return`<div class="seye">Work Log</div><div class="stitle">Tasks</div>
      <div class="g2">
        <div class="card"><div class="card-hd"><div class="ctitle">Completed this period (${d.length})</div></div><ul class="tasklist">${d.map(t=>`<li class="taskitem"><span class="tchk tdone">✓</span>${t.t}</li>`).join('')}</ul></div>
        <div class="card"><div class="card-hd"><div class="ctitle">Upcoming — next period</div></div>
          <ul class="tasklist">${u.map(t=>`<li class="taskitem"><span class="tchk ttodo"></span>${t.t}</li>`).join('')}</ul>
          <div style="font-size:11px;color:var(--t2);padding-top:8px;border-top:1px solid var(--bd0);margin-top:4px">Upcoming tasks are not included in completion statistics</div>
        </div>
      </div>`;
    }
    return'';
  },

  _platCard(name,colour,followers,eng,thirdVal,pf,pe,pt,rateKey,rateVal,note){
    const lbl3=name==='TikTok'?'Views':name.includes('Twitter')?'Engagement':'Impressions';
    const fmtN=v=>v===null?'—':v>=1000?(v/1000).toFixed(0)+'k':v.toLocaleString();
    let delta3='';
    if(pt!==null&&pt!==undefined&&thirdVal!==null&&S.cmpActive){ const d=F.pct(thirdVal,pt); if(d!==null) delta3=`<span class="pchg ${d>=0?'pu':'pd'}">${d>=0?'↑':'↓'}${Math.abs(d)}%</span>`; }
    let deltaEng='';
    if(pe!==null&&pe!==undefined&&eng!==null&&S.cmpActive){ const d=F.pct(eng,pe); if(d!==null) deltaEng=`<span class="pchg ${d>=0?'pu':'pd'}">${d>=0?'↑':'↓'}${Math.abs(d)}%</span>`; }
    return`<div class="platc">
      <div class="pname"><span class="pdot" style="background:${colour}"></span>${name}</div>
      <div class="pstat"><div class="pslbl">Followers</div><div class="psval">${fmtN(followers)}</div></div>
      <div class="pstat"><div class="pslbl">Engagement</div><div class="psval">${fmtN(eng)}${deltaEng}</div></div>
      <div class="pstat"><div class="pslbl">${lbl3}</div><div class="psval">${fmtN(thirdVal)}${delta3}</div></div>
      ${rateKey&&rateVal?`<div class="pstat"><div class="pslbl">Eng Rate</div><div class="psval">${rateVal}%</div></div>`:''}
      ${note?`<p class="pnote">${note}</p>`:''}
    </div>`;
  },

  editAsset(i){
    const rep=DB.getReport(S.clientId,S.year,S.month); if(!rep||!rep.assets[i]) return;
    const a=rep.assets[i];
    document.getElementById('ea-title').value=a.title||'';
    document.getElementById('ea-brand').value=a.brand||'';
    document.getElementById('ea-desc').value=a.desc||'';
    document.getElementById('ea-cat').value=a.category||'';
    document.getElementById('ea-campaign').value=a.campaign||'';
    document.getElementById('ea-tags').value=(a.tags||[]).join(', ');
    document.getElementById('ea-notes').value=a.notes||'';
    document.getElementById('ea-featured').checked=!!a.featured;
    document.getElementById('ea-idx').value=i;
    MODAL.open('modal-edit-asset');
  },
  saveAsset(){
    const i=parseInt(document.getElementById('ea-idx').value);
    const rep=DB.getReport(S.clientId,S.year,S.month); if(!rep||!rep.assets[i]) return;
    const a=rep.assets[i];
    a.title=document.getElementById('ea-title').value||a.title;
    a.brand=document.getElementById('ea-brand').value||'';
    a.desc=document.getElementById('ea-desc').value||'';
    a.category=document.getElementById('ea-cat').value||'';
    a.campaign=document.getElementById('ea-campaign').value||'';
    a.tags=document.getElementById('ea-tags').value.split(',').map(t=>t.trim()).filter(Boolean);
    a.notes=document.getElementById('ea-notes').value||'';
    a.featured=document.getElementById('ea-featured').checked;
    INTEL.record('Asset edited',a.title);
    MODAL.close('modal-edit-asset');
    this.render();
  },
  addTask(type,input){
    const t=input.value.trim(); if(!t) return;
    const rep=DB.getReport(S.clientId,S.year,S.month); if(!rep) return;
    if(!rep.tasks[type]) rep.tasks[type]=[];
    rep.tasks[type].push({t,lb:null});
    input.value='';
    this.render();
  },
  removeTask(type,idx){
    const rep=DB.getReport(S.clientId,S.year,S.month); if(!rep) return;
    rep.tasks[type].splice(idx,1);
    this.render();
  },
  moveTask(fromType,idx,toType){
    const rep=DB.getReport(S.clientId,S.year,S.month); if(!rep) return;
    const [task]=rep.tasks[fromType].splice(idx,1);
    if(!rep.tasks[toType]) rep.tasks[toType]=[];
    rep.tasks[toType].push(task);
    this.render();
  },
  uploadAsset(input){
    const f=input.files[0]; if(!f) return;
    const r=new FileReader();
    r.onload=e=>{ DB.addAsset(S.clientId,S.year,S.month,{title:f.name,desc:'Uploaded asset',brand:DB.getClient(S.clientId)?.name||'',icon:'🖼',img:e.target.result}); this.render(); };
    r.readAsDataURL(f);
    input.value='';
  },
  removeAsset(i){ const rep=DB.getReport(S.clientId,S.year,S.month); if(rep){ rep.assets.splice(i,1); this.render(); } },

  /* CHARTS */
  _chartsInContainer(rep,c,container){
    // Init Chart.js for all canvas elements inside the hidden export container
    // We use the same data as _charts() but find elements within container, not globally
    const dark=false; // PDF always light
    const bg0='rgba(0,25,43,.06)'; const tc='rgba(0,25,43,.45)'; const raised='rgba(0,25,43,.06)';
    const axO={responsive:false,animation:{duration:0},plugins:{legend:{display:false}},
      scales:{x:{ticks:{color:tc,font:{size:11}},grid:{color:bg0}},y:{ticks:{color:tc,font:{size:11}},grid:{color:bg0}}}};
    const mk=(id,type,data,opts)=>{
      const el=container.querySelector('#'+id);
      if(!el||el.width===0) return;
      try{
        // Set explicit pixel dimensions so toDataURL works
        if(!el.width||el.width<10){ el.width=el.parentElement?.offsetWidth||700; el.height=220; }
        new Chart(el,{type,data,options:{...axO,...(opts||{})}});
      }catch(err){}
    };
    const mv=key=>rep.metrics.find(m=>m.key===key)?.value_number??null;
    const mp=key=>rep.metrics.find(m=>m.key===key)?.prev??null;
    // Set explicit pixel dimensions on every canvas before init
    container.querySelectorAll('canvas').forEach(canvas=>{
      const pw=canvas.parentElement?.offsetWidth||700;
      canvas.width=Math.max(pw,400);
      canvas.height=260;
      canvas.style.width=canvas.width+'px';
      canvas.style.height='260px';
    });
    // Temporarily redirect getElementById so _charts() finds canvases in the container
    const origGetEl=document.getElementById.bind(document);
    document.getElementById=id=>container.querySelector('#'+id)||origGetEl(id);
    try{
      // Override Chart.defaults so all charts in this call use print-friendly options
      const origDefaults={...Chart.defaults};
      Chart.defaults.color='rgba(0,25,43,.55)';
      Chart.defaults.borderColor='rgba(0,25,43,.08)';
      Chart.defaults.animation=false;
      this._charts(rep,c);
      Object.assign(Chart.defaults,origDefaults);
    }catch(e){ console.warn('Chart render error:',e); }
    document.getElementById=origGetEl;
  },
  _charts(rep,c){
    const mv=k=>rep.metrics.find(m=>m.key===k)?.value_number??0;
    const mp=k=>rep.metrics.find(m=>m.key===k)?.prev??null;
    const isGT=S.clientId==='cl-gt';
    const isTD=S.clientId==='cl-td';
    const isdark=document.documentElement.getAttribute('data-theme')!=='light';
    const bg0=isdark?'rgba(255,255,255,.06)':'rgba(0,25,43,.06)';
    const tc=isdark?'rgba(255,255,255,.45)':'rgba(0,25,43,.45)';
    const raised=isdark?'#043760':'#E8EFF6';
    const axO={responsive:true,maintainAspectRatio:false,animation:{duration:600,easing:'easeOutQuart'},plugins:{legend:{display:false}},scales:{x:{ticks:{color:tc,font:{size:10.5}},grid:{color:bg0}},y:{ticks:{color:tc,font:{size:10.5}},grid:{color:bg0}}}};
    const mk=(id,type,data,extra={})=>{
      const el=document.getElementById(id); if(!el) return;
      if(!el.offsetWidth){
        const ph=parseInt((el.parentElement?.style.height||'200'),10)||200;
        const pw=el.parentElement?.offsetWidth||el.parentElement?.getBoundingClientRect().width||600;
        el.width=Math.max(pw>0?Math.round(pw):600,200);
        el.height=ph;
        el.style.width='100%'; el.style.height=ph+'px';
      }
      try{
        CHARTS.destroy(id);
        S.charts[id]=new Chart(el,{type,data,options:{responsive:true,maintainAspectRatio:false,animation:{duration:600},plugins:{legend:{display:false}},...extra}});
      }catch(err){ console.warn('[CHART ERR]',id,err.message); } };

    if(isTD){
      // Topaz Detailing charts
      const tdBrand='#ec1d24';
      const tdBrandA='rgba(236,29,36,.25)';
      mk('c-pie','doughnut',{datasets:[{data:[mv('td_decals_rev')??0,mv('td_care_rev')??0],backgroundColor:[tdBrand,'#94A3B8'],borderWidth:0}]},{cutout:'60%',plugins:{legend:{display:true,position:'bottom',labels:{color:tc,font:{size:10},boxWidth:8}},tooltip:{callbacks:{label:ctx=>'£'+(ctx.raw/1000).toFixed(1)+'k'}}}});
      // KPI progress bar chart
      const tdKpiVals=[mv('td_shop_rev')??0,mv('td_ig_fol')??0,mv('td_yt_subs')??0,mv('td_hs_contacts')??0];
      const tdKpiTgts=[10000,350000,250000,2000];
      const tdKpiPcts=tdKpiVals.map((v,i)=>Math.min(100,Math.round(v/tdKpiTgts[i]*100)));
      mk('c-kpi-rev','bar',{labels:['Shop Rev','Instagram','YouTube','HubSpot'],datasets:[{label:'% of Target',data:tdKpiPcts,backgroundColor:[tdBrand,tdBrand,tdBrand,tdBrand],borderRadius:4},{label:'Target',data:[100,100,100,100],backgroundColor:[raised,raised,raised,raised],borderRadius:4}]},{...axO,scales:{...axO.scales,y:{...axO.scales.y,ticks:{...axO.scales.y.ticks,callback:v=>v+'%'},suggestedMax:120}},plugins:{legend:{display:true,labels:{color:tc,font:{size:10.5},boxWidth:10}}}});
      const igPct=Math.round((mv('td_ig_fol')??0)/350000*100);
      const ytPct=Math.round((mv('td_yt_subs')??0)/250000*100);
      mk('c-kpi-soc','doughnut',{datasets:[{data:[igPct,Math.max(0,100-igPct)],backgroundColor:[tdBrand,raised],borderWidth:0}]},{cutout:'72%'});
      mk('c-kpi-rat','doughnut',{datasets:[{data:[ytPct,Math.max(0,100-ytPct)],backgroundColor:['#0A66C2',raised],borderWidth:0}]},{cutout:'72%'});
      // Followers comparison
      mk('c-followers','bar',{labels:['Instagram','YouTube','Facebook','LinkedIn'],datasets:[{label:S.month,data:[mv('td_ig_fol')??0,mv('td_yt_subs')??0,mv('td_fb_fol')??0,mv('td_li_fol')??0],backgroundColor:[tdBrand,'#FF0000','#1877F2','#0A66C2'],borderRadius:5},...(S.cmpActive?[{label:'Prev',data:[mp('td_ig_fol')??0,mp('td_yt_subs')??0,mp('td_fb_fol')??0,mp('td_li_fol')??0],backgroundColor:[tdBrandA,'rgba(255,0,0,.25)','rgba(24,119,242,.25)','rgba(10,102,194,.25)'],borderRadius:5}]:[])]}, S.cmpActive?{...axO,plugins:{legend:{display:true,labels:{color:tc,font:{size:10.5},boxWidth:10}}}}:{...axO});
      // Views comparison
      mk('c-soc-eng','bar',{labels:['Instagram Views','YouTube Views','LinkedIn Eng'],datasets:[{label:S.month,data:[mv('td_ig_views')??0,mv('td_yt_views')??0,mv('td_li_eng')??0],backgroundColor:[tdBrand,'#FF0000','#0A66C2'],borderRadius:5},...(S.cmpActive?[{label:'Prev',data:[mp('td_ig_views')??0,mp('td_yt_views')??0,mp('td_li_eng')??0],backgroundColor:[tdBrandA,'rgba(255,0,0,.25)','rgba(10,102,194,.25)'],borderRadius:5}]:[])]}, S.cmpActive?{...axO,plugins:{legend:{display:true,labels:{color:tc,font:{size:10.5},boxWidth:10}}}}:{...axO});
      // Ad spend vs enquiries
      mk('c-paid-kk','bar',{labels:['Studios Spend','Shop Spend','Paid Enquiries','Web Enquiries'],datasets:[{label:S.month,data:[mv('td_studio_spend2')??0,mv('td_shop_spend2')??0,mv('td_paid_social_enq')??0,mv('td_web_enq')??0],backgroundColor:[tdBrand,tdBrandA,'#94A3B8','#4A7FA5'],borderRadius:5}]},{...axO});
      // Website users and sessions
      mk('c-web-chan','bar',{labels:['Studio Users','Studio Sessions','Shop Users','Shop Sessions'],datasets:[{label:S.month,data:[mv('td_web_users_s')??0,mv('td_web_sess_s')??0,mv('td_web_users_sh')??0,mv('td_web_sess_sh')??0],backgroundColor:[tdBrand,tdBrandA,'#4A7FA5','rgba(74,127,165,.35)'],borderRadius:5},...(S.cmpActive?[{label:'Prev',data:[mp('td_web_users_s')??0,mp('td_web_sess_s')??0,mp('td_web_users_sh')??0,mp('td_web_sess_sh')??0],backgroundColor:['rgba(236,29,36,.15)','rgba(236,29,36,.08)','rgba(74,127,165,.15)','rgba(74,127,165,.08)'],borderRadius:5}]:[])]}, S.cmpActive?{...axO,plugins:{legend:{display:true,labels:{color:tc,font:{size:10.5},boxWidth:10}}}}:{...axO});
      // Email metrics
      mk('c-email-met','bar',{labels:['Open Rate','CTR'],datasets:[{data:[mv('td_email_open')??0,mv('td_email_ctr')??0],backgroundColor:[tdBrand,'#4A7FA5'],borderRadius:5}]},{...axO,scales:{...axO.scales,y:{...axO.scales.y,ticks:{...axO.scales.y.ticks,callback:v=>v+'%'}}}});
      return;
    }

    mk('c-pie','doughnut',{datasets:[{data:isGT?[30,22,16,12,10,10]:[35,28,14,10,8,5],backgroundColor:isGT?['#ED7209','#4A7FA5','#22C55E','#FFD600','#8B5CF6','#94A3B8']:['#FFD600','#4A7FA5','#ED7209','#22C55E','#8B5CF6','#94A3B8'],borderWidth:0}]},{cutout:'60%'});

    if(!isGT){
      const revDs=[{label:'Actual',data:[mv('revenue_cch'),mv('revenue_kk_ytd')],backgroundColor:'#FFD600',borderRadius:5}];
      if(S.cmpActive&&mp('revenue_cch')) revDs.push({label:'Prev',data:[mp('revenue_cch')||0,mp('revenue_kk_ytd')||0],backgroundColor:'#ED7209',borderRadius:5});
      revDs.push({label:'Target',data:[2292678,630000],backgroundColor:raised,borderRadius:5});
      mk('c-kpi-rev','bar',{labels:['CCH Revenue','KK Revenue'],datasets:revDs},{...axO,scales:{...axO.scales,y:{...axO.scales.y,ticks:{...axO.scales.y.ticks,callback:v=>'£'+(v/1000).toFixed(0)+'k'}}},plugins:{legend:{display:true,labels:{color:tc,font:{size:10.5},boxWidth:10}}}});
      mk('c-kpi-soc','doughnut',{datasets:[{data:[Math.min(mv('social_views')/7500000*100,100),Math.max(0,100-mv('social_views')/7500000*100)],backgroundColor:['#FFD600',raised],borderWidth:0}]},{cutout:'72%'});
      mk('c-kpi-rat','doughnut',{datasets:[{data:[Math.min(mv('review_rating')/4.2*100,100),Math.max(0,100-mv('review_rating')/4.2*100)],backgroundColor:[mv('review_rating')>=4.0?'#22C55E':'#E84545',raised],borderWidth:0}]},{cutout:'72%'});
      const allMons=DB.getMonths(S.clientId,S.year);
      const tVals=allMons.map(m=>DB.getReport(S.clientId,S.year,m)?.metrics.find(x=>x.key==='revenue_cch')?.value_number||0);
      mk('c-kpi-trend','line',{labels:allMons,datasets:[{data:tVals,borderColor:'#FFD600',backgroundColor:'rgba(255,214,0,.07)',borderWidth:2,pointRadius:5,pointBackgroundColor:'#FFD600',tension:.35,fill:true}]},{...axO,scales:{...axO.scales,y:{...axO.scales.y,ticks:{...axO.scales.y.ticks,callback:v=>'£'+(v/1000).toFixed(0)+'k'}}}});
      const fMons=DB.getMonths(S.clientId,S.year);
      const fVals=fMons.map(m=>{ const r=DB.getReport(S.clientId,S.year,m); return r?['fb_followers','ig_followers','tt_followers','li_followers'].reduce((s,k)=>s+(r.metrics.find(x=>x.key===k)?.value_number||0),0):0; });
      mk('c-followers','line',{labels:fMons,datasets:[{data:fVals,borderColor:'#FFD600',backgroundColor:'rgba(255,214,0,.07)',borderWidth:2,pointRadius:5,pointBackgroundColor:'#FFD600',tension:.35,fill:true}]},{...axO,scales:{...axO.scales,y:{...axO.scales.y,ticks:{...axO.scales.y.ticks,callback:v=>(v/1000).toFixed(0)+'k'}}}});
      const sDs=[{label:S.month,data:[mv('fb_eng'),mv('ig_eng'),mv('tt_eng'),mv('li_eng')],backgroundColor:['#1877F2','#E1306C','#FF0050','#0A66C2'],borderRadius:5}];
      if(S.cmpActive) sDs.push({label:'Prev',data:[mp('fb_eng')||0,mp('ig_eng')||0,mp('tt_eng')||0,mp('li_eng')||0],backgroundColor:['rgba(24,119,242,.3)','rgba(225,48,108,.3)','rgba(255,0,80,.3)','rgba(10,102,194,.3)'],borderRadius:5});
      mk('c-soc-eng','bar',{labels:['Facebook','Instagram','TikTok','LinkedIn'],datasets:sDs},{...axO,...(S.cmpActive?{plugins:{legend:{display:true,labels:{color:tc,font:{size:10.5},boxWidth:10}}}}:{})});
      mk('c-paid-kk','bar',{labels:['Ad Spend','Revenue'],datasets:[{label:S.month,data:[mv('kk_spend'),mv('kk_rev')],backgroundColor:['#ED7209','#FFD600'],borderRadius:6},...(S.cmpActive?[{label:'Prev',data:[mp('kk_spend')||0,mp('kk_rev')||0],backgroundColor:['rgba(237,114,9,.35)','rgba(255,214,0,.35)'],borderRadius:6}]:[])]}, {...axO,scales:{...axO.scales,y:{...axO.scales.y,ticks:{...axO.scales.y.ticks,callback:v=>'£'+v.toFixed(0)}}},...(S.cmpActive?{plugins:{legend:{display:true,labels:{color:tc,font:{size:10.5},boxWidth:10}}}}:{})});
      mk('c-paid-cch','bar',{labels:['Impressions (÷100)','Followers Gained'],datasets:[{data:[Math.round(mv('cch_imp')/100),mv('cch_fol')],backgroundColor:['#FFD600','#ED7209'],borderRadius:5},...(S.cmpActive?[{data:[Math.round((mp('cch_imp')||0)/100),mp('cch_fol')||0],backgroundColor:['rgba(255,214,0,.35)','rgba(237,114,9,.35)'],borderRadius:5}]:[])]}, {...axO,...(S.cmpActive?{plugins:{legend:{display:true,labels:{color:tc,font:{size:10.5},boxWidth:10}}}}:{})});
      const wDs=[{label:S.month,data:[mv('ch_direct'),mv('ch_organic'),mv('ch_paid'),mv('ch_ref'),mv('ch_email')],backgroundColor:'#FFD600',borderRadius:4}];
      if(S.cmpActive) wDs.push({label:'Prev',data:[mp('ch_direct')||0,mp('ch_organic')||0,mp('ch_paid')||0,mp('ch_ref')||0,mp('ch_email')||0],backgroundColor:'rgba(255,214,0,.35)',borderRadius:4});
      mk('c-web-chan','bar',{labels:['Direct','Organic','Paid','Referral','Email'],datasets:wDs},{...axO,indexAxis:'y',scales:{...axO.scales,x:{...axO.scales.x,ticks:{...axO.scales.x.ticks,callback:v=>(v/1000).toFixed(0)+'k'}}},...(S.cmpActive?{plugins:{legend:{display:true,labels:{color:tc,font:{size:10.5},boxWidth:10}}}}:{})});
      const pgV=S.month==='Jan'?[22949,21397,24395,21981,14629]:[39673,27641,25201,20526,15205];
      mk('c-web-pages','bar',{labels:['Calendar','Booking','Home','Cars','Voucher Codes'],datasets:[{data:pgV,backgroundColor:raised,borderRadius:4}]},{...axO,indexAxis:'y',scales:{...axO.scales,x:{...axO.scales.x,ticks:{...axO.scales.x.ticks,callback:v=>(v/1000).toFixed(0)+'k'}}}});
      const eDs=[{label:'Open Rate',data:[mv('cch_e_open'),...(mv('kk_e_cmp')>0?[mv('kk_e_open')]:[])],backgroundColor:'#FFD600',borderRadius:4},{label:'CTR',data:[mv('cch_e_ctr'),...(mv('kk_e_cmp')>0?[mv('kk_e_ctr')]:[])],backgroundColor:'#ED7209',borderRadius:4}];
      if(S.cmpActive) eDs.push({label:'Prev OR',data:[mp('cch_e_open')||0],backgroundColor:'rgba(255,214,0,.3)',borderRadius:4});
      mk('c-email-met','bar',{labels:['CCH',...(mv('kk_e_cmp')>0?['KK']:[])],datasets:eDs},{...axO,scales:{...axO.scales,y:{...axO.scales.y,ticks:{...axO.scales.y.ticks,callback:v=>v+'%'}}},plugins:{legend:{display:true,labels:{color:tc,font:{size:10.5},boxWidth:10}}}});
      mk('c-tasks','doughnut',{datasets:[{data:[100,0],backgroundColor:['#22C55E',raised],borderWidth:0}]},{cutout:'70%'});
    } else {
      mk('c-kpi-rev','bar',{labels:['New Followers','Social Eng.','Sessions÷100','Email Contacts'],datasets:[{label:'Actual',data:[mv('new_followers'),mv('social_eng'),Math.round(mv('sessions_ytd')/100),mv('email_contacts')],backgroundColor:'#FFD600',borderRadius:5},{label:'Target',data:[3007,8500,3910,20000],backgroundColor:raised,borderRadius:5}]},{...axO,plugins:{legend:{display:true,labels:{color:tc,font:{size:10.5},boxWidth:10}}}});
      mk('c-kpi-soc','doughnut',{datasets:[{data:[88,12],backgroundColor:['#22C55E',raised],borderWidth:0}]},{cutout:'72%'});
      mk('c-kpi-rat','doughnut',{datasets:[{data:[63,37],backgroundColor:['#ED7209',raised],borderWidth:0}]},{cutout:'72%'});
      mk('c-soc-eng','bar',{labels:['Facebook','Instagram','LinkedIn','X/Twitter'],datasets:[{data:[mv('fb_eng'),mv('ig_eng'),mv('li_eng'),mv('tw_eng')],backgroundColor:['#1877F2','#E1306C','#0A66C2','#1DA1F2'],borderRadius:5}]},{...axO});
      mk('c-paid-kk','bar',{labels:['Ad Spend (£)','Profile Visits'],datasets:[{data:[mv('meta_spend'),mv('meta_visits')],backgroundColor:['#ED7209','#FFD600'],borderRadius:6}]},{...axO});
      mk('c-web-chan','bar',{labels:['Organic','Direct','Email','Referral'],datasets:[{data:[mv('ch_organic'),mv('ch_direct'),mv('ch_email'),mv('ch_ref')],backgroundColor:'#FFD600',borderRadius:4}]},{...axO,indexAxis:'y',scales:{...axO.scales,x:{...axO.scales.x,ticks:{...axO.scales.x.ticks,callback:v=>(v/1000).toFixed(0)+'k'}}}});
      mk('c-web-pages','line',{labels:['Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb'],datasets:[{data:[32246,36341,31399,35269,28446,17396,26672,23479,0,0,mv('revenue_web')],borderColor:'#ED7209',backgroundColor:'rgba(237,114,9,.08)',borderWidth:2,pointRadius:4,tension:.35,fill:true}]},{...axO,scales:{...axO.scales,y:{...axO.scales.y,ticks:{...axO.scales.y.ticks,callback:v=>'£'+(v/1000).toFixed(0)+'k'}}}});
      mk('c-email-met','bar',{labels:['Open Rate','CTR'],datasets:[{data:[mv('e_open'),mv('e_ctr')],backgroundColor:'#FFD600',borderRadius:5}]},{...axO,scales:{...axO.scales,y:{...axO.scales.y,ticks:{...axO.scales.y.ticks,callback:v=>v+'%'}}}});
    }
  },
};

/* CHARTS MANAGER */
const CHARTS = {
  _applyTheme(){
    const dark=document.documentElement.getAttribute('data-theme')!=='light';
    const tc=dark?'rgba(255,255,255,.5)':'rgba(0,25,43,.45)';
    if(window.Chart){
      Chart.defaults.color=tc;
      Chart.defaults.borderColor=dark?'rgba(255,255,255,.07)':'rgba(0,25,43,.07)';
    }
  },
  destroyAll(){ for(const k in S.charts){ try{S.charts[k].destroy();}catch(e){} } S.charts={}; },
  destroy(id){ if(S.charts[id]){ try{S.charts[id].destroy();}catch(e){} delete S.charts[id]; } },
};

/* BLOCK BUILDER */
const BUILDER = {
  _currentSection:null,
  TYPES:[
    {id:'kpi_card',ico:'📊',lbl:'KPI Card',sub:'Single metric with optional target'},
    {id:'kpi_row',ico:'📈',lbl:'KPI Row',sub:'Multiple metrics in a row'},
    {id:'bar_chart',ico:'▤',lbl:'Bar Chart',sub:'Grouped or stacked bars'},
    {id:'line_chart',ico:'◝',lbl:'Line Chart',sub:'Trend over time'},
    {id:'donut_chart',ico:'◎',lbl:'Donut Chart',sub:'Proportion / progress'},
    {id:'platform_grid',ico:'📱',lbl:'Platform Cards',sub:'Social platform breakdown'},
    {id:'table',ico:'☰',lbl:'Data Table',sub:'Rows of metrics'},
    {id:'task_list',ico:'✓',lbl:'Task List',sub:'Completed / upcoming tasks'},
    {id:'insight',ico:'',lbl:'Insight Block',sub:'Commentary / analysis text'},
    {id:'asset_gallery',ico:'🖼',lbl:'Asset Gallery',sub:'Creative deliverables'},
    {id:'text_block',ico:'T',lbl:'Text Block',sub:'Rich text / notes'},
    {id:'divider',ico:'—',lbl:'Divider',sub:'Section separator'},
    {id:'email_campaign',ico:'📧',lbl:'Email Campaigns',sub:'Campaign snapshots with stats'},
  ],
  openPicker(section){
    this._currentSection=section;
    const grid=document.getElementById('block-type-grid');
    if(!grid) return;
    grid.innerHTML=this.TYPES.map(t=>`
      <div class="block-type" onclick="BUILDER.addBlock('${section}','${t.id}')">
        <div class="bt-ico">${t.ico}</div>
        <div class="bt-lbl">${t.lbl}</div>
        <div class="bt-sub">${t.sub}</div>
      </div>`).join('');
    MODAL.open('modal-addblk');
  },
  _blockRegistry:{},
  addBlock(section,type){
    MODAL.close('modal-addblk');
    const el=document.getElementById('rs-'+section); if(!el) return;
    const id='blk-'+Date.now();
    const typeLabel={kpi_card:'KPI Card',kpi_row:'KPI Row',bar_chart:'Bar Chart',line_chart:'Line Chart',donut_chart:'Donut Chart',platform_grid:'Platform Cards',table:'Data Table',task_list:'Task List',insight:'Insight Block',asset_gallery:'Asset Gallery',text_block:'Text Block',divider:'Divider'};
    const t=this.TYPES.find(x=>x.id===type)||{ico:'',lbl:type};
    this._blockRegistry[id]={id,section,type,width:'full',sort:Date.now(),data:{}};
    const blkHtml=`<div class="card blk-full" id="${id}"
      data-blk-id="${id}" data-blk-type="${type}" data-blk-section="${section}"
      draggable="true" style="border:1px dashed rgba(255,214,0,.3)"
      ondragstart="BUILDER.onDragStart(event,'${id}')"
      ondragover="BUILDER.onDragOver(event,'${id}')"
      ondragleave="BUILDER.onDragLeave(event,'${id}')"
      ondrop="BUILDER.onDrop(event,'${id}')"
      ondragend="BUILDER.onDragEnd(event)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
        <div style="display:flex;align-items:center;gap:7px" id="blk-hd-${id}">
          <span style="color:var(--t2);cursor:grab;font-size:16px" title="Drag to reorder">⠿</span>
          <div style="font-size:12.5px;font-weight:600;color:var(--y)">${t.ico} ${typeLabel[type]||type}</div>
          <span style="font-size:9.5px;background:rgba(255,214,0,.1);border:1px solid rgba(255,214,0,.2);border-radius:3px;padding:2px 6px">Configure</span>
        </div>
        <div style="display:flex;gap:5px;align-items:center">
          <select style="background:var(--inp);border:1px solid var(--inpb);border-radius:var(--rs);padding:3px 7px;font-size:10.5px;color:var(--t0)"
            onchange="BUILDER.setBlockWidth('${id}',this.value)">
            <option value="full" selected>Full width</option><option value="half">Half width</option>
          </select>
          <button class="btn btn-g btn-sm" onclick="BUILDER.configBlock('${id}','${type}')">Configure</button>
          <button class="btn btn-r btn-sm" onclick="BUILDER.removeBlock('${id}')">Remove</button>
        </div>
      </div>
      ${this._blkPreview(type)}
    </div>`;
    // Try to insert into the blk-wrap container first, then fall back
    const wrap=el.querySelector('.blk-wrap');
    const addRow=el.querySelector('.add-block-row');
    if(wrap) wrap.insertAdjacentHTML('beforeend',blkHtml);
    else if(addRow) addRow.insertAdjacentHTML('beforebegin',blkHtml);
    else el.insertAdjacentHTML('beforeend',blkHtml);
  },
  removeBlock(id){ delete this._blockRegistry[id]; document.getElementById(id)?.remove(); },
  setBlockWidth(id,w){
    const el=document.getElementById(id); if(!el) return;
    if(this._blockRegistry[id]) this._blockRegistry[id].width=w;
    el.className=el.className.replace(/blk-full|blk-half/g,'').trim()+' blk-'+w;
  },
  _dragId:null, _dropTargetId:null,
  _insertBefore:true,
  _insertSide:null, // 'left'|'right'|null (for half-width targets)

  onDragStart(e,id){
    this._dragId=id;
    e.currentTarget.classList.add('blk-dragging');
    e.dataTransfer.effectAllowed='move';
    e.dataTransfer.setData('text/plain',id);
    document.querySelectorAll('.blk-drop-zone').forEach(z=>z.classList.add('active'));
  },

  onDragOver(e,id){
    e.preventDefault();
    e.dataTransfer.dropEffect='move';
    if(this._dragId===id) return;
    const target=e.currentTarget;
    const rect=target.getBoundingClientRect();
    // Use precise cursor position relative to the target
    const relY=e.clientY-rect.top;
    const relX=e.clientX-rect.left;
    const isHalf=target.classList.contains('blk-half');
    // Clear all previous indicators
    document.querySelectorAll('.blk-insert-before,.blk-insert-after,.blk-insert-left,.blk-insert-right')
      .forEach(el=>el.classList.remove('blk-insert-before','blk-insert-after','blk-insert-left','blk-insert-right'));
    if(isHalf){
      // For half-width: use left/right quadrant for side insertion
      const midX=rect.width/2;
      this._insertSide=relX<midX?'left':'right';
      this._insertBefore=relY<rect.height/2;
      target.classList.add(this._insertSide==='left'?'blk-insert-left':'blk-insert-right');
    } else {
      // For full-width: top 40% = before, bottom 40% = after, middle = before (bias upward)
      this._insertBefore=relY<(rect.height*0.5);
      this._insertSide=null;
      target.classList.add(this._insertBefore?'blk-insert-before':'blk-insert-after');
    }
    // Store target for drop
    this._dropTargetId=id;
  },

  onDrop(e,id){
    e.preventDefault();
    e.stopPropagation();
    document.querySelectorAll('.blk-insert-before,.blk-insert-after,.blk-insert-left,.blk-insert-right,.blk-drop-zone.active')
      .forEach(el=>el.classList.remove('blk-insert-before','blk-insert-after','blk-insert-left','blk-insert-right','active'));
    // Use the drop target from dragover (more reliable than the drop event target)
    const dropId=this._dropTargetId||id;
    if(!this._dragId||this._dragId===dropId) return;
    const drag=document.getElementById(this._dragId);
    const target=document.getElementById(dropId);
    if(!drag||!target) return;
    if(!drag||!target) return;
    const targetIsHalf=target.classList.contains('blk-half');
    const dragReg=this._blockRegistry[this._dragId];
    // Determine insertion position: insertBefore was set in onDragOver
    const before=this._insertBefore;
    if(targetIsHalf&&this._insertSide){
      // Dropping beside a half-width block — make dragged block half too
      if(dragReg) dragReg.width='half';
      drag.classList.remove('blk-full'); drag.classList.add('blk-half');
      const wsel=drag.querySelector('select[onchange*="setBlockWidth"]');
      if(wsel) wsel.value='half';
      if(this._insertSide==='left') target.parentNode.insertBefore(drag,target);
      else target.insertAdjacentElement('afterend',drag);
    } else {
      // Standard above/below: use insertAdjacentElement for reliable positioning
      if(before){
        target.insertAdjacentElement('beforebegin',drag);
      } else {
        target.insertAdjacentElement('afterend',drag);
      }
    }
    this._dropTargetId=null;
    // Update sort order in registry
    [...(target.parentNode||document).querySelectorAll('[data-blk-id]')].forEach((el,i)=>{
      if(this._blockRegistry[el.dataset.blkId]) this._blockRegistry[el.dataset.blkId].sort=i;
    });
  },

  onDropZone(e,section){
    e.preventDefault();
    document.querySelectorAll('.blk-drop-zone').forEach(z=>{z.classList.remove('active','dragover');});
    if(!this._dragId) return;
    const drag=document.getElementById(this._dragId); if(!drag) return;
    const wrap=document.getElementById('blk-wrap-'+section); if(!wrap) return;
    wrap.appendChild(drag);
    if(this._blockRegistry[this._dragId]) this._blockRegistry[this._dragId].section=section;
    [...wrap.querySelectorAll('[data-blk-id]')].forEach((el,i)=>{
      if(this._blockRegistry[el.dataset.blkId]) this._blockRegistry[el.dataset.blkId].sort=i;
    });
  },

  onDragLeave(e,id){
    // Only clear indicators if we're actually leaving this block (not entering a child)
    const related=e.relatedTarget;
    const block=e.currentTarget;
    if(related&&block.contains(related)) return;
    block.classList.remove('blk-insert-before','blk-insert-after','blk-insert-left','blk-insert-right');
  },
  onDragEnd(e){
    e.currentTarget.classList.remove('blk-dragging');
    document.querySelectorAll('.blk-insert-before,.blk-insert-after,.blk-insert-left,.blk-insert-right,.blk-drop-zone.active')
      .forEach(el=>el.classList.remove('blk-insert-before','blk-insert-after','blk-insert-left','blk-insert-right','active'));
    this._dragId=null; this._insertSide=null;
  },
  _blkPreview(type){
    if(type==='kpi_card') return`<div class="gauto"><div class="kpi g"><div class="klbl">Metric label</div><div class="kval">—</div><div class="ksub">No target set</div></div></div>`;
    if(type==='insight') return`<div class="ins a"><p>Add your insight text here…</p></div>`;
    if(type==='table') return`<div style="overflow:auto"><table class="tbl"><thead><tr><th>Column 1</th><th>Column 2</th><th>Column 3</th></tr></thead><tbody><tr><td>—</td><td>—</td><td>—</td></tr></tbody></table></div>`;
    if(type==='task_list') return`<ul class="tasklist"><li class="taskitem"><span class="tchk tdone">✓</span>Example task</li></ul>`;
    if(type==='text_block') return`<p style="font-size:12.5px;color:var(--t1)">Click configure to add your content…</p>`;
    if(type==='divider') return`<hr style="border:none;border-top:1px solid var(--bd1);margin:4px 0">`;
    if(type.includes('chart')) return`<div style="height:160px;background:var(--bg2);border-radius:var(--rs);display:flex;align-items:center;justify-content:center;font-size:12px;color:var(--t2)">Chart will appear here after configuration</div>`;
    return`<div style="padding:16px;background:var(--bg2);border-radius:var(--rs);text-align:center;font-size:12px;color:var(--t2)">Configure this block to add data</div>`;
  },
  _addMetricSlot(){
    const count=parseInt(document.getElementById('cb-count')?.value||0);
    const i=count;
    const slot=document.createElement('div');
    slot.id='cb-metric-slot-'+i;
    slot.className='card';
    slot.style.marginBottom='10px';
    slot.innerHTML=`<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
      <div style="font-size:11px;font-weight:600;color:var(--o)">Metric ${i+1}</div>
      <button type="button" class="btn btn-r btn-sm" style="font-size:9.5px" onclick="this.closest('[id^=cb-metric-slot]').remove();document.getElementById('cb-count').value--"> Remove</button>
    </div>
    <div class="g2">
      <div class="fg"><label class="fl">Label</label><input class="fi" id="cb-label-${i}" placeholder="e.g. Website Users"></div>
      <div class="fg"><label class="fl">Value</label><input class="fi" id="cb-val-${i}" type="number" placeholder="0"></div>
    </div>
    <div class="g2">
      <div class="fg"><label class="fl">Unit</label><select class="fi" id="cb-unit-${i}"><option value="count">Number</option><option value="currency_gbp">£ Currency</option><option value="percentage">Percentage %</option><option value="number">Decimal</option></select></div>
      <div class="fg"><label class="fl">Target (optional)</label><input class="fi" id="cb-target-${i}" type="number" placeholder=""></div>
    </div>
    <div class="fg"><label class="fl">Source link (optional)</label><input class="fi" id="cb-link-${i}" placeholder="https://analytics.google.com/…"></div>`;
    const addBtn=document.querySelector('#cb-body button[onclick="_addMetricSlot"]')||document.querySelector('#cb-body button');
    if(addBtn) addBtn.before(slot); else document.getElementById('cb-body').appendChild(slot);
    document.getElementById('cb-count').value=count+1;
  },
  _currentBlockId:null, _currentBlockType:null,
  configBlock(id,type){
    this._currentBlockId=id;
    this._currentBlockType=type;
    const titles={kpi_card:'Configure KPI Card',kpi_row:'Configure KPI Row',bar_chart:'Configure Bar Chart',line_chart:'Configure Line Chart',donut_chart:'Configure Donut Chart',platform_grid:'Configure Platform Cards',table:'Configure Data Table',task_list:'Configure Task List',insight:'Configure Insight Block',asset_gallery:'Configure Asset Gallery',text_block:'Configure Text Block',divider:'Divider'};
    document.getElementById('cb-title').textContent=titles[type]||'Configure block';
    // Pass existing block data so form can pre-fill
    const existingData=this._blockRegistry[id]?.data||{};
    const existingWidth=this._blockRegistry[id]?.width||'full';
    document.getElementById('cb-body').innerHTML=this._configForm(type,id,existingData,existingWidth);
    MODAL.open('modal-config-block');
  },
  _configForm(type,id,existing={},existingWidth='full'){
    const el=document.getElementById(id);
    // Restore saved data from registry if re-editing
    const saved=this._blockRegistry[id]?.data||{};
    const sw=this._blockRegistry[id]?.width||'full';
    if(type==='kpi_card'||type==='kpi_row'){
      // kpi_card: flexible number of metrics (default 1, user can add more)
      // kpi_row: default 4 slots
      const savedMetrics=saved.metrics||[];
      const defaultN=type==='kpi_row'?4:1;
      const n=Math.max(defaultN,savedMetrics.length);
      let rows='';
      for(let i=0;i<n;i++){
        const sv=savedMetrics[i]||{};
        rows+=`<div class="card" style="margin-bottom:10px" id="cb-metric-slot-${i}">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
            <div style="font-size:11px;font-weight:600;color:var(--o)">${type==='kpi_card'?'Metric':'Metric '+(i+1)}</div>
            ${i>=1?`<button type="button" class="btn btn-r btn-sm" style="font-size:9.5px" onclick="this.closest('[id^=cb-metric-slot]').remove();document.getElementById('cb-count').value--;"> Remove</button>`:''}
          </div>
          <div class="g2">
            <div class="fg"><label class="fl">Label</label><input class="fi" id="cb-label-${i}" placeholder="e.g. Website Users" value="${sv.label||''}"></div>
            <div class="fg"><label class="fl">Value</label><input class="fi" id="cb-val-${i}" type="number" placeholder="0" value="${sv.value||''}"></div>
          </div>
          <div class="g2">
            <div class="fg"><label class="fl">Unit</label><select class="fi" id="cb-unit-${i}">
              <option value="count" ${sv.unit==='count'?'selected':''}>Number</option>
              <option value="currency_gbp" ${sv.unit==='currency_gbp'?'selected':''}>£ Currency</option>
              <option value="percentage" ${sv.unit==='percentage'?'selected':''}>Percentage %</option>
              <option value="number" ${sv.unit==='number'?'selected':''}>Decimal</option>
            </select></div>
            <div class="fg"><label class="fl">Target (optional)</label><input class="fi" id="cb-target-${i}" type="number" placeholder="" value="${sv.target||''}"></div>
          </div>
          <div class="fg"><label class="fl">Source link (optional)</label><input class="fi" id="cb-link-${i}" placeholder="https://analytics.google.com/…" value="${sv.link||''}"></div>
        </div>`;
      }
      return `<input type="hidden" id="cb-count" value="${n}">
      ${rows}
      <button type="button" class="btn btn-g btn-sm" style="margin-bottom:12px" onclick="BUILDER._addMetricSlot()">+ Add metric</button>
      <div class="fg"><label class="fl">Layout</label><select class="fi" id="cb-width"><option value="full" ${sw==='full'?'selected':''}>Full width</option><option value="half" ${sw==='half'?'selected':''}>Half width</option></select></div>`;
    }
    if(type==='text_block'||type==='insight'){
      const savedText=saved.text||'';
      const savedTitle=saved.title||'';
      const savedTone=saved.tone||'g';
      const savedWidth=sw;
      return`${type==='text_block'?`<div class="fg"><label class="fl">Title (optional)</label><input class="fi" id="cb-blk-title" placeholder="Optional block heading" value="${savedTitle}"></div>`:''}
      <div class="fg"><label class="fl">Content</label><textarea class="fi" id="cb-text" rows="5" placeholder="Enter your text here…">${savedText}</textarea></div>
      ${type==='insight'?`<div class="fg"><label class="fl">Style</label><select class="fi" id="cb-tone"><option value="g" ${savedTone==='g'?'selected':''}>Positive (green)</option><option value="a" ${savedTone==='a'?'selected':''}>Neutral (amber)</option><option value="w" ${savedTone==='w'?'selected':''}>Warning (red)</option></select></div>`:''}
      <div class="fg"><label class="fl">Layout</label><select class="fi" id="cb-width"><option value="full" ${savedWidth==='full'?'selected':''}>Full width</option><option value="half" ${savedWidth==='half'?'selected':''}>Half width</option></select></div>`;
    }
    if(type==='table'){
      return`<div class="fg"><label class="fl">Table title</label><input class="fi" id="cb-title-val" placeholder="e.g. Top Pages"></div>
      <div class="fg"><label class="fl">Columns (comma-separated)</label><input class="fi" id="cb-cols" placeholder="Page, Users, Sessions, Bounce Rate"></div>
      <div class="fg"><label class="fl">Data rows (one row per line, values comma-separated)</label><textarea class="fi" id="cb-rows" rows="5" placeholder="Homepage, 12400, 15200, 55%&#10;Calendar, 9800, 11300, 48%"></textarea></div>
      <div class="fg"><label class="fl">Layout</label><select class="fi" id="cb-width"><option value="full"${existingWidth==='full'?' selected':''}>Full width</option><option value="half"${existingWidth==='half'?' selected':''}>Half width</option></select></div>`;
    }
    if(type==='bar_chart'||type==='line_chart'){
      const sw2=this._blockRegistry[id]?.width||'full';
      const sd=this._blockRegistry[id]?.data||{};
      return`<div class="fg"><label class="fl">Chart title</label><input class="fi" id="cb-title-val" placeholder="e.g. Traffic by Channel" value="${sd.title||''}"></div>
      <div class="fg"><label class="fl">Data source</label>
        <select class="fi" id="cb-datasrc" style="margin-bottom:4px">
          <option value="manual">Manual entry</option>
          <option value="google_analytics_4">Google Analytics 4 (future)</option>
          <option value="meta">Meta / Facebook (future)</option>
          <option value="mailerlite">MailerLite (future)</option>
          <option value="mailchimp">Mailchimp (future)</option>
          <option value="google_ads">Google Ads (future)</option>
        </select>
        <span style="font-size:10.5px;color:var(--t2)">API connections coming — enter data manually for now</span>
      </div>
      <div class="fg"><label class="fl">Labels (comma-separated)</label><input class="fi" id="cb-cols" placeholder="Jan, Feb, Mar, Apr" value="${sd.labels||''}"></div>
      <div class="fg"><label class="fl">Values (comma-separated numbers)</label><input class="fi" id="cb-rows" placeholder="1200, 1850, 2100, 1900" value="${sd.values||''}"></div>
      <div class="fg"><label class="fl">Colour</label><input class="fi" id="cb-colour" type="color" value="${sd.colour||'#FFD600'}"></div>
      <div class="fg"><label class="fl">Layout</label><select class="fi" id="cb-width"><option value="full" ${sw2==='full'?'selected':''}>Full width</option><option value="half" ${sw2==='half'?'selected':''}>Half width</option></select></div>`;
    }
    if(type==='donut_chart'){
      return`<div class="fg"><label class="fl">Chart title</label><input class="fi" id="cb-title-val" placeholder="e.g. Traffic Sources" value="${existing.title||''}"></div>
      <div class="fg"><label class="fl">Labels (comma-separated)</label><input class="fi" id="cb-cols" placeholder="Direct, Organic, Paid, Email" value="${existing.labels||''}"></div>
      <div class="fg"><label class="fl">Values (comma-separated numbers)</label><input class="fi" id="cb-rows" placeholder="40, 30, 20, 10" value="${existing.values||''}"></div>
      <div class="fg"><label class="fl">Layout</label><select class="fi" id="cb-width"><option value="full"${existingWidth==='full'?' selected':''}>Full width</option><option value="half">Half width</option></select></div>`;
    }
    if(type==='platform_grid'){
      const sd=this._blockRegistry[id]?.data||{};
      const sw2=this._blockRegistry[id]?.width||'full';
      const platforms=sd.platforms||[{platform:'Facebook',colour:'#1877F2',followers:'',engagement:'',impressions:'',rate:'',comment:''}];
      const platRows=platforms.map((p,i)=>`
        <div class="card" style="margin-bottom:8px" id="plat-slot-${i}">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
            <div style="font-size:11px;font-weight:600;color:var(--o)">Platform ${i+1}</div>
            ${i>0?`<button type="button" class="btn btn-r btn-sm" style="font-size:9.5px" onclick="this.closest('[id^=plat-slot]').remove()">Remove</button>`:''}
          </div>
          <div class="g2">
            <div class="fg"><label class="fl">Platform name</label><input class="fi" id="plat-name-${i}" value="${p.platform||''}" placeholder="Facebook"></div>
            <div class="fg"><label class="fl">Brand colour</label><input class="fi" type="color" id="plat-col-${i}" value="${p.colour||'#1877F2'}"></div>
          </div>
          <div class="g2">
            <div class="fg"><label class="fl">Followers</label><input class="fi" id="plat-fol-${i}" value="${p.followers||''}" type="number" placeholder="0"></div>
            <div class="fg"><label class="fl">Engagement</label><input class="fi" id="plat-eng-${i}" value="${p.engagement||''}" type="number" placeholder="0"></div>
          </div>
          <div class="g2">
            <div class="fg"><label class="fl">Impressions</label><input class="fi" id="plat-imp-${i}" value="${p.impressions||''}" type="number" placeholder="0"></div>
            <div class="fg"><label class="fl">Engagement rate %</label><input class="fi" id="plat-rate-${i}" value="${p.rate||''}" type="number" step="0.01" placeholder="0.00"></div>
          </div>
          <div class="fg"><label class="fl">Comment / note (optional)</label><input class="fi" id="plat-comment-${i}" value="${p.comment||''}" placeholder="e.g. Strong growth this month"></div>
          <div class="fg"><label class="fl">Data source (future API)</label>
            <select class="fi" id="plat-src-${i}">
              <option value="manual" ${(p.source||'manual')==='manual'?'selected':''}>Manual entry</option>
              <option value="meta" ${p.source==='meta'?'selected':''}>Meta / Facebook API (future)</option>
              <option value="instagram" ${p.source==='instagram'?'selected':''}>Instagram API (future)</option>
              <option value="linkedin" ${p.source==='linkedin'?'selected':''}>LinkedIn API (future)</option>
              <option value="tiktok" ${p.source==='tiktok'?'selected':''}>TikTok API (future)</option>
            </select>
          </div>
        </div>`).join('');
      return`<input type="hidden" id="plat-count" value="${platforms.length}">
        ${platRows}
        <button type="button" class="btn btn-g btn-sm" style="margin-bottom:12px" onclick="BUILDER._addPlatformSlot()">+ Add platform</button>
        <div class="fg"><label class="fl">Layout</label><select class="fi" id="cb-width"><option value="full" ${sw2==='full'?'selected':''}>Full width</option><option value="half" ${sw2==='half'?'selected':''}>Half width</option></select></div>`;
    }
    if(type==='email_campaign'){
      const sd=this._blockRegistry[id]?.data||{};
      const sw2=this._blockRegistry[id]?.width||'full';
      const campaigns=sd.campaigns||[{title:'',date:'',link:'',sent:'',open_rate:'',ctr:'',preview:''}];
      const campRows=campaigns.map((cp,i)=>`
        <div class="card" style="margin-bottom:8px" id="camp-slot-${i}">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
            <div style="font-size:11px;font-weight:600;color:var(--o)">Campaign ${i+1}</div>
            ${i>0?`<button type="button" class="btn btn-r btn-sm" style="font-size:9.5px" onclick="this.closest('[id^=camp-slot]').remove()">Remove</button>`:''}
          </div>
          <div class="g2">
            <div class="fg"><label class="fl">Campaign title</label><input class="fi" id="camp-title-${i}" value="${cp.title||''}" placeholder="February Newsletter"></div>
            <div class="fg"><label class="fl">Send date</label><input class="fi" type="date" id="camp-date-${i}" value="${cp.date||''}"></div>
          </div>
          <div class="fg"><label class="fl">Link to email (optional)</label><input class="fi" id="camp-link-${i}" value="${cp.link||''}" placeholder="https://…"></div>
          <div class="g2">
            <div class="fg"><label class="fl">Emails sent</label><input class="fi" id="camp-sent-${i}" value="${cp.sent||''}" type="number" placeholder="0"></div>
            <div class="fg"><label class="fl">Open rate %</label><input class="fi" id="camp-or-${i}" value="${cp.open_rate||''}" type="number" step="0.1" placeholder="0.0"></div>
          </div>
          <div class="fg"><label class="fl">CTR %</label><input class="fi" id="camp-ctr-${i}" value="${cp.ctr||''}" type="number" step="0.01" placeholder="0.00"></div>
        </div>`).join('');
      return`<input type="hidden" id="camp-count" value="${campaigns.length}">
        ${campRows}
        <button type="button" class="btn btn-g btn-sm" style="margin-bottom:12px" onclick="BUILDER._addCampaignSlot()">+ Add campaign</button>
        <div class="fg"><label class="fl">Layout</label><select class="fi" id="cb-width"><option value="full" ${sw2==='full'?'selected':''}>Full width</option><option value="half" ${sw2==='half'?'selected':''}>Half width</option></select></div>`;
    }
    return`<div class="fg"><label class="fl">Block title</label><input class="fi" id="cb-title-val" placeholder="Block title"></div>
    <div class="fg"><label class="fl">Layout</label><select class="fi" id="cb-width"><option value="full"${existingWidth==='full'?' selected':''}>Full width</option><option value="half"${existingWidth==='half'?' selected':''}>Half width</option></select></div>`;
  },
  saveBlockConfig(){
    const id=this._currentBlockId; const type=this._currentBlockType;
    if(!id) return;
    const el=document.getElementById(id); if(!el) return;
    const width=document.getElementById('cb-width')?.value||'full';
    if(this._blockRegistry[id]) this._blockRegistry[id].width=width;
    el.className=el.className.replace(/blk-full|blk-half/g,'').trim()+' blk-'+width;
    el.style.borderColor='var(--bd0)';
    // Clear ALL existing content before rebuild — prevents duplication on re-edit
    el.innerHTML='';
    // Build rendered content
    let html='';
    if(type==='kpi_card'||type==='kpi_row'){
      const n=parseInt(document.getElementById('cb-count')?.value||1);
      const metricsSaved=[];
      html='<div class="gauto">';
      for(let i=0;i<n;i++){
        const lbl=document.getElementById('cb-label-'+i)?.value;
        if(!lbl) continue; // skip empty slots
        const val=parseFloat(document.getElementById('cb-val-'+i)?.value||0);
        const unit=document.getElementById('cb-unit-'+i)?.value||'count';
        const tgt=parseFloat(document.getElementById('cb-target-'+i)?.value)||null;
        const link=document.getElementById('cb-link-'+i)?.value||'';
        metricsSaved.push({label:lbl,value:val,unit,target:tgt,link});
        const fv=unit==='currency_gbp'?(val>=1000?'£'+(val/1000).toFixed(0)+'k':'£'+val.toLocaleString()):unit==='percentage'?val+'%':val.toLocaleString();
        html+=`<div class="kpi g"${link?` style="cursor:pointer" onclick="window.open('${link}','_blank')"`:''}><div class="klbl">${lbl}${link?'<span style="margin-left:5px;font-size:9px;opacity:.5">↗</span>':''}</div><div class="kval">${fv}</div>${tgt?`<div class="ksub">Target: ${F.short(tgt,unit)}</div>`:''}</div>`;
      }
      html+='</div>';
      // Persist to registry for re-editing
      if(this._blockRegistry[id]) this._blockRegistry[id].data.metrics=metricsSaved;
      // Also sync back to the report's live metrics array so data persists across tab switches
      const liveRep=DB.getReport(S.clientId,S.year,S.month);
      if(liveRep){
        for(const ms of metricsSaved){
          const existing=liveRep.metrics.find(m=>m.label===ms.label);
          if(existing){ existing.value_number=ms.value; existing.unit=ms.unit||existing.unit; if(ms.target!==null) existing.target=ms.target; }
          else{ liveRep.metrics.push({key:'blk_'+id+'_'+metricsSaved.indexOf(ms),label:ms.label,value_number:ms.value,unit:ms.unit,target:ms.target,prev:null,is_kpi:false,lower:false}); }
        }
      }
    } else if(type==='text_block'){
      const blkTitle=document.getElementById('cb-blk-title')?.value?.trim()||'';
      const txt=document.getElementById('cb-text')?.value||'';
      if(this._blockRegistry[id]) Object.assign(this._blockRegistry[id].data,{title:blkTitle,text:txt});
      html=(blkTitle?`<div style="font-size:14px;font-weight:600;margin-bottom:8px;color:var(--t0)">${blkTitle}</div>`:'')+`<p style="font-size:13px;line-height:1.7;color:var(--t1)">${txt}</p>`;
    } else if(type==='insight'){
      const txt=document.getElementById('cb-text')?.value||'';
      const tone=document.getElementById('cb-tone')?.value||'g';
      if(this._blockRegistry[id]) Object.assign(this._blockRegistry[id].data,{text:txt,tone});
      html=`<div class="ins ${tone}"><p>${txt}</p></div>`;
    } else if(type==='table'){
      const cols=(document.getElementById('cb-cols')?.value||'').split(',').map(s=>s.trim());
      const rows=(document.getElementById('cb-rows')?.value||'').split('\n').map(r=>r.split(',').map(s=>s.trim()));
      html=`<div style="font-size:14px;font-weight:600;margin-bottom:10px">${document.getElementById('cb-title-val')?.value||''}</div><div style="overflow:auto"><table class="tbl"><thead><tr>${cols.map(c=>`<th>${c}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
    } else if(type==='bar_chart'||type==='line_chart'){
      const canId='cb-chart-'+id;
      const labels=(document.getElementById('cb-cols')?.value||'').split(',').map(s=>s.trim());
      const vals=(document.getElementById('cb-rows')?.value||'').split(',').map(s=>parseFloat(s.trim())||0);
      const colour=document.getElementById('cb-colour')?.value||'#FFD600';
      const title=document.getElementById('cb-title-val')?.value||'';
      const datasrc=document.getElementById('cb-datasrc')?.value||'manual';
      if(this._blockRegistry[id]) Object.assign(this._blockRegistry[id].data,{title,labels:(document.getElementById('cb-cols')?.value||''),values:(document.getElementById('cb-rows')?.value||''),colour,datasrc,_title:title});
      html=`<div style="font-size:14px;font-weight:600;margin-bottom:10px">${title}</div><div style="height:200px"><canvas id="${canId}"></canvas></div>`;
      el.innerHTML=html+'<div style="display:flex;gap:6px;margin-top:8px;border-top:1px solid var(--bd0);padding-top:10px"><button class="btn btn-g btn-sm" onclick="BUILDER.configBlock(this.dataset.bid,this.dataset.bt)" data-bid="'+id+'" data-bt="'+type+'">&#9881; Edit</button><button class="btn btn-r btn-sm" onclick="document.getElementById(this.dataset.bid).remove()" data-bid="'+id+'">Remove</button></div>';
      MODAL.close('modal-config-block');
      setTimeout(()=>{
        const canvas=document.getElementById(canId); if(!canvas) return;
        new Chart(canvas,{type:type==='bar_chart'?'bar':'line',data:{labels,datasets:[{data:vals,backgroundColor:colour,borderColor:colour,borderRadius:5,fill:type==='line_chart',tension:.35}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}}}});
      },50);
      return;
    } else if(type==='donut_chart'){
      const canId='cb-chart-'+id;
      const labels=(document.getElementById('cb-cols')?.value||'').split(',').map(s=>s.trim());
      const vals=(document.getElementById('cb-rows')?.value||'').split(',').map(s=>parseFloat(s.trim())||0);
      const title=document.getElementById('cb-title-val')?.value||'';
      if(this._blockRegistry[id]) Object.assign(this._blockRegistry[id].data,{labels:document.getElementById('cb-cols')?.value||'',values:document.getElementById('cb-rows')?.value||'',title});
      // Add a label summary below the donut for clarity
      const labelSummary=labels.map((l,i)=>'<div style="display:flex;align-items:center;gap:6px;font-size:12px;margin-bottom:4px"><span style="width:10px;height:10px;border-radius:50%;background:'+['#FFD600','#ED7209','#22C55E','#3B82F6','#8B5CF6','#EC4899'][i%6]+';flex-shrink:0;display:inline-block"></span>'+l+(vals[i]!==undefined?' — <strong>'+vals[i]+'</strong>':'')+'</div>').join('');
      el.innerHTML='<div style="font-size:14px;font-weight:600;margin-bottom:10px">'+title+'</div>'
        +'<div class="donut-wrap" style="position:relative;max-width:360px;margin:0 auto"><canvas id="'+canId+'"></canvas></div>'
        +'<div style="margin-top:10px">'+labelSummary+'</div>'
        +'<div style="display:flex;gap:6px;margin-top:10px"><button class="btn btn-g btn-sm" onclick="BUILDER.configBlock(this.dataset.id,this.dataset.t)" data-id="'+id+'" data-t="'+type+'">⚙ Edit</button><button class="btn btn-r btn-sm" onclick="BUILDER.removeBlock(this.dataset.id)" data-id="'+id+'">Remove</button></div>';
      MODAL.close('modal-config-block');
      // Simple init: use responsive mode within the constrained container
      setTimeout(()=>{
        const canvas=document.getElementById(canId); if(!canvas) return;
        const colours=['#FFD600','#ED7209','#22C55E','#3B82F6','#8B5CF6','#EC4899'];
        const isDark=document.documentElement.getAttribute('data-theme')!=='light';
        const tc=isDark?'rgba(255,255,255,.55)':'rgba(0,25,43,.58)';
        if(S.charts&&S.charts[canId]) try{S.charts[canId].destroy();}catch(e){}
        const ch=new Chart(canvas,{type:'doughnut',
          data:{labels,datasets:[{data:vals,backgroundColor:colours.slice(0,vals.length),borderWidth:0}]},
          options:{responsive:true,maintainAspectRatio:true,aspectRatio:1.4,cutout:'58%',
            plugins:{legend:{display:false}}}});  // legend replaced by HTML label summary above
        if(S.charts) S.charts[canId]=ch;
      },80);
      return;
    }
    if(type==='platform_grid'){
      const n=parseInt(document.getElementById('plat-count')?.value||1);
      const platforms=[];
      for(let i=0;i<n;i++){
        const nm=document.getElementById('plat-name-'+i)?.value; if(!nm) continue;
        platforms.push({platform:nm,colour:document.getElementById('plat-col-'+i)?.value||'#888',followers:document.getElementById('plat-fol-'+i)?.value||'',engagement:document.getElementById('plat-eng-'+i)?.value||'',impressions:document.getElementById('plat-imp-'+i)?.value||'',rate:document.getElementById('plat-rate-'+i)?.value||'',comment:document.getElementById('plat-comment-'+i)?.value||'',source:document.getElementById('plat-src-'+i)?.value||'manual'});
      }
      if(this._blockRegistry[id]) this._blockRegistry[id].data.platforms=platforms;
      const fmt=v=>v&&+v>0?(+v>=1000?((+v/1000).toFixed(0)+'k'):(+v).toLocaleString()):'—';
      html=`<div class="platg">${platforms.map(p=>`<div class="platc"><div class="pname"><span class="pdot" style="background:${p.colour}"></span>${p.platform}</div><div class="pstat"><div class="pslbl">Followers</div><div class="psval">${fmt(p.followers)}</div></div><div class="pstat"><div class="pslbl">Engagement</div><div class="psval">${fmt(p.engagement)}</div></div><div class="pstat"><div class="pslbl">Impressions</div><div class="psval">${fmt(p.impressions)}</div></div>${p.rate?`<div class="pstat"><div class="pslbl">Eng Rate</div><div class="psval">${p.rate}%</div></div>`:''} ${p.comment?`<p class="pnote">${p.comment}</p>`:''}</div>`).join('')}</div>`;
    }
    if(type==='email_campaign'){
      const n=parseInt(document.getElementById('camp-count')?.value||1);
      const campaigns=[];
      for(let i=0;i<n;i++){
        const t=document.getElementById('camp-title-'+i)?.value; if(!t) continue;
        campaigns.push({title:t,date:document.getElementById('camp-date-'+i)?.value||'',link:document.getElementById('camp-link-'+i)?.value||'',sent:document.getElementById('camp-sent-'+i)?.value||'',open_rate:document.getElementById('camp-or-'+i)?.value||'',ctr:document.getElementById('camp-ctr-'+i)?.value||''});
      }
      if(this._blockRegistry[id]) this._blockRegistry[id].data.campaigns=campaigns;
      // Build email campaign cards without nested template literals
      const campCards=campaigns.map(cp=>{
        const ds=cp.date?new Date(cp.date).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}):'';
        const or=parseFloat(cp.open_rate||0); const ctr=parseFloat(cp.ctr||0);
        const orCol=or>=40?'var(--g)':or>=25?'var(--am)':'var(--r)';
        const ctrCol=ctr>=2?'var(--g)':ctr>=0.8?'var(--am)':'var(--r)';
        let pb='';
        if(cp.link){
          if(cp.link.includes('mailerlite')) pb='<span style="font-size:9px;background:#09C964;color:#fff;border-radius:3px;padding:1px 5px;font-weight:600">MailerLite</span>';
          else if(cp.link.includes('mailchi')) pb='<span style="font-size:9px;background:#FFE01B;color:#241C15;border-radius:3px;padding:1px 5px;font-weight:600">Mailchimp</span>';
          else if(cp.link.includes('hubspot')) pb='<span style="font-size:9px;background:#FF7A59;color:#fff;border-radius:3px;padding:1px 5px;font-weight:600">HubSpot</span>';
          else if(cp.link.includes('brevo')) pb='<span style="font-size:9px;background:#0B996E;color:#fff;border-radius:3px;padding:1px 5px;font-weight:600">Brevo</span>';
          else pb='<span style="font-size:9px;background:var(--bg2);color:var(--t2);border:1px solid var(--bd0);border-radius:3px;padding:1px 5px">Link</span>';
        }
        // Try to render an iframe preview for supported providers
        let prev='';
        if(cp.link){
          const isMailerLite=cp.link.includes('preview.mailerlite')||cp.link.includes('ml.mailerlite');
          const isMailchimp=cp.link.includes('mailchi.mp')||cp.link.includes('campaign-archive');
          const canEmbed=isMailerLite||isMailchimp;
          // Extract domain for favicon
          let domain=''; try{ domain=new URL(cp.link).hostname; }catch(e){}
          const faviconUrl=domain?'https://www.google.com/s2/favicons?domain='+domain+'&sz=16':'';
          if(canEmbed){
            // Use iframe for providers that allow embedding
            prev='<div style="height:200px;border-bottom:1px solid var(--bd0);position:relative;overflow:hidden;background:#fff">'
              +'<iframe src="'+cp.link+'" style="width:100%;height:100%;border:none;pointer-events:none;transform:scale(0.6);transform-origin:top left;width:167%;height:167%" sandbox="allow-same-origin" loading="lazy" title="'+cp.title+' preview"></iframe>'
              +'<div style="position:absolute;bottom:0;left:0;right:0;height:36px;background:linear-gradient(transparent,var(--bg2));display:flex;align-items:flex-end;justify-content:center;padding-bottom:6px">'
              +'<a href="'+cp.link+'" target="_blank" style="font-size:10.5px;color:#3B82F6;text-decoration:none">Open full email ↗</a></div></div>';
          } else {
            // Rich link card for other URLs
            prev='<div style="height:100px;background:linear-gradient(135deg,var(--bg2),var(--bg3));display:flex;align-items:center;justify-content:center;border-bottom:1px solid var(--bd0)">'
              +'<div style="text-align:center">'
              +(faviconUrl?'<div style="display:flex;align-items:center;justify-content:center;gap:5px;margin-bottom:5px"><img src="'+faviconUrl+'" width="14" height="14" style="border-radius:2px"><span style="font-size:10px;color:var(--t2)">'+domain+'</span></div>':'')
              +'<div style="font-size:12.5px;font-weight:600;margin-bottom:3px">'+cp.title+'</div>'
              +(ds?'<div style="font-size:10px;color:var(--t2)">'+ds+'</div>':'')
              +'<a href="'+cp.link+'" target="_blank" style="font-size:10px;color:#3B82F6;display:block;margin-top:4px">View campaign ↗</a>'
              +'</div></div>';
          }
        }
        const stats=[
          cp.sent?'<div style="text-align:center;padding:7px;background:var(--bg2);border-radius:var(--rs)"><div style="font-size:9px;color:var(--t2);text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px;font-weight:600">Delivered</div><div style="font-size:16px;font-weight:700">'+(+cp.sent).toLocaleString()+'</div></div>':'',
          cp.open_rate?'<div style="text-align:center;padding:7px;background:var(--bg2);border-radius:var(--rs)"><div style="font-size:9px;color:var(--t2);text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px;font-weight:600">Open rate</div><div style="font-size:16px;font-weight:700;color:'+orCol+'">'+cp.open_rate+'%</div></div>':'',
          cp.ctr?'<div style="text-align:center;padding:7px;background:var(--bg2);border-radius:var(--rs)"><div style="font-size:9px;color:var(--t2);text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px;font-weight:600">CTR</div><div style="font-size:16px;font-weight:700;color:'+ctrCol+'">'+cp.ctr+'%</div></div>':'',
          (cp.open_rate&&cp.ctr)?'<div style="text-align:center;padding:7px;background:var(--bg2);border-radius:var(--rs)"><div style="font-size:9px;color:var(--t2);text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px;font-weight:600">CTOR</div><div style="font-size:16px;font-weight:700">'+((+cp.ctr/+cp.open_rate)*100).toFixed(1)+'%</div></div>':''
        ].filter(Boolean).join('');
        return '<div style="border:1px solid var(--bd0);border-radius:var(--rl);overflow:hidden">'
          +'<div style="background:var(--bg2);padding:10px 14px;display:flex;align-items:flex-start;justify-content:space-between;gap:10px;border-bottom:1px solid var(--bd0)">'
          +'<div style="flex:1"><div style="display:flex;align-items:center;gap:6px;margin-bottom:3px"><div style="font-size:13px;font-weight:700">'+cp.title+'</div>'+pb+'</div>'
          +(ds?'<div style="font-size:10.5px;color:var(--t2)">Sent '+ds+'</div>':'')
          +'</div>'+(cp.link?'<a href="'+cp.link+'" target="_blank" class="btn btn-g btn-sm" style="font-size:10.5px;flex-shrink:0">View ↗</a>':'')+'</div>'
          +prev+'<div style="padding:11px 14px;display:grid;grid-template-columns:repeat(auto-fit,minmax(80px,1fr));gap:8px">'+stats+'</div></div>';
      }).join('');
      html='<div style="display:grid;gap:11px">'+campCards+'</div>'
        +'<div style="margin-top:8px;padding:7px 10px;background:var(--bg2);border-radius:var(--rs);font-size:10px;color:var(--t2)">Manual entry · Future: MailerLite, Mailchimp, HubSpot, Brevo, Klaviyo</div>';
    }
    if(type==='asset_gallery'){
      const assets=this._blockRegistry[id]?.data?.assets||[];
      html=`<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px">${assets.map((a,i)=>`<div style="background:var(--bg2);border-radius:var(--rs);padding:10px;position:relative"><div style="font-size:28px;margin-bottom:6px;text-align:center">${a.img?`<img src="${a.img}" style="width:100%;height:80px;object-fit:cover;border-radius:4px">`:a.icon||'🖼'}</div><div style="font-size:12px;font-weight:600;margin-bottom:3px">${a.title}</div>${a.desc?`<div style="font-size:10.5px;color:var(--t1)">${a.desc}</div>`:''}<div style="position:absolute;top:5px;right:5px;display:flex;gap:3px"><button class="btn btn-g btn-sm" style="font-size:9px;padding:2px 5px" onclick="BUILDER.editGalleryAsset('${id}',${i})">✎</button><button class="btn btn-r btn-sm" style="font-size:9px;padding:2px 5px" onclick="BUILDER.removeGalleryAsset('${id}',${i})">✕</button></div></div>`).join('')}<div style="border:1px dashed var(--bd1);border-radius:var(--rs);padding:16px;display:flex;align-items:center;justify-content:center;cursor:pointer;min-height:80px" onclick="BUILDER.addGalleryAsset('${id}')"><span style="font-size:12px;color:var(--t2)">+ Add asset</span></div></div>`;
    }
    if(type==='task_list'){
      const tasks=this._blockRegistry[id]?.data?.tasks||[];
      let taskHtmlStr='';
      for(let i=0;i<tasks.length;i++){
        const t=tasks[i];
        taskHtmlStr+='<li class="taskitem">';
        taskHtmlStr+='<span class="tchk '+(t.done?'tdone':'ttodo')+'" onclick="BUILDER.toggleTask(\'' +id+'\','+i+')" style="cursor:pointer;flex-shrink:0">'+(t.done?'✓':'')+'</span>';
        taskHtmlStr+='<span style="flex:1;'+(t.done?'text-decoration:line-through;opacity:.5':'')+'">'+t.text+'</span>';
        taskHtmlStr+='<button class="btn btn-r btn-sm" style="font-size:9px;padding:1px 5px" onclick="BUILDER.removeTaskItem(\'' +id+'\','+i+')">✕</button>';
        taskHtmlStr+='</li>';
      }
      html='<div class="blk-tasklist-wrap"><ul class="tasklist" style="margin-bottom:8px">'+taskHtmlStr+'</ul>'
        +'<button class="btn btn-g btn-sm" style="font-size:10.5px;width:100%;margin-top:0" onclick="BUILDER.addTaskItem(\'' +id+'\')">+ Add task</button></div>';
    }
    // Update the block element
    // Rebuild the entire block element: header + content
    const typeLabel2={kpi_card:'KPI Card',kpi_row:'KPI Row',bar_chart:'Bar Chart',line_chart:'Line Chart',donut_chart:'Donut Chart',platform_grid:'Platforms',table:'Table',task_list:'Tasks',insight:'Insight',asset_gallery:'Assets',text_block:'Text',email_campaign:'Email',divider:'Divider'};
    const title_saved=this._blockRegistry[id]?.data?.title||'';
    const displayLabel=title_saved||typeLabel2[type]||type;
    const headerHtml=`<div class="blk-ctrl" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;gap:8px">
      <div style="display:flex;align-items:center;gap:7px;flex:1;min-width:0">
        <span style="color:var(--t2);cursor:grab;font-size:16px;flex-shrink:0" title="Drag to reorder">⠿</span>
        <span style="font-size:12px;font-weight:600;color:var(--t1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis" id="blk-hd-${id}">${displayLabel}</span>
      </div>
      <div style="display:flex;gap:5px;align-items:center;flex-shrink:0">
        <select style="background:var(--inp);border:1px solid var(--inpb);border-radius:var(--rs);padding:3px 7px;font-size:10.5px;color:var(--t0)" onchange="BUILDER.setBlockWidth('${id}',this.value)">
          <option value="full" ${(this._blockRegistry[id]?.width||'full')==='full'?'selected':''}>Full width</option>
          <option value="half" ${(this._blockRegistry[id]?.width||'full')==='half'?'selected':''}>Half width</option>
        </select>
        <button class="btn btn-g btn-sm" onclick="BUILDER.configBlock('${id}','${type}')">Edit</button>
        <button class="btn btn-r btn-sm" onclick="BUILDER.removeBlock('${id}')">✕</button>
      </div>
    </div>`;
    el.innerHTML=headerHtml+html;
    MODAL.close('modal-config-block');
  },
  // Gallery helpers
  addGalleryAsset(blockId){
    document.getElementById('ga-modal-title').textContent='Add asset';
    document.getElementById('ga-title').value='';
    document.getElementById('ga-desc').value='';
    document.getElementById('ga-icon').value='🖼';
    document.getElementById('ga-img').value='';
    document.getElementById('ga-block-id').value=blockId;
    document.getElementById('ga-asset-idx').value='';
    MODAL.open('modal-gallery-asset');
  },
  editGalleryAsset(blockId,idx){
    const reg=this._blockRegistry[blockId]; if(!reg) return;
    const a=reg.data.assets?.[idx]; if(!a) return;
    document.getElementById('ga-modal-title').textContent='Edit asset';
    document.getElementById('ga-title').value=a.title||'';
    document.getElementById('ga-desc').value=a.desc||'';
    document.getElementById('ga-icon').value=a.icon||'🖼';
    document.getElementById('ga-block-id').value=blockId;
    document.getElementById('ga-asset-idx').value=idx;
    MODAL.open('modal-gallery-asset');
  },
  saveGalleryAsset(){
    const blockId=document.getElementById('ga-block-id').value;
    const idx=document.getElementById('ga-asset-idx').value;
    const title=document.getElementById('ga-title').value.trim(); if(!title) return;
    const desc=document.getElementById('ga-desc').value.trim();
    const icon=document.getElementById('ga-icon').value||'🖼';
    const imgInput=document.getElementById('ga-img');
    const reg=this._blockRegistry[blockId]; if(!reg) return;
    if(!reg.data.assets) reg.data.assets=[];
    const doSave=(imgData)=>{
      if(idx!==''){
        const a=reg.data.assets[parseInt(idx)]; if(a) Object.assign(a,{title,desc,icon,img:imgData||a.img});
      } else { reg.data.assets.push({title,desc,icon,img:imgData||null}); }
      this._currentBlockId=blockId; this._currentBlockType='asset_gallery';
      MODAL.close('modal-gallery-asset');
      this.saveBlockConfig();
    };
    if(imgInput.files[0]){ const r=new FileReader(); r.onload=e=>doSave(e.target.result); r.readAsDataURL(imgInput.files[0]); }
    else doSave(null);
  },
  removeGalleryAsset(blockId,idx){
    const reg=this._blockRegistry[blockId]; if(!reg?.data?.assets) return;
    reg.data.assets.splice(idx,1);
    this._currentBlockId=blockId; this._currentBlockType='asset_gallery';
    this.saveBlockConfig();
  },
  // Task list helpers
  addTaskItem(blockId){
    document.getElementById('ti-text').value='';
    document.getElementById('ti-done').checked=false;
    document.getElementById('ti-block-id').value=blockId;
    MODAL.open('modal-task-item');
  },
  saveTaskItem(){
    const blockId=document.getElementById('ti-block-id').value;
    const text=document.getElementById('ti-text').value.trim(); if(!text) return;
    const done=document.getElementById('ti-done').checked;
    if(!this._blockRegistry[blockId]) return;
    if(!this._blockRegistry[blockId].data.tasks) this._blockRegistry[blockId].data.tasks=[];
    this._blockRegistry[blockId].data.tasks.push({text,done});
    this._currentBlockId=blockId; this._currentBlockType='task_list';
    MODAL.close('modal-task-item');
    this.saveBlockConfig();
  },
  toggleTask(blockId,idx){
    const reg=this._blockRegistry[blockId]; if(!reg?.data?.tasks) return;
    const t=reg.data.tasks[idx]; if(t) t.done=!t.done;
    this._currentBlockId=blockId; this._currentBlockType='task_list';
    this.saveBlockConfig();
  },
  removeTaskItem(blockId,idx){
    const reg=this._blockRegistry[blockId]; if(!reg?.data?.tasks) return;
    reg.data.tasks.splice(idx,1);
    this._currentBlockId=blockId; this._currentBlockType='task_list';
    this.saveBlockConfig();
  },
  // Platform + campaign slot helpers
  _addPlatformSlot(){
    const n=parseInt(document.getElementById('plat-count')?.value||0);
    const slot=document.createElement('div'); slot.id='plat-slot-'+n; slot.className='card'; slot.style.marginBottom='8px';
    slot.innerHTML=`<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px"><div style="font-size:11px;font-weight:600;color:var(--o)">Platform ${n+1}</div><button type="button" class="btn btn-r btn-sm" style="font-size:9.5px" onclick="this.closest('[id^=plat-slot]').remove()">Remove</button></div><div class="g2"><div class="fg"><label class="fl">Platform name</label><input class="fi" id="plat-name-${n}" placeholder="Instagram"></div><div class="fg"><label class="fl">Brand colour</label><input class="fi" type="color" id="plat-col-${n}" value="#E1306C"></div></div><div class="g2"><div class="fg"><label class="fl">Followers</label><input class="fi" id="plat-fol-${n}" type="number" placeholder="0"></div><div class="fg"><label class="fl">Engagement</label><input class="fi" id="plat-eng-${n}" type="number" placeholder="0"></div></div><div class="g2"><div class="fg"><label class="fl">Impressions</label><input class="fi" id="plat-imp-${n}" type="number" placeholder="0"></div><div class="fg"><label class="fl">Engagement rate %</label><input class="fi" id="plat-rate-${n}" type="number" step="0.01" placeholder="0.00"></div></div><div class="fg"><label class="fl">Comment</label><input class="fi" id="plat-comment-${n}" placeholder="Optional note"></div>`;
    document.getElementById('plat-count').value=n+1;
    const addBtn=document.querySelector('#cb-body button');
    if(addBtn) addBtn.before(slot); else document.getElementById('cb-body').appendChild(slot);
  },
  _addCampaignSlot(){
    const n=parseInt(document.getElementById('camp-count')?.value||0);
    const slot=document.createElement('div'); slot.id='camp-slot-'+n; slot.className='card'; slot.style.marginBottom='8px';
    slot.innerHTML=`<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px"><div style="font-size:11px;font-weight:600;color:var(--o)">Campaign ${n+1}</div><button type="button" class="btn btn-r btn-sm" style="font-size:9.5px" onclick="this.closest('[id^=camp-slot]').remove()">Remove</button></div><div class="g2"><div class="fg"><label class="fl">Campaign title</label><input class="fi" id="camp-title-${n}" placeholder="Monthly newsletter"></div><div class="fg"><label class="fl">Send date</label><input class="fi" type="date" id="camp-date-${n}"></div></div><div class="fg"><label class="fl">Link to email</label><input class="fi" id="camp-link-${n}" placeholder="https://…"></div><div class="g2"><div class="fg"><label class="fl">Sent</label><input class="fi" id="camp-sent-${n}" type="number" placeholder="0"></div><div class="fg"><label class="fl">Open rate %</label><input class="fi" id="camp-or-${n}" type="number" step="0.1" placeholder="0.0"></div></div>`;
    document.getElementById('camp-count').value=n+1;
    const addBtn=document.querySelector('#cb-body button');
    if(addBtn) addBtn.before(slot); else document.getElementById('cb-body').appendChild(slot);
  },
  addSection(){ const name=prompt('Section name:'); if(!name) return; alert(`Section "${name}" added — in production this creates a new module tab and stores it in the report's module config.`); },
};

/* SETTINGS */
const SETTINGS = {
  load(){
    const u=S.user; if(!u) return;
    const av=document.getElementById('settings-av');
    if(av){ if(u.avatar) av.innerHTML=`<img src="${u.avatar}" alt="">`; else { av.innerHTML=''; av.textContent=u.initials; av.style.background=u.role==='admin'?'#ED7209':'#4A7FA5'; av.style.color='#fff'; av.style.fontSize='24px'; av.style.fontWeight='700'; av.style.display='flex'; av.style.alignItems='center'; av.style.justifyContent='center'; } }
    const n=document.getElementById('s-name'); if(n) n.value=u.name;
    const e=document.getElementById('s-email'); if(e) e.value=u.email;
    const sig=document.getElementById('s-sig'); if(sig) sig.value=u.signature||'';
    const ep=document.getElementById('s-eprov'); if(ep) ep.value=u.email_provider||'system';
    // Load Scooby config
    const sn=document.getElementById('s-scooby-name'); if(sn) sn.value=SCOOBY_CONFIG.name;
    const sav=document.getElementById('s-scooby-av');
    if(sav){ if(SCOOBY_CONFIG.avatar) sav.innerHTML=`<img src="${SCOOBY_CONFIG.avatar}" style="width:100%;height:100%;object-fit:cover;border-radius:50%">`; else sav.textContent=SCOOBY_CONFIG.emoji; }
    // Pre-fill send signature
    const sendSig=document.getElementById('send-sig'); if(sendSig&&u.signature) sendSig.value=u.signature;
    const sigPrev=document.getElementById('send-sig-preview'); if(sigPrev&&u.signature){ sigPrev.style.display='block'; sigPrev.innerHTML=u.signature; }
  },
  save(){
    const u=S.user; if(!u) return;
    const name=document.getElementById('s-name')?.value;
    const sig=document.getElementById('s-sig')?.value;
    const ep=document.getElementById('s-eprov')?.value;
    const pw=document.getElementById('s-pass')?.value;
    const updates={};
    if(name) updates.name=name;
    if(sig!==undefined) updates.signature=sig;
    if(ep) updates.email_provider=ep;
    if(pw) updates.pass=pw;
    // Save Scooby config
    const scoobyName=document.getElementById('s-scooby-name')?.value?.trim();
    if(scoobyName) SCOOBY_CONFIG.name=scoobyName;
    AI.init();
    DB.updateUser(u.id,updates);
    Object.assign(u,updates);
    // Update topbar name
    document.getElementById('uname').textContent=u.name;
    // Update send signature
    const sendSig=document.getElementById('send-sig'); if(sendSig) sendSig.value=sig||'';
    const sigPrev=document.getElementById('send-sig-preview'); if(sigPrev&&sig){ sigPrev.style.display='block'; sigPrev.innerHTML=sig; } else if(sigPrev){ sigPrev.style.display='none'; }
    const ok=document.getElementById('s-ok'); if(ok){ ok.style.display='block'; setTimeout(()=>ok.style.display='none',2500); }
  },
  updateAvatar(input){
    const f=input.files[0]; if(!f) return;
    const r=new FileReader();
    r.onload=e=>{ const u=S.user; if(!u) return; DB.updateUser(u.id,{avatar:e.target.result}); u.avatar=e.target.result; AUTH._updateAvatar(u); this.load(); };
    r.readAsDataURL(f);
  },
  updateScoobyAvatar(input){
    const f=input.files[0]; if(!f) return;
    const r=new FileReader();
    r.onload=e=>{ SCOOBY_CONFIG.avatar=e.target.result; AI.init(); this.load(); };
    r.readAsDataURL(f);
  },
};

/* EMAIL */
const EMAIL = {
  populateClients(){
    const sel=document.getElementById('send-client'); if(!sel) return;
    sel.innerHTML=DB.getParents().map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
    this.populateReports();
  },
  populateReports(){
    const cid=document.getElementById('send-client')?.value;
    const sel=document.getElementById('send-report'); if(!sel||!cid) return;
    sel.innerHTML=DB.getAllSummaries().filter(s=>s.client_id===cid).map(s=>`<option value="${s.client_id}|${s.year}|${s.month}">${s.month} ${s.year} — ${s.status}</option>`).join('');
  },
  preview(){
    const cid=document.getElementById('send-client')?.value;
    const c=DB.getClient(cid);
    const to=document.getElementById('send-to')?.value;
    const msg=document.getElementById('send-msg')?.value;
    const sig=document.getElementById('send-sig')?.value||S.user?.signature||'';
    const box=document.getElementById('send-preview-box'); if(!box) return;
    box.style.display='block';
    box.innerHTML=`<strong>To:</strong> ${to||'(recipients)'}<br><strong>Subject:</strong> ${c?.name||''} — Your report is ready<br><strong>From:</strong> ${S.user?.name||''} via Karbon Creative<br>${msg?`<br>${msg}<br>`:''}<br>${sig?`<hr style="border-color:var(--bd0);margin:8px 0"><div style="font-size:11.5px">${sig}</div>`:''}`;
  },
  send(){
    const cid=document.getElementById('send-client')?.value;
    const rv=document.getElementById('send-report')?.value;
    const to=document.getElementById('send-to')?.value.trim();
    if(!cid||!rv||!to) return;
    const[rcid,yr,mon]=rv.split('|');
    DB.logEmail({sent_by:S.user?.id,sent_by_name:S.user?.name,client_id:cid,year:yr,month:mon,recipients:to,message:document.getElementById('send-msg')?.value,provider:S.user?.email_provider||'system'});
    const ok=document.getElementById('send-ok'); if(ok){ ok.style.display='block'; setTimeout(()=>ok.style.display='none',3000); }
  },
  buildLog(){
    const el=document.getElementById('email-log-list'); if(!el) return;
    const log=DB.getLog();
    if(!log.length){ el.innerHTML='<p style="font-size:13px;color:var(--t1)">No emails sent yet.</p>'; return; }
    el.innerHTML=`<div class="card"><table class="tbl" style="font-size:12px"><thead><tr><th>Date</th><th>Sent by</th><th>Client</th><th>Report</th><th>Recipients</th><th>Provider</th></tr></thead><tbody>${log.map(e=>`<tr><td>${F.date(e.sent_at)}</td><td>${e.sent_by_name||'—'}</td><td>${DB.getClient(e.client_id)?.name||e.client_id}</td><td>${e.month} ${e.year}</td><td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${e.recipients}</td><td>${e.provider}</td></tr>`).join('')}</tbody></table></div>`;
  },
};

/* YEAR VIEW */
const YV = {
  cid:'cl-bl', yr:2026, cmpYr:null,
  build(preserveCid){
    if(!preserveCid){ 
      // Default to current active client, not just any parent
      this.cid=S.clientId||DB.getParents()[0]?.id; 
    }
    const yrs=DB.getYears(this.cid);
    if(!yrs.includes(this.yr)) this.yr=yrs[yrs.length-1]||2026;
    const btns=document.getElementById('yv-btns');
    if(btns){
      // Client users only see their permitted clients
      const isClient=S.user?.role==='client';
      const allowedClients=isClient
        ? DB.getParents().filter(c=>S.user.client_ids.includes(c.id))
        : DB.getParents();
      const clientBtns=allowedClients.map(c=>`<button class="mbtn${c.id===this.cid?' on':''}" onclick="YV.setC('${c.id}')">${c.name}</button>`).join('');
      const yrBtns=yrs.length>1?'<div class="msep"></div>'+yrs.map(y=>`<button class="mbtn${y===this.yr?' on':''}" onclick="YV.setYr(${y})">${y}</button>`).join(''):'';
      const cmpSel=yrs.length>1?'<div class="msep"></div><select class="mysel" onchange="YV.setCmpYr(+this.value)"><option value="0">No comparison</option>'+yrs.map(y=>'<option value="'+y+'"'+(y===this.cmpYr?' selected':'')+'>'+y+'</option>').join('')+'</select>':'';
      btns.innerHTML=clientBtns+yrBtns+cmpSel;
    }
    this._render();
  },
  setC(id){ this.cid=id; this.yr=DB.getYears(id).slice(-1)[0]||2026; this.cmpYr=null; this.build(true); },
  setYr(y){ this.yr=y; this.build(true); },
  setCmpYr(y){ this.cmpYr=y||null; this._render(); },
  _render(){
    const c=DB.getClient(this.cid); if(!c) return;
    const yr=this.yr;
    const mons=DB.getMonths(this.cid,yr);
    const isGT=this.cid==='cl-gt';
    const isTD=this.cid==='cl-td';
    const grid=document.getElementById('yv-months');
    const delta=(curr,prev)=>{
      if(prev===null||prev===undefined||!this.cmpYr||!prev) return '';
      const pct=Math.round((curr-prev)/Math.abs(prev)*100);
      const col=pct>=0?'var(--g)':'var(--r)';
      return '<span style="font-size:10px;font-weight:600;color:'+col+';margin-left:4px">'+(pct>0?'↑':'↓')+Math.abs(pct)+'%</span>';
    };
    if(grid) grid.innerHTML=mons.map(m=>{
      const r=DB.getReport(this.cid,yr,m); if(!r) return'';
      const mv=k=>r.metrics.find(x=>x.key===k)?.value_number||0;
      const rcmp=this.cmpYr?DB.getReport(this.cid,this.cmpYr,m):null;
      const cv=k=>rcmp?.metrics.find(x=>x.key===k)?.value_number??null;
      return`<div class="yvcard" onclick="NAV.openReport('${this.cid}')">
        <div class="yvmonth">${DB.ML[m]} ${yr}${this.cmpYr?' <span style="font-size:9.5px;color:var(--t2)">vs '+this.cmpYr+'</span>':''} <span style="font-size:10px;color:var(--o)">${m}</span></div>
        ${isGT?`
          <div class="yvstat"><span>Revenue</span><strong>£${(mv('revenue_web')/1000).toFixed(1)}k</strong>${delta(mv('revenue_web'),cv('revenue_web'))}</div>
          <div class="yvstat"><span>Users</span><strong>${mv('web_users').toLocaleString()}</strong>${delta(mv('web_users'),cv('web_users'))}</div>
          <div class="yvstat"><span>Social Eng. YTD</span><strong>${mv('social_eng').toLocaleString()}</strong></div>
        `:`
          <div class="yvstat"><span>CCH Revenue</span><strong>£${(mv('revenue_cch')/1000).toFixed(0)}k</strong>${delta(mv('revenue_cch'),cv('revenue_cch'))}</div>
          <div class="yvstat"><span>KK Revenue YTD</span><strong>£${(mv('revenue_kk_ytd')/1000).toFixed(0)}k</strong>${delta(mv('revenue_kk_ytd'),cv('revenue_kk_ytd'))}</div>
          <div class="yvstat"><span>Social Views</span><strong>${mv('social_views')>=1e6?(mv('social_views')/1e6).toFixed(2)+'M':(mv('social_views')/1000).toFixed(0)+'k'}</strong>${delta(mv('social_views'),cv('social_views'))}</div>
          <div class="yvstat"><span>Web Users</span><strong>${mv('web_users').toLocaleString()}</strong>${delta(mv('web_users'),cv('web_users'))}</div>
        `}
        <div style="font-size:11px;color:var(--o);margin-top:7px">View full report →</div>
      </div>`;
    }).join('');
    // Charts
    const revKey=isGT?'revenue_web':'revenue_cch';
    const socKey=isGT?'social_eng':'social_views';
    const rv=mons.map(m=>DB.getReport(this.cid,yr,m)?.metrics.find(x=>x.key===revKey)?.value_number||0);
    const sv=mons.map(m=>DB.getReport(this.cid,yr,m)?.metrics.find(x=>x.key===socKey)?.value_number||0);
    const rvCmp=this.cmpYr?mons.map(m=>DB.getReport(this.cid,this.cmpYr,m)?.metrics.find(x=>x.key===revKey)?.value_number||0):null;
    const isdark=document.documentElement.getAttribute('data-theme')!=='light';
    const bg0=isdark?'rgba(255,255,255,.06)':'rgba(0,25,43,.06)';
    const tc=isdark?'rgba(255,255,255,.45)':'rgba(0,25,43,.45)';
    const axO={responsive:true,maintainAspectRatio:false,animation:{duration:600},plugins:{legend:{display:false}},scales:{x:{ticks:{color:tc,font:{size:10.5}},grid:{color:bg0}},y:{ticks:{color:tc,font:{size:10.5}},grid:{color:bg0}}}};
    CHARTS.destroy('yv-rev'); CHARTS.destroy('yv-soc');
    const rvc=document.getElementById('yv-rev');
    if(rvc){
      const revDs=[{data:rv,borderColor:'#FFD600',backgroundColor:'rgba(255,214,0,.07)',borderWidth:2,pointRadius:5,pointBackgroundColor:'#FFD600',tension:.35,fill:true,label:String(yr)}];
      if(rvCmp) revDs.push({data:rvCmp,borderColor:'#ED7209',backgroundColor:'transparent',borderWidth:1.5,pointRadius:3,borderDash:[5,3],tension:.35,fill:false,label:String(this.cmpYr)});
      const showLegend=!!rvCmp;
      S.charts['yv-rev']=new Chart(rvc,{type:'line',data:{labels:mons,datasets:revDs},options:{...axO,plugins:{legend:{display:showLegend,labels:{color:tc,font:{size:10.5},boxWidth:10}}},scales:{...axO.scales,y:{...axO.scales.y,ticks:{...axO.scales.y.ticks,callback:v=>'£'+(v/1000).toFixed(0)+'k'}}}}});
    }
    const svc=document.getElementById('yv-soc');
    if(svc) S.charts['yv-soc']=new Chart(svc,{type:'bar',data:{labels:mons,datasets:[{data:sv,backgroundColor:'#ED7209',borderRadius:5}]},options:{...axO,scales:{...axO.scales,y:{...axO.scales.y,ticks:{...axO.scales.y.ticks,callback:v=>v>=1000?(v/1000).toFixed(0)+'k':v}}}}});
    // Traffic trend
    const tvKey='web_users';
    const tv=mons.map(m=>DB.getReport(this.cid,yr,m)?.metrics.find(x=>x.key===tvKey)?.value_number||0);
    const tvCmp=this.cmpYr?mons.map(m=>DB.getReport(this.cid,this.cmpYr,m)?.metrics.find(x=>x.key===tvKey)?.value_number||0):null;
    const tvc=document.getElementById('yv-traffic');
    if(tvc){
      CHARTS.destroy('yv-traffic');
      const tvDs=[{data:tv,borderColor:'#3B82F6',backgroundColor:'rgba(59,130,246,.07)',borderWidth:2,pointRadius:4,tension:.35,fill:true,label:String(yr)}];
      if(tvCmp) tvDs.push({data:tvCmp,borderColor:'rgba(59,130,246,.4)',backgroundColor:'transparent',borderWidth:1.5,borderDash:[4,3],pointRadius:3,tension:.35,fill:false,label:String(this.cmpYr)});
      S.charts['yv-traffic']=new Chart(tvc,{type:'line',data:{labels:mons,datasets:tvDs},options:{...axO,plugins:{legend:{display:!!tvCmp,labels:{color:tc,font:{size:10},boxWidth:8}}},scales:{...axO.scales,y:{...axO.scales.y,ticks:{...axO.scales.y.ticks,callback:v=>v>=1000?(v/1000).toFixed(0)+'k':v}}}}});
    }
    // KPI achievement radar/line — show % achieved vs expected per KPI over months
    const kpiMons=mons.filter(m=>DB.getReport(this.cid,yr,m));
    const kpis=kpiMons.length?DB.getReport(this.cid,yr,kpiMons[0])?.metrics.filter(m=>m.is_kpi&&m.target)||[]:[];
    const kvc=document.getElementById('yv-kpi');
    if(kvc&&kpis.length){
      CHARTS.destroy('yv-kpi');
      const kpiDs=kpis.slice(0,3).map((k,i)=>({
        label:k.label,
        data:mons.map(m=>{
          const r=DB.getReport(this.cid,yr,m); if(!r) return null;
          const km=r.metrics.find(x=>x.key===k.key); if(!km||!km.target||!km.value_number) return null;
          return Math.round((km.value_number/km.target)*100);
        }),
        borderColor:['#FFD600','#ED7209','#22C55E'][i],
        backgroundColor:'transparent',borderWidth:2,pointRadius:4,tension:.3,fill:false,
      }));
      S.charts['yv-kpi']=new Chart(kvc,{type:'line',data:{labels:mons,datasets:kpiDs},options:{...axO,plugins:{legend:{display:true,labels:{color:tc,font:{size:10},boxWidth:8}}},scales:{...axO.scales,y:{...axO.scales.y,min:0,max:130,ticks:{...axO.scales.y.ticks,callback:v=>v+'%'}}}}});
    } else if(kvc){
      CHARTS.destroy('yv-kpi');
      kvc.getContext('2d').fillStyle=tc; kvc.getContext('2d').fillText('No KPI target data available',10,80);
    }
  },
};

/* MODALS */
const INTEL = {
  // ── AUDIT LOG ──
  _log:[],
  record(action,detail){
    const entry={ts:new Date().toISOString(),user:S.user?.name||'System',action,detail};
    this._log.unshift(entry);
    // Also push to central audit log
    RV_DB.audit(action, S.user?.name||'System', {
      icon:'', area:'Reporting', type:'system', detail:detail||action
    });
    this._refreshAuditIfOpen();
  },

  _refreshAuditIfOpen(){
    const vRv=document.getElementById('v-rv-activity');
    const vRep=document.getElementById('v-audit');
    const isOpen=(vRv&&vRv.classList.contains('on'))||(vRep&&vRep.classList.contains('on'));
    if(isOpen) this.buildAudit();
  },

  buildAudit(){
    const el=document.getElementById('rv-activity-list')||document.getElementById('audit-list'); if(!el) return;
    const log=RV_DB.getAuditLog();
    const _allAuditEls=[document.getElementById('rv-activity-list'),document.getElementById('audit-list')].filter(Boolean);
    const _setAuditHtml=function(html){ _allAuditEls.forEach(function(e){ e.innerHTML=html; }); };
    console.log('[AUDIT READ] log length='+log.length, log[0]||'empty');
    if(!log.length){
      _setAuditHtml('<p style="font-size:13px;color:var(--t2);padding:20px 0">No activity yet. Events are recorded as you work.</p>');
      return;
    }
    const relTime=ts=>{
      const d=Date.now()-new Date(ts);
      if(d<60000) return Math.floor(d/1000)+'s ago';
      if(d<3600000) return Math.floor(d/60000)+'m ago';
      if(d<86400000) return Math.floor(d/3600000)+'h ago';
      return new Date(ts).toLocaleDateString('en-GB',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});
    };
    const areaCol={Review:'var(--o)',Reporting:'#3B82F6','Users & Access':'#8B5CF6',System:'var(--t2)'};
    _setAuditHtml('<div class="card" style="padding:0;overflow:hidden"><table class="tbl" style="font-size:12px">'
      +'<thead><tr><th style="width:100px">Time</th><th>Action</th><th>User</th><th>Job / Client</th><th style="width:90px">Area</th></tr></thead>'
      +'<tbody>'+log.map(e=>{
        const col=areaCol[e.area]||'var(--t2)';
        const jobLink=e.jobId?'<span data-jid="'+e.jobId+'" onclick="RV.openJob(this.dataset.jid)" style="cursor:pointer;color:var(--o)">'+( e.jobTitle||e.jobId)+'</span>':(e.jobTitle||'—');
        const client=e.clientName?'<span style="color:var(--t2)"> · '+e.clientName+'</span>':'';
        return'<tr>'
          +'<td style="color:var(--t2);white-space:nowrap;padding:9px 12px">'+relTime(e.ts)+'</td>'
          +'<td style="padding:9px 12px;font-weight:500">'+(e.detail||e.action)+'</td>'
          +'<td style="padding:9px 12px;color:var(--t2)">'+e.user+'</td>'
          +'<td style="padding:9px 12px;max-width:220px;overflow:hidden;text-overflow:ellipsis">'+jobLink+client+'</td>'
          +'<td style="padding:9px 12px"><span style="font-size:9px;font-weight:700;padding:2px 6px;border-radius:4px;background:'+col+'22;color:'+col+'">'+( e.area||'Review')+'</span></td>'
          +'</tr>';
      }).join('')+'</tbody></table></div>')
  },

  // ── FORECASTING ──
  buildForecast(){
    const el=document.getElementById('forecast-content'); if(!el) return;
    const all=DB.getAllSummaries();
    if(!all.length){ el.innerHTML='<p style="font-size:13px;color:var(--t1)">No report data available.</p>'; return; }
    const byClient={};
    for(const s of all){
      if(!byClient[s.client_id]) byClient[s.client_id]={name:s.client_name,cid:s.client_id,reports:[]};
      byClient[s.client_id].reports.push(s);
    }
    const rows=Object.values(byClient).map(({name,cid,reports})=>{
      const c=DB.getClient(cid); if(!c) return{id:cid,name,html:'',ahead:0,track:0,behind:0};
      // Use most recent report
      const latestRep=reports.sort((a,b)=>b.year-a.year||DB.MONTHS.indexOf(b.month)-DB.MONTHS.indexOf(a.month))[0];
      const kpis=DB.getMetrics(cid,latestRep.year,latestRep.month).filter(m=>m.is_kpi&&m.target&&m.value_number!==null);
      let ahead=0,track=0,behind=0;
      const cards=kpis.map(m=>{
        const exp=DB.kpiExpected(cid,latestRep.month);
        const progress=m.lower?Math.max(0,(m.target-m.value_number)/m.target+1):m.value_number/m.target;
        const pace=progress/Math.max(exp,0.001);
        const forecast=Math.round(m.lower?(m.target-(progress*m.target)):Math.min((progress/Math.max(exp,0.001))*m.target,m.target*5));
        const pct=Math.round(progress*100);
        const expPct=Math.round(exp*100);
        const status=pace>=0.95?'Ahead':pace>=0.8?'On Track':'Behind';
        if(status==='Ahead') ahead++;
        else if(status==='On Track') track++;
        else behind++;
        const barW=Math.min(pct,100);
        const barCol=pace>=0.95?'var(--g)':pace>=0.8?'var(--am)':'var(--r)';
        const scls=pace>=0.95?'bg':pace>=0.8?'ba':'br';
        return`<div style="padding:12px 0;border-bottom:1px solid var(--bd0)">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
            <div style="font-size:13px;font-weight:600">${m.label}</div>
            <span class="badge ${scls}" style="font-size:10.5px">${status}</span>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;font-size:11.5px;margin-bottom:8px">
            <div><div style="color:var(--t2);font-size:9.5px;text-transform:uppercase;letter-spacing:.6px;font-weight:600;margin-bottom:2px">Actual</div><div style="font-weight:600">${F.val(m)}</div></div>
            <div><div style="color:var(--t2);font-size:9.5px;text-transform:uppercase;letter-spacing:.6px;font-weight:600;margin-bottom:2px">Target</div><div style="font-weight:600">${m.lower?'&lt; ':''}${F.short(m.target,m.unit)}</div></div>
            <div><div style="color:var(--t2);font-size:9.5px;text-transform:uppercase;letter-spacing:.6px;font-weight:600;margin-bottom:2px">EOY Forecast</div><div style="font-weight:600">${F.short(forecast,m.unit)}</div></div>
          </div>
          <div style="background:var(--bg2);border-radius:4px;height:6px;overflow:hidden;margin-bottom:3px">
            <div style="height:100%;width:${barW}%;background:${barCol};border-radius:4px;transition:width .6s ease"></div>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--t2)">
            <span>${pct}% achieved</span><span>Expected: ${expPct}%</span>
          </div>
        </div>`;
      }).join('');
      return{id:cid,name,html:cards||'<p style="font-size:12px;color:var(--t1);padding:8px 0">No KPIs with targets set.</p>',ahead,track,behind,latestRep,c};
    });
    const hpill=(n,col,lbl)=>n?`<div style="display:flex;align-items:center;gap:4px;font-size:11.5px;font-weight:600;color:${col}"><span style="width:8px;height:8px;border-radius:50%;background:${col};display:inline-block"></span>${n} ${lbl}</div>`:'';
    el.innerHTML=rows.map(r=>`
      <div class="acc-item" id="fc-acc-${r.id}" style="margin-bottom:10px">
        <div class="acc-hd" onclick="this.closest('.acc-item').classList.toggle('open')">
          <div style="display:flex;align-items:center;gap:10px">
            ${r.c?.logo?`<img src="${r.c.logo}" style="width:22px;height:22px;border-radius:4px;object-fit:contain">`:`<div style="width:22px;height:22px;border-radius:5px;background:${r.c?.brand_colour||'var(--y)'};display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:${r.c?.brand_text||'#000'}">${r.c?.initials||'?'}</div>`}
            <div>
              <div class="acc-name">${r.name}</div>
              <div style="font-size:10.5px;color:var(--t1)">${r.latestRep?`Latest: ${r.latestRep.month} ${r.latestRep.year}`:''} · ${r.c?.reporting_year_start===1?'Calendar':'Financial'} year</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <div style="display:flex;gap:10px">
              ${hpill(r.ahead,'var(--g)','Ahead')}
              ${hpill(r.track,'var(--am)','On Track')}
              ${hpill(r.behind,'var(--r)','Behind')}
            </div>
            <span class="acc-arrow">▾</span>
          </div>
        </div>
        <div class="acc-body">${r.html}</div>
      </div>`).join('');
    if(!el.innerHTML||el.innerHTML==='') el.innerHTML='<p style="font-size:13px;color:var(--t1)">No KPIs with targets found.</p>';
  },

  // ── ANOMALY DETECTION ──
  THRESHOLD:0.25, // 25% change flags an anomaly
  _dismissed:new Set(),
  buildAnomalies(){
    const el=document.getElementById('anomaly-list'); if(!el) return;
    const anomalies=[];
    const all=DB.getAllSummaries();
    for(const s of all){
      const rep=DB.getReport(s.client_id,s.year,s.month); if(!rep) continue;
      for(const m of rep.metrics){
        if(m.prev===null||m.prev===0||m.value_number===null) continue;
        const chg=(m.value_number-m.prev)/Math.abs(m.prev);
        if(Math.abs(chg)>this.THRESHOLD){
          const key=`${s.client_id}|${s.year}|${s.month}|${m.key}`;
          if(!this._dismissed.has(key)){
            anomalies.push({key,client:s.client_name,month:s.month,year:s.year,label:m.label,actual:m.value_number,prev:m.prev,chg,unit:m.unit,lower:m.lower});
          }
        }
      }
    }
    if(!anomalies.length){ el.innerHTML='<div class="ins g" style="margin-bottom:0"><p>No anomalies detected. All changes within ±25% threshold.</p></div>'; return; }
    // Group by client
    const byC={};
    for(const a of anomalies){ if(!byC[a.client]) byC[a.client]={items:[],pos:0,neg:0}; byC[a.client].items.push(a); const good=(a.lower&&a.chg<0)||(!a.lower&&a.chg>0); if(good) byC[a.client].pos++; else byC[a.client].neg++; }
    el.innerHTML=Object.entries(byC).map(([client,{items,pos,neg}])=>`
      <div class="acc-item" style="margin-bottom:10px">
        <div class="acc-hd" onclick="this.closest('.acc-item').classList.toggle('open')">
          <div style="display:flex;align-items:center;gap:9px">
            ${(()=>{const k=Object.keys(byC).find(k=>byC[k]===byC[client]);const cl=DB.getClients().find(c=>c.name===client);return cl?.logo?`<img src="${cl.logo}" style="width:24px;height:24px;border-radius:5px;object-fit:contain;background:${cl.brand_colour}">`:cl?`<div style="width:24px;height:24px;border-radius:5px;background:${cl.brand_colour||'var(--y)'};display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:${cl.brand_text||'#000'};flex-shrink:0">${cl.initials||'?'}</div>`:''})()}
            <div class="acc-name">${client}</div>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            ${neg?`<span class="badge br" style="font-size:10.5px;font-weight:700">${neg} unusual</span>`:''}
            ${pos?`<span class="badge bg" style="font-size:10.5px">${pos} positive</span>`:''}
            <span class="acc-arrow">▾</span>
          </div>
        </div>
        <div class="acc-body">
          ${items.map(a=>{
            const good=(a.lower&&a.chg<0)||(!a.lower&&a.chg>0);
            const pct=Math.round(Math.abs(a.chg)*100);
            return`<div data-anom="${a.key}" style="display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--bd0);gap:10px">
              <div>
                <div style="font-size:12.5px;font-weight:500">${a.label} <span class="badge ${good?'bg':'br'}" style="font-size:9.5px">${a.chg>0?'+':''}${pct}%</span></div>
                <div style="font-size:11px;color:var(--t1)">${a.month} ${a.year} · ${F.short(a.prev,a.unit)} → ${F.short(a.actual,a.unit)}</div>
              </div>
              <button class="btn btn-g btn-sm" onclick="INTEL.dismiss('${a.key}',this)" style="flex-shrink:0">Dismiss</button>
            </div>`;
          }).join('')}
        </div>
      </div>`).join('');
  },
  _updateSidebarBadges(){
    const setbadge=(btnId,count,color)=>{
      const btn=document.getElementById(btnId); if(!btn) return;
      let badge=btn.querySelector('.sb-badge');
      if(count>0){
        if(!badge){ badge=document.createElement('span'); badge.className='sb-badge'; btn.appendChild(badge); }
        badge.style.background=color||'#E84545';
        badge.textContent=count;
        badge.style.display='';
      } else if(badge){ badge.remove(); }
    };
    // Anomalies count (red) — only unusual/bad anomalies
    setbadge('sb-anomalies', INTEL._countActiveAnomalies(), '#E84545');
    // Opportunities count (orange)
    try{
      const all=DB.getAllSummaries();
      let oppCount=0;
      for(const s of all){ oppCount+=OPPS._detectAll(s).filter(o=>!OPPS._dismissed.has(o.id)).length; }
      setbadge('sb-opportunities', oppCount, '#ED7209');
    }catch(e){}
    // KPI Alerts count (red) — KPIs needing attention
    try{
      const all2=DB.getAllSummaries();
      let kpiAttn=0;
      for(const s of all2){
        const rep=DB.getReport(s.client_id,s.year,s.month); if(!rep) continue;
        const kpis=rep.metrics.filter(m=>m.is_kpi&&m.target&&m.value_number!==null);
        kpiAttn+=kpis.filter(m=>DB.kpiHealth(s.client_id,m,s.month)==='attn').length;
      }
      setbadge('sb-kpialerts', kpiAttn, '#E84545');
    }catch(e){}
  },
  _countActiveAnomalies(){
    // Uses the same key format as buildAnomalies: `clientId|year|month|metricKey`
    const all=DB.getAllSummaries();
    let count=0;
    for(const s of all){
      const rep=DB.getReport(s.client_id,s.year,s.month); if(!rep) continue;
      for(const m of rep.metrics){
        if(m.prev===null||m.prev===0||m.value_number===null) continue;
        const chg=(m.value_number-m.prev)/Math.abs(m.prev);
        if(Math.abs(chg)>this.THRESHOLD){
          const key=`${s.client_id}|${s.year}|${s.month}|${m.key}`;
          const good=(m.lower&&chg<0)||(!m.lower&&chg>0);
          if(!good&&!this._dismissed.has(key)) count++;
        }
      }
    }
    return count;
  },
  dismiss(key,btnEl){
    this._dismissed.add(key);
    this.record('Anomaly dismissed',key);
    this._updateSidebarBadges();
    if(btnEl){
      const row=btnEl.closest('[data-anom]');
      if(row){
        row.style.transition='opacity .22s,max-height .22s';
        row.style.opacity='0';
        row.style.maxHeight=row.offsetHeight+'px';
        row.style.overflow='hidden';
        setTimeout(()=>{
          const acc=row.closest('.acc-item');
          row.remove();
          if(acc){
            // Update badge counts live
            const remaining=acc.querySelectorAll('[data-anom]');
            const negBadge=acc.querySelector('.badge.br');
            const posBadge=acc.querySelector('.badge.bg');
            let neg=0,pos=0;
            acc.querySelectorAll('[data-anom]').forEach(r=>{
              const chgEl=r.querySelector('.badge');
              if(chgEl){ const isGood=chgEl.classList.contains('bg'); if(isGood) pos++; else neg++; }
            });
            if(negBadge) negBadge.textContent=neg+' unusual';
            if(posBadge) posBadge.textContent=pos+' positive';
            if(neg===0&&negBadge) negBadge.style.display='none';
            if(pos===0&&posBadge) posBadge.style.display='none';
            // Remove empty accordion
            if(remaining.length===0){
              acc.style.transition='opacity .22s';
              acc.style.opacity='0';
              setTimeout(()=>{
                acc.remove();
                // If no accordions left show empty state
                const list=document.getElementById('anomaly-list');
                if(list&&!list.querySelector('.acc-item')){
                  list.innerHTML='<div class="ins g"><p>All anomalies resolved. No unusual changes detected.</p></div>';
                }
              },240);
            }
          }
        },230);
        return;
      }
    }
    this.buildAnomalies();
  },

  // ── METRIC LIBRARY ──
  _metricDefs:[
    {id:'ml-1',name:'Website Users',label:'Total Users',desc:'Unique users who visited the website.',cat:'website',unit:'count',manual:false,platform:'Google Analytics 4',source_link:'https://analytics.google.com'},
    {id:'ml-2',name:'Sessions',label:'Sessions',desc:'Total sessions including return visits.',cat:'website',unit:'count',manual:false,platform:'Google Analytics 4',source_link:''},
    {id:'ml-3',name:'Conversion Rate',label:'Session Conversion Rate',desc:'Percentage of sessions resulting in a conversion.',cat:'website',unit:'percentage',manual:false,platform:'Google Analytics 4',source_link:''},
    {id:'ml-4',name:'Email Open Rate',label:'Open Rate',desc:'Percentage of sent emails that were opened.',cat:'email',unit:'percentage',manual:false,platform:'MailerLite / Mailchimp',source_link:''},
    {id:'ml-5',name:'Email CTR',label:'Click Through Rate',desc:'Percentage of sent emails with at least one click.',cat:'email',unit:'percentage',manual:false,platform:'MailerLite / Mailchimp',source_link:''},
    {id:'ml-6',name:'Revenue',label:'Website Revenue',desc:'Total transactional revenue through the website.',cat:'overview',unit:'currency_gbp',manual:true,platform:'Manual / GA4 ecommerce',source_link:''},
    {id:'ml-7',name:'Followers',label:'Total Followers',desc:'Combined social media followers across all platforms.',cat:'social',unit:'count',manual:false,platform:'Meta / LinkedIn / TikTok',source_link:''},
    {id:'ml-8',name:'Impressions',label:'Impressions',desc:'Total times content was displayed.',cat:'social',unit:'count',manual:false,platform:'Meta / LinkedIn',source_link:''},
    {id:'ml-9',name:'Engagement Rate',label:'Engagement Rate',desc:'Engagements divided by impressions.',cat:'social',unit:'percentage',manual:false,platform:'Meta',source_link:''},
    {id:'ml-10',name:'ROAS',label:'Return on Ad Spend',desc:'Revenue generated per £1 of ad spend.',cat:'paid_advertising',unit:'number',manual:false,platform:'Google Ads / Meta',source_link:''},
  ],
  buildMetricLib(){
    const el=document.getElementById('metric-lib-list'); if(!el) return;
    const cats={overview:'Overview',website:'Website',email:'Email',social:'Social Media',paid_advertising:'Paid Advertising'};
    const byCat={};
    for(const m of this._metricDefs){ if(!byCat[m.cat]) byCat[m.cat]=[]; byCat[m.cat].push(m); }
    el.innerHTML=Object.entries(byCat).map(([cat,mets])=>`
      <div class="card" style="margin-bottom:14px">
        <div class="card-hd"><div><div class="ctitle">${cats[cat]||cat}</div></div></div>
        <table class="tbl"><thead><tr><th>Metric</th><th>Label</th><th>Unit</th><th>Platform</th><th>Type</th><th>Actions</th></tr></thead>
        <tbody>${mets.map(m=>`<tr>
          <td><strong>${m.name}</strong><br><span style="font-size:10.5px;color:var(--t1)">${m.desc}</span></td>
          <td>${m.label}</td>
          <td>${m.unit}</td>
          <td>${m.platform||'—'}</td>
          <td><span class="badge ${m.manual?'ba':'bg'}">${m.manual?'Manual':'API-ready'}</span></td>
          <td><button class="btn btn-g btn-sm" onclick="INTEL.editMetricDef('${m.id}')">Edit</button></td>
        </tr>`).join('')}</tbody>
        </table>
      </div>`).join('');
  },
  addMetricDef(){
    // Clear modal for new metric
    ['emd-name','emd-label','emd-desc','emd-platform','emd-link'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
    document.getElementById('emd-cat').value='website';
    document.getElementById('emd-unit').value='count';
    document.getElementById('emd-manual').value='true';
    document.getElementById('emd-id').value='new-'+Date.now();
    MODAL.open('modal-editmetric');
  },
  editMetricDef(id){
    const m=this._metricDefs.find(x=>x.id===id); if(!m) return;
    document.getElementById('emd-name').value=m.name||'';
    document.getElementById('emd-label').value=m.label||'';
    document.getElementById('emd-desc').value=m.desc||'';
    document.getElementById('emd-cat').value=m.cat||'website';
    document.getElementById('emd-unit').value=m.unit||'count';
    document.getElementById('emd-platform').value=m.platform||'';
    document.getElementById('emd-manual').value=String(!!m.manual);
    document.getElementById('emd-link').value=m.source_link||'';
    document.getElementById('emd-id').value=id;
    MODAL.open('modal-editmetric');
  },
  saveMetricDefModal(){
    const id=document.getElementById('emd-id').value;
    const data={
      name:document.getElementById('emd-name').value.trim()||'Untitled metric',
      label:document.getElementById('emd-label').value.trim()||document.getElementById('emd-name').value.trim(),
      desc:document.getElementById('emd-desc').value.trim(),
      cat:document.getElementById('emd-cat').value,
      unit:document.getElementById('emd-unit').value,
      platform:document.getElementById('emd-platform').value.trim(),
      manual:document.getElementById('emd-manual').value==='true',
      source_link:document.getElementById('emd-link').value.trim(),
    };
    const existing=this._metricDefs.find(x=>x.id===id);
    if(existing){ Object.assign(existing,data); this.record('Metric definition updated',data.name); }
    else { this._metricDefs.push({id:'ml-'+Date.now(),...data}); this.record('Metric definition added',data.name); }
    MODAL.close('modal-editmetric');
    this.buildMetricLib();
  },
  deleteMetricDef(id){
    if(!confirm('Delete this metric definition?')) return;
    const idx=this._metricDefs.findIndex(x=>x.id===id);
    if(idx>=0){ this._metricDefs.splice(idx,1); this.record('Metric definition deleted',id); }
    MODAL.close('modal-editmetric');
    this.buildMetricLib();
  },
};

// Patch DB/REPORT/MODAL to record audit events
const OPPS = {
  _dismissed:new Set(),
  _detectAll(s){
    const rep=DB.getReport(s.client_id,s.year,s.month); if(!rep) return[];
    const c=DB.getClient(s.client_id); if(!c) return[];
    const opps=[];
    // Multi-key lookup: tries each key in order, returns first match
    const get=(...keys)=>{for(const k of keys){const m=rep.metrics.find(x=>x.key===k);if(m)return m;}return null;};
    const mv=(...keys)=>get(...keys)?.value_number??null;
    // Key aliases: map generic concepts to client-specific keys
    const _ig_fol=get('ig_followers','td_ig_fol');
    const _ig_eng=get('ig_eng','td_li_eng');
    const _ig_imp=get('ig_imp');
    const _ig_views=get('td_ig_views');
    const _fb_fol=get('fb_followers','td_fb_fol');
    const _fb_eng=get('fb_eng');
    const _fb_imp=get('fb_imp');
    const _tt_eng=get('tt_eng');
    const _li_fol=get('li_followers','td_li_fol');
    const _li_eng=get('li_eng','td_li_eng');
    const _web_users=get('web_users','td_web_users_s');
    const _web_sessions=get('web_sessions','td_web_sess_s');
    const _web_bounce=get('web_bounce');
    const _web_cvr=get('conversion_rate','conv_rate','td_web_cvr_s');
    const _ch_organic=get('ch_organic');
    const _ch_paid=get('ch_paid','td_paid_social_enq');
    const _spend=get('kk_spend','cch_spend','meta_spend','td_studio_spend','td_shop_spend');
    const _rev=get('kk_rev','revenue_cch','revenue_web','td_shop_rev');
    const _email_open=get('cch_e_open','e_open','td_email_open');
    const _email_ctr=get('cch_e_ctr','e_ctr','td_email_ctr');
    const _email_contacts=get('email_contacts','td_hs_contacts');
    const _unsub=get('unsubscribes');
    // pct defined above
    const pct=(m)=>{ if(!m||m.prev===null||!m.prev||m.value_number===null) return null; return Math.round((m.value_number-m.prev)/Math.abs(m.prev)*100); };
    const add=(id,cat,pri,icon,title,detail,action,metric)=>{
      if(!this._dismissed.has(id)) opps.push({id,client:c.name,category:cat,priority:pri,icon,title,detail,action,metric,cid:s.client_id,yr:s.year,mon:s.month});
    };
    // ── Social ──
    const ttEng=_tt_eng?.value_number??null; const fbEng=_fb_eng?.value_number??null; const igEng=_ig_eng?.value_number??null;
    if(ttEng&&fbEng&&ttEng>fbEng*1.2) add(`tt-vs-fb-${s.client_id}`,'Social','High','🎵','TikTok outperforming Facebook',`TikTok engagement (${ttEng.toLocaleString()}) outperforms Facebook (${fbEng.toLocaleString()}) by ${Math.round((ttEng/fbEng-1)*100)}%. Short-form video is delivering stronger returns.`,'Increase TikTok frequency and consider reallocating Facebook budget to TikTok advertising.','tt_eng');
    const igImp=_ig_imp?.value_number??null; const igFol=_ig_fol?.value_number??null;
    if(igImp&&igImp>50000&&igFol&&igFol<5000) add(`ig-fol-${s.client_id}`,'Social','Medium','📸','High Instagram reach, low follower growth',`${(igImp/1000).toFixed(0)}k impressions but only ${igFol.toLocaleString()} followers. Reach not converting to community growth.`,'Add follow CTAs to top Reels. Use Stories to redirect reach audiences to your profile.','ig_followers');
    const fbImp=_fb_imp?.value_number??null; const fbFol=_fb_fol?.value_number??null;
    if(fbImp&&fbFol&&(fbEng||0)/(fbImp)*100<0.5) add(`fb-eng-imp-${s.client_id}`,'Social','Medium','👍','High impressions but weak engagement rate',`Facebook engagement rate appears low vs impressions. Content is reaching people but not prompting interaction.`,'Test more interactive formats — polls, questions, shareable content. Prioritise posts that prompt comments or shares.','fb_eng');
    const fbFolPct=pct(_fb_fol);
    if(fbFolPct!==null&&Math.abs(fbFolPct)<2&&(fbFol||0)>5000) add(`follower-stag-${s.client_id}`,'Social','Low','📉','Follower growth stagnating',`Facebook followers ${fbFolPct>=0?'grew':'declined'} only ${Math.abs(fbFolPct)}% this month. Community growth has plateaued.`,'Run a follower campaign or contest. Boost best-performing organic posts to build awareness in new audiences.','fb_followers');
    // ── Email ──
    const openRate=_email_open; const ctr=_email_ctr;
    if(openRate&&ctr&&openRate.value_number>30&&ctr.value_number<1.5) add(`email-ctr-${s.client_id}`,'Email','Medium','✉️','Strong open rate, weak CTR',`${openRate.value_number}% open rate shows interest — but ${ctr.value_number}% CTR means subscribers are not clicking through.`,'Review CTA placement and copy. Try a single-CTA email. Test button vs text link. Check mobile rendering.','e_ctr');
    const unsub=_unsub;
    if(unsub&&unsub.prev&&unsub.value_number<unsub.prev*0.8) add(`unsub-freq-${s.client_id}`,'Email','Low','📧','Unsubscribes falling — healthy signal',`Unsubscribes down ${Math.abs(pct(unsub)||0)}%. Audience-content fit improving.`,'Consider a modest send frequency increase or new email format to capitalise on improved engagement.','unsubscribes');
    const emailContacts=_email_contacts;
    if(emailContacts&&emailContacts.target&&emailContacts.value_number/emailContacts.target<0.5) add(`list-growth-${s.client_id}`,'Email','High','','Email list growth significantly behind target',`Contacts at ${F.val(emailContacts)} vs target of ${F.short(emailContacts.target,emailContacts.unit)}. List growth is the foundation of email marketing scale.`,'Review lead magnet performance. Add pop-ups or exit-intent captures. Consider a competition or giveaway to accelerate sign-ups.','email_contacts');
    // ── Website ──
    const bounce=_web_bounce?.value_number??null;
    if(bounce&&bounce>65) add(`bounce-${s.client_id}`,'Website','High','🌐','High bounce rate',`Bounce rate of ${bounce}% suggests landing pages are not matching visitor intent.`,'Audit top 3 entry pages vs traffic source. Align landing page content to the channel driving visitors.','web_bounce');
    const webUsers=_web_users; const webPct=pct(webUsers);
    const convRate=_web_cvr; const convPct=pct(convRate);
    if(webPct!==null&&webPct>20&&convPct!==null&&convPct<0) add(`traffic-conv-drop-${s.client_id}`,'Website','High','📊','High traffic growth but conversion declining',`Traffic up ${webPct}% but conversion rate dropped ${Math.abs(convPct)}%. New traffic may not be well-qualified.`,'Review which channels are driving the traffic increase. Ensure landing pages match campaign messaging and audience intent.','conversion_rate');
    if(convPct!==null&&convPct>10&&webPct!==null&&webPct<0) add(`conv-improving-${s.client_id}`,'Website','Low','','Conversion improving despite lower traffic',`Conversion rate up ${convPct}% while traffic declined ${Math.abs(webPct)}%. Audience quality has improved.`,'Identify which traffic sources are driving the highest-quality visitors. Invest more in those channels.','conv_rate');
    const webDur=rep.metrics.find(m=>m.key==='web_dur'); // text field
    const sessions=_web_sessions?.value_number??null;
    if(bounce&&bounce<45&&sessions&&sessions>10000) add(`low-bounce-scale-${s.client_id}`,'Website','Low','🚀','Strong engagement quality — scale opportunity',`Bounce rate of ${bounce}% is excellent. Users are engaged. This is the right time to increase traffic investment.`,'Consider increasing paid spend or content production to capitalise on the strong landing page performance.','web_bounce');
    // ── Paid ──
    const spend=_spend?.value_number??null;
    const rev=_rev?.value_number??null;
    if(spend&&rev&&spend>0&&rev/spend>10) add(`roas-scale-${s.client_id}`,'Paid','High','💰','Strong ROAS — scaling opportunity',`ROAS of ${(rev/spend).toFixed(1)}x on current spend. High return justifies increasing investment.`,'Test a 20-30% spend increase on the best-performing campaign. Monitor CPA to ensure efficiency holds as spend scales.','kk_rev');
    const kkCpc=get('kk_cpc'); const kkCpcPct=pct(kkCpc);
    if(kkCpcPct!==null&&kkCpcPct>15&&kkCpc) add(`cpc-rising-${s.client_id}`,'Paid','Medium','⚠️','Cost per conversion rising',`Cost per conversion up ${kkCpcPct}% month-on-month. Efficiency is declining.`,'Review bidding strategy and audience targeting. Test new ad creative. Consider pausing underperforming ad sets.','kk_cpc');
    // ── Revenue ──
    const revMet=_rev;
    const socTotal=(_fb_fol?.value_number||0)+(_ig_fol?.value_number||0)+(mv('tt_followers')||0)+(_li_fol?.value_number||0);
    if(revMet&&pct(revMet)>15&&socTotal&&socTotal<30000) add(`rev-social-${s.client_id}`,'Social','Medium','📈','Revenue growing but audience base is small',`Revenue up ${pct(revMet)}% but total social following is ${socTotal.toLocaleString()}. Commercial momentum not matched by community scale.`,'Invest in organic and paid follower acquisition. A larger engaged audience will amplify future campaigns.','fb_followers');
    // ── Organic vs Paid ──
    const organic=_ch_organic?.value_number??null; const paid=_ch_paid?.value_number??null;
    if(organic&&paid&&organic>paid*3) add(`organic-strong-${s.client_id}`,'Website','Low','🌿','Organic outperforming paid traffic',`Organic search (${(organic/1000).toFixed(0)}k) is significantly outperforming paid social (${(paid/1000).toFixed(0)}k). SEO investment is delivering.`,'Continue content and SEO investment. Consider reducing paid budget slightly and reallocating to content production.','ch_organic');
    return opps;
  },
  build(){
    const el=document.getElementById('opp-list'); if(!el) return;
    const filters=document.getElementById('opp-filters');
    const all=DB.getAllSummaries();
    const allOpps=[];
    for(const s of all) allOpps.push(...this._detectAll(s));

    const active=allOpps.filter(o=>!this._dismissed.has(o.id));
    if(filters) filters.innerHTML=['All','High','Medium','Low','Social','Email','Website','Paid'].map(f=>`<button class="mbtn${f==='All'?' on':''}" onclick="OPPS._filter('${f}',this)">${f}</button>`).join('');

    // Find clients with reports but no opportunities (new companies / clean metrics)
    const allSummaries=DB.getAllSummaries();
    const clientsWithReports=new Set(allSummaries.map(s=>s.client_id));
    const clientsWithOpps=new Set(active.map(o=>o.cid));
    const monitoringClients=[...clientsWithReports].filter(cid=>!clientsWithOpps.has(cid)).map(cid=>DB.getClient(cid)).filter(Boolean);
    if(!active.length && !monitoringClients.length){ el.innerHTML='<div class="ins g" style="margin-bottom:0"><p>No opportunities detected at this time. All core metrics appear balanced.</p></div>'; return; }
    if(!active.length){
      el.innerHTML=monitoringClients.map(c=>`<div style="padding:14px 18px;background:var(--bg2);border-radius:var(--rs);border:1px solid var(--bd0);margin-bottom:10px;display:flex;align-items:center;gap:12px">
        <div style="width:32px;height:32px;border-radius:7px;background:${c.brand_colour};display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:${c.brand_text};flex-shrink:0">${c.initials}</div>
        <div><div style="font-size:13px;font-weight:600">${c.name}</div><div style="font-size:12px;color:var(--t2);margin-top:2px">Monitoring — no opportunities flagged. Add metric data to enable opportunity detection.</div></div>
      </div>`).join('');
      return;
    }

    // Group by client
    const byClient={};
    for(const o of active){ if(!byClient[o.client]) byClient[o.client]={cid:o.cid,items:[],high:0,med:0,low:0}; byClient[o.client].items.push(o); if(o.priority==='High')byClient[o.client].high++;else if(o.priority==='Medium')byClient[o.client].med++;else byClient[o.client].low++; }
    // Show monitoring placeholders for clients with no opportunities alongside those with opps
    const monitoringHtml=monitoringClients.map(c=>`<div style="padding:14px 18px;background:var(--bg2);border-radius:var(--rs);border:1px solid var(--bd0);margin-bottom:10px;display:flex;align-items:center;gap:12px">
      <div style="width:32px;height:32px;border-radius:7px;background:${c.brand_colour};display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:${c.brand_text};flex-shrink:0">${c.initials}</div>
      <div><div style="font-size:13px;font-weight:600">${c.name}</div><div style="font-size:12px;color:var(--t2);margin-top:2px">Monitoring — no opportunities flagged yet.</div></div>
    </div>`).join('');
    el.innerHTML=monitoringHtml+Object.entries(byClient).map(([client,data])=>`
      <div class="acc-item opp-acc" id="opp-acc-${data.cid}" style="margin-bottom:10px">
        <div class="acc-hd" onclick="this.closest('.acc-item').classList.toggle('open')">
          <div style="display:flex;align-items:center;gap:9px">
            ${(()=>{const cl=DB.getClient(data.cid);return cl?.logo?`<img src="${cl.logo}" style="width:24px;height:24px;border-radius:5px;object-fit:contain;background:${cl.brand_colour}">`:cl?`<div style="width:24px;height:24px;border-radius:5px;background:${cl.brand_colour};display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:${cl.brand_text};flex-shrink:0">${cl.initials}</div>`:''})()}
            <div class="acc-name">${client}</div>
          </div>
          <div style="display:flex;align-items:center;gap:6px">
            ${data.high?`<span class="badge br" style="font-size:10px">${data.high} High</span>`:''}
            ${data.med?`<span class="badge ba" style="font-size:10px">${data.med} Medium</span>`:''}
            ${data.low?`<span class="badge bb" style="font-size:10px">${data.low} Low</span>`:''}
            <span class="acc-arrow">▾</span>
          </div>
        </div>
        <div class="acc-body">
          ${data.items.map(o=>{
            const pcls={High:'br',Medium:'ba',Low:'bb'}[o.priority]||'bn';
            return`<div style="padding:14px 0;border-bottom:1px solid var(--bd0)" data-cat="${o.category}" data-pri="${o.priority}">
              <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px">
                <div style="display:flex;align-items:flex-start;gap:10px;flex:1">
                  <span style="font-size:22px;flex-shrink:0">${o.icon}</span>
                  <div>
                    <div style="font-size:13.5px;font-weight:700;margin-bottom:5px">${o.title}</div>
                    <div style="display:flex;gap:5px;margin-bottom:7px"><span class="badge ${pcls}" style="font-size:9.5px">${o.priority}</span><span class="badge bn" style="font-size:9.5px">${o.category}</span></div>
                    <div style="font-size:12.5px;color:var(--t1);margin-bottom:8px">${o.detail}</div>
                    <div style="background:rgba(255,214,0,.06);border:1px solid rgba(255,214,0,.15);border-radius:var(--rs);padding:8px 11px;font-size:12px">
                      <span style="font-size:9.5px;font-weight:700;color:var(--o);text-transform:uppercase;display:block;margin-bottom:2px">Action</span>${o.action}
                    </div>
                  </div>
                </div>
                <div style="display:flex;flex-direction:column;gap:5px;flex-shrink:0">
                  <button class="btn btn-g btn-sm" onclick="NAV.openReport('${o.cid}')">View</button>
                  <button class="btn btn-r btn-sm" onclick="OPPS.dismiss('${o.id}')">Dismiss</button>
                </div>
              </div>
            </div>`;
          }).join('')}
        </div>
      </div>`).join('');
    // Accordions start collapsed by default
  },
  _filter(f,btn){
    document.querySelectorAll('#opp-filters .mbtn').forEach(b=>b.classList.remove('on'));
    if(btn) btn.classList.add('on');
    document.querySelectorAll('.opp-acc .acc-body [data-cat]').forEach(card=>{
      const cat=card.dataset.cat; const pri=card.dataset.pri;
      card.style.display=(f==='All'||f===cat||f===pri)?'':'none';
    });
  },
  dismiss(id){ this._dismissed.add(id); INTEL.record('Opportunity dismissed',id); this.build(); },
};

/* ══════════════════════════════════════════════════════════
   MARKETING HEALTH SCORE
══════════════════════════════════════════════════════════ */
const SNAPSHOT = {
  // _history[clientId][yrMon] = {score, sat, wins:[], concerns:[], ts}
  _history:{},
  _satisfaction:{}, // current (live) satisfaction per client
  _highlights:{},   // current wins/concerns per client
  _viewMode:{},     // clientId → 'current'|'history'

  _selectedClient:null, // null = all clients overview
  build(){
    const el=document.getElementById('client-health-content'); if(!el) return;
    const clients=DB.getParents();
    // Score key + controls
    const scoreKey=`<div style="margin-bottom:20px">
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px">
        <select class="mysel" id="ch-client-sel" style="min-width:180px" onchange="SNAPSHOT.selectClient(this.value)">
          <option value="">All clients overview</option>
          ${clients.map(c=>`<option value="${c.id}" ${SNAPSHOT._selectedClient===c.id?'selected':''}>${c.name}</option>`).join('')}
        </select>
        <button class="btn btn-g btn-sm" style="font-size:10.5px" onclick="SNAPSHOT.selectClient('')">Agency overview</button>
      </div>
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:10px 14px;background:var(--bg2);border-radius:var(--rs);border:1px solid var(--bd0)">
        <span style="font-size:10px;font-weight:700;color:var(--t2);text-transform:uppercase;letter-spacing:.8px;margin-right:4px">Health score:</span>
        <span style="display:flex;align-items:center;gap:4px;font-size:11.5px"><span style="width:9px;height:9px;border-radius:50%;background:#E84545;display:inline-block"></span><strong style="color:#E84545">0–49</strong> Needs attention</span>
        <span style="display:flex;align-items:center;gap:4px;font-size:11.5px"><span style="width:9px;height:9px;border-radius:50%;background:#D97706;display:inline-block"></span><strong style="color:#D97706">50–59</strong> Fair</span>
        <span style="display:flex;align-items:center;gap:4px;font-size:11.5px"><span style="width:9px;height:9px;border-radius:50%;background:#3B82F6;display:inline-block"></span><strong style="color:#3B82F6">60–74</strong> Good</span>
        <span style="display:flex;align-items:center;gap:4px;font-size:11.5px"><span style="width:9px;height:9px;border-radius:50%;background:#16A34A;display:inline-block"></span><strong style="color:#16A34A">75+</strong> Healthy</span>
      </div>
    </div>`;
    if(this._selectedClient){
      // Single client view
      const c=DB.getClient(this._selectedClient);
      if(!c){ el.innerHTML=scoreKey+'<p style="color:var(--t1)">Client not found.</p>'; return; }
      const yrs=DB.getYears(c.id); if(!yrs.length){ el.innerHTML=scoreKey+'<p style="color:var(--t1)">No reports for this client.</p>'; return; }
      const yr=yrs[yrs.length-1];
      const mons=DB.getMonths(c.id,yr); if(!mons.length){ el.innerHTML=scoreKey; return; }
      const mon=mons[mons.length-1];
      const rep=DB.getReport(c.id,yr,mon); if(!rep){ el.innerHTML=scoreKey; return; }
      el.innerHTML=scoreKey+this._buildClientCard(c,rep,mon,yr);
    } else {
      // All clients overview — compact score cards
      const overviewCards=clients.map(c=>{
        const yrs=DB.getYears(c.id); if(!yrs.length) return'';
        const yr=yrs[yrs.length-1];
        const mons=DB.getMonths(c.id,yr); if(!mons.length) return'';
        const mon=mons[mons.length-1];
        const rep=DB.getReport(c.id,yr,mon); if(!rep) return'';
        const score=this._score(c.id,rep);
        const col=score>=75?'#16A34A':score>=60?'#3B82F6':score>=50?'#D97706':'#E84545';
        const grade=score>=75?'Healthy':score>=60?'Good':score>=50?'Fair':'Needs attention';
        const sat=this._satisfaction[c.id]||5;
        const satCol=sat>=7?'#16A34A':sat>=5?'#D97706':'#E84545';
        const kpis=rep.metrics.filter(m=>m.is_kpi&&m.value_number!==null);
        const ahead=kpis.filter(m=>DB.kpiHealth(c.id,m,mon)==='ahead').length;
        const attn=kpis.filter(m=>DB.kpiHealth(c.id,m,mon)==='attn').length;
        return`<div class="card" style="margin-bottom:10px;border-left:4px solid ${col};cursor:pointer" onclick="SNAPSHOT.selectClient('${c.id}')">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:12px">
            <div style="display:flex;align-items:center;gap:10px">
              <div style="width:32px;height:32px;border-radius:8px;background:${c.brand_colour};display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:${c.brand_text};overflow:hidden;flex-shrink:0">${c.logo?`<img src="${c.logo}" style="width:100%;height:100%;object-fit:contain">`:c.initials}</div>
              <div>
                <div style="font-size:14px;font-weight:600">${c.name}</div>
                <div style="font-size:10.5px;color:var(--t2)">${DB.ML[mon]||mon} ${yr} · ${grade}</div>
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:14px">
              <div style="text-align:center"><div style="font-size:26px;font-weight:800;color:${col};line-height:1">${score}</div><div style="font-size:9px;color:var(--t2)">Health</div></div>
              <div style="text-align:center"><div style="font-size:26px;font-weight:800;color:${satCol};line-height:1">${sat}</div><div style="font-size:9px;color:var(--t2)">Sat.</div></div>
              <div style="text-align:center"><div style="font-size:16px;font-weight:700;color:var(--g)">${ahead}</div><div style="font-size:9px;color:var(--t2)">Ahead</div></div>
              <div style="text-align:center"><div style="font-size:16px;font-weight:700;color:${attn?'#E84545':'#16A34A'}">${attn}</div><div style="font-size:9px;color:var(--t2)">Attn</div></div>
              <div style="color:var(--t2);font-size:14px">›</div>
            </div>
          </div>
        </div>`;
      }).join('');
      el.innerHTML=scoreKey+'<div style="font-size:11px;font-weight:700;color:var(--t2);text-transform:uppercase;letter-spacing:.8px;margin-bottom:10px">Agency overview — click a client to view full health details</div>'+overviewCards;
    }
  },
  selectClient(cid){
    this._selectedClient=cid||null;
    this.build();
  },
  _score(cid,rep){
    const all=rep.metrics;
    let total=0,count=0;
    // KPI achievement (35%)
    const kpis=all.filter(m=>m.is_kpi&&m.target&&m.value_number!==null);
    if(kpis.length){
      const exp=DB.kpiExpected(cid,rep._month||'Feb');
      const scores=kpis.map(m=>{
        const prog=m.lower?Math.max(0,(m.target-m.value_number)/m.target+1):m.value_number/m.target;
        return Math.min(100,Math.round(prog/Math.max(exp,0.001)*100));
      });
      total+=scores.reduce((a,b)=>a+b,0)/scores.length*0.30; count+=0.30;
    }
    // Trend direction (25%) — metrics improving vs declining
    const withPrev=all.filter(m=>m.prev!==null&&m.value_number!==null);
    if(withPrev.length){
      const improving=withPrev.filter(m=>{const p=m.prev?Math.round((m.value_number-m.prev)/Math.abs(m.prev)*100):0;return(m.lower&&p<0)||(!m.lower&&p>0);});
      total+=(improving.length/withPrev.length)*100*0.25; count+=0.25;
    }
    // Anomalies — penalise (10%)
    const anomalies=all.filter(m=>m.prev&&m.value_number&&Math.abs((m.value_number-m.prev)/m.prev)>0.25&&!((m.lower&&m.value_number<m.prev)||(!m.lower&&m.value_number>m.prev)));
    total+=Math.max(0,100-anomalies.length*20)*0.1; count+=0.1;
    // Forecast confidence (5%)
    total+=(kpis.length>0?Math.min(100,(kpis.length/6)*100):30)*0.05; count+=0.05;
    // Client satisfaction (30%) — strong exponential: very unhappy = danger territory
    const sat=this._satisfaction[cid];
    if(sat!==null&&sat!==undefined){
      // Steep curve: 10→100, 8→72, 5→31, 3→11, 1→1
      // sat=1 → score≈8 (needs attention), sat=9 → score≈90 (healthy)
      const satScore=Math.round(Math.pow(sat/10,2.5)*100);
      total+=satScore*0.30; count+=0.30;
      // Reduce other weights proportionally (total still sums to 1.0)
    }
    return count>0?Math.min(100,Math.round(total/count)):50;
  },
  _buildClientCard(c,rep,mon,yr){
    const score=this._score(c.id,rep);
    const col=score>=75?'#16A34A':score>=60?'#3B82F6':score>=50?'#D97706':'#E84545';
    const grade=score>=75?'Healthy':score>=60?'Good':score>=50?'Fair':'Needs attention';
    const kpis=rep.metrics.filter(m=>m.is_kpi&&m.value_number!==null);
    const ahead=kpis.filter(m=>DB.kpiHealth(c.id,m,mon)==='ahead').length;
    const attn=kpis.filter(m=>DB.kpiHealth(c.id,m,mon)==='attn').length;
    const allAlerts=DB.getAllAlerts().filter(a=>a.client_id===c.id&&a.health==='attn');
    const allOpps=OPPS._getForClient?OPPS._getForClient(c.id):[]; // future
    const sat=this._satisfaction[c.id]||null;
    const highlights=this._highlights[c.id]||{wins:[],concerns:[]};
    return`<div class="card" style="margin-bottom:18px;border-top:3px solid ${col}">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:16px">
        <div style="display:flex;align-items:center;gap:12px">
          <div style="width:40px;height:40px;border-radius:10px;background:${c.brand_colour};display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;color:${c.brand_text};overflow:hidden;flex-shrink:0">${c.logo?`<img src="${c.logo}" style="width:100%;height:100%;object-fit:contain">`:c.initials}</div>
          <div><div style="font-size:16px;font-weight:700">${c.name}</div><div style="font-size:11px;color:var(--t2)">${DB.ML[mon]||mon} ${yr} · Last report</div></div>
        </div>
        <div style="display:flex;align-items:center;gap:16px">
          <div style="text-align:center">
            <div style="font-size:38px;font-weight:800;line-height:1;color:${col}" id="snap-score-${c.id}" data-score>${score}</div>
            <div style="font-size:10.5px;color:${col};font-weight:600" id="snap-grade-${c.id}" data-grade>${grade}</div>
            <div style="font-size:9.5px;color:var(--t2)">Health score</div>
          </div>
          <div style="text-align:center;margin-left:8px"><div style="font-size:38px;font-weight:800;line-height:1;color:${(sat||5)>=7?'#16A34A':(sat||5)>=5?'#D97706':'#E84545'}" id="sat-big-${c.id}">${sat||5}</div><div style="font-size:9.5px;color:var(--t2)">Satisfaction /10</div></div>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:14px">
        <div style="background:var(--bg2);border-radius:var(--rs);padding:10px;text-align:center"><div style="font-size:9.5px;color:var(--t2);text-transform:uppercase;letter-spacing:.6px;font-weight:600;margin-bottom:4px">KPIs Ahead</div><div style="font-size:22px;font-weight:700;color:var(--g)">${ahead}</div></div>
        <div style="background:var(--bg2);border-radius:var(--rs);padding:10px;text-align:center"><div style="font-size:9.5px;color:var(--t2);text-transform:uppercase;letter-spacing:.6px;font-weight:600;margin-bottom:4px">Need Attention</div><div style="font-size:22px;font-weight:700;color:${attn?'#E84545':'#16A34A'}">${attn}</div></div>
        <div style="background:var(--bg2);border-radius:var(--rs);padding:10px;text-align:center"><div style="font-size:9.5px;color:var(--t2);text-transform:uppercase;letter-spacing:.6px;font-weight:600;margin-bottom:4px">Total KPIs</div><div style="font-size:22px;font-weight:700">${kpis.length}</div></div>
        <div style="background:var(--bg2);border-radius:var(--rs);padding:10px;text-align:center"><div style="font-size:9.5px;color:var(--t2);text-transform:uppercase;letter-spacing:.6px;font-weight:600;margin-bottom:4px">Alerts</div><div style="font-size:22px;font-weight:700;color:${allAlerts.length?'#E84545':'#16A34A'}">${allAlerts.length}</div></div>
      </div>
      ${rep.insights?.overview?.text?`<div style="font-size:12.5px;color:var(--t1);line-height:1.65;margin-bottom:12px">${rep.insights.overview.text.slice(0,200)}…</div>`:''}
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
        <div>
          <div style="font-size:10px;font-weight:700;color:#16A34A;text-transform:uppercase;letter-spacing:.6px;margin-bottom:6px"> Wins / Highlights</div>
          <div id="snap-wins-${c.id}" style="font-size:12px;color:var(--t1)">
            ${highlights.wins.length?highlights.wins.map((w,i)=>`<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:6px;margin-bottom:4px;padding:3px 0"><span>• ${w}</span><button onclick="SNAPSHOT.removeNote('${c.id}','win',${i})" style="background:none;border:none;cursor:pointer;font-size:10px;color:var(--r);flex-shrink:0;padding:0;line-height:1;opacity:.7" title="Remove">✕</button></div>`).join(''):'<span style="color:var(--t2);font-size:11.5px">No highlights noted</span>'}
          </div>
          <button class="btn btn-g btn-sm" style="margin-top:6px;font-size:10px" onclick="SNAPSHOT.addNote('${c.id}','win')">+ Add win</button>
        </div>
        <div>
          <div style="font-size:10px;font-weight:700;color:#E84545;text-transform:uppercase;letter-spacing:.6px;margin-bottom:6px">⚠️ Strategic concerns</div>
          <div id="snap-concerns-${c.id}" style="font-size:12px;color:var(--t1)">
            ${highlights.concerns.length?highlights.concerns.map((w,i)=>`<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:6px;margin-bottom:4px;padding:3px 0"><span>• ${w}</span><button onclick="SNAPSHOT.removeNote('${c.id}','concern',${i})" style="background:none;border:none;cursor:pointer;font-size:10px;color:var(--r);flex-shrink:0;padding:0;line-height:1;opacity:.7" title="Remove">✕</button></div>`).join(''):'<span style="color:var(--t2);font-size:11.5px">No concerns noted</span>'}
          </div>
          <button class="btn btn-g btn-sm" style="margin-top:6px;font-size:10px" onclick="SNAPSHOT.addNote('${c.id}','concern')">+ Add concern</button>
        </div>
      </div>
      <div style="border-top:1px solid var(--bd0);padding-top:10px;margin-bottom:4px">
        <button class="btn btn-g btn-sm" style="font-size:10.5px" onclick="SNAPSHOT.saveSnapshot('${c.id}','${mon}','${yr}')">📌 Save snapshot for ${DB.ML[mon]||mon} ${yr}</button>
        ${this._history[c.id]&&Object.keys(this._history[c.id]).length?`<button class="btn btn-g btn-sm" style="font-size:10.5px;margin-left:6px" onclick="SNAPSHOT.toggleHistory('${c.id}')">🕐 View history</button>`:''}
        <div id="snap-hist-${c.id}" style="display:none;margin-top:10px">${this._renderHistory(c.id)}</div>
      </div>
      <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
        <div style="display:flex;align-items:center;gap:6px">
          <span style="font-size:11.5px;color:var(--t1)">Client satisfaction:</span>
          <input type="range" min="1" max="10" value="${sat||5}" style="width:100px;accent-color:var(--y)" id="sat-slider-${c.id}" oninput="SNAPSHOT.setSatisfaction('${c.id}',+this.value)">
          <span style="font-size:12px;font-weight:600;min-width:36px;color:${(sat||5)>=7?'#16A34A':(sat||5)>=5?'#D97706':'#E84545'}" id="sat-val-${c.id}" data-satval>${sat||5}/10</span>
        </div>
        <button class="btn btn-g btn-sm" style="margin-left:auto" onclick="NAV.openReport('${c.id}')">View full report →</button>
      </div>
    </div>`;
  },
  setSatisfaction(cid,val){
    this._satisfaction[cid]=val;
    // Find the report for this client
    const yrs=DB.getYears(cid); if(!yrs.length) return;
    const yr=yrs[yrs.length-1];
    const mons=DB.getMonths(cid,yr); if(!mons.length) return;
    const rep=DB.getReport(cid,yr,mons[mons.length-1]); if(!rep) return;
    const newScore=this._score(cid,rep);
    const col=newScore>=75?'#16A34A':newScore>=60?'#3B82F6':newScore>=50?'#D97706':'#E84545';
    const grade=newScore>=75?'Healthy':newScore>=60?'Good':newScore>=50?'Fair':'Needs attention';
    const satCol=val>=7?'#16A34A':val>=5?'#D97706':'#E84545';
    // Update all elements by ID — reliable, no DOM traversal needed
    const scoreEl=document.getElementById('snap-score-'+cid);
    const gradeEl=document.getElementById('snap-grade-'+cid);
    const satValEl=document.getElementById('sat-val-'+cid);
    const satBigEl=document.getElementById('sat-big-'+cid);
    if(scoreEl){ scoreEl.textContent=newScore; scoreEl.style.color=col; }
    if(gradeEl){ gradeEl.textContent=grade; gradeEl.style.color=col; }
    if(satValEl){ satValEl.textContent=val+'/10'; satValEl.style.color=satCol; }
    if(satBigEl){ satBigEl.textContent=val; satBigEl.style.color=satCol; }
    // Update card border
    const slider=document.getElementById('sat-slider-'+cid);
    const card=slider?.closest('.card');
    if(card) card.style.borderTopColor=col;
  },
  removeNote(cid,type,idx){
    if(!this._highlights[cid]) return;
    const arr=type==='win'?this._highlights[cid].wins:this._highlights[cid].concerns;
    if(arr) arr.splice(idx,1);
    this.build();
  },
  saveSnapshot(cid,mon,yr){
    if(!this._history[cid]) this._history[cid]={};
    const key=yr+'-'+mon;
    const rep=DB.getReport(cid,yr,mon)||DB.getReport(cid,parseInt(yr),mon);
    const sat=this._satisfaction[cid]||5;
    const h=this._highlights[cid]||{wins:[],concerns:[]};
    const score=rep?this._score(cid,rep):50;
    this._history[cid][key]={
      score,sat,month:mon,year:yr,ts:new Date().toISOString(),
      wins:[...(h.wins||[])],concerns:[...(h.concerns||[])],
      label:(DB.ML[mon]||mon)+' '+(yr||'')
    };
    INTEL.record('Health snapshot saved',cid+' '+key);
    this.build();
  },
  toggleHistory(cid){
    const el=document.getElementById('snap-hist-'+cid); if(!el) return;
    el.style.display=el.style.display==='none'?'block':'none';
  },
  _renderHistory(cid){
    const hist=this._history[cid]; if(!hist||!Object.keys(hist).length) return'';
    const entries=Object.entries(hist).sort((a,b)=>b[0].localeCompare(a[0]));
    return'<div style="border-top:1px solid var(--bd0);padding-top:10px">'
      +'<div style="font-size:10px;font-weight:700;color:var(--t2);text-transform:uppercase;letter-spacing:.8px;margin-bottom:10px">Historical health scores</div>'
      +entries.map(([key,e])=>{
        const col=e.score>=75?'#16A34A':e.score>=60?'#3B82F6':e.score>=50?'#D97706':'#E84545';
        const satCol=e.sat>=7?'#16A34A':e.sat>=5?'#D97706':'#E84545';
        return'<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;padding:10px 0;border-bottom:1px solid var(--bd0)">'
          +'<div style="flex:1">'
          +'<div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">'
          +'<div style="font-size:24px;font-weight:800;line-height:1;color:'+col+'">'+e.score+'</div>'
          +'<div><div style="font-size:13px;font-weight:600">'+e.label+'</div>'
          +'<div style="font-size:10.5px;color:var(--t2)">Satisfaction: <span style="color:'+satCol+';font-weight:600">'+e.sat+'/10</span></div></div></div>'
          +(e.wins.length?'<div style="font-size:11.5px;color:var(--g);margin-bottom:2px"> '+e.wins.slice(0,2).join(' · ')+(e.wins.length>2?' +'+(e.wins.length-2)+' more':'')+'</div>':'')
          +(e.concerns.length?'<div style="font-size:11.5px;color:var(--r)">⚠️ '+e.concerns.slice(0,2).join(' · ')+(e.concerns.length>2?' +'+(e.concerns.length-2)+' more':'')+'</div>':'')
          +'<div style="font-size:10px;color:var(--t2);margin-top:4px">'+new Date(e.ts).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'})+'</div>'
          +'</div>'
          +'<div style="display:flex;flex-direction:column;gap:4px;flex-shrink:0">'
          +'<button class="btn btn-g btn-sm" style="font-size:9.5px" onclick="SNAPSHOT.editHistoryEntry(this.dataset.cid,this.dataset.key)" data-cid="'+cid+'" data-key="'+key+'">Edit</button>'
          +'<button class="btn btn-r btn-sm" style="font-size:9.5px" onclick="SNAPSHOT.deleteHistoryEntry(this.dataset.cid,this.dataset.key)" data-cid="'+cid+'" data-key="'+key+'">Delete</button>'
          +'</div>'
          +'</div>';
      }).join('')
      +'</div>';
  },
  editHistoryEntry(cid,key){
    const e=this._history[cid]?.[key]; if(!e) return;
    document.getElementById('snap-note-label').textContent='Edit notes for '+e.label;
    this._editHistCid=cid; this._editHistKey=key;
    MODAL.open('modal-snap-note');
    document.getElementById('snap-note-input').value=e.wins.concat(e.concerns).join(', ');
  },
  deleteHistoryEntry(cid,key){
    if(!this._history[cid]) return;
    delete this._history[cid][key];
    // Re-render the history panel
    const el=document.getElementById('snap-hist-'+cid);
    if(el) el.innerHTML=this._renderHistory(cid);
    else this.build();
  },
  _editHistCid:null, _editHistKey:null,
  _addNoteType:null, _addNoteCid:null,
  addNote(cid,type){
    this._addNoteType=type; this._addNoteCid=cid;
    const el=document.getElementById('snap-note-input');
    const label=document.getElementById('snap-note-label');
    if(el) el.value='';
    if(label) label.textContent=type==='win'?'Add a win or highlight:':'Add a strategic concern:';
    MODAL.open('modal-snap-note');
  },
  saveSnapNote(){
    const text=document.getElementById('snap-note-input')?.value?.trim(); if(!text) return;
    const cid=this._addNoteCid; const type=this._addNoteType;
    if(!this._highlights[cid]) this._highlights[cid]={wins:[],concerns:[]};
    this._highlights[cid][type==='win'?'wins':'concerns'].push(text);
    MODAL.close('modal-snap-note');
    this.build();
  },
};

const HEALTH = { _score(cid,rep){ return SNAPSHOT._score(cid,rep); }, build(){ SNAPSHOT.build(); } };
const EXEC = { build(){ SNAPSHOT.build(); } };

/* ══════════════════════════════════════════════════════════
   CAMPAIGN TIMELINE
══════════════════════════════════════════════════════════ */
const TIMELINE = {
  _events:[
    {id:"ev-1",client_id:"cl-bl",date:"2026-02-01",type:"email",title:"Valentine's CCH Campaign",notes:"4x newsletter sends",colour:"#ED7209"},
    {id:"ev-2",client_id:"cl-bl",date:"2026-02-01",type:"paid",title:"CCH Meta Valentine's Ads",notes:"£623 spend, boosted reach",colour:"#3B82F6"},
    {id:'ev-3',client_id:'cl-bl',date:'2026-02-10',type:'content',title:'Social Series Branding Launch',notes:'Torque Talk, Hero of the Week etc',colour:'#22C55E'},
    {id:'ev-4',client_id:'cl-bl',date:'2026-02-15',type:'website',title:'Castle Combe Lightboxes Live',notes:'New campaign landing assets',colour:'#8B5CF6'},
    {id:'ev-5',client_id:'cl-gt',date:'2026-02-01',type:'email',title:'We Buy Your Trailer Campaign',notes:'~49% open rate achieved',colour:'#ED7209'},
    {id:'ev-6',client_id:'cl-gt',date:'2026-02-15',type:'website',title:'Towbar Gallery Redesign',notes:'Vehicle model selector launched',colour:'#8B5CF6'},
    // Topaz Detailing events
    {id:'ev-td-1',client_id:'cl-td',date:'2026-03-01',type:'email',title:'Topaz HubSpot Campaign',notes:'Email marketing baseline — 1,781 new contacts added',colour:'#ec1d24'},
    {id:'ev-td-2',client_id:'cl-td',date:'2026-03-01',type:'paid',title:'Studios Meta Advertising',notes:'£4,728 Studios paid spend — March baseline',colour:'#ec1d24'},
    {id:'ev-td-3',client_id:'cl-td',date:'2026-03-15',type:'content',title:'Social Content Drive',notes:'1.4M Instagram views across all Topaz accounts',colour:'#ec1d24'},
    {id:'ev-td-4',client_id:'cl-td',date:'2026-04-01',type:'paid',title:'Reduced Ad Spend — April',notes:'Studios spend down 37% to £2,967. Shop down 61% to £1,096. Paid social efficiency improved.',colour:'#ec1d24'},
    {id:'ev-td-5',client_id:'cl-td',date:'2026-04-01',type:'email',title:'April Email Campaign',notes:'1 campaign sent — 14.17% open rate, 0.97% CTR',colour:'#ec1d24'},
    {id:'ev-td-6',client_id:'cl-td',date:'2026-04-15',type:'content',title:'YouTube Growth',notes:'69,598 views (+34.5%), 2,801 watch hours (+51.9%) — strongest month on record',colour:'#ec1d24'},
  ],
  _typeColours:{email:'#ED7209',paid:'#3B82F6',content:'#22C55E',website:'#8B5CF6',pr:'#F59E0B',event:'#EC4899'},
  build(){
    const el=document.getElementById('timeline-content'); if(!el) return;
    // Group by client, then by year/month
    const byClient={};
    for(const ev of this._events){
      const cid=ev.client_id; const c=DB.getClient(cid);
      if(!byClient[cid]) byClient[cid]={name:c?.name||cid,events:[]};
      byClient[cid].events.push(ev);
    }
    const legend=`<div style="margin-bottom:16px;display:flex;gap:10px;flex-wrap:wrap">
      ${Object.entries(this._typeColours).map(([t,col])=>`<span style="display:inline-flex;align-items:center;gap:5px;font-size:11px"><span style="width:9px;height:9px;border-radius:50%;background:${col};display:inline-block"></span>${t.charAt(0).toUpperCase()+t.slice(1)}</span>`).join('')}
    </div>`;
    el.innerHTML=legend+Object.entries(byClient).map(([cid,data])=>{
      const sorted=[...data.events].sort((a,b)=>b.date.localeCompare(a.date));
      // Group by year-month
      const byMonth={};
      for(const ev of sorted){ const ym=ev.date.slice(0,7); if(!byMonth[ym]) byMonth[ym]=[]; byMonth[ym].push(ev); }
      return`<div class="acc-item" style="margin-bottom:10px">
        <div class="acc-hd" onclick="this.closest('.acc-item').classList.toggle('open')">
          <div class="acc-name">${data.name}</div>
          <div style="display:flex;align-items:center;gap:6px"><span class="badge bn" style="font-size:10px">${data.events.length} event${data.events.length!==1?'s':''}</span><span class="acc-arrow">▾</span></div>
        </div>
        <div class="acc-body">
          ${Object.entries(byMonth).map(([ym,evs])=>`
            <div style="font-size:10.5px;font-weight:700;color:var(--o);text-transform:uppercase;letter-spacing:.8px;padding:10px 0 5px;border-bottom:1px solid var(--bd0);margin-bottom:8px">${new Date(ym+'-01').toLocaleDateString('en-GB',{month:'long',year:'numeric'})}</div>
            <div style="position:relative;padding-left:20px;margin-bottom:12px">
              <div style="position:absolute;left:0;top:0;bottom:0;width:2px;background:var(--bd1)"></div>
              ${evs.map(ev=>{
                const col=this._typeColours[ev.type]||'var(--y)';
                return`<div style="position:relative;margin-bottom:12px">
                  <div style="position:absolute;left:-24px;top:8px;width:10px;height:10px;border-radius:50%;background:${col};border:2px solid var(--bg1)"></div>
                  <div class="card" style="border-left:3px solid ${col};padding:10px 12px;margin-bottom:0">
                    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px">
                      <div style="flex:1">
                        <div style="font-size:10px;color:var(--t2);margin-bottom:2px">${new Date(ev.date).toLocaleDateString('en-GB',{day:'numeric',month:'short'})} · <span class="badge bn" style="font-size:8.5px">${ev.type}</span></div>
                        <div style="font-size:13px;font-weight:600;margin-bottom:2px">${ev.title}</div>
                        ${ev.description||ev.notes?`<div style="font-size:12px;color:var(--t1);margin-bottom:3px">${ev.description||ev.notes}</div>`:''}
                        ${ev.link?`<a href="${ev.link}" target="_blank" style="font-size:11px;color:var(--bl)">🔗 ${ev.link.slice(0,50)}${ev.link.length>50?'…':''}</a>`:''}
                        ${ev.kpi_note?`<div style="font-size:11px;color:var(--am);margin-top:3px">📊 ${ev.kpi_note}</div>`:''}
                      </div>
                      <div style="display:flex;gap:4px;flex-shrink:0">
                        <button class="btn btn-g btn-sm" style="font-size:9.5px" onclick="TIMELINE.editEvent('${ev.id}')">Edit</button>
                        <button class="btn btn-r btn-sm" style="font-size:9.5px" onclick="TIMELINE.deleteEvent('${ev.id}')">✕</button>
                      </div>
                    </div>
                  </div>
                </div>`;
              }).join('')}
            </div>`).join('')}
        </div>
      </div>`;
    }).join('')+'<div class="ins a" style="margin-top:10px"><p>Cross-reference campaign dates with traffic and engagement changes to validate campaign impact.</p></div>';
  },
  _openModal(ev){
    const clients=DB.getParents();
    document.getElementById('tev-client').innerHTML=clients.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
    document.getElementById('tev-id').value=ev?.id||'';
    document.getElementById('tev-title').textContent=ev?'Edit event':'Add campaign event';
    document.getElementById('tev-name').value=ev?.title||'';
    document.getElementById('tev-date').value=ev?.date||new Date().toISOString().split('T')[0];
    document.getElementById('tev-type').value=ev?.type||'content';
    document.getElementById('tev-client').value=ev?.client_id||clients[0]?.id||'';
    document.getElementById('tev-desc').value=ev?.description||ev?.notes||'';
    document.getElementById('tev-link').value=ev?.link||'';
    document.getElementById('tev-kpi').value=ev?.kpi_note||'';
    MODAL.open('modal-timeline-event');
  },
  saveEvent(){
    const id=document.getElementById('tev-id').value;
    const title=document.getElementById('tev-name').value.trim(); if(!title) return;
    const date=document.getElementById('tev-date').value||new Date().toISOString().split('T')[0];
    const type=document.getElementById('tev-type').value;
    const cid=document.getElementById('tev-client').value;
    const desc=document.getElementById('tev-desc').value.trim();
    const link=document.getElementById('tev-link').value.trim();
    const kpiNote=document.getElementById('tev-kpi').value.trim();
    const col=this._typeColours[type]||'#FFD600';
    if(id){
      const ev=this._events.find(e=>e.id===id);
      if(ev) Object.assign(ev,{title,date,type,client_id:cid,description:desc,notes:desc,link,kpi_note:kpiNote,colour:col});
      INTEL.record('Timeline event edited',title);
    } else {
      this._events.push({id:'ev-'+Date.now(),client_id:cid,date,type,title,notes:desc,description:desc,link,kpi_note:kpiNote,colour:col});
      INTEL.record('Timeline event added',title);
    }
    MODAL.close('modal-timeline-event');
    this.build();
  },
  editEvent(id){ const ev=this._events.find(e=>e.id===id); if(ev) this._openModal(ev); },
  deleteEvent(id){
    if(!this._events.find(e=>e.id===id)) return;
    this._events=this._events.filter(e=>e.id!==id);
    INTEL.record('Timeline event deleted',id);
    this.build();
  },
  addEvent(){ this._openModal(null); },
};

/* ══════════════════════════════════════════════════════════
   INTERNAL WORKSPACE (Admin-only notes)
══════════════════════════════════════════════════════════ */
const WORKSPACE = {
  _notes:[
    {id:'n-1',client_id:'cl-bl',type:'prep',content:'Blendini Feb report: bot traffic spike (43k sessions China/Singapore) excluded from conversion rate. Use adjusted figure of 10.01% in client comms.',author:'Karbon Creative',ts:'2026-03-01T08:00:00Z'},
    {id:'n-2',client_id:'cl-bl',type:'observation',content:'Review rating consistently below 4.0 target. Worth flagging in Q1 review. Client may need a proactive review generation campaign.',author:'Karbon Creative',ts:'2026-03-01T09:00:00Z'},
    {id:'n-3',client_id:'cl-gt',type:'prep',content:'GT Towing Feb: strong month overall. Client is focused on email list growth to 20k — mention resend strategy success in the walkthrough.',author:'Karbon Creative',ts:'2026-03-01T10:00:00Z'},
  ],
  build(){
    const sel=document.getElementById('ws-client-sel');
    if(sel) sel.innerHTML=DB.getParents().map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
    this.load();
  },
  load(){
    const el=document.getElementById('workspace-notes'); if(!el) return;
    const cid=document.getElementById('ws-client-sel')?.value||DB.getParents()[0]?.id;
    const notes=this._notes.filter(n=>n.client_id===cid).sort((a,b)=>b.ts.localeCompare(a.ts));
    const typeLabel={prep:'Report Prep',observation:'Observation',action:'Action Required',internal:'Internal Note'};
    const typeCol={prep:'var(--bl)',observation:'var(--am)',action:'var(--r)',internal:'var(--t2)'};
    if(!notes.length){ el.innerHTML='<p style="font-size:13px;color:var(--t1)">No internal notes for this client yet.</p>'; return; }
    el.innerHTML=notes.map(n=>`<div class="card" style="margin-bottom:10px;border-left:3px solid ${typeCol[n.type]||'var(--t2)'}">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:8px">
        <div>
          <span class="badge bn" style="font-size:9.5px">${typeLabel[n.type]||n.type}</span>
          <span style="font-size:10.5px;color:var(--t2);margin-left:8px">${F.date(n.ts)} · ${n.author}</span>
        </div>
        <button class="btn btn-r btn-sm" onclick="WORKSPACE.delete('${n.id}')">Delete</button>
      </div>
      <div style="font-size:13px;color:var(--t0);line-height:1.65">${n.content}</div>
    </div>`).join('');
  },
  addNote(){
    const cid=document.getElementById('ws-client-sel')?.value||DB.getParents()[0]?.id;
    document.getElementById('ws-note-type').value='observation';
    document.getElementById('ws-note-content').value='';
    document.getElementById('ws-note-client').value=cid;
    MODAL.open('modal-workspace-note');
  },
  saveNote(){
    const cid=document.getElementById('ws-note-client').value;
    const type=document.getElementById('ws-note-type').value;
    const content=document.getElementById('ws-note-content').value.trim(); if(!content) return;
    this._notes.push({id:'n-'+Date.now(),client_id:cid,type,content,author:S.user?.name||'Admin',ts:new Date().toISOString()});
    INTEL.record('Internal note added',content.slice(0,40));
    MODAL.close('modal-workspace-note');
    this.load();
  },
  delete(id){ this._notes=this._notes.filter(n=>n.id!==id); INTEL.record('Internal note deleted',id); this.load(); },
};

/* ══════════════════════════════════════════════════════════
   SAVED VIEWS
══════════════════════════════════════════════════════════ */
const TEMPLATES = {
  _builtIn:[
    {id:'t-1',name:'Full Monthly Report',desc:'Complete report with all modules — ideal for standard monthly client reports.',modules:['overview','kpis','social','paid_advertising','website','email','creative_assets','tasks'],icon:'▤',type:'built-in'},
    {id:'t-2',name:'Executive Summary',desc:'High-level overview for directors and senior stakeholders.',modules:['overview','kpis','forecast'],icon:'◧',type:'built-in'},
    {id:'t-3',name:'Social & Paid Focus',desc:'Social media and paid advertising performance focus.',modules:['social','paid_advertising'],icon:'📱',type:'built-in'},
    {id:'t-4',name:'Email Marketing Report',desc:'Dedicated email marketing performance report.',modules:['email'],icon:'✉️',type:'built-in'},
    {id:'t-5',name:'Website Analytics',desc:'Website traffic, conversion and UX-focused report.',modules:['website'],icon:'🌐',type:'built-in'},
    {id:'t-6',name:'Creative & Delivery',desc:'Tasks completed and creative assets delivered.',modules:['creative_assets','tasks'],icon:'🖼',type:'built-in'},
    {id:'t-7',name:'KPI & Forecasting',desc:'KPI tracking and year-ahead performance forecasting.',modules:['kpis','forecast'],icon:'📈',type:'built-in'},
  ],
  _custom:[],
  build(){
    const el=document.getElementById('templates-list'); if(!el) return;
    const all=[...this._builtIn,...this._custom];
    el.innerHTML=`<div style="font-size:11px;font-weight:700;color:var(--t2);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px">Built-in templates</div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px;margin-bottom:24px">
      ${this._builtIn.map(t=>this._card(t)).join('')}
    </div>
    ${this._custom.length?`<div style="font-size:11px;font-weight:700;color:var(--t2);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px">Custom templates</div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px">
      ${this._custom.map(t=>this._card(t)).join('')}
    </div>`:'<div class="ins a"><p>No custom templates yet. Save a report as a template or build one from scratch above.</p></div>'}`;
  },
  _card(t){
    const isCustom=t.type!=='built-in';
    return`<div class="card" style="position:relative">
      <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:10px">
        <span style="font-size:22px;flex-shrink:0">${t.icon}</span>
        <div style="flex:1">
          <div style="font-size:13.5px;font-weight:700;margin-bottom:2px">${t.name}</div>
          <div style="font-size:11px;color:var(--t2);margin-bottom:6px">${t.modules.length} module${t.modules.length!==1?'s':''}</div>
          <div style="font-size:12px;color:var(--t1);margin-bottom:10px">${t.desc}</div>
          <div style="display:flex;flex-wrap:wrap;gap:3px;margin-bottom:10px">${t.modules.map(m=>`<span style="font-size:9px;background:var(--bg2);border:1px solid var(--bd0);border-radius:3px;padding:1px 5px">${DB.MODL[m]||m}</span>`).join('')}</div>
        </div>
      </div>
      <div style="display:flex;gap:6px">
        <button class="btn btn-y btn-sm" style="flex:1" onclick="TEMPLATES.apply('${t.id}')">Apply to report</button>
        ${isCustom?`<button class="btn btn-r btn-sm" onclick="TEMPLATES.delete('${t.id}')">Delete</button>`:''}
      </div>
    </div>`;
  },
  _saveModalMode:null,
  saveFromCurrent(){
    const c=DB.getClient(S.clientId); if(!c) return;
    this._saveModalMode='current';
    document.getElementById('st-modal-title').textContent='Save report as template';
    document.getElementById('st-name').value=`${c.name} template`;
    document.getElementById('st-desc').value=`Saved from ${c.name} — ${DB.ML[S.month]||S.month} ${S.year}`;
    const mods=DB.MODO;
    document.getElementById('st-modules').innerHTML=mods.map(m=>`<label style="display:flex;align-items:center;gap:7px;font-size:12.5px;padding:5px 8px;background:var(--bg2);border-radius:var(--rs);cursor:pointer"><input type="checkbox" value="${m}" ${c.modules[m]?'checked':''}> ${DB.MODL[m]||m}</label>`).join('');
    MODAL.open('modal-save-template');
  },
  createBlank(){
    this._saveModalMode='blank';
    document.getElementById('st-modal-title').textContent='Create blank template';
    document.getElementById('st-name').value='';
    document.getElementById('st-desc').value='';
    const mods=DB.MODO;
    document.getElementById('st-modules').innerHTML=mods.map(m=>`<label style="display:flex;align-items:center;gap:7px;font-size:12.5px;padding:5px 8px;background:var(--bg2);border-radius:var(--rs);cursor:pointer"><input type="checkbox" value="${m}"> ${DB.MODL[m]||m}</label>`).join('');
    MODAL.open('modal-save-template');
  },
  saveModal(){
    const name=document.getElementById('st-name').value.trim(); if(!name) return;
    const desc=document.getElementById('st-desc').value.trim();
    const modules=[...document.querySelectorAll('#st-modules input:checked')].map(i=>i.value);
    if(!modules.length){ document.getElementById('st-name').focus(); return; }
    this._custom.push({id:'t-'+Date.now(),name,desc,modules,icon:'⊛',type:'custom',created:new Date().toISOString()});
    INTEL.record('Template created',name);
    MODAL.close('modal-save-template');
    this.build();
  },
  apply(id){
    const t=[...this._builtIn,...this._custom].find(x=>x.id===id); if(!t) return;
    const c=DB.getClient(S.clientId); if(!c) return;
    if(!confirm(`Apply template "${t.name}" to ${c.name}? This will update which modules are visible.`)) return;
    DB.MODO.forEach(m=>c.modules[m]=false);
    t.modules.forEach(m=>c.modules[m]=true);
    INTEL.record('Template applied',`${t.name} → ${c.name}`);
    NAV.openReport(S.clientId);
  },
  delete(id){ this._custom=this._custom.filter(t=>t.id!==id); this.build(); },
  // Called from Add Report modal to populate template selector
  getAll(){ return[...this._builtIn,...this._custom]; },
};

/* STRATEGY PDFs */
const STRAT = {
  _docs:[], // {id, client_id, title, year, size, date, data, visible_to_client}
  build(){
    const sel=document.getElementById('spdf-client');
    if(sel) sel.innerHTML=DB.getParents().map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
    this.load();
  },
  load(){
    const el=document.getElementById('spdf-list'); if(!el) return;
    const cid=document.getElementById('spdf-client')?.value||DB.getParents()[0]?.id;
    const docs=this._docs.filter(d=>d.client_id===cid).sort((a,b)=>b.year-a.year||a.title.localeCompare(b.title));
    if(!docs.length){ el.innerHTML='<div class="ins a"><p>No strategy PDFs uploaded for this client yet.</p></div>'; return; }
    // Group by year
    const byYear={};
    for(const d of docs){ if(!byYear[d.year]) byYear[d.year]=[]; byYear[d.year].push(d); }
    el.innerHTML=Object.entries(byYear).sort((a,b)=>b[0]-a[0]).map(([yr,items])=>`
      <div style="margin-bottom:18px">
        <div style="font-size:11px;font-weight:700;color:var(--o);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px">${yr}</div>
        ${items.map(d=>`<div class="card" style="display:flex;align-items:center;gap:12px;margin-bottom:8px;padding:12px 14px">
          <span style="font-size:28px;flex-shrink:0">📄</span>
          <div style="flex:1">
            <div style="font-size:13.5px;font-weight:600">${d.title}</div>
            <div style="font-size:11px;color:var(--t2)">${d.date} · ${d.size} · ${d.visible_to_client?'Visible to client':'Admin only'}</div>
          </div>
          <div style="display:flex;gap:6px">
            ${d.data?`<button class="btn btn-y btn-sm" onclick="STRAT.view('${d.id}')">View</button><a href="${d.data}" download="${d.title}.pdf" class="btn btn-g btn-sm">Download</a>`:''}
            <button class="btn btn-g btn-sm" onclick="STRAT.editDoc('${d.id}')">Edit</button>
            <button class="btn btn-g btn-sm" onclick="STRAT.toggleClient('${d.id}')">${d.visible_to_client?'Hide from client':'Share with client'}</button>
            <button class="btn btn-r btn-sm" onclick="STRAT.delete('${d.id}')">Delete</button>
          </div>
        </div>`).join('')}
      </div>`).join('');
  },
  _pendingFile:null,
  upload(input){
    const f=input.files[0]; if(!f) return;
    this._pendingFile=f;
    document.getElementById('spdf-modal-title').textContent='Upload strategy PDF';
    document.getElementById('spdf-title').value=f.name.replace('.pdf','').replace(/-/g,' ');
    document.getElementById('spdf-year').value='2026';
    document.getElementById('spdf-notes').value='';
    document.getElementById('spdf-edit-id').value='';
    document.getElementById('spdf-file-wrap').style.display='none';
    input.value='';
    MODAL.open('modal-strat-pdf');
  },
  editDoc(id){
    const d=this._docs.find(x=>x.id===id); if(!d) return;
    this._pendingFile=null;
    document.getElementById('spdf-modal-title').textContent='Edit document';
    document.getElementById('spdf-title').value=d.title;
    document.getElementById('spdf-year').value=d.year;
    document.getElementById('spdf-notes').value=d.notes||'';
    document.getElementById('spdf-edit-id').value=id;
    document.getElementById('spdf-file-wrap').style.display='';
    MODAL.open('modal-strat-pdf');
  },
  saveModal(){
    const id=document.getElementById('spdf-edit-id').value;
    const title=document.getElementById('spdf-title').value.trim()||'Untitled';
    const year=parseInt(document.getElementById('spdf-year').value)||2026;
    const notes=document.getElementById('spdf-notes').value.trim();
    const cid=document.getElementById('spdf-client')?.value||DB.getParents()[0]?.id;
    if(id){
      // Edit existing
      const d=this._docs.find(x=>x.id===id);
      const newFile=document.getElementById('spdf-file-input')?.files[0];
      const doSave=(data)=>{
        if(d){ d.title=title; d.year=year; d.notes=notes; if(data) d.data=data; }
        INTEL.record('Strategy PDF updated',title);
        MODAL.close('modal-strat-pdf');
        this.load();
      };
      if(newFile){ const r=new FileReader(); r.onload=e=>doSave(e.target.result); r.readAsDataURL(newFile); }
      else doSave(null);
    } else {
      // New upload
      if(!this._pendingFile) return;
      const f=this._pendingFile;
      const reader=new FileReader();
      reader.onload=e=>{
        this._docs.push({id:'spdf-'+Date.now(),client_id:cid,title,year,notes,size:this._fmtSize(f.size),date:new Date().toLocaleDateString('en-GB'),data:e.target.result,visible_to_client:false});
        INTEL.record('Strategy PDF uploaded',title);
        MODAL.close('modal-strat-pdf');
        this.load();
      };
      reader.readAsDataURL(f);
      this._pendingFile=null;
    }
  },
  view(id){
    const d=this._docs.find(x=>x.id===id); if(!d||!d.data) return;
    document.getElementById('pdf-viewer-title').textContent=d.title;
    document.getElementById('pdf-viewer-dl').href=d.data;
    document.getElementById('pdf-viewer-dl').download=d.title+'.pdf';
    document.getElementById('pdf-viewer-frame').src=d.data;
    MODAL.open('modal-pdf-viewer');
  },
  toggleClient(id){ const d=this._docs.find(x=>x.id===id); if(d) d.visible_to_client=!d.visible_to_client; this.load(); },
  delete(id){ this._docs=this._docs.filter(x=>x.id!==id); this.load(); },
  _fmtSize(b){ return b>1e6?(b/1e6).toFixed(1)+'MB':b>1e3?(b/1e3).toFixed(0)+'KB':b+'B'; },
};

/* UI */
const _origSetMetric=DB.setMetric.bind(DB);
DB.setMetric=function(cid,yr,mon,key,val){ _origSetMetric(cid,yr,mon,key,val); INTEL.record('Metric updated',`${DB.getClient(cid)?.name} ${mon} ${yr} — ${key}: ${val}`); };
const _origSetStatus=DB.setStatus.bind(DB);
DB.setStatus=function(cid,yr,mon,s){
  _origSetStatus(cid,yr,mon,s);
  const detail=`${DB.getClient(cid)?.name} ${mon} ${yr} → ${s}${S.user?' (by '+S.user.name+')':''}`;
  INTEL.record('Status changed',detail);
  // Record approver on the report
  const rep=DB.getReport(cid,yr,mon);
  if(rep&&s==='approved') rep._approved_by=S.user?.name||'Unknown';
  if(rep&&s==='published') rep._published_by=S.user?.name||'Unknown';
};
const _origLogEmail=DB.logEmail.bind(DB);
DB.logEmail=function(e){ _origLogEmail(e); INTEL.record('Report email sent',`to ${e.recipients} by ${e.sent_by_name}`); };

/* CLIENT — for client-facing navigation */

export { ADMIN, REPORT, BUILDER, INTEL, OPPS, SNAPSHOT, TIMELINE, STRAT };
