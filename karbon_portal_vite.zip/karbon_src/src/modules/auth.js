import { DB, S } from "./db.js";
import { getCompanyBrandColour, getContrastText } from "./helpers.js";

const AUTH = {
  login(){
    const e=document.getElementById('l-em').value.trim().toLowerCase();
    const p=document.getElementById('l-pw').value;
    const u=DB.findUser(e,p);
    if(!u){ document.getElementById('l-err').style.display='block'; return; }
    document.getElementById('l-err').style.display='none';
    // Normalise all company/client colours on login
    DB.syncCompanyColours();
    // Ensure existing demo companies have correct colours from _companies record
    (function normaliseDemoColours(){
      const cos=DB.getCompanies();
      cos.forEach(co=>{
        if(!co.colour&&co.clientIds?.[0]){
          const cl=DB.getClient(co.clientIds[0]);
          if(cl?.brand_colour) co.colour=cl.brand_colour; // adopt existing client colour
        }
      });
    })();
    S.user=u;
    this._boot(u);
  },
  _boot(u){
    document.getElementById('login').style.display='none';
    document.getElementById('app').classList.add('on');
    document.querySelectorAll('.mbg').forEach(m=>{if(m.parentElement!==document.body)document.body.appendChild(m);});
    document.getElementById('login-logo').innerHTML=Logo(22);
    // Restore sidebar collapsed state
    try{ if(localStorage.getItem('sb-collapsed')==='1'){ const sb=document.getElementById('sidebar'); if(sb) sb.classList.add('collapsed'); } }catch(e){}
    document.getElementById('tb-logo').innerHTML=Logo(20);
    this._updateAvatar(u);
    document.getElementById('uname').textContent=u.name;
    if(u.role==='admin'){
      // Reset stale state from previous session (including any client-hidden elements)
      ['sidebar','abar'].forEach(id=>{ const el=document.getElementById(id); if(el){el.style.removeProperty('display');el.classList.remove('on');} });
      document.querySelectorAll('[data-admin-only]').forEach(el=>el.style.removeProperty('display'));
      document.getElementById('ubadge').style.display='inline-block';
      document.getElementById('sidebar').classList.add('on');
      document.getElementById('abar').classList.add('on');
      document.body.classList.add('is-admin');
      ADMIN.buildClients();
      ADMIN.buildKpiBanner();
      AI.hide(); // Scooby is client-side only
      setTimeout(()=>INTEL._updateSidebarBadges(),500);
      NAV.go('clients',document.getElementById('sb-clients'));
    } else {
      // CLIENT: strict isolation — only their assigned clients and published reports
      const ids=u.client_ids.filter(id=>DB.getClient(id)); // filter to valid clients only
      if(!ids.length){ document.body.innerHTML='<div style="padding:40px;text-align:center;font-family:sans-serif;color:#fff"><h2>No accounts assigned</h2><p>Please contact your account manager.</p></div>'; return; }
      // Pick first client with a published report
      let chosenClient=ids[0], chosenYear=null, chosenMonth=null;
      for(const id of ids){
        const yrs=DB.getYears(id);
        for(const yr of [...yrs].reverse()){
          const mons=DB.getMonths(id,yr).filter(m=>DB.getReport(id,yr,m)?.status==='published');
          if(mons.length){ chosenClient=id; chosenYear=yr; chosenMonth=mons[mons.length-1]; break; }
        }
        if(chosenYear) break;
      }
      S.clientId=chosenClient;
      S.year=chosenYear||(DB.getYears(chosenClient).slice(-1)[0]||2026);
      S.month=chosenMonth||(DB.getMonths(chosenClient,S.year).slice(-1)[0]||'Jan');
      REPORT.buildMonthBtns();
      REPORT.render();
      NAV.go('report',null);
      // Hide ALL admin controls
      document.getElementById('abar').classList.remove('on');
      document.getElementById('abar').style.display='none';
      // Hide sidebar entirely for clients — they only have reports + settings
      document.getElementById('sidebar')?.classList.remove('on');
      // Show client account switcher only if multiple valid clients assigned
      if(ids.length>1 && !document.getElementById('client-switcher')){
        const switcher=document.createElement('div');
        switcher.id='client-switcher';
        switcher.style.cssText='background:var(--bg1);border-bottom:1px solid var(--bd0);padding:8px 18px;display:flex;align-items:center;gap:8px;font-size:12px;flex-wrap:wrap;';
        switcher.innerHTML='<span style="color:var(--t2);font-size:10px;font-weight:600;letter-spacing:.8px;text-transform:uppercase">Your accounts:</span>'
          + ids.map(id=>{ const cl=DB.getClient(id); return cl?`<button class="mbtn${id===S.clientId?' on':''}" onclick="CLIENT.switchTo('${id}')">${cl.name}</button>`:'' }).join('');
        const reportView=document.getElementById('v-report');
        if(reportView) reportView.insertBefore(switcher, reportView.firstChild);
      }
    }
    EMAIL.populateClients();
    SETTINGS.load();
  },
  _updateAvatar(u){
    // Set top-right avatar colour from company brand colour
    const _uavEl=document.getElementById('uav');
    if(_uavEl){
      const _uavCos=typeof DB!=='undefined'?DB.getCompanies().filter(c=>(u.companies||[u.company].filter(Boolean)).some(id=>c.id===id)):[];
      const _uavCol=_uavCos[0]?.colour||getCompanyBrandColour((u.companies||[u.company].filter(Boolean))[0]||'');
      _uavEl.style.background=_uavCol||'var(--bg2)';
      _uavEl.style.color=getContrastText(_uavCol||'#001a2e');
      _uavEl.textContent=u.initials||u.name?.[0]||'?';
    }
    const av=document.getElementById('uav');
    if(u.avatar) av.innerHTML=`<img src="${u.avatar}" alt="">`;
    else av.textContent=u.initials;
  },
  logout(){
    S.user=null; S.cmpActive=false;
    document.getElementById('login').style.display='';
    document.getElementById('app').classList.remove('on');
    document.body.classList.remove('is-admin');
    CHARTS.destroyAll();
    document.getElementById('l-em').value='';
    document.getElementById('l-pw').value='';
    document.getElementById('sidebar').classList.remove('on');
    document.getElementById('abar').classList.remove('on');
  },
};
document.addEventListener('keydown',e=>{ if(e.key==='Enter'&&document.getElementById('login').style.display!=='none') AUTH.login(); });

/* NAV */
const _origBoot=AUTH._boot.bind(AUTH);
AUTH._boot=function(u){
  if(u.role==='client'){
    const _portals=u.portals||['review'];
    if(_portals.length===1){
      // Single-portal client: skip area home, go directly
      document.getElementById('login').style.display='none';
      document.querySelectorAll('.mbg').forEach(m=>{if(m.parentElement!==document.body)document.body.appendChild(m);});
      document.getElementById('login-logo').innerHTML=Logo(22);
      document.getElementById('tb-logo').innerHTML=Logo(20);
      AUTH._updateAvatar(u); document.getElementById('uname').textContent=u.name;
      document.getElementById('ubadge').style.display='none'; document.body.classList.remove('is-admin');
      EMAIL.populateClients(); SETTINGS.load();
      ['sidebar','abar'].forEach(id=>{const e=document.getElementById(id);if(e){e.classList.remove('on');e.style.display='none';}});
      AREA.enter(_portals[0]); return;
    }
    // Multi-portal client: show area home
    // Clients use area-based flow — skip full reporting boot to avoid flash
    document.getElementById('login').style.display='none';
    document.querySelectorAll('.mbg').forEach(m=>{if(m.parentElement!==document.body)document.body.appendChild(m);});
    document.getElementById('login-logo').innerHTML=Logo(22);
    document.getElementById('tb-logo').innerHTML=Logo(20);
    AUTH._updateAvatar(u);
    document.getElementById('uname').textContent=u.name;
    // Hide admin UI immediately — never visible to clients
    document.getElementById('ubadge').style.display='none';
    document.body.classList.remove('is-admin');
    document.getElementById('sidebar')?.classList.remove('on');
    if(document.getElementById('abar')){
      document.getElementById('abar').classList.remove('on');
      document.getElementById('abar').style.display='none';
    }
    EMAIL.populateClients();
    SETTINGS.load();
  } else {
    // Reset any client-hidden elements before admin boot
    document.querySelectorAll('[data-admin-only]').forEach(el=>el.style.removeProperty('display'));
    _origBoot(u); // full reporting boot for admins
  }
  document.getElementById('app').classList.add('on');
  AREA.showHome();
};

// Init
document.getElementById('login-logo').innerHTML=Logo(22);
// Login button
document.addEventListener('DOMContentLoaded',function(){var b=document.getElementById('login-submit-btn');if(b) b.addEventListener('click',function(){ AUTH.login(); });});

export { AUTH };
