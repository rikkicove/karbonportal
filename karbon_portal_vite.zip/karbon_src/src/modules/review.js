import { DB, S, F, RV_DB as _RV_DB } from "./db.js";
import { getCompanyBrandColour, getContrastText } from "./helpers.js";

const RV_DB = {
  _jobs: [], // {id,title,clientId,folder,status,stage,due,desc,assignedTo,created,versions:[],comments:[],activity:[]}
  _jobSeq: 0,       // auto-increment job ID counter
  _brand_terms: [], // {id,term,replace,severity,clientId}
  _favourites: [], // jobIds that are pinned/favourited

  toggleFavourite(jobId){
    const idx=this._favourites.indexOf(jobId);
    if(idx>=0) this._favourites.splice(idx,1);
    else this._favourites.push(jobId);
  },
  isFavourite(jobId){ return this._favourites.includes(jobId); },

  // Two-stage: Internal Review stages, then Client Review stages
  STATUS_LABELS: {
    'ir:draft':'Draft','ir:ready':'Ready for Review','ir:amend':'Amendments Needed','ir:done':'Internal Signed Off',
    'cr:draft':'Pending','cr:ready':'Ready for Review','cr:amend':'Amendments','cr:signed_off':'Signed Off'
  },
  STATUS_COLS: {
    'ir:draft':'#94A3B8','ir:ready':'#3B82F6','ir:amend':'#ED7209','ir:done':'#16A34A',
    'cr:draft':'#94A3B8','cr:ready':'#F59E0B','cr:amend':'#ED7209','cr:signed_off':'#16A34A'
  },
  // Which stage a status belongs to
  getStage(status){ return (status||'').startsWith('cr:')?'client':'internal'; },
  KANBAN_COLS: ['ir:draft','ir:ready','ir:amend','ir:done','cr:draft','cr:ready','cr:amend','cr:signed_off'],
  INTERNAL_COLS: ['ir:draft','ir:ready','ir:amend','ir:done'],
  CLIENT_COLS:   ['cr:ready','cr:amend','cr:signed_off'],

  getJobs(clientId){ return this._jobs.filter(j=>!clientId||j.clientId===clientId); },
  getJob(id){ return this._jobs.find(j=>j.id===id); },

  createJob(data){
    const job = {
      id: 'job-'+(++this._jobSeq),
      jobNo: data.jobNo||String(Date.now()).slice(-5),
      title: data.title||'Untitled',
      clientId: data.clientId||'',
      folder: data.folder||'General',
      status: data.status||'ir:draft',
      archived: data.archived||false,
      due: data.due||null,
      desc: data.desc||'',
      assignedTo: data.assignedTo||'',
      created: new Date().toISOString(),
      versions: [],
      comments: [],
      activity: [{ts:new Date().toISOString(),user:S.user?.name||'Admin',action:'Job created',icon:''}]
    };
    this._jobs.push(job);
    return job;
  },

  updateJob(id, data){
    const j=this.getJob(id); if(!j) return;
    Object.assign(j, data);
    if(j.archived&&data.status&&!['cr:signed_off','ir:done'].includes(data.status)){j.archived=false;j.archivedAt=null;j.archivedBy=null;}
    this.logActivity(id, S.user?.name||'Admin', 'Status updated to '+this.STATUS_LABELS[j.status], '');
  },

  addVersion(jobId, data){
    const j=this.getJob(jobId); if(!j) return null;
    const ver = {
      id: 'v-'+Date.now(),
      label: data.label||('V'+(j.versions.length+1)),
      files: data.files||[],
      notes: data.notes||'',
      uploaded: new Date().toISOString(),
      uploadedBy: S.user?.name||'Admin',
      comments: []
    };
    j.versions.push(ver);
    this.logActivity(jobId, S.user?.name||'Admin', 'Uploaded '+ver.label, '');
    return ver;
  },

  addComment(jobId, versionId, data){
    const j=this.getJob(jobId); if(!j) return;
    const comment = {
      id: 'c-'+Date.now(),
      text: data.text||'',
      author: S.user?.name||'User',
      role: S.user?.role||'client',
      x: data.x||0, y: data.y||0,
      resolved: false,
      ts: new Date().toISOString(),
      replies: [],
      pin: data.pin||null,
      page: data.page!==undefined ? data.page : null,
      timestamp: data.timestamp!==undefined ? data.timestamp : null
    };
    // Add to version if provided, else job-level
    if(versionId){
      const ver=j.versions.find(v=>v.id===versionId);
      if(ver) ver.comments.push(comment);
    } else {
      j.comments.push(comment);
    }
    this.logActivity(jobId, comment.author, 'Added comment', '');
    return comment;
  },

  _auditLog: [],  // central audit trail

  logActivity(jobId, user, action, icon='ℹ️', opts={}){
    const j=this.getJob(jobId);
    const entry={
      id:'a-'+Date.now()+'-'+Math.random().toString(36).slice(2,6),
      ts:new Date().toISOString(),
      user:user||'System',
      action,icon,
      jobId:jobId||null,
      jobTitle:j?.title||opts.jobTitle||null,
      clientId:j?.clientId||opts.clientId||null,
      clientName:opts.clientName||(j?.clientId?DB.getClient(j.clientId)?.name:null)||null,
      folderId:opts.folderId||null,
      area:opts.area||'Review',
      type:opts.type||'job',
      detail:opts.detail||action,
    };
    this._auditLog.unshift(entry);
    if(this._auditLog.length>500) this._auditLog.length=500;
    if(j) j.activity.unshift({ts:entry.ts,user,action,icon});
    console.log('[AUDIT WRITE]', entry.action, entry.detail, 'total='+this._auditLog.length);
    if(typeof INTEL!=='undefined') INTEL._refreshAuditIfOpen();
  },

  audit(action, user, opts={}){
    // General audit log entry (not job-specific)
    const entry={
      id:'a-'+Date.now()+'-'+Math.random().toString(36).slice(2,6),
      ts:new Date().toISOString(),
      user:user||S?.user?.name||'System',
      action,icon:opts.icon||'ℹ️',
      jobId:null,jobTitle:null,
      clientId:opts.clientId||null,
      clientName:opts.clientName||(opts.clientId?DB.getClient(opts.clientId)?.name:null)||null,
      folderId:opts.folderId||null,
      area:opts.area||'Review',
      type:opts.type||'system',
      detail:opts.detail||action,
    };
    this._auditLog.unshift(entry);
    if(this._auditLog.length>500) this._auditLog.length=500;
    console.log('[AUDIT WRITE]', entry.action, entry.detail, 'total='+this._auditLog.length);
    if(typeof INTEL!=='undefined') INTEL._refreshAuditIfOpen();
  },

  getAuditLog(){ return this._auditLog; },

  // Notification store
  _notifications:[],
  addNotification(type, jobId, message, forUser){
    this._notifications.unshift({
      id:'notif-'+Date.now(), type, jobId, message,
      forUser: forUser||'all',
      ts: new Date().toISOString(),
      read: false
    });
    if(this._notifications.length>100) this._notifications=this._notifications.slice(0,100);
    try{ if(typeof RV!=='undefined') RV._updateNotifBadge(); }catch(e){}
  },
  getNotifications(user){
    return this._notifications.filter(n=>n.forUser==='all'||n.forUser===user?.name);
  },
  markAllRead(user){
    this.getNotifications(user).forEach(n=>{ n.read=true; });
    try{ if(typeof RV!=='undefined') RV._updateNotifBadge(); }catch(e){}
  },

  // Seed demo data
  seed(){
    if(this._jobs.length) return;
    const clients=DB.getParents();
    if(!clients.length) return;
    const demos=[
      {title:'Summer Campaign Social Pack',clientId:clients[0]?.id,folder:'Social Campaigns',status:'cr:ready',due:'2026-06-01',desc:'6x Instagram posts, 4x Facebook ads for the summer promotion.',assignedTo:'Sarah, Tom'},
      {title:'Valentine\u2019s Email Header',clientId:clients[0]?.id,folder:'Email Campaigns',status:'cr:signed_off',due:'2026-02-10',desc:'Email header artwork for Valentine\u2019s campaign.',assignedTo:'Sarah'},
      {title:'Brand Guidelines 2026',clientId:clients[0]?.id,folder:'Brand',status:'ir:ready',due:'2026-07-01',desc:'Updated brand guidelines document with new colour palette.',assignedTo:'Tom'},
      {title:'PPC Ad Creative Pack',clientId:clients[0]?.id,folder:'Paid Advertising',status:'ir:amend',due:'2026-05-28',desc:'Google and Meta ad creatives for Q2 spend.',assignedTo:'Laura'},
    ];
    if(clients[1]){
      demos.push({title:'Website Redesign Mockups',clientId:clients[1]?.id,folder:'Website',status:'ir:draft',due:'2026-06-15',desc:'Homepage and key landing page redesign.',assignedTo:'Tom, Sarah'});
      demos.push({title:'Tow Truck Brochure',clientId:clients[1]?.id,folder:'Print',status:'cr:ready',due:'2026-05-30',desc:'A4 trifold brochure for new towing service.',assignedTo:'Laura'});
    }
    demos.forEach(d=>{
      const j=this.createJob(d);
      // Add demo version
      this.addVersion(j.id,{
        label:'V1',
        files:[{name:'design_v1.jpg',type:'image',url:'',size:'2.4 MB'}],
        notes:'First draft for review.'
      });
    });
    // Seed _folders from demo job folder strings (normalise to ID-based structure)
    if(!this._folders) this._folders={};
    const _seenFolders={};
    this._jobs.filter(j=>j.folder&&j.clientId).forEach(j=>{
      const _fkey=j.clientId+'::'+j.folder;
      if(!_seenFolders[_fkey]){
        const _fid='folder-seed-'+j.clientId+'-'+j.folder.replace(/[^a-z0-9]/gi,'-').toLowerCase();
        _seenFolders[_fkey]=_fid;
        if(!this._folders[_fid]){
          this._folders[_fid]={id:_fid,name:j.folder,clientId:j.clientId,parentId:null,created:Date.now()};
        }
      }
      // Assign folderId to job for drag+drop
      if(!j.folderId) j.folderId=_seenFolders[_fkey];
    });

    // Seed brand terms
    this._brand_terms=[
      {id:'bt-1',term:'motorsports',replace:'Motorsport',severity:'error',clientId:clients[0]?.id},
      {id:'bt-2',term:'lorem ipsum',replace:'',severity:'error',clientId:''},
      {id:'bt-3',term:'click here',replace:'find out more',severity:'warn',clientId:''},
    ];
    // Seed demo archived jobs
    const sevenDaysAgo=new Date(Date.now()-3*24*60*60*1000).toISOString();
    const fourDaysAgo=new Date(Date.now()-4*24*60*60*1000).toISOString();
    const twoDaysAgo=new Date(Date.now()-2*24*60*60*1000).toISOString();
    if(clients[0]){
      const aJob1=this.createJob({title:'Q1 Newsletter Design',clientId:clients[0].id,folder:'Email Campaigns',status:'cr:signed_off',assignedTo:'Sarah'});
      aJob1.archived=true; aJob1.archivedAt=sevenDaysAgo; aJob1.archivedBy='Charles Cumberlidge';
      const aJob2=this.createJob({title:'Christmas Promotion Banner',clientId:clients[0].id,folder:'Social Campaigns',status:'cr:signed_off',assignedTo:'Tom'});
      aJob2.archived=true; aJob2.archivedAt=fourDaysAgo; aJob2.archivedBy='Rikki Cove';
    }
    if(clients[1]){
      const aJob3=this.createJob({title:'Fleet Vehicle Wrap Design',clientId:clients[1].id,folder:'Brand',status:'cr:signed_off',assignedTo:'Laura'});
      aJob3.archived=true; aJob3.archivedAt=twoDaysAgo; aJob3.archivedBy='Charles Cumberlidge';
    }
    // Demo jobs from previous months for filter testing
    if(clients[0]){
      ['2025-11','2025-08','2025-12'].forEach((ym,i)=>{
        const titles=[['Q4 Social Pack','Social Campaigns'],['Mid-Year Brand Review','Brand'],['Year End Report Cover','Print']];
        const [title,folder]=titles[i];
        const j2=this.createJob({title,clientId:clients[0].id,folder,status:'cr:signed_off',due:ym+'-15',assignedTo:'Charles Cumberlidge'});
        this.addVersion(j2.id,{label:'V1',files:[{name:'artwork.jpg',type:'image',url:'',size:'1.2 MB'}],notes:'Final.'});
      });
    }
    // Demo job assigned to Charles with unresolved comments
    if(clients[0]){
      const atnJob=this.createJob({title:'Brand Refresh Concepts',clientId:clients[0].id,folder:'Brand',status:'ir:ready',due:'2026-06-15',assignedTo:'Charles Cumberlidge'});
      this.addVersion(atnJob.id,{label:'V1',files:[{name:'brand_refresh.jpg',type:'image',url:'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800',size:'2.1 MB'}],notes:'Initial concepts.'});
      const atnVer=atnJob.versions[0];
      atnVer.comments=[
        {id:'demo-c1',author:'Sarah',role:'client',text:'The blue feels too cold — can we try something warmer?',ts:new Date(Date.now()-3600000).toISOString(),resolved:false,pin:false,replies:[]},
        {id:'demo-c2',author:'Tom',role:'admin',text:'Typography needs to be bolder on the secondary header.',ts:new Date(Date.now()-7200000).toISOString(),resolved:false,pin:false,replies:[]},
      ];
    }
    // Demo video job for testing video review
    if(clients[0]){
      const vJob=this.createJob({title:'Summer Campaign Video Edit',clientId:clients[0].id,folder:'Video Production',status:'cr:ready',due:'2026-07-01',assignedTo:'Charles Cumberlidge'});
      this.addVersion(vJob.id,{label:'V1 Cut',files:[{name:'summer_campaign_v1.mp4',type:'video',url:'https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/360/Big_Buck_Bunny_360_10s_1MB.mp4',size:'1.0 MB'}],notes:'First cut for review. Check pacing at 0:20 and title card at 0:45.'});
      this.addVersion(vJob.id,{label:'V2 Cut',files:[{name:'summer_campaign_v2.mp4',type:'video',url:'',size:'52 MB'}],notes:'Revised cut with client feedback applied.'});
    }
    // Demo archived jobs for Recently Archived area
    const _3d=new Date(Date.now()-3*24*60*60*1000).toISOString();
    const _5d=new Date(Date.now()-5*24*60*60*1000).toISOString();
    const _2d=new Date(Date.now()-2*24*60*60*1000).toISOString();
    if(clients[0]){['Q1 Newsletter Design','Christmas Promotion Banner'].forEach((title,i)=>{
      const aj=this.createJob({title,clientId:clients[0].id,folder:i?'Social Campaigns':'Email Campaigns',status:'cr:signed_off',assignedTo:'Charles Cumberlidge'});
      aj.archived=true; aj.archivedAt=[_3d,_5d][i]; aj.archivedBy=['Charles Cumberlidge','Rikki Cove'][i];
    });}
    if(clients[1]){
      const aj=this.createJob({title:'Fleet Vehicle Wrap Design',clientId:clients[1].id,folder:'Brand',status:'cr:signed_off',assignedTo:'Charles Cumberlidge'});
      aj.archived=true; aj.archivedAt=_2d; aj.archivedBy='Charles Cumberlidge';
    }
    // Seed demo notifications
    const demoJobs=this._jobs;
    if(demoJobs.length&&!this._notifications.length){
      const now=Date.now();
      this._notifications=[
        {id:'n-1',type:'assign',jobId:demoJobs[0]?.id,message:'Karbon Creative assigned you to "'+( demoJobs[0]?.title||'a job')+'"',forUser:'all',ts:new Date(now-5*60000).toISOString(),read:false},
        {id:'n-2',type:'comment',jobId:demoJobs[0]?.id,message:'A comment was added to "'+(demoJobs[0]?.title||'a job')+'"',forUser:'all',ts:new Date(now-12*60000).toISOString(),read:false},
        {id:'n-3',type:'status',jobId:demoJobs[1]?.id,message:'Job moved to Ready for Client Review: "'+(demoJobs[1]?.title||'a job')+'"',forUser:'all',ts:new Date(now-2*3600000).toISOString(),read:false},
        {id:'n-4',type:'upload',jobId:demoJobs[2]?.id,message:'New version uploaded to "'+(demoJobs[2]?.title||'a job')+'"',forUser:'all',ts:new Date(now-24*3600000).toISOString(),read:true},
      ];
    }
  }
};

/* ══════════════════════════════════════════════════════════
   REVIEW CONTROLLER
══════════════════════════════════════════════════════════ */
const RV = {
  _currentJob: null,
  _annotateMode: null, // 'pin'|'draw'|null
  _pendingFiles: [],

  boot(){
    const _bootTs=Date.now();

    // Move all .mbg modal divs to direct children of body.
    document.querySelectorAll('.mbg').forEach(m=>{
      if(m.parentElement!==document.body) document.body.appendChild(m);
    });
    RV_DB.seed();
    this._updateNotifBadge(); // update badge after seed
    this.buildClientNav();
    this.buildDashboard();
    this.buildKanban();
    this.buildJobsList();
    this.buildBrandChecker();
    this.buildActivity();
    const isClient=S.user?.role==='client';
    // Hide admin-only new job buttons for clients
    ['rv-static-newjob-1','rv-static-newjob-2'].forEach(id=>{
      const el=document.getElementById(id);
      if(el) el.style.display=isClient?'none':'';
    });
    // Apply client role restrictions FIRST before populating views
    document.getElementById('rv-admin-nav').style.display=isClient?'none':'';
    if(isClient){
      // Hide all admin-only sidebar items from clients
      document.querySelectorAll('[data-admin-only]').forEach(el=>el.style.display='none');
      // Rename "All Jobs" section heading for clients and rename Projects link
      // Show clients a "Projects & Folders" label on the clients section
      const cliHd=document.querySelector('#rv-client-nav')?.closest('.rvsb-section')?.querySelector('.rvsb-hd');
      if(cliHd) cliHd.textContent='Projects & Folders';
    
      // Direct route to Ready for Review — no click simulation
      this.showReviewQueue(document.getElementById('rvsb-review-queue'));}
    AI.hide(); // Scooby not shown in review area for anyone
    this._updateBadge();
    this._updateReviewBadge();
    // Seed audit log with system boot entry
    RV_DB.audit('Portal session started', S.user?.name||'System', {
      icon:'', area:'Review', type:'system',
      detail:'Session started by '+(S.user?.name||'Unknown')
    });


  },

  go(view, btn){
    document.querySelectorAll('.rv-view').forEach(v=>v.classList.remove('on'));
    document.querySelectorAll('.rvsb-btn').forEach(b=>b.classList.remove('on'));
    const el=document.getElementById('v-'+view);
    if(el) el.classList.add('on');
    if(btn) btn.classList.add('on');
    if(view==='rv-activity') INTEL.buildAudit();
  },

  toggleSidebar(){
    const sb=document.getElementById('rv-sidebar');
    sb?.classList.toggle('collapsed');
    const arrow=document.getElementById('rv-sb-arrow');
    if(arrow) arrow.style.transform=sb?.classList.contains('collapsed')?'scaleX(-1)':'scaleX(1)';
  },

  _updateNotifBadge(){
    const notifs=RV_DB.getNotifications(S.user);
    const unread=notifs.filter(n=>!n.read).length;
    const badge=document.getElementById('rv-notif-badge');
    const count=document.getElementById('rv-notif-count');
    if(badge) badge.style.display=unread?'flex':'none';
    if(count) count.textContent=unread>9?'9+':unread;
  },

  showNotifications(){
    const panel=document.getElementById('rv-notif-panel');
    if(!panel) return;
    if(panel.style.display==='flex'){ panel.style.display='none'; return; }
    panel.style.display='flex';
    const notifs=RV_DB.getNotifications(S.user);
    let html='<div style="padding:10px 14px;border-bottom:1px solid var(--bd0);display:flex;align-items:center;justify-content:space-between;flex-shrink:0">'
      +'<span style="font-size:13px;font-weight:700;color:var(--t0)">Notifications</span>';
    if(notifs.some(n=>!n.read)) html+='<button onclick="RV_DB.markAllRead(S.user);RV._updateNotifBadge();RV.showNotifications()" style="background:none;border:none;cursor:pointer;font-size:11px;color:var(--o);padding:0">Mark all read</button>';
    html+='</div><div style="overflow-y:auto;flex:1">';
    if(notifs.length){
      notifs.slice(0,30).forEach(n=>{
        const j=RV_DB.getJob(n.jobId);
        html+='<div class="rv-notif-row" data-nid="'+n.id+'" data-jid="'+(n.jobId||'')+'" style="padding:10px 14px;border-bottom:1px solid var(--bd0);cursor:pointer;background:'+(n.read?'':'rgba(237,114,9,.05)')+';display:flex;gap:10px;align-items:flex-start">'
          +'<div style="width:7px;height:7px;border-radius:50%;background:'+(n.read?'transparent':'#ED7209')+';margin-top:5px;flex-shrink:0"></div>'
          +'<div style="flex:1"><div style="font-size:12px;color:var(--t0);margin-bottom:2px;line-height:1.4">'+n.message+'</div>'
          +(j?'<div style="font-size:10.5px;color:var(--o);margin-bottom:2px">'+j.title+'</div>':'')
          +'<div style="font-size:10px;color:var(--t2)">'+new Date(n.ts).toLocaleString('en-GB',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})+'</div>'
          +'</div></div>';
      });
    } else {
      html+='<div style="padding:28px 20px;text-align:center;font-size:12.5px;color:var(--t2)">No notifications yet</div>';
    }
    html+='</div>';
    panel.innerHTML=html;
    // Wire click handlers on notification rows
    panel.querySelectorAll('.rv-notif-row').forEach(row=>{
      row.addEventListener('click',()=>RV._notifClick(row.dataset.nid,row.dataset.jid));
    });
    setTimeout(()=>{ RV_DB.markAllRead(S.user); RV._updateNotifBadge(); },2000);
    setTimeout(()=>{
      const close=(e)=>{ if(!panel.contains(e.target)&&!document.getElementById('rv-notif-btn')?.contains(e.target)){ panel.style.display='none'; document.removeEventListener('click',close,true); } };
      document.addEventListener('click',close,true);
    },100);
  },
  _notifClick(notifId,jobId){
    // Mark this notification read and navigate to job
    const n=RV_DB._notifications.find(x=>x.id===notifId);
    if(n) n.read=true;
    RV._updateNotifBadge();
    document.getElementById('rv-notif-panel').style.display='none';
    if(jobId) RV.openJob(jobId);
  },

  _getAllowedClients(){
    // Returns client IDs the current user can see — from user AND company level
    const u=S.user; if(!u) return [];
    const userIds=u.client_ids||[];
    const companyIds=(u.companies||[]).flatMap(cid=>{
      const co=DB.getCompanies().find(c=>c.id===cid);
      return co?.clientIds||[];
    });
    return [...new Set([...userIds,...companyIds])];
  },

  _updateBadge(){
    const isClient=S.user?.role==='client';
    const allowed=this._getAllowedClients();
    const pending=RV_DB._jobs.filter(j=>{
      if(isClient&&!allowed.includes(j.clientId)) return false;
      return j.status==='cr:ready'||j.status==='cr:amend'||j.status==='ir:amend';
    }).length;
    const badge=document.getElementById('rvsb-pending-badge');
    if(badge){
      badge.textContent=pending;
      badge.style.display=pending>0?'':'none';
    }
  },

  buildClientNav(){
    const el=document.getElementById('rv-client-nav'); if(!el) return;
    const isClient=S.user?.role==='client';
    const allowed=this._getAllowedClients();
    const clients=DB.getParents().filter(c=>!isClient||allowed.includes(c.id));
    el.innerHTML=clients.map(c=>`
      <button class="rvsb-btn" onclick="RV.openClient('${c.id}',this)">
        <span class="rvsb-ico" style="background:${c.brand_colour};border-radius:4px;color:${c.brand_text};font-size:9px;font-weight:700">${c.initials}</span>
        <span class="rvsb-label">${c.name}</span>
      </button>`).join('');
  },

  buildDashboard(){
    const el=document.getElementById('rv-dash-content'); if(!el) return;
    const isClient=S.user?.role==='client';
    const allowed=this._getAllowedClients();
    const allJobs=RV_DB._jobs.filter(j=>isClient?allowed.includes(j.clientId):true);
    const active=allJobs.filter(j=>!j.archived);
    const now=new Date();
    const irReady=active.filter(j=>j.status==='ir:ready');
    const crReady=active.filter(j=>j.status==='cr:ready');
    const amends=active.filter(j=>j.status==='ir:amend'||j.status==='cr:amend');
    const signedOff=allJobs.filter(j=>j.status==='cr:signed_off');
    const overdue=active.filter(j=>j.due&&new Date(j.due)<now&&!['cr:signed_off','ir:done'].includes(j.status));
    const recentSO=[...RV_DB._jobs.filter(j=>j.status==='cr:signed_off'&&!j.archived)].sort((a,b)=>(b.signedOffAt||b.updated||b.created||0)-(a.signedOffAt||a.updated||a.created||0)).slice(0,6);
    const teamWork={};
    if(!isClient) active.forEach(j=>(j.assignedTo||'').split(',').map(s=>s.trim()).filter(Boolean).forEach(n=>{ (teamWork[n]=teamWork[n]||[]).push(j); }));
    const pill=j=>{
      const c=DB.getClient(j.clientId);
      const col=RV_DB.STATUS_COLS[j.status]||'#94A3B8';
      const due=j.due?new Date(j.due):null; const od=due&&due<now&&j.status!=='cr:signed_off';
      let _pillPrev=''; let _pillPrevType='image';
      for(const ver of [...j.versions].reverse()){
        for(const f of ver.files||[]){
          if(f.url&&(f.type==='image'||/\.(jpg|jpeg|png|gif)$/i.test(f.name||''))){_pillPrev=f.url;_pillPrevType='image';break;}
          if(f.url&&(f.type==='pdf'||/\.pdf$/i.test(f.name||''))){_pillPrev=f.url;_pillPrevType='pdf';break;}
          if(f.url&&(f.type==='video'||/\.(mp4|mov|webm)$/i.test(f.name||''))){_pillPrev=f.url;_pillPrevType='video';break;}
        }
        if(_pillPrev) break;
      }
      return`<div onclick="RV.openJob('${j.id}')" style="background:var(--bg2);border-radius:var(--rs);cursor:pointer;overflow:hidden;display:flex;flex-direction:column" onmouseover="this.style.background='var(--bg1)'" onmouseout="this.style.background='var(--bg2)'">
        ${_pillPrevType==='image'&&_pillPrev?`<div style="height:52px;overflow:hidden"><img src="${_pillPrev}" style="width:100%;height:100%;object-fit:cover"></div>`
          :_pillPrevType==='pdf'&&_pillPrev?`<div id="pdf-thumb-${j.id}" style="height:52px;background:#2a2a2a;display:flex;align-items:center;justify-content:center"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" width="28" height="28" opacity=".3"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>`
          :_pillPrevType==='video'&&_pillPrev?`<div style="height:52px;overflow:hidden"><video src="${_pillPrev}" style="width:100%;height:100%;object-fit:cover" preload="metadata" muted playsinline onloadedmetadata="this.currentTime=1"></video></div>`
          :''}
        <div style="display:flex;align-items:center;gap:10px;padding:8px 12px">
          ${c?`<div style="width:20px;height:20px;border-radius:4px;background:${c.brand_colour};display:flex;align-items:center;justify-content:center;font-size:7px;font-weight:700;color:${c.brand_text};flex-shrink:0">${c.initials}</div>`:''}
          <div style="flex:1;min-width:0">
            <div style="font-size:12.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${j.title}</div>
            <div style="font-size:10.5px;color:var(--t2)">${c?.name||''}${j.folder?' · '+j.folder:''}</div>
          </div>
          <span style="background:${col}22;color:${col};font-size:9.5px;font-weight:700;padding:2px 7px;border-radius:10px;white-space:nowrap;flex-shrink:0">${od?'Overdue':(RV_DB.STATUS_LABELS[j.status]||j.status)}</span>
        </div>
      </div>`;
    };
    const stat=(n,c,col,act,sub)=>`<div class="card" style="cursor:pointer;border-top:3px solid ${col};min-width:0" onclick="${act}">
        <div style="font-size:28px;font-weight:800;color:${col};line-height:1">${n}</div>
        <div style="font-size:12px;font-weight:600;margin-top:4px">${c}</div>
        ${sub?`<div style="font-size:10.5px;color:var(--t2);margin-top:2px">${sub}</div>`:''}
      </div>`;
    const hd=(t,btn)=>`<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid var(--bd0)">
        <div style="font-size:13px;font-weight:700;color:var(--t0)">${t}</div>${btn||''}
      </div>`;
    const rrBtn=`<button onclick="RV.showReviewQueue(document.getElementById('rvsb-review-queue'))" style="background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.3);color:#F59E0B;border-radius:var(--rs);padding:4px 10px;cursor:pointer;font-size:11.5px;font-weight:600;font-family:var(--fn)">View all →</button>`;
    el.innerHTML=`
      <div class="rv-seye">${isClient?'Client View':'Operations'}</div>
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px"><div class="rv-title" style="margin-bottom:0">${isClient?'Review Overview':'Dashboard'}</div>${!isClient?`<button class="btn btn-o btn-sm" onclick="RV.newJobModal()" style="white-space:nowrap;flex-shrink:0">+ New job</button>`:''}</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:24px">
        ${isClient
          ? stat(crReady.length,'Ready for Review','#F59E0B',"RV.showReviewQueue(document.getElementById('rvsb-review-queue'))",'Awaiting your input')
            +stat(amends.length,'Amendments','#ED7209',"RV.go('rv-jobs',null)",'Feedback needed')
            +stat(signedOff.length,'Signed Off','#16A34A',"RV.go('rv-jobs',null)",'Completed')
          : stat(irReady.length,'Internal Review','#3B82F6',"RV.showReviewQueue(document.getElementById('rvsb-review-queue'))",'Awaiting Karbon')
            +stat(crReady.length,'Client Review','#F59E0B',"RV.showReviewQueue(document.getElementById('rvsb-review-queue'))",'Awaiting client')
            +stat(amends.length,'Amendments','#ED7209',"RV.go('rv-jobs',null)",'Active')
            +stat(overdue.length,'Overdue','#E84545',"RV.go('rv-jobs',null)",'Need attention')
            +stat(signedOff.length,'Signed Off','#16A34A',"RV.go('rv-jobs',null)",'All time')
        }
      </div>
      ${!isClient?`<div style="margin-bottom:22px">${hd('Client Overview')}<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:8px">${DB.getParents().map(c=>{const cj=active.filter(j=>j.clientId===c.id);if(!cj.length)return '';const ir=cj.filter(j=>j.status==='ir:ready'||j.status==='cr:ready').length;const am=cj.filter(j=>j.status==='ir:amend'||j.status==='cr:amend').length;const od=cj.filter(j=>j.due&&new Date(j.due)<now).length;const so=allJobs.filter(j=>j.clientId===c.id&&j.status==='cr:signed_off').length;return'<div onclick="RV.openClient(\''+c.id+'\',null)" style="background:var(--bg2);border-radius:var(--rs);cursor:pointer;padding:10px 12px;display:flex;flex-direction:column;gap:7px" onmouseover="this.style.background=\'var(--bg1)\'" onmouseout="this.style.background=\'var(--bg2)\'">'
    +'<div style="display:flex;align-items:center;gap:8px;overflow:hidden">'
    +'<div style="width:24px;height:24px;border-radius:6px;background:'+c.brand_colour+';display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:700;color:'+c.brand_text+';flex-shrink:0">'+c.initials+'</div>'
    +'<div style="font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+c.name+'</div>'
    +'</div>'
    +'<div style="font-size:10px;color:var(--t2);font-weight:500">Total Active: '+cj.length+'</div>'
    +'<div style="display:flex;gap:4px;flex-wrap:wrap">'
    +(ir?'<span style="background:rgba(245,158,11,.15);color:#F59E0B;font-size:9.5px;font-weight:700;padding:2px 7px;border-radius:8px">'+ir+' Review</span>':'')
    +(am?'<span style="background:rgba(237,114,9,.15);color:var(--o);font-size:9.5px;font-weight:700;padding:2px 7px;border-radius:8px">'+am+' Amend</span>':'')
    +(so?'<span style="background:rgba(22,163,74,.12);color:#16A34A;font-size:9.5px;font-weight:700;padding:2px 7px;border-radius:8px">'+so+' Signed off</span>':'')
    +'</div>'
    +'</div>';}).join('')}</div></div>`:''}
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:22px;align-items:start">
        <div>
          ${hd('⚠ Overdue')}
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
            ${overdue.slice(0,6).map(pill).join('')||'<p style="font-size:12px;color:var(--t2);margin:0;grid-column:1/-1">No overdue jobs ✓</p>'}
          </div>
        </div>
        <div>
        ${(()=>{
        const _myName=S.user?.name||'';
        const jcm={};
        allJobs.forEach(j=>{
          const ac=[...(j.comments||[]),...j.versions.flatMap(v=>v.comments||[])].filter(c=>!c.resolved&&(!_myName||!c.author||c.author.toLowerCase().trim()!==_myName.toLowerCase().trim()));
          if(!ac.length) return;
          const lc=ac.sort((a,b)=>new Date(b.ts||0)-new Date(a.ts||0))[0];
          jcm[j.id]={j,n:ac.length,lc,cid:j.clientId};
        });
        const gr=Object.values(jcm).sort((a,b)=>new Date(b.lc?.ts||0)-new Date(a.lc?.ts||0)).slice(0,6);
        if(!gr.length) return '';
        let out='<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">';
        gr.forEach(({j:jj,n,lc,cid})=>{
          const cl=DB.getClient(cid);
          const d=lc?.ts?new Date(lc.ts):null;
          const rel=d?((Date.now()-d)<3600000?Math.floor((Date.now()-d)/60000)+'m ago':d.toLocaleDateString('en-GB',{day:'numeric',month:'short'})):'-';
                    let _rcaP='',_rcaPT='image';
          for(const ver of [...jj.versions].reverse()){for(const f of ver.files||[]){if(f.url&&(f.type==='image'||/\.(jpg|jpeg|png|gif)$/i.test(f.name||''))){_rcaP=f.url;_rcaPT='image';break;}if(f.url&&(f.type==='pdf'||/\.pdf$/i.test(f.name||''))){_rcaP=f.url;_rcaPT='pdf';break;}if(f.url&&(f.type==='video'||/\.(mp4|mov|webm)$/i.test(f.name||''))){_rcaP=f.url;_rcaPT='video';break;}}if(_rcaP)break;}
          const _rcaSC=RV_DB.STATUS_COLS[jj.status]||'#94A3B8';
          out+='<div onclick="RV.openJob(\''+jj.id+'\')" style="background:var(--bg2);border-radius:var(--rs);cursor:pointer;overflow:hidden;display:flex;flex-direction:column" onmouseover="this.style.background=\'var(--bg1)\'" onmouseout="this.style.background=\'var(--bg2)\'">'
            +(_rcaPT==='image'&&_rcaP?'<div style="height:52px;overflow:hidden"><img src="'+_rcaP+'" style="width:100%;height:100%;object-fit:cover"></div>':_rcaPT==='pdf'&&_rcaP?'<div style="height:52px;background:#1e1e1e;display:flex;align-items:center;justify-content:center"><svg viewBox="0 0 24 24" fill="none" stroke="#888" stroke-width="1.5" width="20" height="20"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>':_rcaPT==='video'&&_rcaP?'<div style="height:52px;overflow:hidden"><video src="'+_rcaP+'" style="width:100%;height:100%;object-fit:cover" preload="metadata" muted></video></div>':'')
            +'<div style="padding:8px 10px">'
            +(cl?'<div style="display:flex;align-items:center;gap:5px;margin-bottom:3px"><div style="width:14px;height:14px;border-radius:3px;flex-shrink:0;background:'+cl.brand_colour+';display:flex;align-items:center;justify-content:center;font-size:6px;font-weight:700;color:'+cl.brand_text+'">'+cl.initials+'</div><span style="font-size:9.5px;color:var(--t2);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+cl.name+'</span><span style="background:'+_rcaSC+'22;color:'+_rcaSC+';font-size:8.5px;font-weight:700;padding:1px 5px;border-radius:7px;flex-shrink:0">'+n+(n!==1?' comments':' comment')+'</span></div>':'')
            +'<div style="font-size:11.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+jj.title+'</div>'
            +'<div style="font-size:9.5px;color:var(--t2);margin-top:2px">'+rel+'</div>'
            +'</div></div>';
        });
        out+='</div>';
        return '<div>'+hd('Recent Comment Activity','<span style="font-size:9.5px;color:var(--t2);font-weight:400">from other users</span>')+out+'</div>';
      })()}
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:32px;padding-top:8px">
        <div>
          ${hd('Ready for Review',rrBtn)}
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
            ${(isClient?crReady:irReady).slice(0,6).map(pill).join('')||'<div style="font-size:11px;color:var(--t2);font-weight:500;padding:12px 0;grid-column:1/-1">Nothing awaiting review</div>'}
          </div>
        </div>
        <div>
          ${hd('Recent Sign-offs')}
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
            ${recentSO.slice(0,6).map(j=>{
        const cl=DB.getClient(j.clientId);
        const soDate=j.signedOffAt?new Date(j.signedOffAt).toLocaleDateString('en-GB',{day:'numeric',month:'short'}):new Date(j.created||Date.now()).toLocaleDateString('en-GB',{day:'numeric',month:'short'});
        const soBy=j.signedOffBy||'';
        let _soP='',_soPT='image';
        for(const ver of [...j.versions].reverse()){for(const f of ver.files||[]){if(f.url&&(f.type==='image'||/\.(jpg|jpeg|png|gif)$/i.test(f.name||''))){_soP=f.url;_soPT='image';break;}if(f.url&&(f.type==='pdf'||/\.pdf$/i.test(f.name||''))){_soP=f.url;_soPT='pdf';break;}if(f.url&&(f.type==='video'||/\.(mp4|mov|webm)$/i.test(f.name||''))){_soP=f.url;_soPT='video';break;}}if(_soP)break;}
        return`<div onclick="RV.openJob('${j.id}')" style="background:var(--bg2);border-radius:var(--rs);cursor:pointer;overflow:hidden;display:flex;flex-direction:column" onmouseover="this.style.background='var(--bg1)'" onmouseout="this.style.background='var(--bg2)'">
          ${_soPT==='image'&&_soP?`<div style="height:52px;overflow:hidden"><img src="${_soP}" style="width:100%;height:100%;object-fit:cover"></div>`:_soPT==='pdf'&&_soP?`<div style="height:52px;background:#1e1e1e;display:flex;align-items:center;justify-content:center"><svg viewBox="0 0 24 24" fill="none" stroke="#888" stroke-width="1.5" width="20" height="20"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>`:_soPT==='video'&&_soP?`<div style="height:52px;overflow:hidden"><video src="${_soP}" style="width:100%;height:100%;object-fit:cover" preload="metadata" muted></video></div>`:''}
          <div style="padding:8px 10px;display:flex;flex-direction:column;gap:3px">
            <div style="display:flex;align-items:center;gap:5px">${cl?`<div style="width:14px;height:14px;border-radius:3px;flex-shrink:0;background:${cl.brand_colour};display:flex;align-items:center;justify-content:center;font-size:6px;font-weight:700;color:${cl.brand_text}">${cl.initials}</div>`:''}<span style="font-size:9.5px;color:var(--t2);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${cl?.name||''}</span><span style="font-size:8.5px;font-weight:700;padding:1px 5px;border-radius:7px;background:rgba(22,163,74,.12);color:#16A34A;flex-shrink:0">✓ Signed off</span></div>
            <div style="font-size:11.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${j.title}</div>
            <div style="font-size:9.5px;color:var(--t2)">${soDate}${soBy?' · '+soBy:''}</div>
          </div>
        </div>`;
      }).join('')||'<div style="font-size:11px;color:var(--t2);font-weight:500;padding:12px 0">No sign-offs yet</div>'}
          </div>
        </div>
      </div>
                  ${(()=>{const ia=active.filter(j=>j.status==='ir:amend');const ca=active.filter(j=>j.status==='cr:amend');if(!ia.length&&!ca.length)return'';const mkA=j=>{const cl=DB.getClient(j.clientId);const uc=[...(j.comments||[]),...j.versions.flatMap(v=>v.comments||[])].filter(c=>!c.resolved).length;const statCol=RV_DB.STATUS_COLS[j.status]||'#94A3B8';const statLbl=RV_DB.STATUS_LABELS[j.status]||j.status;let _mkaPrev='',_mkaPrevType='image';for(const ver of [...j.versions].reverse()){for(const f of ver.files||[]){if(f.url&&(f.type==='image'||/\.(jpg|jpeg|png|gif)$/i.test(f.name||''))){_mkaPrev=f.url;_mkaPrevType='image';break;}if(f.url&&(f.type==='pdf'||/\.pdf$/i.test(f.name||''))){_mkaPrev=f.url;_mkaPrevType='pdf';break;}if(f.url&&(f.type==='video'||/\.(mp4|mov|webm)$/i.test(f.name||''))){_mkaPrev=f.url;_mkaPrevType='video';break;}}if(_mkaPrev)break;}
  return`<div onclick="RV.openJob('${j.id}')" style="background:var(--bg2);border-radius:var(--rs);cursor:pointer;overflow:hidden;display:flex;flex-direction:column" onmouseover="this.style.background='var(--bg1)'" onmouseout="this.style.background='var(--bg2)'">
    ${_mkaPrevType==='image'&&_mkaPrev?`<div style="height:60px;overflow:hidden"><img src="${_mkaPrev}" style="width:100%;height:100%;object-fit:cover"></div>`:_mkaPrevType==='pdf'&&_mkaPrev?`<div id="pdf-thumb-${j.id}" style="height:60px;background:#2a2a2a;display:flex;align-items:center;justify-content:center"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" width="22" height="22" opacity=".3"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>`:_mkaPrevType==='video'&&_mkaPrev?`<div style="height:60px;overflow:hidden"><video src="${_mkaPrev}" style="width:100%;height:100%;object-fit:cover" preload="metadata" muted playsinline onloadedmetadata="this.currentTime=1"></video></div>`:''}
    <div style="padding:9px 11px;flex:1"><div style="display:flex;align-items:center;gap:6px;margin-bottom:5px">${cl?`<div style="width:16px;height:16px;border-radius:3px;background:${cl.brand_colour};display:flex;align-items:center;justify-content:center;font-size:6px;font-weight:700;color:${cl.brand_text}">${cl.initials}</div>`:''}<span style="font-size:10px;color:var(--t2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${cl?.name||''}</span></div><div style="font-size:11.5px;font-weight:600;margin-bottom:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${j.title}</div><div style="display:flex;justify-content:space-between;align-items:center"><span style="background:${statCol}22;color:${statCol};font-size:9px;font-weight:700;padding:1px 6px;border-radius:8px">${statLbl}</span>${uc?`<span style="font-size:9.5px;color:#3B82F6">${uc} comment${uc!==1?'s':''}</span>`:''}</div></div></div>`;};const ghostCard='<div style="border:1.5px dashed rgba(255,255,255,.1);border-radius:var(--rs);padding:14px 12px;text-align:center"><div style="font-size:11px;color:var(--t2);font-weight:500">No amendments</div></div>';return`<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:22px"><div>${hd('Internal Amendments')}<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">${ia.slice(0,6).map(mkA).join('')||ghostCard}</div></div><div>${hd('Client Amendments')}<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">${ca.slice(0,6).map(mkA).join('')||ghostCard}</div></div></div>`;})()}
      ${(()=>{
        const myName=S.user?.name||'';
        // Jobs assigned to me with unresolved comments
        const needsAttn=active.filter(j=>{
          const isAssigned=!myName||!j.assignedTo||(j.assignedTo||'').toLowerCase().includes(myName.toLowerCase());
          if(!isAssigned) return false;
          const allCmts=[...(j.comments||[]),...j.versions.flatMap(v=>v.comments||[])];
          return allCmts.some(c=>!c.resolved);
        }).slice(0,5);
        if(!needsAttn.length) return '';
        return`<div style="margin-bottom:22px">${hd('Jobs Requiring Attention')}<div style="display:flex;flex-direction:column;gap:6px">`
          +needsAttn.map(j=>{
            const cl=DB.getClient(c.clientId);
            const d=c.ts?new Date(c.ts):null;
            const rel=d?((Date.now()-d)/(1000*60)<60?Math.floor((Date.now()-d)/60000)+'m ago':d.toLocaleDateString('en-GB',{day:'numeric',month:'short'})):'-';
            const jc2=DB.getClient(j.clientId);
            const unresCmts=[...(j.comments||[]),...j.versions.flatMap(v=>v.comments||[])].filter(c=>!c.resolved);
            const latestAct=RV_DB._activity?.filter(a=>a.jobId===j.id).slice(-1)[0];
            const d2=latestAct?.ts?new Date(latestAct.ts):null;
            const rel2=d2?((Date.now()-d2)/(1000*60)<60?Math.floor((Date.now()-d2)/60000)+'m ago':d2.toLocaleDateString('en-GB',{day:'numeric',month:'short'})):'-';
            return`<div onclick="RV.openJob('${j.id}')" style="display:flex;align-items:center;gap:10px;padding:9px 12px;background:var(--bg2);border-radius:var(--rs);cursor:pointer;transition:background .12s" onmouseover="this.style.background='var(--bg1)'" onmouseout="this.style.background='var(--bg2)'">
              ${jc2?`<div style="width:24px;height:24px;border-radius:5px;background:${jc2.brand_colour};display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:700;color:${jc2.brand_text};flex-shrink:0">${jc2.initials}</div>`:''}
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${j.title}</div>
                <div style="font-size:10.5px;color:var(--t2)">${jc2?.name||''}${j.folder?' · '+j.folder:''}</div>
              </div>
              <div style="display:flex;flex-direction:column;align-items:flex-end;gap:2px;flex-shrink:0">
                <span style="background:rgba(232,69,69,.15);color:#E84545;font-size:9.5px;font-weight:700;padding:2px 7px;border-radius:10px">${unresCmts.length} comment${unresCmts.length!==1?'s':''}</span>
                <span style="font-size:10px;color:var(--t2)">${rel2}</span>
              </div>
            </div>`;
          }).join('')+'</div></div>';
      })()}
`;
    // Async PDF thumbnails for review pills
    setTimeout(()=>{
      RV_DB._jobs.forEach(j=>{
        const thumbEl=document.getElementById('pdf-thumb-'+j.id);
        if(!thumbEl) return;
        for(const ver of [...j.versions].reverse()){
          for(const f of ver.files||[]){
            if(f.url&&(f.type==='pdf'||/\.pdf$/i.test(f.name||''))){
              RV._getPdfThumb(f.url,(dataUrl)=>{
                const el2=document.getElementById('pdf-thumb-'+j.id);
                if(dataUrl&&el2) el2.innerHTML=`<img src="${dataUrl}" style="width:100%;height:72px;object-fit:cover;display:block">`;
              }); return;
            }
          }
        }
      });
    },300);
  },

  _jobRow(j){
    const c=DB.getClient(j.clientId);
    const due=j.due?new Date(j.due):null;
    const isOverdue=due&&due<new Date()&&j.status!=='cr:signed_off'&&j.status!=='ir:done';
    const statCol=RV_DB.STATUS_COLS[j.status]||'#94A3B8';
    const statLabel=RV_DB.STATUS_LABELS[j.status]||j.status;
    const verCount=j.versions.length;
    const commentCount=j.versions.reduce((a,v)=>a+v.comments.length,0)+j.comments.length;
    return`<div class="card" style="cursor:pointer;transition:all .13s;border-left:3px solid ${statCol}" onclick="RV.openJob('${j.id}')">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px">
        <div style="flex:1">
          <div style="font-size:10px;font-weight:700;color:var(--o);text-transform:uppercase;letter-spacing:.6px;margin-bottom:3px">${c?c.name:j.clientId} · ${j.folder}</div>
          <div style="font-size:13.5px;font-weight:600;margin-bottom:5px">${j.title}</div>
          <div style="display:flex;flex-wrap:wrap;gap:5px;align-items:center">
            <span class="kb-pill ${j.status.startsWith('cr:signed_off')?'approved':j.status.includes('amend')?'amend':j.status.startsWith('cr:')?'review':'draft'}" style="font-size:9.5px">${statLabel}</span>
            ${verCount?'<span style="font-size:10.5px;color:var(--t2)">'+verCount+' version'+(verCount>1?'s':'')+'</span>':''}
            ${commentCount?'<span style="font-size:10.5px;color:var(--t2)">💬 '+commentCount+'</span>':''}
            ${isOverdue?'<span class="kb-pill overdue" style="font-size:9.5px">Overdue</span>':''}
          </div>
        </div>
        <div style="text-align:right;flex-shrink:0">
          <div style="font-size:10.5px;color:${isOverdue?'#E84545':'var(--t2)'};font-weight:${isOverdue?'700':'400'}">${due?due.toLocaleDateString('en-GB',{day:'numeric',month:'short'}):'No deadline'}</div>
          ${j.assignedTo?`<div style="font-size:10px;color:var(--t2);margin-top:3px">${j.assignedTo}</div>`:''}
        </div>
      </div>
    </div>`;
  },

  buildKanban(){
    const board=document.getElementById('kanban-board'); if(!board) return;
    const filterClient=document.getElementById('kb-filter-client')?.value||'';
    const filterUser=document.getElementById('kb-filter-user')?.value||'';
    const sortMode=document.getElementById('kb-sort')?.value||'';
    const isClient=S.user?.role==='client';
    const allowed=this._getAllowedClients();
    const showArchived=document.getElementById('rv-show-archived')?.checked||false;
    // Pinned jobs shown in Projects & Folders only
    const jobs=RV_DB._jobs.filter(j=>{
      if(isClient&&!allowed.includes(j.clientId)) return false;
      if(filterClient&&j.clientId!==filterClient) return false;
      if(filterUser&&!(j.assignedTo||'').toLowerCase().includes(filterUser.toLowerCase())) return false;
      if(!showArchived&&j.archived) return false;
      return true;
    });
    // Populate user dropdown
    const uSel=document.getElementById('kb-filter-user');
    if(uSel&&uSel.options.length<=1){const users=[...new Set(RV_DB._jobs.flatMap(j=>(j.assignedTo||'').split(',').map(s=>s.trim()).filter(Boolean)))].sort();users.forEach(u=>{uSel.innerHTML+=`<option value="${u}">${u}</option>`;});}
    const cfSel=document.getElementById('kb-filter-client');
    if(cfSel&&cfSel.options.length<=1){
      DB.getParents().forEach(c=>{cfSel.innerHTML+=`<option value="${c.id}">${c.name}</option>`;});
    }
    const mkCol=(status)=>{
      let colJobs=jobs.filter(j=>j.status===status);
      // Apply sort
      if(sortMode==='due-asc') colJobs.sort((a,b)=>(a.due?new Date(a.due):new Date(9e15))-(b.due?new Date(b.due):new Date(9e15)));
      else if(sortMode==='due-desc') colJobs.sort((a,b)=>(b.due?new Date(b.due):new Date(0))-(a.due?new Date(a.due):new Date(0)));
      else if(sortMode==='oldest') colJobs.sort((a,b)=>(a.created||0)-(b.created||0));
      else if(sortMode==='newest') colJobs.sort((a,b)=>(b.created||0)-(a.created||0));
      else if(sortMode==='title') colJobs.sort((a,b)=>a.title.localeCompare(b.title));
      const statCol=RV_DB.STATUS_COLS[status]||'#94A3B8';
      const statLabel=RV_DB.STATUS_LABELS[status]||status;
      return`<div class="kb-col" data-status="${status}"
        ondragover="event.preventDefault();this.querySelector('.kb-col-body').classList.add('kb-card-drop')"
        ondragleave="this.querySelector('.kb-col-body').classList.remove('kb-card-drop')"
        ondrop="RV.dropJob(event,'${status}')">
        <div class="kb-col-hd">
          <span style="color:${statCol};display:flex;align-items:center;gap:5px">
            <span style="width:8px;height:8px;border-radius:50%;background:${statCol};display:inline-block"></span>
            ${statLabel}
          </span>
          <div style="display:flex;align-items:center;gap:5px"><span style="font-size:10.5px;background:var(--bg3);border-radius:10px;padding:1px 7px;color:var(--t2)">${colJobs.length}</span>${status==='cr:signed_off'?`<button onclick="RV.archiveAllSignedOff()" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:4px;padding:2px 7px;cursor:pointer;font-size:9.5px;color:rgba(255,255,255,.5);font-family:var(--fn)">Archive all</button>`:''}</div>
        </div>
        <div class="kb-col-body">
          ${colJobs.map(j=>this._kanbanCard(j)).join('')}
          ${colJobs.length===0?`<div style="border:1.5px dashed rgba(255,255,255,.1);border-radius:var(--rs);padding:16px 12px;text-align:center;margin-bottom:8px"><div style="font-size:11px;color:var(--t2);font-weight:500">Nothing here yet</div></div>`:''}
          ${!isClient?`<button class="kb-add-btn" onclick="RV.newJobModal('${status}')">+ Add job</button>`:''}
        </div>
      </div>`;
    };
    if(isClient){
      board.innerHTML='<div style="display:contents">'+RV_DB.CLIENT_COLS.map(mkCol).join('')+'</div>';
    } else {
      const intCols=RV_DB.INTERNAL_COLS.map(mkCol).join('');
      const cliCols=RV_DB.CLIENT_COLS.map(mkCol).join('');
      board.innerHTML=`
        <div style="display:flex;flex-direction:column;gap:8px;flex-shrink:0">
          <div style="font-size:10px;font-weight:700;color:#3B82F6;text-transform:uppercase;letter-spacing:.8px;padding:4px 2px;border-bottom:2px solid #3B82F6;margin-bottom:4px">Internal Review</div>
          <div style="display:flex;gap:14px">${intCols}</div>
        </div>
        <div style="width:2px;background:var(--bd1);flex-shrink:0;margin:0 4px;align-self:stretch;border-radius:1px"></div>
        <div style="display:flex;flex-direction:column;gap:8px;flex-shrink:0">
          <div style="font-size:10px;font-weight:700;color:#ED7209;text-transform:uppercase;letter-spacing:.8px;padding:4px 2px;border-bottom:2px solid #ED7209;margin-bottom:4px">Client Review</div>
          <div style="display:flex;gap:14px">${cliCols}</div>
        </div>`;
    }
  },

  _kanbanCard(j){
    const c=DB.getClient(j.clientId);
    const due=j.due?new Date(j.due):null;
    const isOverdue=due&&due<new Date()&&j.status!=='cr:signed_off'&&j.status!=='ir:done';
    const verCount=j.versions.length;
    const commentCount=j.versions.reduce((a,v)=>a+v.comments.length,0)+j.comments.length;
    return`<div class="kb-card" draggable="true"
      ondragstart="RV.dragJob(event,'${j.id}')"
      ondragend="event.currentTarget.classList.remove('dragging')"
      onclick="RV.openJob('${j.id}')">
      <div style="display:flex;align-items:flex-start;gap:6px">
        <div style="flex:1">${c?`<div class="kb-client">${c.name}</div>`:''}
        <div class="kb-job-name">${j.title}</div></div>
        <button onclick="event.stopPropagation();RV_DB.toggleFavourite('${j.id}');if(RV._activeClientId)RV.openClient(RV._activeClientId,null);else RV.refreshBoards()" style="background:none;border:none;cursor:pointer;padding:2px;flex-shrink:0;color:${RV_DB.isFavourite(j.id)?'#FFD600':'rgba(255,255,255,.3)'}" title="${RV_DB.isFavourite(j.id)?'Unpin':'Pin job'}">
          <svg viewBox="0 0 16 16" fill="${RV_DB.isFavourite(j.id)?'#FFD600':'none'}" stroke="${RV_DB.isFavourite(j.id)?'#FFD600':'currentColor'}" stroke-width="1.5" width="13" height="13"><polygon points="8,2 10,6 14,6.5 11,9.5 11.5,14 8,12 4.5,14 5,9.5 2,6.5 6,6"/></svg>
        </button>
      </div>
      <div class="kb-meta">
        ${j.folder?`<span class="kb-pill draft">${j.folder}</span>`:''}
        ${isOverdue?'<span class="kb-pill overdue">Overdue</span>':''}
      </div>
      <div class="kb-foot">
        <div class="kb-stats">
          ${verCount?`<span>📄 ${verCount}</span>`:''}
          ${commentCount?`<span>💬 ${commentCount}</span>`:''}
        </div>
        <div class="kb-due ${isOverdue?'overdue':''}">         ${due?due.toLocaleDateString('en-GB',{day:'numeric',month:'short'}):''}
        </div>
      </div>
    </div>`;
  },

  dragJob(e,id){ e.dataTransfer.setData('text/plain',id); e.currentTarget.classList.add('dragging'); },
  dropJob(e,newStatus){
    e.preventDefault();
    e.currentTarget.querySelector('.kb-col-body')?.classList.remove('kb-card-drop');
    const id=e.dataTransfer.getData('text/plain');
    const j2=RV_DB.getJob(id);if(j2){j2.status=newStatus;if(j2.archived&&!['cr:signed_off','ir:done'].includes(newStatus)){j2.archived=false;j2.archivedAt=null;j2.archivedBy=null;}RV_DB.logActivity(id,S.user?.name||'Admin','Moved to '+(RV_DB.STATUS_LABELS[newStatus]||newStatus),'');}
    this._updateReviewBadge();
    this.buildKanban();
    this.buildDashboard();
    this._updateBadge();
  },

  buildJobsList(){
    const el=document.getElementById('rv-jobs-list'); if(!el) return;
    this.filterJobs();
  },

  filterJobs(){
    const el=document.getElementById('rv-jobs-list'); if(!el) return;
    const search=(document.getElementById('rv-search')?.value||'').toLowerCase();
    const status=document.getElementById('rv-filter-status')?.value||'';
    const clientFilter=document.getElementById('rv-filter-client')?.value||'';
    const isClient=S.user?.role==='client';
    const allowed=this._getAllowedClients();
    const cSel=document.getElementById('rv-filter-client');
    if(cSel&&!isClient&&cSel.options.length<=1) DB.getParents().forEach(c=>{cSel.innerHTML+=`<option value="${c.id}">${c.name}</option>`;});
    if(cSel&&isClient) cSel.style.display='none';
    const jobsDateRange=parseInt(document.getElementById('rv-filter-date-range')?.value||'0');
    const jobsRangeCutoff=jobsDateRange?new Date(Date.now()-jobsDateRange*30*24*60*60*1000):null;
    const jobs=RV_DB._jobs.filter(j=>{
      if(isClient&&!allowed.includes(j.clientId)) return false;
      if(clientFilter&&j.clientId!==clientFilter) return false;
      if(status&&j.status!==status) return false;
      if(search&&!j.title.toLowerCase().includes(search)&&!(DB.getClient(j.clientId)?.name||'').toLowerCase().includes(search)) return false;
      if(jobsRangeCutoff){const jd=j.due?new Date(j.due):new Date(j.created||Date.now());if(jd<jobsRangeCutoff)return false;}
      return true;
    });
    el.innerHTML=jobs.length?jobs.map(j=>this._jobRow(j)).join('')
      :'<div class="ins a"><p>No jobs match the current filters.</p></div>';
  },

  _filterClientJobs(clientId){
    const id=clientId||this._activeClientId;
    if(!id) return;
    const gridEl=document.getElementById('rv-client-jobs-grid');
    if(!gridEl) return;  // grid not in DOM yet - do nothing
    const search=(document.getElementById('rv-folder-search')?.value||'').toLowerCase();
    const _fyr=document.getElementById('rv-folder-filter-yr')?.value||'';
    const _fmon=document.getElementById('rv-folder-filter-mon')?.value||'';
    const _frange=parseInt(document.getElementById('rv-folder-date-range')?.value||'0');
    const _frangeCutoff=_frange?new Date(Date.now()-_frange*30*24*60*60*1000):null;
    const MO=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const cJobs=RV_DB.getJobs(id).filter(j=>{
      if(j.archived) return false;
      const _afId=this._folderNav?.folderId||null;if(_afId){const _afN=RV_DB._folders?.[_afId]?.name||'';if(!((j.folderId===_afId)||(j.folder&&j.folder===_afN)))return false;}
      if(search&&!j.title.toLowerCase().includes(search)&&!(j.folder||'').toLowerCase().includes(search)) return false;
      if(_fyr){ const yr=(j.due?new Date(j.due):new Date(j.created||Date.now())).getFullYear()+''; if(yr!==_fyr) return false; }
      if(_fmon){ const mn=MO[(j.due?new Date(j.due):new Date(j.created||Date.now())).getMonth()]; if(mn!==_fmon) return false; }
      if(_frangeCutoff){ const _jd=j.due?new Date(j.due):new Date(j.created||Date.now()); if(_jd<_frangeCutoff) return false; }
      return true;
    });
    // Group by folder
    const byFolder={};
    if(RV_DB._folders) Object.values(RV_DB._folders).filter(f=>f.clientId===id).forEach(f=>{ if(!byFolder[f.path]) byFolder[f.path]={_jobs:[],name:f.name,parent:f.parent||''}; });
    cJobs.forEach(j=>{ const fp=j.folder||''; if(!byFolder[fp]) byFolder[fp]={_jobs:[],name:fp||'Unfoldered',parent:''}; byFolder[fp]._jobs.push(j); });
    // Render folders - only top-level (no parent) or unfoldered
    const folderHTML=Object.entries(byFolder).filter(([k,v])=>!v.parent).map(([folderName,folderData])=>{
      const topJobs=folderData._jobs||[];
      // Sub-folders
      const subFolders=Object.entries(byFolder).filter(([k,v])=>v.parent===folderName);
      // Sub-folders show as a labelled row of job cards inside the parent grid
      const subHTML=subFolders.map(([sfName,sfData])=>sfData._jobs.length?
        `<div style="grid-column:1/-1;margin-top:8px"><div style="font-size:11px;font-weight:600;color:var(--t2);margin-bottom:6px;display:flex;align-items:center;gap:5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="12" height="12"><path d="M2 4a1 1 0 0 1 1-1h3l2 2h5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4z"/></svg>${sfData.name}</div><div class="rv-compact-grid">${sfData._jobs.map(j=>this._jobCard(j)).join('')}</div></div>`
        :`<div style="grid-column:1/-1;font-size:11px;color:var(--t2);padding:8px 0;display:flex;align-items:center;gap:5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="12" height="12"><path d="M2 4a1 1 0 0 1 1-1h3l2 2h5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4z"/></svg>${sfData.name} (empty)</div>`
      ).join('');
      if(!topJobs.length&&!subFolders.length&&search) return '';
      return folderName?`<details open style="margin-bottom:18px"><summary style="font-size:13px;font-weight:700;cursor:pointer;padding:4px 0;display:flex;align-items:center;gap:8px">📁 ${folderData.name||folderName}<span style="font-size:10px;color:var(--t2)">${topJobs.length}</span></summary><div class="rv-compact-grid" style="margin-top:10px">${topJobs.map(j=>this._jobCard(j)).join('')}${subHTML}</div></details>`:`<div style="margin-bottom:18px"><div style="font-size:11px;font-weight:600;color:var(--t2);margin-bottom:8px;text-transform:uppercase;letter-spacing:.5px">Unfoldered</div><div class="rv-compact-grid">${topJobs.map(j=>this._jobCard(j)).join('')}</div></div>`;
    }).join('');
    gridEl.innerHTML=folderHTML||`<div style="text-align:center;padding:40px;color:var(--t2)"><p style="font-size:14px;font-weight:600">${search?'No jobs match "'+search+'"':'No jobs yet'}</p></div>`;
    // PDF thumbs
    cJobs.forEach(j=>{const el=document.getElementById('pdf-thumb-'+j.id);if(!el)return;for(const ver of [...j.versions].reverse()){for(const f of ver.files||[]){if(f.url&&(f.type==='pdf'||/\.pdf$/i.test(f.name||''))){RV._getPdfThumb(f.url,(d)=>{const e=document.getElementById('pdf-thumb-'+j.id);if(d&&e)e.innerHTML=`<img src="${d}" style="width:100%;height:100%;object-fit:cover;display:block">`;});return;}}}});
  },

  createFolder(clientId,parentPath){
    if(S.user?.role==='client') return;
    const existing=document.getElementById('rv-folder-modal-wrap');
    if(existing) existing.remove();
    const wrap=document.createElement('div');
    wrap.id='rv-folder-modal-wrap';
    wrap.dataset.cid=clientId;
    wrap.dataset.parentid=parentPath||'';  // parentPath is now a folder ID
    wrap.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;display:flex;align-items:center;justify-content:center';
    const pp=parentPath||'';
    wrap.innerHTML='<div style="background:var(--bg1);border-radius:12px;padding:24px 28px;min-width:320px;box-shadow:0 8px 40px rgba(0,0,0,.4)">'
      +'<div style="font-size:15px;font-weight:700;margin-bottom:16px">Create folder'+(pp?(()=>{const _fn=RV_DB._folders?.[pp]?.name||pp;return' inside <em>'+_fn+'</em>';})():'')+'</div>'
      +'<input id="rv-new-folder-name" class="fi" placeholder="Folder name" style="width:100%;padding:8px 12px;font-size:13px;margin-bottom:16px">'
      +'<div style="display:flex;gap:8px;justify-content:flex-end">'
      +'<button class="btn btn-g btn-sm" onclick="document.getElementById(\'rv-folder-modal-wrap\').remove()">Cancel</button>'
      +'<button class="btn btn-o btn-sm" onclick="RV._doCreateFolder()">Create folder</button>'
      +'</div></div>';
    document.body.appendChild(wrap);
    setTimeout(()=>document.getElementById('rv-new-folder-name')?.focus(),50);
    wrap.addEventListener('keydown',e=>{if(e.key==='Enter')RV._doCreateFolder();if(e.key==='Escape')wrap.remove();});
  },

  _onDropToFolder(event,targetFolderIdOrName,clientId){
    event.preventDefault();
    const jid=event.dataTransfer.getData('text/plain');
    if(!jid) return;
    const j=RV_DB.getJob(jid); if(!j) return;
    const el=event.currentTarget;
    el.style.background=''; el.style.outline='';
    // targetFolderIdOrName can be a folder ID or name
    const targetFolder=RV_DB._folders?.[targetFolderIdOrName]||Object.values(RV_DB._folders||{}).find(f=>f.id===targetFolderIdOrName);
    if(targetFolder){
      j.folder=targetFolder.name;
      j.folderId=targetFolder.id;
    } else {
      j.folder=targetFolderIdOrName||'';
      j.folderId='';
    }
    RV_DB.audit('Job moved: "'+j.title+'" → '+(j.folder||'Unfoldered'), S.user?.name||'Admin', {
      clientId, jobId:j.id, icon:'', area:'Review', type:'folder',
      detail:'Moved "'+j.title+'" to '+(j.folder?'"'+j.folder+'"':'Unfoldered')
    });
    this.openClient(clientId,null);
    this.buildKanban();
    this.buildDashboard();
    this._updateBadge();
  },

  _folderNav:{clientId:null,folderId:null,path:[]},
  _sidebarOpen:false,

  openSubFolder(folderId){
    const f=RV_DB._folders?.[folderId]; if(!f) return;
    // Build breadcrumb path
    const path=[];
    let cur=f;
    while(cur){path.unshift({id:cur.id,name:cur.name});cur=cur.parentId?RV_DB._folders?.[cur.parentId]:null;}
    this._folderNav={clientId:f.clientId,folderId,path};
    this.openClient(f.clientId,null);
  },

  renameFolder(folderId){
    if(S.user?.role==='client') return;
    const f=RV_DB._folders?.[folderId]; if(!f) return;
    const wrap=document.createElement('div');
    wrap.id='rv-rename-folder-wrap';
    wrap.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;display:flex;align-items:center;justify-content:center';
    wrap.innerHTML='<div style="background:var(--bg1);border-radius:12px;padding:24px 28px;min-width:320px;box-shadow:0 8px 40px rgba(0,0,0,.4)">'
      +'<div style="font-size:15px;font-weight:700;margin-bottom:16px">Rename folder</div>'
      +'<input id="rv-rename-folder-inp" class="fi" value="'+f.name+'" style="width:100%;padding:8px 12px;font-size:13px;margin-bottom:16px">'
      +'<div style="display:flex;gap:8px;justify-content:flex-end">'
      +'<button class="btn btn-g btn-sm" onclick="document.getElementById(\'rv-rename-folder-wrap\').remove()">Cancel</button>'
      +'<button class="btn btn-o btn-sm" onclick="RV._doRenameFolder(\''+folderId+'\')">Save</button>'
      +'</div></div>';
    document.body.appendChild(wrap);
    setTimeout(()=>{const inp=document.getElementById('rv-rename-folder-inp');if(inp){inp.focus();inp.select();}},50);
    wrap.addEventListener('keydown',e=>{if(e.key==='Enter')RV._doRenameFolder(folderId);if(e.key==='Escape')wrap.remove();});
  },

  _doRenameFolder(folderId){
    const f=RV_DB._folders?.[folderId]; if(!f) return;
    const name=document.getElementById('rv-rename-folder-inp')?.value?.trim();
    if(!name){const inp=document.getElementById('rv-rename-folder-inp');if(inp)inp.style.borderColor='var(--o)';return;}
    // Update all jobs that reference this folder by name
    const oldName=f.name;
    f.name=name;
    RV_DB._jobs.forEach(j=>{if(j.folderId===folderId)j.folder=name;else if(j.folder===oldName&&j.clientId===f.clientId)j.folder=name;});
    // Update breadcrumb path if this folder is in the current nav
    if(this._folderNav?.path){this._folderNav.path=this._folderNav.path.map(p=>p.id===folderId?{...p,name}:p);}
    document.getElementById('rv-rename-folder-wrap')?.remove();
    RV_DB.audit('Folder renamed: "'+oldName+'" → "'+name+'"', S.user?.name||'Admin', {
      clientId:f.clientId, folderId, icon:'', area:'Review', type:'folder',
      detail:'Renamed folder from "'+oldName+'" to "'+name+'"'
    });
    this.openClient(f.clientId,null);
  },

  _navToFolder(folderId){
    if(!folderId){
      // Go back to root
      const cid=this._folderNav?.clientId||this._activeClientId;
      this._folderNav={clientId:cid,folderId:null,path:[]};
      this.openClient(cid,null);
    } else {
      this.openSubFolder(folderId);
    }
  },

  _doCreateFolder(){
    if(S.user?.role==='client') return;
    const wrap=document.getElementById('rv-folder-modal-wrap');
    const clientId=wrap?.dataset?.cid;
    const parentId=wrap?.dataset?.parentid||'';  // parent folder ID (not path)
    const name=document.getElementById('rv-new-folder-name')?.value?.trim();
    if(!name){const inp=document.getElementById('rv-new-folder-name');if(inp)inp.style.borderColor='var(--o)';return;}
    wrap?.remove();
    if(!RV_DB._folders) RV_DB._folders={};
    const folderId='folder-'+Date.now();
    const folderObj={id:folderId,clientId,name,parentId,created:Date.now()};
    RV_DB._folders[folderId]=folderObj;
    console.log('[FOLDER] created',folderObj,'total='+Object.keys(RV_DB._folders).length);
    RV_DB.audit('Folder created: '+name, S.user?.name||'Admin', {
      clientId, folderId, icon:'', area:'Review', type:'folder',
      detail:(parentId?(()=>{const _pf=RV_DB._folders?.[parentId];return _pf?'Subfolder "'+name+'" created inside "'+_pf.name+'"':'Subfolder "'+name+'" created';})():'Folder "'+name+'" created')
    });
    this.openClient(clientId,null);
  },

  openClient(clientId, btn){
    const isClient=S.user?.role==='client';
    this._activeClientId=clientId;

    // Reset folder nav if navigating to a different client
    if(this._folderNav?.clientId!==clientId){this._folderNav={clientId,folderId:null,path:[]};}
    const activeFolderId=this._folderNav?.folderId||null;
    const c=DB.getClient(clientId); if(!c) return;
    const el=document.getElementById('rv-client-content'); if(!el) return;
    // Store active client for filter reuse
    this._activeClientId=clientId;
    const _fyr=document.getElementById('rv-folder-filter-yr')?.value||'';
    const _fmon=document.getElementById('rv-folder-filter-mon')?.value||'';
    const _fsearch=(document.getElementById('rv-folder-search')?.value||'').toLowerCase();
    const _frange=parseInt(document.getElementById('rv-folder-date-range')?.value||'0');
    const _frangeCutoff=_frange?new Date(Date.now()-_frange*30*24*60*60*1000):null;
    const cJobs=RV_DB.getJobs(clientId).filter(j=>{
      if(activeFolderId){const _afN=RV_DB._folders?.[activeFolderId]?.name||'';if(!((j.folderId===activeFolderId)||(j.folder&&j.folder===_afN)))return false;}
      if(_fsearch&&!j.title.toLowerCase().includes(_fsearch)&&!(j.folder||'').toLowerCase().includes(_fsearch)) return false;
      if(_frangeCutoff){const _jd=j.due?new Date(j.due):new Date(j.created||Date.now());if(_jd<_frangeCutoff)return false;}
      // Archived jobs visible in Projects & Folders
      if(_fyr||_fmon){
        const _d=j.due?new Date(j.due):new Date(j.created||Date.now());
        if(_fyr&&String(_d.getFullYear())!==_fyr) return false;
        if(_fmon&&['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][_d.getMonth()]!==_fmon) return false;
      }
      return true;
    });
    // Group by folder then by year/month
    const byFolder={};
    // Pre-populate byFolder with any saved folders from RV_DB._folders
    if(RV_DB._folders){
      Object.values(RV_DB._folders).filter(f=>f.clientId===clientId).forEach(f=>{
        if(!byFolder[f.path]) byFolder[f.path]={_jobs:[],_sub:{}};
      });
    }
    cJobs.forEach(j=>{
      const folder=j.folder||'Unsorted';
      const sub=j.subfolder||null;
      if(!byFolder[folder]) byFolder[folder]={_jobs:[],_sub:{}};
      if(sub){if(!byFolder[folder]._sub[sub])byFolder[folder]._sub[sub]=[];byFolder[folder]._sub[sub].push(j);}
      else byFolder[folder]._jobs.push(j);
    });
    
    // Pinned jobs section for this client
    const pinnedFavsHTML=(()=>{
      const favs=RV_DB._jobs.filter(j=>RV_DB.isFavourite(j.id)&&j.clientId===clientId);
      if(!favs.length) return '';
      return '<div style="margin-bottom:16px;padding:10px 14px;background:rgba(255,214,0,.06);border:1px solid rgba(255,214,0,.2);border-radius:var(--rs)"><div style="font-size:10px;font-weight:700;color:#FFD600;text-transform:uppercase;letter-spacing:.8px;margin-bottom:8px">&#9733; Pinned</div><div class=\"rv-compact-grid\">'
        +favs.map(j=>this._jobCard(j)).join('')+'</div></div>';
    })();
    // Build folder HTML outside template literal to avoid nested template issues
    const folderHTML=(()=>{
    // Get all saved folders for this client
    const savedFolders=RV_DB._folders?Object.values(RV_DB._folders).filter(f=>f.clientId===clientId):[];
    // Build folder map by ID for quick lookup
    const folderById={};
    savedFolders.forEach(f=>folderById[f.id]=f);
    // Root folders: no parentId or parentId is ''
    // When navigating into a folder, show only that folder; otherwise show all root
    const _fsMode=document.getElementById('rv-folder-sort')?.value||'az';
    const _sortFolders=(arr)=>{
      const _cjCount=f=>RV_DB.getJobs(clientId).filter(j=>j.folderId===f.id&&!j.archived).length;
      return[...arr].sort((a,b)=>
        _fsMode==='za'?b.name.localeCompare(a.name):
        _fsMode==='newest'?(b.created||0)-(a.created||0):
        _fsMode==='oldest'?(a.created||0)-(b.created||0):
        _fsMode==='most'?_cjCount(b)-_cjCount(a):
        _fsMode==='least'?_cjCount(a)-_cjCount(b):
        a.name.localeCompare(b.name));
    };
    const rootFolders=activeFolderId
      ? savedFolders.filter(f=>f.id===activeFolderId)
      : _sortFolders(savedFolders.filter(f=>!f.parentId));
    // Jobs not in any named folder go into top-level unfoldered section
    const unfolderedJobs=cJobs.filter(j=>!j.folder&&!j.subfolderId);
    // Jobs in root folders
    const renderFolderCard=(f)=>{
      // Jobs directly in this folder
      const folderJobs=cJobs.filter(j=>j.folder===f.name&&!j.subfolderId);
      // Child folders
      const childFolders=savedFolders.filter(cf=>cf.parentId===f.id);
      const fId=f.id;
      const openCount=folderJobs.filter(j=>!['cr:signed_off','ir:done'].includes(j.status)).length;
      const fIcon='<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="13" height="13"><path d="M2 4a1 1 0 0 1 1-1h3l2 2h5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4z"/></svg>';
      let html='<details open style="margin-bottom:18px" ondragover="event.preventDefault();event.currentTarget.style.outline=\'2px solid var(--o)\';event.currentTarget.style.background=\'rgba(237,114,9,.06)\'" ondragleave="event.currentTarget.style.outline=\'\';event.currentTarget.style.background=\'\'" ondrop="RV._onDropToFolder(event,\''+f.name+'\',\''+clientId+'\')">'; 
      html+='<summary style="list-style:none;display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--bd0);margin-bottom:12px;cursor:pointer">';
      html+=fIcon+'<span style="font-size:13px;font-weight:700">'+f.name+'</span>';
      if(openCount) html+='<span style="background:rgba(237,114,9,.15);color:var(--o);font-size:10px;font-weight:700;padding:2px 7px;border-radius:10px">'+openCount+' active</span>';
      if(!isClient){
        html+='<div style="margin-left:auto;display:flex;gap:5px">'
        +'<button onclick="event.preventDefault();event.stopPropagation();RV.renameFolder(\''+f.id+'\')" style="font-size:10px;color:var(--t2);padding:2px 8px;border:1px solid var(--bd1);border-radius:6px;background:none;cursor:pointer">Rename</button>'
        +'<button onclick="event.preventDefault();event.stopPropagation();RV.createFolder(\''+clientId+'\',\''+fId+'\')" style="font-size:10px;color:var(--t2);padding:2px 8px;border:1px solid var(--bd1);border-radius:6px;background:none;cursor:pointer">+ Sub-folder</button>'
        +'</div>';
      }
      html+='</summary>';
      html+='<div class="rv-compact-grid">';
      // Render child folder cards first
      childFolders.forEach(cf=>{
        const cfJobs=RV_DB.getJobs(clientId).filter(j=>!j.archived&&(j.folderId===cf.id||(j.folder===cf.name&&!j.folderId)));
        html+='<div onclick="RV.openSubFolder(\''+cf.id+'\')" draggable="false" ondragover="event.preventDefault();event.stopPropagation();this.style.outline=\'2px solid var(--o)\';this.style.background=\'rgba(237,114,9,.08)\'" ondragleave="this.style.outline=\'\';this.style.background=\'var(--bg2)\'" ondrop="event.stopPropagation();RV._onDropToFolder(event,\''+cf.id+'\',\''+clientId+'\')" style="background:var(--bg2);border-radius:var(--rs);padding:12px 14px;cursor:pointer;display:flex;flex-direction:column;gap:8px;border:1px solid var(--bd0)" onmouseover="this.style.background=\'var(--bg1)\';this.style.borderColor=\'var(--o)\'" onmouseout="this.style.background=\'var(--bg2)\';this.style.borderColor=\'var(--bd0)\'">'
  +'<div style="display:flex;align-items:center;gap:8px"><svg viewBox="0 0 24 24" fill="rgba(237,114,9,.2)" stroke="var(--o)" stroke-width="1.5" width="20" height="20"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"/></svg>'
  +'<span style="font-size:12.5px;font-weight:700">'+cf.name+'</span></div>'
  +'<div style="display:flex;align-items:center;justify-content:space-between">'
  +'<span style="font-size:10px;color:var(--t2)">'+cfJobs.length+' job'+(cfJobs.length!==1?'s':'')+' inside</span>'
  +'<span style="font-size:9px;font-weight:700;padding:2px 7px;border-radius:8px;background:rgba(237,114,9,.12);color:var(--o)">Subfolder</span>'
  +'</div></div>';
      });
      // Then folder's direct jobs
      folderJobs.forEach(j=>{ html+=this._jobCard(j); });
      if(!childFolders.length&&!folderJobs.length) html+='<div style="font-size:11px;color:var(--t2);padding:8px;grid-column:1/-1">Empty folder</div>';
      html+='</div></details>';
      return html;
    };
    // Build byFolder from jobs for legacy support (jobs with j.folder set)
    const legacyFolders={};
    cJobs.filter(j=>j.folder&&!rootFolders.find(f=>f.name===j.folder)).forEach(j=>{
      if(!legacyFolders[j.folder]) legacyFolders[j.folder]={_jobs:[]};
      legacyFolders[j.folder]._jobs.push(j);
    });
    let html='';
    // Root saved folders
    rootFolders.forEach(f=>{ html+=renderFolderCard(f); });
    // Legacy folders (from j.folder string, not in savedFolders)
    Object.entries(legacyFolders).forEach(([fname,fdata])=>{
      html+='<details open style="margin-bottom:18px"><summary style="list-style:none;display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--bd0);margin-bottom:12px;cursor:pointer"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="13" height="13"><path d="M2 4a1 1 0 0 1 1-1h3l2 2h5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4z"/></svg><span style="font-size:13px;font-weight:700">'+fname+'</span></summary><div class="rv-compact-grid">'+fdata._jobs.map(j=>this._jobCard(j)).join('')+'</div></details>';
    });
    // Unfoldered jobs
    if(unfolderedJobs.length) html+='<div id="rv-unfoldered-drop" style="margin-bottom:18px"><div style="font-size:11px;font-weight:600;color:var(--t2);margin-bottom:8px;text-transform:uppercase;letter-spacing:.5px">Unfoldered</div><div class="rv-compact-grid">'+unfolderedJobs.map(j=>this._jobCard(j)).join('')+'</div></div>';
    return html;
  })();
    // Build sidebar + breadcrumb vars
    const _nav=this._folderNav||{};
    // Back button: go to parent folder, or to root if at top level
    const _backFId=_nav.path&&_nav.path.length>1?_nav.path[_nav.path.length-2].id:null;
    const _backToRoot=_nav.path&&_nav.path.length===1;
    const _backBtn=_nav.path&&_nav.path.length
      ?'<button onclick="'+(_backToRoot?'RV._navToFolder(null)':'RV._navToFolder(\''+_backFId+'\')' )+'" style="display:inline-flex;align-items:center;gap:4px;font-size:11px;padding:3px 10px;border-radius:5px;border:1px solid var(--bd0);background:none;cursor:pointer;color:var(--t2);margin-bottom:8px">&#8592; Back</button>'
      :'';
    const _bc=_nav.path?.length
      ?'<nav style="font-size:11px;color:var(--t2);margin-bottom:12px;display:flex;align-items:center;gap:4px;flex-wrap:wrap"><span onclick="RV._navToFolder(null)" style="cursor:pointer;color:var(--o)">All folders</span>'+_nav.path.map((p,i)=>' <span style="opacity:.4">&#8250;</span> '+(i<_nav.path.length-1?'<span onclick="RV._navToFolder(\''+p.id+'\')" style="cursor:pointer;color:var(--o)">'+p.name+'</span>':'<span style="color:var(--t1);font-weight:600">'+p.name+'</span>')).join('')+'</nav>'
      :'';
    const _allF=RV_DB._folders?Object.values(RV_DB._folders).filter(f=>f.clientId===clientId):[];
    const _rootF=[..._allF.filter(f=>!f.parentId)].sort((a,b)=>a.name.localeCompare(b.name));
    const _treeNode=(f,d=0)=>{
      const _ch=_allF.filter(ch=>ch.parentId===f.id);
      const _act=_nav.folderId===f.id;
      const _jc=RV_DB.getJobs(clientId).filter(j=>j.folderId===f.id&&!j.archived).length;
      return'<div style="margin-left:'+(d*12)+'px"><div onclick="RV.openSubFolder(\''+f.id+'\')" style="padding:4px 7px;border-radius:5px;cursor:pointer;display:flex;align-items:center;gap:5px;font-size:11.5px;'+(_act?'background:rgba(237,114,9,.15);color:var(--o);font-weight:600':'')+'" onmouseover="if(this.style.fontWeight!==\'600\')this.style.background=\'var(--bg3)\'" onmouseout="if(this.style.fontWeight!==\'600\')this.style.background=\'\'"><svg viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\" width=\"11\" height=\"11\"><path d=\"M2 4a1 1 0 0 1 1-1h3l2 2h5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4z\"/></svg>'+f.name+(_jc?'<span style=\"font-size:9px;color:var(--t2);margin-left:4px\">('+_jc+')</span>':'')+'</div>'+_ch.map(ch=>_treeNode(ch,d+1)).join('')+'</div>';
    };
    const _treeHtml=_rootF.map(f=>_treeNode(f)).join('');
    const _sbOpen=this._sidebarOpen===true;  // default collapsed
el.innerHTML=`
      <div class="rv-seye">${c.name}</div>
      <div style="display:flex;gap:16px;align-items:flex-start">
        ${_sbOpen&&_treeHtml?`<div style="width:185px;flex-shrink:0;background:var(--bg2);border-radius:var(--rs);padding:10px 8px;border:1px solid var(--bd0)"><div style="font-size:9.5px;font-weight:700;color:var(--t2);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px;padding:0 4px">Folders</div><div onclick="RV._navToFolder(null)" style="padding:4px 8px;border-radius:5px;cursor:pointer;font-size:11.5px;margin-bottom:4px" onmouseover="this.style.background='var(--bg3)'" onmouseout="this.style.background=''">All folders</div>${_treeHtml}</div>`:''}
        <div style="flex:1;min-width:0">
          ${_bc}
      <div style="display:flex;gap:8px;margin-bottom:14px;align-items:center;flex-wrap:wrap">
        <input class="fi" id="rv-folder-search" placeholder="Search jobs…" style="font-size:12px;padding:5px 10px;width:200px" oninput="RV._filterClientJobs('${clientId}')">
        <button onclick="RV._sidebarOpen=!RV._sidebarOpen;RV.openClient('${clientId}',null)" class="btn btn-g btn-sm" style="display:flex;align-items:center;gap:5px;flex-shrink:0"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="12" height="12"><path d="M2 4a1 1 0 0 1 1-1h3l2 2h5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4z"/></svg>${_sbOpen?'Hide List View':'Show List View'}</button>
        <select class="fi" id="rv-folder-sort" data-cid="${clientId}" style="font-size:12px;padding:5px 8px;width:120px" onchange="RV.openClient(this.dataset.cid,null)"><option value="az">A → Z</option><option value="za">Z → A</option><option value="newest">Newest</option><option value="oldest">Oldest</option><option value="most">Most jobs</option><option value="least">Least jobs</option></select>
        <select class="fi" id="rv-folder-date-range" data-cid="${clientId}" style="font-size:12px;padding:5px 10px;width:auto;min-width:130px" onchange="RV.openClient(this.dataset.cid,null)"><option value="">All time</option><option value="3">Last 3 months</option><option value="6">Last 6 months</option><option value="9">Last 9 months</option></select>
        <select class="fi" id="rv-folder-filter-yr" data-cid="${clientId}" style="font-size:12px;padding:5px 10px;width:auto;min-width:90px" onchange="RV.openClient(this.dataset.cid,null)">
          <option value="">All years</option>
          ${[...new Set(RV_DB.getJobs(clientId).filter(j=>!j.archived).map(j=>j.due?new Date(j.due).getFullYear():new Date(j.created||Date.now()).getFullYear()))].sort((a,b)=>b-a).map(y=>`<option value="${y}" ${_fyr==y?'selected':''}>${y}</option>`).join('')}
        </select>
        <select class="fi" id="rv-folder-filter-mon" data-cid="${clientId}" style="font-size:12px;padding:5px 10px;width:auto;min-width:100px" onchange="RV.openClient(this.dataset.cid,null)">
          <option value="">All months</option>
          ${(()=>{const _monHasJobs=new Set(RV_DB.getJobs(clientId).filter(j=>!j.archived).map(j=>{const _d=j.due?new Date(j.due):new Date(j.created||Date.now());return['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][_d.getMonth()];}));return['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'].map(m=>`<option value="${m}" ${_fmon===m?'selected':''} ${!_monHasJobs.has(m)?'disabled style="opacity:.4"':''}>${m}</option>`).join('');})() }
        </select>
      </div>
      <div class="rv-title" style="margin-bottom:12px">Projects & Folders</div>
      ${!isClient ? `<div style="display:flex;gap:8px;margin-bottom:18px">      </div>` : ''}
      ${pinnedFavsHTML||''}
      ${_backBtn}${_bc}<div id="rv-client-jobs-grid">${folderHTML||'<div style="text-align:center;padding:40px;color:var(--t2)"><p style="font-size:14px;font-weight:600">No jobs yet</p></div>'}</div>
    
        </div>
      </div>
    `;
    this.go('rv-client',btn);
    // Set up drag-drop for unfoldered section
    setTimeout(()=>{
      const ufd=document.getElementById('rv-unfoldered-drop');
      if(ufd){
        ufd.addEventListener('dragover',e=>{e.preventDefault();ufd.style.outline='2px dashed var(--t2)';});
        ufd.addEventListener('dragleave',()=>{ufd.style.outline='';});
        ufd.addEventListener('drop',e=>{e.preventDefault();ufd.style.outline='';RV._onDropToFolder(e,'',clientId);});
      }
    },50);
    this._updateReviewBadge();
    // Async-load PDF thumbnails for any job cards
    RV_DB._jobs.filter(j=>j.clientId===clientId).forEach(j=>{
      for(const ver of [...j.versions].reverse()){
        for(const f of ver.files||[]){
          if(f.url&&(f.type==='pdf'||/\.pdf$/i.test(f.name||''))){
            const thumbEl=document.getElementById('pdf-thumb-'+j.id);
            if(thumbEl) this._getPdfThumb(f.url,(dataUrl)=>{
              if(dataUrl&&thumbEl) thumbEl.innerHTML=`<img src="${dataUrl}" style="width:100%;height:100%;object-fit:cover;display:block">`;
            });
            break;
          }
        }
      }
    });
  },

  _jobCard(j){
    const isComplete=j.archived&&j.status==='cr:signed_off';
    const statCol=isComplete?'#16A34A':(RV_DB.STATUS_COLS[j.status]||'#94A3B8');
    const due=j.due?new Date(j.due):null;
    const isOverdue=due&&due<new Date()&&!['cr:signed_off','ir:done'].includes(j.status);
    // Find preview image
    let previewUrl=''; let previewType='image';
    for(const ver of [...j.versions].reverse()){
      for(const f of ver.files||[]){
        if(f.url&&(f.type==='image'||/\.(jpg|jpeg|png|gif)$/i.test(f.name||''))){previewUrl=f.url;previewType='image';break;}
        if(f.url&&(f.type==='pdf'||/\.pdf$/i.test(f.name||''))){previewUrl=f.url;previewType='pdf';break;}
        if(f.url&&(f.type==='video'||/\.(mp4|mov|webm)$/i.test(f.name||''))){previewUrl=f.url;previewType='video';break;}
      }
      if(previewUrl) break;
    }
    return`<div class="rv-jcard" draggable="true" data-jid="${j.id}" onclick="RV.openJob('${j.id}')" onmouseover="this.style.borderColor='var(--o)';this.style.transform='translateY(-2px)'" onmouseout="this.style.borderColor='var(--bd0)';this.style.transform=''" ondragstart="event.dataTransfer.setData('text/plain','${j.id}');event.dataTransfer.effectAllowed='move';this.style.opacity='.5'" ondragend="this.style.opacity='1'">
      <div style="height:100px;background:var(--bg2);position:relative;overflow:hidden;border-bottom:1px solid var(--bd0)">
        ${previewType==='image'&&previewUrl
          ?`<img src="${previewUrl}" style="width:100%;height:100%;object-fit:cover" onerror="this.style.display='none'">`
          :previewType==='pdf'&&previewUrl
          ?`<div id="pdf-thumb-${j.id}" style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:var(--bg2)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" width="32" height="32" opacity=".3"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>`
          :previewType==='video'&&previewUrl
          ?`<video src="${previewUrl}" style="width:100%;height:100%;object-fit:cover" preload="metadata" muted playsinline onloadedmetadata="this.currentTime=1"></video>`
          :`<div style="display:flex;align-items:center;justify-content:center;height:100%;opacity:.25"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="28" height="28"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg></div>`}</div>
      <div style="padding:8px 10px">
        <div style="font-size:11px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:2px">${j.title}</div>
        <div style="font-size:10px;color:var(--t2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${j.folder||''}</div>
        ${due?`<div style="font-size:9.5px;color:${isOverdue?'#E84545':'var(--t2)'};margin-top:3px">${isOverdue?'Overdue: ':'Due: '}${due.toLocaleDateString('en-GB',{day:'numeric',month:'short'})}</div>`:''}
        <div style="margin-top:6px;display:flex;gap:4px">
          <button onclick="event.stopPropagation();RV_DB.toggleFavourite('${j.id}');if(RV._activeClientId)RV.openClient(RV._activeClientId,null);else RV.refreshBoards()" style="background:none;border:none;cursor:pointer;padding:0;font-size:12px;color:${RV_DB.isFavourite(j.id)?'#FFD600':'rgba(255,255,255,.2)'}" title="${RV_DB.isFavourite(j.id)?'Unpin':'Pin'}">&#9733;</button>
        </div>
      </div>
    </div>`;
  },

  openJob(id, activeVersionId){
    this._currentJob=id;
    const j=RV_DB.getJob(id); if(!j) return;
    const c=DB.getClient(j.clientId);
    const el=document.getElementById('rv-job-content'); if(!el) return;
    // Switch to the job view — critical for rendering
    this.go('rv-job', null);

    const isClient=S.user?.role==='client';
    const latestVer=activeVersionId?j.versions.find(v=>v.id===activeVersionId)||j.versions[j.versions.length-1]:j.versions[j.versions.length-1]||null;
    const statCol=RV_DB.STATUS_COLS[j.status]||'#94A3B8';
    const stages=['internal_review','client_review','amendments','approved'];

    el.innerHTML=`
      <div class="rv-job-header">
        <div>
          ${(()=>{
            if(!j.folder&&!j.folderId) return '';
            const _jFId=j.folderId||(RV_DB._folders?Object.values(RV_DB._folders).find(f=>f.name===j.folder&&f.clientId===j.clientId)?.id:null);
            const _jPath=[];let _cur=_jFId?RV_DB._folders[_jFId]:null;
            if(!_cur&&j.folder) _jPath.unshift({id:null,name:j.folder});
            while(_cur){_jPath.unshift({id:_cur.id,name:_cur.name});_cur=_cur.parentId?RV_DB._folders[_cur.parentId]:null;}
            if(!_jPath.length) return '';
            return '<nav style="font-size:10.5px;color:var(--t2);margin-bottom:8px;display:flex;align-items:center;gap:3px;flex-wrap:wrap;opacity:.65">'
              +'<span onclick="RV.go(\'rv-client\',null)" style="cursor:pointer;color:inherit" onmouseover="this.style.opacity=\'1\'" onmouseout="this.style.opacity=\'\'" >Projects & Folders</span>'
              +_jPath.map(p=>' <span style="opacity:.5">&#8250;</span> '+(p.id?'<span onclick="RV.openSubFolder(\''+p.id+'\')" style="cursor:pointer;color:inherit" onmouseover="this.style.opacity=\'1\'" onmouseout="this.style.opacity=\'\'" >'+p.name+'</span>':'<span>'+p.name+'</span>')).join('')
              +'</nav>';
          })()}
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
            ${c?`<div style="width:28px;height:28px;border-radius:6px;background:${c.brand_colour};display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:${c.brand_text}">${c.initials}</div>`:''}
            <div style="font-size:10px;font-weight:700;color:var(--o);text-transform:uppercase;letter-spacing:.6px">${c?.name||''}</div>
          </div>
          <div style="font-size:20px;font-weight:700;margin-bottom:8px">${j.title}</div>
          <div style="margin-bottom:12px">
            ${!isClient?'<div style="font-size:9px;font-weight:700;color:#3B82F6;text-transform:uppercase;letter-spacing:.8px;margin-bottom:5px">Internal Review</div>':''}
            ${!isClient?`<div class="rv-stage-trail" style="margin-bottom:8px">
              ${RV_DB.INTERNAL_COLS.map(s=>{
                const isCurrent=j.status===s;
                const isDone=RV_DB.INTERNAL_COLS.indexOf(s)<RV_DB.INTERNAL_COLS.indexOf(j.status)||RV_DB.getStage(j.status)==='client';
                return`<div class="rv-stage ${isCurrent?'on':isDone?'done':''}" data-action="rv-status" data-jid="${id}" data-status="${s}" style="cursor:pointer">${RV_DB.STATUS_LABELS[s]||s}</div>`;
              }).join('')}
            </div>`:''}
            <div style="font-size:9px;font-weight:700;color:#ED7209;text-transform:uppercase;letter-spacing:.8px;margin-bottom:5px">${isClient&&c?c.name+' Review':'Client Review'}</div>
            <div class="rv-stage-trail">
              ${RV_DB.CLIENT_COLS.map(s=>{
                const isCurrent=j.status===s;
                const isDone=RV_DB.CLIENT_COLS.indexOf(s)<RV_DB.CLIENT_COLS.indexOf(j.status);
                return`<div class="rv-stage ${isCurrent?'on':isDone?'done':''}" data-action="rv-status" data-jid="${id}" data-status="${s}"
                  style="cursor:${!isClient?'pointer':'default'}">${RV_DB.STATUS_LABELS[s]||s}</div>`;
              }).join('')}
            </div>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;align-items:flex-end">
          <div style="font-size:11px;color:var(--t2)">${j.due?`Due: <strong>${new Date(j.due).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'})}</strong>`:''}</div>
          ${j.assignedTo?`<div style="font-size:11px;color:var(--t2)">Assigned: ${j.assignedTo}</div>`:''}
          <div style="display:flex;gap:6px">
            ${isClient&&j.status==='cr:ready'?`
              <button class="btn btn-o btn-sm" data-action="rv-approve" data-jid="${id}">✓ Approve</button>
              <button class="btn btn-r btn-sm" data-action="rv-reject" data-jid="${id}" style="border:1.5px solid var(--o);color:var(--o);background:rgba(237,114,9,.08)">Request changes</button>
            `:''}
            ${!isClient?(j.archived?`<button class="rv-file-tool" onclick="RV.unarchiveJob('${id}')" style="font-size:12px;color:#FFD600">Restore</button>`:`<button class="rv-file-tool" onclick="RV.archiveJob('${id}')" style="font-size:12px;color:var(--t2)">Archive</button>`):''}
            ${(j.status==='cr:signed_off'||j.status==='ir:done')?`<button class="rv-file-tool" onclick="RV.reopenJob('${id}')" style="font-size:12px;color:#F59E0B;border-color:rgba(245,158,11,.35)">↩ Reopen</button>`:''}
            ${!isClient?`<button class="btn btn-o btn-sm" data-action="rv-share"  data-jid="${id}">Share</button>`:''}
            ${!isClient?`<button class="btn btn-g btn-sm" data-action="rv-edit"   data-jid="${id}">Edit</button>`:''}
          </div>
          ${(()=>{
            const _isC=S.user?.role==='client';
            const _al=RV._getAllowedClients?.call(RV)||[];
            const _sts=_isC?['cr:ready']:['ir:ready'];
            const _ot=RV_DB._jobs.filter(x=>!x.archived&&_sts.includes(x.status)&&x.id!==id&&(!_isC||_al.includes(x.clientId)));
            if(!_ot.length) return '';
            return '<div style="margin-bottom:12px;padding:11px 15px;background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.25);border-radius:8px;display:flex;align-items:center;justify-content:space-between;gap:12px">'
              +'<div><div style="font-size:10px;font-weight:700;color:#F59E0B;text-transform:uppercase;letter-spacing:.7px;margin-bottom:2px">Review queue</div>'
              +'<div style="font-size:13px;color:var(--t0)"><strong>'+_ot.length+' other job'+(_ot.length!==1?'s':'')+' ready for review</strong></div></div>'
              +'<button onclick="RV.showReviewQueue(document.getElementById(\'rvsb-review-queue\'))" style="background:rgba(245,158,11,.15);border:1px solid rgba(245,158,11,.3);color:#F59E0B;border-radius:var(--rs);padding:4px 11px;cursor:pointer;font-size:11.5px;font-weight:600;font-family:var(--fn);white-space:nowrap">View queue →</button>'
              +'</div>';
          })()}
        </div>
      </div>

      ${j.desc?`<div class="ins a" style="margin-bottom:14px"><p>${j.desc}</p></div>`:''}

      <div style="display:grid;grid-template-columns:1fr 280px;gap:16px;align-items:flex-start">
        <!-- Main file viewer -->
        <div>

                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;padding:8px 12px;background:var(--bg2);border-radius:var(--rs);border:1px solid var(--bd0)">
      ${j.versions.length>1?`
        <label style="font-size:11px;font-weight:700;color:var(--t2);text-transform:uppercase;letter-spacing:.6px;white-space:nowrap">Version:</label>
        <select class="fi" style="font-size:12px;padding:4px 8px;flex:1" onchange="RV.showVersion('${id}',this.value)">
          ${[...j.versions].reverse().map(v=>{const vCmts=v.comments||[];const openC=vCmts.filter(c=>!c.resolved).length;return'<option value="'+v.id+'" '+(v===latestVer?'selected':'')+'>'+v.label+(v===latestVer?' (current)':'')+'  ·  '+new Date(v.uploaded).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'})+(openC?' · '+openC+' comment'+(openC!==1?'s':''):'')+' </option>';}).join('')}
        </select>
      `:`<span style="font-size:11.5px;color:var(--t2);flex:1">No additional versions yet</span>`}
      ${!isClient?`<button class="btn btn-g btn-sm" onclick="RV.uploadModal('${id}')" style="display:flex;align-items:center;gap:4px;flex-shrink:0"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" width="12" height="12"><line x1="8" y1="2" x2="8" y2="14"/><line x1="2" y1="8" x2="14" y2="8"/></svg> Add version</button>`:''}
    </div>
          ${latestVer?this._versionViewer(j,latestVer):
            `<div class="rv-dropzone" onclick="RV.uploadModal('${id}')" style="cursor:pointer;position:relative;z-index:5;pointer-events:auto"
                ondragover="event.preventDefault();this.classList.add('over')"
                ondragleave="this.classList.remove('over')"
                ondrop="event.preventDefault();this.classList.remove('over');RV._currentJob='${id}';RV._quickDrop(event.dataTransfer.files,'${id}')">
              <div class="rv-dropzone-ico">
                <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.6" width="36" height="36" style="color:var(--t2)"><rect x="4" y="6" width="24" height="20" rx="2"/><polyline points="16 11 16 21"/><polyline points="11 16 16 11 21 16"/></svg>
              </div>
              <div style="font-size:13px;color:var(--t1);margin-top:6px">No files yet</div>
              <div style="font-size:11.5px;color:var(--t2);margin-top:4px">${!isClient?'Click to browse or drag files here':''}</div>
            </div>`}
        </div>

        <!-- Comments panel -->
        <div>
          <div class="rv-comments-panel">
            <div class="rv-cp-hd">
              <span style="display:flex;align-items:center;gap:5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14" style="flex-shrink:0"><path d="M2 2h12a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H9l-3 3V11H2a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z"/></svg> Comments (<span id="rv-cmt-count-${id}">0</span>)</span>
              <select class="fi" style="padding:3px 7px;font-size:10.5px;width:auto;color:var(--t0)" onchange="RV.filterComments('${id}',this.value)">
                <option value="all">All</option>
                <option value="open">Open</option>
                <option value="resolved">Resolved</option>
              </select>
            </div>
            <div class="rv-comments" id="rv-comments-${id}">
              ${this._renderComments(j, latestVer)}
            </div>
            <div class="rv-comment-input">
              <textarea class="fi" id="rv-cmt-input-${id}" rows="2" placeholder="Add a comment…" style="font-size:12px;resize:none;margin-bottom:6px"></textarea>
              <button class="btn btn-o btn-sm" style="width:100%" onclick="RV.addComment('${id}')">Post comment</button>
            </div>
          </div>

          <div id="rv-brand-job-${id}" style="display:none;margin-top:10px;max-height:180px;overflow-y:auto;font-size:12px"></div>
          <!-- Activity -->
          <div style="margin-top:12px">
            <div style="font-size:11px;font-weight:700;color:var(--t2);text-transform:uppercase;letter-spacing:.8px;margin-bottom:8px">Activity</div>
            <div style="max-height:220px;overflow-y:auto">
              ${j.activity.slice(0,10).map(a=>`
                <div class="rv-activity-item">
                  <div class="rv-activity-ico">${(()=>{
                    const ic={'':'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14"><rect x="3" y="2" width="10" height="12" rx="1"/><line x1="6" y1="6" x2="10" y2="6"/><line x1="6" y1="9" x2="10" y2="9"/></svg>',
                    '':'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14"><line x1="8" y1="11" x2="8" y2="3"/><polyline points="5 6 8 3 11 6"/><line x1="3" y1="13" x2="13" y2="13"/></svg>',
                    '':'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14"><path d="M13 9a5 5 0 0 1-5 4H5l-3 2V6a5 5 0 0 1 5-5h1a5 5 0 0 1 5 5v3z"/></svg>',
                    '':'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14"><path d="M13 8A5 5 0 1 1 8 3"/><polyline points="13 3 13 8 8 8"/></svg>',
                    '':'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14"><polyline points="3 8 6 11 13 4"/></svg>',
                    '✏️':'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14"><path d="M11 2l3 3-8 8H3v-3l8-8z"/></svg>'};
                    return ic[a.icon]||'<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14"><circle cx="8" cy="8" r="6"/><line x1="8" y1="7" x2="8" y2="11"/><circle cx="8" cy="5" r=".5" fill="currentColor"/></svg>';
                  })()}</div>
                  <div style="flex:1"><div class="rv-activity-text"><strong>${a.user}</strong> ${a.action}</div></div>
                  <div class="rv-activity-time">${new Date(a.ts).toLocaleDateString('en-GB',{day:'numeric',month:'short'})}</div>
                </div>`).join('')}
            </div>
          </div>
        </div>
      </div>`;

    this._currentJob=j.id;
    this.go('rv-job', null);
    setTimeout(()=>{
      if(latestVer){
        const file=latestVer.files[0];
        const isPdf=file?.type==='pdf'||/\.pdf$/i.test(file?.name||'');
        if(isPdf&&file?.url) this.pdfInit(j.id,file.url,latestVer?.id||null);
        this._renderShapes(j.id,latestVer.id);
        // Draw pin markers AFTER shapes so they sit on top and aren't wiped
        this._addPinMarker(j.id,latestVer.id);
        // Set initial comment count
        const _initCntEl=document.getElementById('rv-cmt-count-'+id);
        if(_initCntEl){
          const _allInit=[...(latestVer?.comments||[]),...(j.comments||[])];
          _initCntEl.textContent=_allInit.length;
        }
        if(file&&(file.type==='image'||isPdf)) this.setAnnotateTool(j.id,latestVer.id,'pin');
      }
    },150);
  },

  _versionViewer(j,ver){
    const file=ver.files[0]||null;
    const fileIcon=file?{image:'🖼',pdf:'📄',video:'🎥',doc:'📝'}[file.type]||'📁':'📁';
    const isImg=file?.type==='image'||/\.(jpg|jpeg|png|svg|gif)$/i.test(file?.name||'');
    const isPdf=file?.type==='pdf'||/\.pdf$/i.test(file?.name||'');
    const isVid=file?.type==='video'||/\.(mp4|mov|webm)$/i.test(file?.name||'');

    const pdfViewer=isPdf&&file?.url?`
      <div id="rv-pdf-${j.id}" style="background:#525659;padding:8px;min-height:500px;position:relative">
        <div id="rv-pdf-debug-${j.id}" style="position:absolute;top:8px;right:8px;z-index:9999;background:#0d1117;color:#58a6ff;padding:8px 10px;font-size:10px;font-family:monospace;border-radius:6px;border:1px solid #30363d;min-width:200px"></div>
        <div class="pdf-toolbar" style="display:flex;align-items:center;justify-content:center;gap:10px;padding:8px;background:#3d3d3d;margin-bottom:8px">
          <button class="rv-file-tool" onclick="RV.pdfPage(-1,'${j.id}')" style="color:#fff;border-color:rgba(255,255,255,.2)">‹ Prev</button>
          <span id="rv-pdf-pg-${j.id}" style="font-size:12px;color:#fff;min-width:80px;text-align:center">Page 1</span>
          <button class="rv-file-tool" onclick="RV.pdfPage(1,'${j.id}')" style="color:#fff;border-color:rgba(255,255,255,.2)">Next ›</button>
          <button class="rv-file-tool" onclick="RV.pdfZoom(.1,'${j.id}')" style="color:#fff;border-color:rgba(255,255,255,.2)">+ Zoom</button>
          <button class="rv-file-tool" onclick="RV.pdfZoom(-.1,'${j.id}')" style="color:#fff;border-color:rgba(255,255,255,.2)">− Zoom</button>
        </div>
        <div id="rv-pdf-canvas-wrap-${j.id}" style="position:relative;display:block;margin:0 auto;overflow:visible">
          <canvas id="rv-pdf-canvas-${j.id}" style="display:block;max-width:100%"></canvas>
          <svg id="rv-draw-${j.id}" style="position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;overflow:visible;z-index:5"></svg>
        </div>
      </div>` : '';

    return`<div class="rv-file-area">
      <div class="rv-file-toolbar" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:6px">
        <!-- Annotation tools — left -->
        <div style="display:flex;align-items:center;gap:4px;flex-wrap:wrap">
          ${!isVid?`
          <button class="rv-file-tool rv-ann-btn" data-tool="pin" onclick="RV.setAnnotateTool('${j.id}','${ver.id}','pin')" style="display:flex;align-items:center;gap:3px;font-size:12px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="12" height="12"><circle cx="8" cy="6" r="3"/><line x1="8" y1="9" x2="8" y2="14"/></svg> Pin</button>
          <button class="rv-file-tool rv-ann-btn" data-tool="rect" onclick="RV.setAnnotateTool('${j.id}','${ver.id}','rect')" style="display:flex;align-items:center;gap:3px;font-size:12px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="12" height="12"><rect x="3" y="3" width="10" height="10" rx="1"/></svg> Box</button>
          <button class="rv-file-tool rv-ann-btn" data-tool="circle" onclick="RV.setAnnotateTool('${j.id}','${ver.id}','circle')" style="display:flex;align-items:center;gap:3px;font-size:12px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="12" height="12"><circle cx="8" cy="8" r="5"/></svg> Circle</button>
          <button class="rv-file-tool rv-ann-btn" data-tool="arrow" onclick="RV.setAnnotateTool('${j.id}','${ver.id}','arrow')" style="display:flex;align-items:center;gap:3px;font-size:12px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="12" height="12"><line x1="2" y1="14" x2="14" y2="2"/><polyline points="6 2 14 2 14 10"/></svg> Arrow</button>
          <button class="rv-file-tool rv-ann-btn" data-tool="highlight" onclick="RV.setAnnotateTool('${j.id}','${ver.id}','highlight')" style="display:flex;align-items:center;gap:3px;font-size:12px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" width="14" height="14"><polygon points="12,2 14,4 8,12 4,12 4,8" fill="rgba(255,214,0,.4)" stroke="#c8a600" stroke-linejoin="round"/><line x1="4" y1="12" x2="4" y2="14"/><line x1="8" y1="12" x2="4" y2="12"/></svg> Highlight</button>
          <select id="rv-ann-colour-${j.id}" class="fi" style="padding:2px 4px;font-size:12px;cursor:pointer;width:auto;color:var(--t0)">
            <option value="#ED7209">Orange</option><option value="#E84545">Red</option>
            <option value="#3B82F6">Blue</option><option value="#16A34A">Green</option><option value="#FFD600">Yellow</option>
          </select>
          <button class="rv-file-tool" onclick="RV.clearAnnotations('${j.id}','${ver.id}')" style="display:flex;align-items:center;gap:2px;font-size:10.5px;color:#E84545"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="12" height="12"><line x1="3" y1="3" x2="13" y2="13"/><line x1="13" y1="3" x2="3" y2="13"/></svg> Clear</button>
          <button class="rv-file-tool" onclick="RV.runJobAIReview('${j.id}')" style="display:flex;align-items:center;gap:2px;font-size:10.5px;border-left:1px solid var(--bd1);padding-left:8px;margin-left:4px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="12" height="12"><circle cx="8" cy="8" r="5.5"/><path d="M6 8.5l1.5 1.5 3-3"/></svg> Brand Check</button>
          <button class="rv-file-tool" onclick="RV.runSpellCheck('${j.id}')" style="display:flex;align-items:center;gap:3px;font-size:12px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="12" height="12"><line x1="3" y1="5" x2="13" y2="5"/><line x1="3" y1="9" x2="10" y2="9"/><line x1="3" y1="13" x2="7" y2="13"/><path d="M10 11l1.5 2 2-2.5" stroke-linecap="round"/></svg> Spell Check</button>
          `:''}
        </div>
        <!-- Actions — right -->
        <div style="display:flex;align-items:center;gap:6px;flex-shrink:0">
          <button class="rv-file-tool" onclick="RV.openCompare('${j.id}')" style="display:flex;align-items:center;gap:4px;font-size:11.5px">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="13" height="13"><line x1="8" y1="2" x2="8" y2="14"/><polyline points="4 6 2 8 4 10"/><polyline points="12 6 14 8 12 10"/></svg>
            Compare
          </button>
          ${file?`<button class="rv-file-tool" onclick="RV.downloadFile('${j.id}','${ver.id}')" style="display:flex;align-items:center;gap:4px;font-size:11.5px">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="13" height="13"><line x1="8" y1="3" x2="8" y2="11"/><polyline points="5 8 8 11 11 8"/><line x1="3" y1="13" x2="13" y2="13"/></svg>
            Download
          </button>`:''}
          ${S.user?.role!=='client'?`<button onclick="RV.deleteVersion('${j.id}','${ver.id}')" style="border:1px solid rgba(232,69,69,.5);color:#E84545;background:none;border-radius:5px;padding:2px 9px;font-size:10.5px;cursor:pointer;font-family:var(--fn);font-weight:500">Delete</button>`:''}
        </div>
      </div>
      <div class="rv-canvas-wrap" id="rv-canvas-${j.id}" onclick="RV.canvasClick(event,'${j.id}','${ver.id}')">
        ${isPdf&&file?.url?pdfViewer
          :file?.url&&isImg?`<div style="position:relative;display:inline-block;max-width:100%">
            <img src="${file.url}" id="rv-img-${j.id}" draggable="false" style="max-width:100%;max-height:580px;display:block;vertical-align:top">
            <svg id="rv-draw-${j.id}" style="position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;overflow:visible"></svg>
            <canvas id="rv-draw-canvas-${j.id}" style="position:absolute;top:0;left:0;width:100%;height:100%;opacity:0.01;pointer-events:none"></canvas>
          </div>`
          :isVid?`<div id="rv-vid-wrap-${j.id}" style="position:relative;background:#000;width:100%">
            <video id="rv-vid-${j.id}" src="${file?.url||''}" style="width:100%;max-height:500px;display:block;background:#000" onloadedmetadata="RV._vidOnLoad('${j.id}','${ver.id}')" ontimeupdate="RV._vidOnTimeUpdate('${j.id}','${ver.id}')"></video>
            <div style="background:#111;padding:6px 10px;display:flex;align-items:center;gap:8px;flex-wrap:wrap">
              <button onclick="RV._vidTogglePlay('${j.id}')" style="background:var(--o);border:none;color:#fff;border-radius:4px;padding:4px 10px;cursor:pointer;font-size:12px;font-family:var(--fn)" id="rv-vid-play-${j.id}">▶ Play</button>
              <span id="rv-vid-time-${j.id}" style="font-size:11px;color:#ccc;min-width:80px;font-family:monospace">0:00 / 0:00</span>
              <input type="range" id="rv-vid-seek-${j.id}" min="0" max="100" value="0" style="flex:1;min-width:80px;cursor:pointer;accent-color:var(--o)" oninput="RV._vidSeek('${j.id}',this.value)" title="Seek">
              
              <button onclick="RV._vidAddTimestampComment('${j.id}','${ver.id}')" style="background:rgba(245,158,11,.15);border:1px solid rgba(245,158,11,.35);color:#F59E0B;border-radius:4px;padding:4px 10px;cursor:pointer;font-size:12px;font-family:var(--fn)">+ Comment at <span id="rv-vid-ctime-${j.id}">0:00</span></button>
              <button onclick="document.getElementById('rv-vid-${j.id}').requestFullscreen?.()" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.2);color:#ccc;border-radius:4px;padding:4px 8px;cursor:pointer;font-size:12px">⛶</button>
            </div>
            <div id="rv-vid-markers-${j.id}" style="background:#1a1a1a;height:16px;position:relative;cursor:pointer" onclick="RV._vidSeekToMarker('${j.id}','${ver.id}',event)" title="Timeline — click to seek"></div>
          </div>`
          :`<div style="text-align:center;padding:48px;color:rgba(255,255,255,.5)">
            <div style="font-size:48px;margin-bottom:12px">${fileIcon}</div>
            <div style="font-size:14px;font-weight:600;color:rgba(255,255,255,.7)">${file?.name||'No files uploaded'}</div>
            <div style="font-size:11.5px;margin-top:6px">${file?.size||''}</div>
            ${file?`<button class="btn btn-g btn-sm" style="margin-top:14px" onclick="RV.downloadFile('${j.id}','${ver.id}')">⬇ Download</button>`:`<div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap"><label class="btn btn-o btn-sm" style="cursor:pointer">⬆ Upload file<input type="file" style="display:none" onchange="RV.uploadVersionFile('${j.id}','${ver.id}',this)"></label><button class="btn btn-r btn-sm" onclick="RV.deleteEmptyVersion('${j.id}','${ver.id}')">Delete empty version</button></div>`}
          </div>`}
        
      </div>
      ${ver.files.length>1?`<div style="padding:10px 14px;border-top:1px solid var(--bd0);display:flex;gap:8px;overflow-x:auto">
        ${ver.files.map((f,i)=>`<button class="rv-file-tool ${i===0?'on':''}" onclick="RV.switchFile('${j.id}','${ver.id}',${i})">${f.name.slice(0,16)}</button>`).join('')}
      </div>`:''}
    </div>`;
  },



  _renderComments(j,ver,pageFilter){
    let all=[...(ver?.comments||[]),...j.comments];
    if(pageFilter!=null) all=all.filter(c=>c.page===pageFilter||(c.pin&&c.page==null&&pageFilter==null));
    const isAdmin=S.user?.role==='admin';
    const currentUser=S.user?.name||'';
    if(!all.length) return'<div style="padding:16px;text-align:center;font-size:12.5px;color:var(--t2)">No comments yet. Add a comment or click the image to annotate.</div>';
    return all.map((c,i)=>`
      <div class="rv-comment ${c.resolved?'resolved':''}" id="rv-c-${c.id}">
        <div class="rv-comment-author">
          <div style="width:18px;height:18px;border-radius:50%;background:${getCompanyBrandColour((DB.getUsers().find(u=>u.name===c.author)||{companies:[]}).companies?.[0]||'')};color:${getContrastText(getCompanyBrandColour((DB.getUsers().find(u=>u.name===c.author)||{companies:[]}).companies?.[0]||''))}};display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:700;color:#fff">${(c.author||'?')[0]}</div>
          ${c.author||'Unknown'}
          ${c.pin?`<span class="kb-pill review" style="font-size:8.5px;cursor:pointer" onclick="RV.highlightPin('${c.id}','${j.id}')">Pin ${i+1}</span>`:''}
          ${c.timestamp!=null?`<span style='font-size:8.5px;padding:2px 6px;border-radius:10px;background:rgba(245,158,11,.15);color:#F59E0B;cursor:pointer' onclick='RV._vidJumpToComment("${j.id}","${c.id}")'>▶ ${RV._vidFmt(c.timestamp)}</span>`:''}${c.pin&&c.page!=null?`<span style='font-size:8.5px;padding:2px 6px;border-radius:8px;background:rgba(99,102,241,.15);color:#6366F1;margin-left:4px;cursor:pointer' onclick="RV._jumpToPdfPage('${j.id}','${c.id}',${c.page})">Page ${c.page}</span>`:''}
        </div>
        <div class="rv-comment-text">${c.text}</div>
        <div class="rv-comment-meta">
          <span>${new Date(c.ts).toLocaleDateString('en-GB',{day:'numeric',month:'short'})}</span>
          ${!c.resolved
            ?`<button style="background:none;border:none;cursor:pointer;font-size:10px;color:var(--g);padding:0" onclick="RV.resolveComment('${j.id}','${c.id}')">
                <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.8" width="10" height="10"><polyline points="2 6 5 9 10 3"/></svg> Resolve
              </button>`
            :`<button style="background:none;border:none;cursor:pointer;font-size:10px;color:#16A34A;padding:0;display:flex;align-items:center;gap:2px" onclick="RV.unresolveComment('${j.id}','${c.id}')">
                <svg viewBox="0 0 12 12" fill="none" stroke="#16A34A" stroke-width="1.8" width="10" height="10"><polyline points="2 6 5 9 10 3"/></svg> Resolved · Reopen
              </button>`}
          <button style="background:none;border:none;cursor:pointer;font-size:10px;color:var(--t2);padding:0" onclick="RV.replyComment('${j.id}','${c.id}')">Reply</button>
          ${isAdmin||c.author===currentUser
            ?`<button style="background:none;border:none;cursor:pointer;font-size:10px;color:#E84545;padding:0;margin-left:auto" onclick="RV.confirmDeleteComment('${j.id}','${c.id}','${ver?.id||''}',event)">
                <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.8" width="10" height="10"><line x1="2" y1="2" x2="10" y2="10"/><line x1="10" y1="2" x2="2" y2="10"/></svg>
              </button>`
            :''}
        </div>
        ${c.replies?.length?c.replies.map(r=>`<div class="rv-reply">
          <div style="display:flex;align-items:center;gap:4px;margin-bottom:2px">
            <strong style="font-size:10px">${r.author}</strong>
            ${isAdmin||r.author===currentUser?`<button style="background:none;border:none;cursor:pointer;color:#E84545;padding:0;margin-left:auto" onclick="RV.confirmDeleteReply('${j.id}','${c.id}','${r.id}','${ver?.id||''}',event)"><svg viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.8" width="8" height="8"><line x1="1" y1="1" x2="9" y2="9"/><line x1="9" y1="1" x2="1" y2="9"/></svg></button>`:''}
          </div>
          <span>${r.text}</span>
        </div>`).join(''):''}
      </div>`).join('');
  },

  confirmDeleteComment(jobId,commentId,versionId,e){
    e?.stopPropagation();
    // Show inline confirm in the comment element
    const el=document.getElementById('rv-c-'+commentId); if(!el) return;
    const existing=el.querySelector('.rv-del-confirm');
    if(existing){ existing.remove(); return; }
    const confirm=document.createElement('div');
    confirm.className='rv-del-confirm';
    confirm.style.cssText='background:rgba(232,69,69,.08);border:1px solid #E84545;border-radius:var(--rs);padding:7px 10px;margin-top:6px;display:flex;align-items:center;gap:8px;font-size:11.5px;';
    const delBtn=document.createElement('button');
    delBtn.className='btn btn-r btn-sm';
    delBtn.textContent='Delete';
    delBtn.onclick=()=>RV.deleteComment(jobId,commentId,versionId);
    const cancelBtn=document.createElement('button');
    cancelBtn.className='btn btn-g btn-sm';
    cancelBtn.textContent='Cancel';
    cancelBtn.onclick=()=>confirm.remove();
    confirm.innerHTML='<span style="color:#E84545;flex:1">Delete this comment?</span>';
    confirm.appendChild(delBtn);
    confirm.appendChild(cancelBtn);
    el.appendChild(confirm);
  },

  deleteComment(jobId,commentId,versionId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    // Remove from version comments (including any associated highlight shapes)
    for(const ver of j.versions){
      ver.comments=ver.comments.filter(c=>c.id!==commentId);
      // Also remove linked shape (highlight shape linked by commentId)
      if(ver.shapes) ver.shapes=ver.shapes.filter(s=>s.commentId!==commentId);
    }
    // Remove from job-level comments
    j.comments=j.comments.filter(c=>c.id!==commentId);
    RV_DB.logActivity(jobId,S.user?.name||'Admin','Deleted a comment','🗑️');
    const effectiveVerId=versionId||j.versions[j.versions.length-1]?.id;
    const ver=j.versions.find(v=>v.id===effectiveVerId)||null;
    // Redraw shapes (removes orphaned highlight) then redraw pins
    this._renderShapes(jobId,effectiveVerId);
    this._addPinMarker(jobId,effectiveVerId);
    // Refresh comment panel with filter preservation
    this._updateCommentsPanel(jobId,effectiveVerId);
  },

  confirmDeleteReply(jobId,commentId,replyId,versionId,e){
    e?.stopPropagation();
    const j=RV_DB.getJob(jobId); if(!j) return;
    for(const ver of j.versions) for(const c of ver.comments) if(c.id===commentId){ c.replies=(c.replies||[]).filter(r=>r.id!==replyId); }
    for(const c of j.comments) if(c.id===commentId){ c.replies=(c.replies||[]).filter(r=>r.id!==replyId); }
    this._updateCommentsPanel(jobId,versionId);
  },

  _triggerNotif(jobId,type,message){
    const j=RV_DB.getJob(jobId); if(!j) return;
    // Notify assignees
    if(j.assignedTo) j.assignedTo.split(',').map(s=>s.trim()).filter(Boolean).forEach(name=>{
      if(name&&name!==S.user?.name) RV_DB.addNotification(type,jobId,message,name);
    });
  },

  addComment(jobId){
    const input=document.getElementById('rv-cmt-input-'+jobId);
    const text=input?.value?.trim(); if(!text) return;
    const j=RV_DB.getJob(jobId); if(!j) return;
    const ver=j.versions[j.versions.length-1];
    RV_DB.addComment(jobId, ver?.id||null, {text});  // no x/y — not a pin
    RV_DB.logActivity(jobId, S.user?.name||'User', 'Comment added', '', {
      type:'comment', detail:'Commented: "'+text.slice(0,60)+(text.length>60?'…':'')+'"'
    });
    input.value='';
    this.openJob(jobId);
  },

  resolveComment(jobId, commentId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    const allComments=[...j.comments,...j.versions.flatMap(v=>v.comments)];
    const c=allComments.find(x=>x.id===commentId); if(c) c.resolved=true;
    RV_DB.logActivity(jobId,S.user?.name||'Admin','Resolved a comment','✓');
    const ver=j.versions[j.versions.length-1];
    this._updateCommentsPanel(jobId,ver?.id);
    this._addPinMarker(jobId,ver?.id);
  },

  unresolveComment(jobId,commentId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    const allComments=[...j.comments,...j.versions.flatMap(v=>v.comments)];
    const c=allComments.find(x=>x.id===commentId); if(c) c.resolved=false;
    RV_DB.logActivity(jobId,S.user?.name||'Admin','Reopened a comment','↩');
    this._updateCommentsPanel(jobId, j.versions[j.versions.length-1]?.id);
  },

  replyComment(jobId,commentId){
    // Open in-app reply modal instead of browser prompt
    document.getElementById('rv-reply-job-id').value=jobId;
    document.getElementById('rv-reply-comment-id').value=commentId;
    document.getElementById('rv-reply-text').value='';
    document.getElementById('rv-reply-author').textContent=S.user?.name||'User';
    MODAL.open('modal-rv-reply');
    setTimeout(()=>document.getElementById('rv-reply-text')?.focus(),80);
  },

  submitReply(){
    const jobId=document.getElementById('rv-reply-job-id').value;
    const commentId=document.getElementById('rv-reply-comment-id').value;
    const text=document.getElementById('rv-reply-text').value.trim();
    if(!text) return;
    const j=RV_DB.getJob(jobId); if(!j) return;
    const allComments=[...j.comments,...j.versions.flatMap(v=>v.comments)];
    const c=allComments.find(x=>x.id===commentId); if(!c) return;
    if(!c.replies) c.replies=[];
    c.replies.push({id:'r-'+Date.now(),author:S.user?.name||'User',text,ts:new Date().toISOString()});
    RV_DB.logActivity(jobId,S.user?.name||'User','Replied to a comment','');
    MODAL.close('modal-rv-reply');
    this.openJob(jobId);
  },

  // Quick drop: create a version directly from dragged files without opening modal
  _quickDrop(files,jobId){
    if(!files?.length){ this.uploadModal(jobId); return; }
    const fileArr=[...files];
    const label='V'+((RV_DB.getJob(jobId)?.versions.length||0)+1);
    const promises=fileArr.map(f=>new Promise(res=>{
      if(/\.(jpg|jpeg|png|svg|gif)$/i.test(f.name)){
        const r=new FileReader(); r.onload=e=>res({name:f.name,type:'image',url:e.target.result,size:(f.size/1024/1024).toFixed(1)+'MB'}); r.readAsDataURL(f);
      } else if(/\.pdf$/i.test(f.name)){
        const r=new FileReader(); r.onload=e=>res({name:f.name,type:'pdf',url:e.target.result,size:(f.size/1024/1024).toFixed(1)+'MB'}); r.readAsDataURL(f);
      } else if(/\.(mp4|mov|webm)$/i.test(f.name)){
        const r=new FileReader(); r.onload=e=>res({name:f.name,type:'video',url:e.target.result,size:(f.size/1024/1024).toFixed(1)+'MB'}); r.readAsDataURL(f);
      } else {
        res({name:f.name,type:'doc',url:'',size:(f.size/1024/1024).toFixed(1)+'MB'});
      }
    }));
    Promise.all(promises).then(resolved=>{
      RV_DB.addVersion(jobId,{label,notes:'',files:resolved.filter(Boolean)});
      this.openJob(jobId);
      this.buildKanban();
      this._updateBadge();
    });
  },

  _activeTool:null, _drawing:false, _drawStart:{x:0,y:0}, _drawPath:[],

  setAnnotateTool(jobId,versionId,tool){
    // Detect if we're in compare mode and which side this version is on
    const cmpSideSel=document.getElementById('rv-cmp-side-'+jobId);
    const cmpSide=cmpSideSel?cmpSideSel.value:null; // 'a', 'b', or null (not in compare)
    const side=cmpSide==='b'?'b':null;
    // In compare mode, always use the version matching the selected side
    const cmpSelA=document.getElementById('rv-cmp-a');
    const cmpSelB=document.getElementById('rv-cmp-b');
    const cmpJ=RV_DB.getJob(jobId);
    let resolvedVid=versionId;
    if(cmpSelA&&cmpSelB&&cmpJ){
      const iA=parseInt(cmpSelA.value||'0');
      const iB=parseInt(cmpSelB.value||'1');
      resolvedVid=side==='b'?(cmpJ.versions[iB]?.id||versionId):(cmpJ.versions[iA]?.id||versionId);
    }
    this._annotateMode=this._annotateMode?.tool===tool&&this._annotateMode?.side===side?null:{jobId,versionId:resolvedVid,tool,side};
    this._activeTool=this._annotateMode?tool:null;
    // Enable SVG pointer-events on the correct side
    const _sfxT=side?'-'+side:'';
    const _svgOv=document.getElementById('rv-draw-'+jobId+_sfxT)||document.getElementById('rv-draw-'+jobId);
    if(_svgOv) _svgOv.style.pointerEvents=this._annotateMode?'all':'none';
    // Update toolbar button states
    document.querySelectorAll('.rv-ann-btn').forEach(b=>{
      b.classList.toggle('active', b.dataset.tool===tool&&!!this._annotateMode);
    });
    const wrap=document.getElementById('rv-canvas-'+jobId+_sfxT)||document.getElementById('rv-canvas-'+jobId);
    if(wrap) wrap.style.cursor=this._annotateMode?'crosshair':'default';
    if(this._annotateMode){
      this._setupDrawing(jobId,resolvedVid,side);
    } else {
      this._teardownDrawing(jobId);
    }
  },

  _setupDrawing(jobId,versionId,side){
    // SVG suffix: 'b'→'-b', 'a'→'-cmp-a' (compare left), else ''
    const _sfx=side==='b'?'-b':side==='a'?'-cmp-a':'';
    // For PDF: target only the canvas container, not the outer viewer div (which has controls)
    const wrap=document.getElementById('rv-pdf-canvas-wrap-'+jobId+'-cmp-'+side)||document.getElementById('rv-canvas-'+jobId+_sfx)||document.getElementById('rv-pdf-canvas-wrap-'+jobId)||document.getElementById('rv-canvas-'+jobId); if(!wrap) return;
    wrap.onpointerdown=null; wrap.onpointermove=null; wrap.onpointerup=null; wrap.onclick=null;
    wrap.style.userSelect='none'; wrap.style.position='relative';
    wrap.querySelectorAll('img').forEach(img=>{img.draggable=false;img.ondragstart=(e)=>e.preventDefault();});
    const drawSvg=document.getElementById('rv-draw-'+jobId+_sfx); if(drawSvg) drawSvg.style.pointerEvents='none'; // only active when tool selected
    const getPos=(e)=>{
      const _svgRef=wrap.querySelector('svg')||wrap.querySelector('img')||wrap.querySelector('canvas')||wrap;
      const rect=_svgRef.getBoundingClientRect();
      const x=Math.max(0,Math.min(100,(e.clientX-rect.left)/rect.width*100));
      const y=Math.max(0,Math.min(100,(e.clientY-rect.top)/rect.height*100));
      return{x:x.toFixed(2),y:y.toFixed(2)};
    };
    const tool=this._annoteTool=this._annotateMode?.tool||'pin';
    const colour=document.getElementById('rv-ann-colour-'+jobId)?.value||'#ED7209';
    // Sync compare side dropdown so toolbar reads correct side on next button click
    const _cmpSDE=document.getElementById('rv-cmp-side-'+jobId);
    if(_cmpSDE) _cmpSDE.value=side||'a';

    if(tool==='pin'){
      wrap.onclick=(e)=>{
        if(!this._annotateMode||this._pinCooldown) return;
        if(document.getElementById('rv-pin-input-popup')) return;
        // Guard: must be inside the wrap itself (canvas or SVG only), not toolbar buttons
        if(e.target.closest('.pdf-toolbar')) return;
        if(e.target.closest('button')) return;  // never trigger on any button click
        // For PDF compare: ensure click is within the canvas wrap (canvas or SVG)
        if(!wrap.contains(e.target)&&e.target!==wrap) return;
        const pos=getPos(e);
        this._pendingPin={x:+pos.x,y:+pos.y,jobId,versionId,side:side||null};
        console.log('[PIN] showing popup at x='+pos.x+' y='+pos.y+' page='+(RV._pdfState[jobId+'-cmp-'+(side||'')]?.pageNum||RV._pdfState[jobId]?.pageNum||null));
        wrap.onclick=null; // prevent re-trigger while popup open
        this._showPinInput(+pos.x,+pos.y,wrap);
      };
    } else if(tool==='pen'){
      wrap.onmousedown=(e)=>{ this._drawing=true; this._drawPath=[getPos(e)]; };
      wrap.onmousemove=(e)=>{
        if(!this._drawing) return;
        this._drawPath.push(getPos(e));
        this._previewPath(jobId,this._drawPath,colour);
      };
      wrap.onmouseup=(e)=>{
        if(!this._drawing) return; this._drawing=false;
        if(this._drawPath.length>2){
          const ver=RV_DB.getJob(jobId)?.versions.find(v=>v.id===versionId);
          if(ver){ if(!ver.shapes) ver.shapes=[];
            ver.shapes.push({type:'pen',path:this._drawPath,colour,ts:new Date().toISOString()});
          }
          this._renderShapes(jobId,versionId,side);
        }
      };
    } else if(tool==='rect'||tool==='circle'||tool==='arrow'||tool==='highlight'){
      wrap.onpointerdown=(e)=>{ if(e.button!==0) return; if(e.target.closest('.pdf-toolbar')) return; this._drawing=true; this._drawStart=getPos(e); wrap.setPointerCapture(e.pointerId); };
      wrap.onpointermove=(e)=>{
        if(!this._drawing) return;
        this._previewShape(jobId,tool,this._drawStart,getPos(e),colour,side);
      };
      wrap.onpointerup=(e)=>{
        if(!this._drawing) return; this._drawing=false; wrap.releasePointerCapture(e.pointerId);
        const end=getPos(e);
        // Ignore tiny accidental clicks (no meaningful drag)
        const dist=Math.hypot(parseFloat(end.x)-parseFloat(this._drawStart.x),parseFloat(end.y)-parseFloat(this._drawStart.y));
        if(dist<2) return;
        const ver=RV_DB.getJob(jobId)?.versions.find(v=>v.id===versionId);
        if(ver){ if(!ver.shapes) ver.shapes=[];
          const _sdPdfKey=(side==='a'||side==='b')?jobId+'-cmp-'+side:jobId;
          const _shapePage=RV._pdfState?.[_sdPdfKey]?.pageNum??null;
          const shape={type:tool,x1:+this._drawStart.x,y1:+this._drawStart.y,x2:+end.x,y2:+end.y,colour,ts:new Date().toISOString(),page:_shapePage};
        ver.shapes.push(shape);
        // Remove the live preview element immediately — _renderShapes will draw the permanent version
        drawSvg.querySelectorAll('.rv-ann-preview').forEach(el=>el.remove());
        if(tool==='highlight'){
          const cx=(+this._drawStart.x + +end.x)/2;
          const cy=(+this._drawStart.y + +end.y)/2;
          const _hIdx=(ver.shapes||[]).length-1;
          this._pendingPin={x:cx,y:cy,jobId,versionId,side:side||null,_hIdx};
          this._renderShapes(jobId,versionId,side);
          // Disable wrap handlers while popup is open — prevents re-triggering
          wrap.onpointerdown=null; wrap.onpointermove=null; wrap.onpointerup=null;
          this._showPinInput(cx,cy,wrap);
          return;
        }
        }
        this._renderShapes(jobId,versionId,side);
        this._addPinMarker(jobId,versionId,side);
        const _fSvg=document.getElementById('rv-draw-'+jobId+(side?'-'+side:''));
        const _sCvsId=(side==='a'||side==='b')?'rv-pdf-canvas-'+jobId+'-cmp-'+side:'rv-pdf-canvas-'+jobId;
        const _fCvs=document.getElementById(_sCvsId)||document.getElementById('rv-pdf-canvas-'+jobId);
        if(_fSvg&&_fCvs&&_fCvs.width){ _fSvg.setAttribute('width',_fCvs.width); _fSvg.setAttribute('height',_fCvs.height); _fSvg.style.width=_fCvs.width+'px'; _fSvg.style.height=_fCvs.height+'px'; }
        RV._updateCommentsPanel(jobId,versionId);
      };
    }
  },

  _teardownDrawing(jobId,side){
    const _sfxTD=side==='b'?'-b':side==='a'?'-cmp-a':'';
    const wrap=document.getElementById('rv-canvas-'+jobId+_sfxTD)||document.getElementById('rv-canvas-'+jobId); if(!wrap) return;
    wrap.onclick=null; wrap.onmousedown=null; wrap.onmousemove=null; wrap.onmouseup=null;
    wrap.style.cursor='default'; wrap.style.userSelect='';
    // Clear preview SVG
    const svg=document.getElementById('rv-draw-'+jobId+(_sfxTD||''));
    if(svg){ svg.style.pointerEvents='none'; svg.querySelectorAll('.rv-ann-preview').forEach(el=>el.remove()); }
  },

  _previewPath(jobId,path,colour){
    const svg=document.getElementById('rv-draw-'+jobId); if(!svg||path.length<2) return;
    svg.querySelectorAll('.rv-ann-preview').forEach(el=>el.remove());
    const d='M'+path.map(p=>p.x+'% '+p.y+'%').join(' L');
    const el=document.createElementNS('http://www.w3.org/2000/svg','path');
    el.setAttribute('d',d); el.setAttribute('stroke',colour); el.setAttribute('stroke-width','2px');
    el.setAttribute('fill','none'); el.setAttribute('class','rv-ann-preview');
    el.setAttribute('stroke-linecap','round'); el.setAttribute('stroke-linejoin','round');
    el.setAttribute('vector-effect','non-scaling-stroke');
    svg.appendChild(el);
  },

  _previewShape(jobId,type,start,end,colour,side){
    const _sfxA=side==='b'?'-b':side==='a'?'-cmp-a':'';
    const svg=document.getElementById('rv-draw-'+jobId+_sfxA)||document.getElementById('rv-draw-'+jobId); if(!svg) return;
    svg.querySelectorAll('.rv-ann-preview').forEach(el=>el.remove());
    const W=+svg.getAttribute('width')||svg.clientWidth||500;
    const H=+svg.getAttribute('height')||svg.clientHeight||500;
    const x1=+start.x/100*W, y1=+start.y/100*H;
    const x2=+end.x/100*W,   y2=+end.y/100*H;
    if(type==='arrow'){
      const el=document.createElementNS('http://www.w3.org/2000/svg','line');
      el.setAttribute('class','rv-ann-preview');
      el.setAttribute('x1',x1); el.setAttribute('y1',y1);
      el.setAttribute('x2',x2); el.setAttribute('y2',y2);
      el.setAttribute('stroke',colour); el.setAttribute('stroke-width','2.5');
      el.setAttribute('stroke-dasharray','5,3');
      el.setAttribute('vector-effect','non-scaling-stroke');
      svg.appendChild(el);
      return;
    }
    const el=document.createElementNS('http://www.w3.org/2000/svg',type==='circle'?'ellipse':'rect');
    el.setAttribute('class','rv-ann-preview'); el.setAttribute('stroke',colour);
    el.setAttribute('stroke-width','2'); el.setAttribute('fill',type==='highlight'?colour+'33':'none');
    el.setAttribute('vector-effect','non-scaling-stroke');
    if(type==='circle'){
      el.setAttribute('cx',(x1+x2)/2); el.setAttribute('cy',(y1+y2)/2);
      el.setAttribute('rx',Math.abs(x2-x1)/2); el.setAttribute('ry',Math.abs(y2-y1)/2);
    } else {
      el.setAttribute('x',Math.min(x1,x2)); el.setAttribute('y',Math.min(y1,y2));
      el.setAttribute('width',Math.abs(x2-x1)); el.setAttribute('height',Math.abs(y2-y1));
    }
    svg.appendChild(el)
  },

  _renderShapes(jobId,versionId,side){
    const _cmpSideR=jobId.match(/-cmp-([ab])$/)?.[1];
    const _realJidR=jobId.replace(/-cmp-[ab]$/,'');
    const _sfxR=side==='b'||_cmpSideR==='b'?'-b':side==='a'||_cmpSideR==='a'?'-cmp-a':'';
    const _svgJobR=_cmpSideR?_realJidR:jobId;  // use stripped jobId for SVG lookup when compound
    const svg=document.getElementById('rv-draw-'+_svgJobR+_sfxR)||document.getElementById('rv-draw-'+_svgJobR); if(!svg) return;
    // Sync SVG size to PDF canvas if applicable
    const _rsCvsId=(side==='a'||side==='b')?'rv-pdf-canvas-'+jobId+'-cmp-'+side:'rv-pdf-canvas-'+jobId;
    const _rsCvs=document.getElementById(_rsCvsId)||document.getElementById('rv-pdf-canvas-'+jobId);
    if(_rsCvs&&_rsCvs.width){ svg.setAttribute('width',_rsCvs.width); svg.setAttribute('height',_rsCvs.height); svg.style.width=_rsCvs.width+'px'; svg.style.height=_rsCvs.height+'px'; }
    // Clear non-preview/defs before redraw
        [...svg.children].forEach(el=>{
      if(!el.classList.contains('rv-pin-marker')) el.remove();
    });
    const ver=RV_DB.getJob(jobId.replace(/-cmp-[ab]$/,''))?.versions.find(v=>v.id===versionId);
    // pdfState key: 'a' or 'b' → compound key, null/undefined → plain jobId
    // pdfState key: use compound jobId if already compound, else build from side
    const _rsPgKey=jobId.includes('-cmp-')?jobId:(side==='a'||side==='b')?jobId+'-cmp-'+side:jobId;
    const _rsPg=RV._pdfState?.[_rsPgKey]?.pageNum??null;
    console.log('[RS] jobId='+jobId+' side='+side+' key='+_rsPgKey+' page='+_rsPg+' totalShapes='+(ver?.shapes||[]).length);
    const shapes=(ver?.shapes||[]).filter(s=>_rsPg===null ? s.page==null : s.page===_rsPg);
    const _rsW=+svg.getAttribute('width')||svg.clientWidth||500;
    const _rsH=+svg.getAttribute('height')||svg.clientHeight||500;
    const _pct=(v,dim)=>+v/100*dim;  // convert % coord to px
    shapes.forEach(s=>{
      if(s.type==='pen'&&s.path?.length>1){
        const el=document.createElementNS('http://www.w3.org/2000/svg','path');
        el.setAttribute('d','M'+s.path.map(p=>p.x+'% '+p.y+'%').join(' L'));
        el.setAttribute('stroke',s.colour||'#ED7209'); el.setAttribute('stroke-width','2px');
        el.setAttribute('fill','none'); el.setAttribute('vector-effect','non-scaling-stroke');
        el.setAttribute('stroke-linecap','round'); svg.appendChild(el);
      } else if(s.type==='rect'||s.type==='highlight'){
        const el=document.createElementNS('http://www.w3.org/2000/svg','rect');
        el.setAttribute('x',Math.min(s.x1,s.x2)+'%'); el.setAttribute('y',Math.min(s.y1,s.y2)+'%');
        el.setAttribute('width',Math.abs(s.x2-s.x1)+'%'); el.setAttribute('height',Math.abs(s.y2-s.y1)+'%');
        el.setAttribute('stroke',s.colour||'#ED7209'); el.setAttribute('stroke-width','2px');
        el.setAttribute('fill',s.type==='highlight'?(s.colour||'#FFD600')+'33':'none');
        el.setAttribute('vector-effect','non-scaling-stroke'); svg.appendChild(el);
      } else if(s.type==='circle'){
        const el=document.createElementNS('http://www.w3.org/2000/svg','ellipse');
        el.setAttribute('cx',(_pct(s.x1,_rsW)+_pct(s.x2,_rsW))/2); el.setAttribute('cy',(_pct(s.y1,_rsH)+_pct(s.y2,_rsH))/2);
        el.setAttribute('rx',Math.abs(_pct(s.x2,_rsW)-_pct(s.x1,_rsW))/2); el.setAttribute('ry',Math.abs(_pct(s.y2,_rsH)-_pct(s.y1,_rsH))/2);
        el.setAttribute('stroke',s.colour||'#ED7209'); el.setAttribute('stroke-width','2px');
        el.setAttribute('fill','none'); el.setAttribute('vector-effect','non-scaling-stroke'); svg.appendChild(el);
      } else if(s.type==='arrow'){
        const col=s.colour||'#ED7209';
        const ahId='ah'+jobId.replace(/[^a-z0-9]/gi,'');
        if(!svg.querySelector('#'+ahId)){
          let defs=svg.querySelector('defs'); if(!defs){defs=document.createElementNS('http://www.w3.org/2000/svg','defs');svg.insertBefore(defs,svg.firstChild);}
          const mk=document.createElementNS('http://www.w3.org/2000/svg','marker');
          mk.setAttribute('id',ahId); mk.setAttribute('markerWidth','8'); mk.setAttribute('markerHeight','8');
          mk.setAttribute('refX','7'); mk.setAttribute('refY','3'); mk.setAttribute('orient','auto');
          const pth=document.createElementNS('http://www.w3.org/2000/svg','path');
          pth.setAttribute('d','M0,0 L0,6 L8,3 z'); pth.setAttribute('fill',col);
          mk.appendChild(pth); defs.appendChild(mk);
        }
        const el=document.createElementNS('http://www.w3.org/2000/svg','line');
        el.setAttribute('x1',_pct(s.x1,_rsW)); el.setAttribute('y1',_pct(s.y1,_rsH));
        el.setAttribute('x2',_pct(s.x2,_rsW)); el.setAttribute('y2',_pct(s.y2,_rsH));
        el.setAttribute('stroke',col); el.setAttribute('stroke-width','2.5px');
        el.setAttribute('marker-end','url(#'+ahId+')'); el.setAttribute('vector-effect','non-scaling-stroke');
        svg.appendChild(el);
      }
    });
    // NOTE: _addPinMarker is called separately — do NOT call here to avoid duplication
    // Pins are drawn from version.comments (not shapes), _renderShapes handles shapes only
  },

  _showPinInput(x,y,wrap){
    const existing=document.getElementById('rv-pin-input-popup');
    if(existing) existing.remove();
    const popup=document.createElement('div');
    popup.id='rv-pin-input-popup';
    // Clamp position: default above pin, flip below if near top
    const topPct=parseFloat(y);
    const transform=topPct<20?'translate(-50%,12px)':'translate(-50%,-110%)';
    // Clamp left to avoid clipping at edges
    const leftPct=Math.max(15,Math.min(85,parseFloat(x)));
    popup.style.cssText='position:absolute;left:'+leftPct+'%;top:'+y+'%;transform:'+transform+';background:var(--bg1);border:1px solid var(--o);border-radius:var(--rs);padding:10px;z-index:500;min-width:220px;box-shadow:0 4px 20px rgba(0,0,0,.5)';
    // Stop clicks inside popup from propagating to wrap (prevents re-trigger)
    popup.addEventListener('mousedown', e=>e.stopPropagation());
    popup.addEventListener('click', e=>e.stopPropagation());
    popup.innerHTML='<div style="font-size:11px;font-weight:700;color:var(--o);margin-bottom:6px">Add comment</div>'
      +'<textarea id="rv-pin-text" rows="2" class="fi" placeholder="What needs to change here?" style="font-size:12px;resize:none;margin-bottom:6px"></textarea>'
      +'<div style="display:flex;gap:6px">'
      +'<button class="btn btn-o btn-sm" style="flex:1" id="rv-pin-add-btn">Add</button>'
      +'<button class="btn btn-g btn-sm" id="rv-pin-cancel-btn">Cancel</button>'
      +'</div>';
    wrap.style.position='relative';
    wrap.appendChild(popup);
    // Wire buttons via addEventListener (not onclick) to avoid re-triggering
    popup.querySelector('#rv-pin-add-btn').addEventListener('click', (e)=>{ e.stopPropagation(); RV._confirmPin(); });
    popup.querySelector('#rv-pin-cancel-btn').addEventListener('click', (e)=>{ e.stopPropagation(); RV._cancelPin(); });
    setTimeout(()=>document.getElementById('rv-pin-text')?.focus(), 30);
    // Clamp to viewport after render
    requestAnimationFrame(()=>{
      const wRect=wrap.getBoundingClientRect();
      const pRect=popup.getBoundingClientRect();
      if(pRect.right>wRect.right-4) popup.style.left=Math.max(10,leftPct-15)+'%';
      if(pRect.left<wRect.left+4) popup.style.left=Math.min(90,leftPct+15)+'%';
    });
  },

  _cancelPin(){
    document.getElementById('rv-pin-input-popup')?.remove();
    // Clean up any live preview shapes
    const _ppJob=this._pendingPin?.jobId;
    if(_ppJob){ const _ppSvg=document.getElementById('rv-draw-'+_ppJob); if(_ppSvg) _ppSvg.querySelectorAll('.rv-ann-preview').forEach(el=>el.remove()); }
    const _pp=this._pendingPin;
    if(_pp){
      // Remove temp highlight shape if this was a highlight annotation
      if(_pp._hIdx!=null){
        const _vr=RV_DB.getJob(_pp.jobId)?.versions.find(v=>v.id===_pp.versionId);
        if(_vr?.shapes) _vr.shapes.splice(_pp._hIdx,1);
        this._renderShapes(_pp.jobId,_pp.versionId,_pp.side||null);
      }
      this._pendingPin=null;
      // Restore drawing tool (don't teardown — allow more annotations)
      if(this._annotateMode){
        this._setupDrawing(_pp.jobId,_pp.versionId,_pp.side||null);
      }
    }
    // Only clear annotateMode if no tool was active (i.e. this was a one-off cancel)
    // Keep annotateMode so user can keep adding pins after cancel
    document.querySelectorAll('.rv-ann-btn').forEach(b=>{
      if(this._annotateMode&&b.dataset.tool===this._annotateMode.tool) b.classList.add('active');
      else b.classList.remove('active');
    });
  },
  _confirmPin(){
    console.log('[PIN] _confirmPin fired pendingPin='+JSON.stringify(this._pendingPin));
    const text=document.getElementById('rv-pin-text')?.value?.trim();
    document.getElementById('rv-pin-input-popup')?.remove();
    const p=this._pendingPin; if(!p||!text) return;
    const _cpPdfKey=(p.side==='a'||p.side==='b')?p.jobId+'-cmp-'+p.side:p.jobId;
    const _pg=RV._pdfState[_cpPdfKey]?.pageNum??null;
    console.log('[SAVE] jobId='+p.jobId+' side='+p.side+' key='+_cpPdfKey+' page='+_pg+' x='+p.x?.toFixed(1)+' y='+p.y?.toFixed(1));
    RV_DB.addComment(p.jobId,p.versionId,{text,x:p.x,y:p.y,pin:true,page:_pg});
    this._pendingPin=null;
    this._pinCooldown=true; // prevent immediate re-trigger
    // Render shapes first (so highlight box is visible), then add pin markers on top
    this._renderShapes(p.jobId,p.versionId,p.side||null);
    this._addPinMarker(p.jobId,p.versionId,p.side||null);
    // Also sync SVG dimensions for PDF
    const _cpSfx=p.side==='b'?'-b':'';
    const _cpSvg=document.getElementById('rv-draw-'+p.jobId+_cpSfx);
    const _cpCvsId=(p.side==='a'||p.side==='b')?'rv-pdf-canvas-'+p.jobId+'-cmp-'+p.side:'rv-pdf-canvas-'+p.jobId;
    const _cpCanvas=document.getElementById(_cpCvsId)||document.getElementById('rv-pdf-canvas-'+p.jobId);
    if(_cpSvg&&_cpCanvas&&_cpCanvas.width){ _cpSvg.setAttribute('width',_cpCanvas.width); _cpSvg.setAttribute('height',_cpCanvas.height); _cpSvg.style.width=_cpCanvas.width+'px'; _cpSvg.style.height=_cpCanvas.height+'px'; }
    // Live-update comments — use compare panel if in compare mode, otherwise main panel
    const _cmpOv=document.getElementById('rv-compare-overlay');
    if(_cmpOv){
      const _side=p.side||'a';
      const _j=RV_DB.getJob(p.jobId);
      const _selA=document.getElementById('rv-cmp-a');
      const _selB=document.getElementById('rv-cmp-b');
      const _iA=parseInt(_selA?.value||'0');
      const _iB=parseInt(_selB?.value||'1');
      this._cmpRefreshComments(p.jobId,p.versionId,_side,_j,_iA,_iB);
    } else {
      this._updateCommentsPanel(p.jobId,p.versionId);
    }
    if(this._annotateMode) this._setupDrawing(p.jobId,p.versionId,p.side||null);
    setTimeout(()=>{ this._pinCooldown=false; },400);
  },

  _cmtPageFilter:{},
  _setCmtPageFilter(jobId,versionId,page){
    if(page===null) delete this._cmtPageFilter[jobId];
    else this._cmtPageFilter[jobId]=page;
    this._updateCommentsPanel(jobId,versionId);
  },

  _updateCommentsPanel(jobId,versionId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    const ver=j.versions.find(v=>v.id===versionId)||null;
    const el=document.getElementById('rv-comments-'+jobId);
    if(!el) return;
    const _pgFilter=RV._pdfState?.[jobId]?.pageNum??null;
    const _allC=[...(ver?.comments||[]),...(j.comments||[])];
    const _cntEl=document.getElementById('rv-cmt-count-'+jobId);
    if(_cntEl) _cntEl.textContent=_allC.length;
    // Build page filter bar for PDFs
    let _filterBar='';
    if(_pgFilter!==null){
      const _pages=[...new Set(_allC.filter(c=>c.page!=null).map(c=>c.page))].sort((a,b)=>a-b);
      if(_pages.length>0){
        const _curF=RV._cmtPageFilter?.[jobId];
        const _opts='<option value="">All pages</option>'+_pages.map(pg=>'<option value="'+pg+'"'+(pg===_curF?' selected':'')+'>Page '+pg+'</option>').join('');
        _filterBar='<div style="display:flex;align-items:center;gap:6px;margin-bottom:8px"><span style="font-size:10.5px;color:var(--t2);font-weight:600">Page:</span><select onchange="RV._setCmtPageFilter(\''+jobId+'\',\''+versionId+'\',this.value===\'\'?null:+this.value)" class="fi" style="font-size:11px;padding:2px 6px;width:auto">'+_opts+'</select></div>';
      }
    }
    el.innerHTML=_filterBar+this._renderComments(j,ver,RV._cmtPageFilter?.[jobId]);

  },


  _addPinMarker(jobId,versionId,side){
    const _cmpSideP=jobId.match(/-cmp-([ab])$/)?.[1];
    const _realJidP=jobId.replace(/-cmp-[ab]$/,'');
    const _sfxP=side==='b'||_cmpSideP==='b'?'-b':side==='a'||_cmpSideP==='a'?'-cmp-a':'';
    const _svgJobP=_cmpSideP?_realJidP:jobId;
    const svg=document.getElementById('rv-draw-'+_svgJobP+_sfxP)||document.getElementById('rv-draw-'+_svgJobP); if(!svg) return;
    const _realJobId=jobId.replace(/-cmp-[ab]$/,'');
    const j=RV_DB.getJob(_realJobId); if(!j) return;
    const ver=versionId?j.versions.find(v=>v.id===versionId):j.versions[j.versions.length-1];
    // Remove ALL existing pin markers first (prevents duplication)
    // Remove all existing pin markers to prevent duplication
    // Sync SVG dimensions to PDF canvas
    const _apmCvsId=(side==='a'||side==='b')?'rv-pdf-canvas-'+jobId+'-cmp-'+side:'rv-pdf-canvas-'+jobId;
    const _apmCvs=document.getElementById(_apmCvsId)||document.getElementById('rv-pdf-canvas-'+jobId);
    if(_apmCvs&&_apmCvs.width){ svg.setAttribute('width',_apmCvs.width); svg.setAttribute('height',_apmCvs.height); svg.style.width=_apmCvs.width+'px'; svg.style.height=_apmCvs.height+'px'; }
    console.log('[APM-SYNC] svgId=rv-draw-'+_svgJobP+''+_sfxP+' svgW='+svg.getAttribute('width')+' svgH='+svg.getAttribute('height')+' canvasId='+_apmCvsId+' canvasFound='+!!_apmCvs+' canvasW='+((_apmCvs&&_apmCvs.width)||0));
    // Remove only pin marker groups — preserve shapes drawn by _renderShapes
    svg.querySelectorAll('.rv-pin-marker').forEach(el=>el.remove());
    const _pgKey=jobId.includes('-cmp-')?jobId:(side==='a'||side==='b')?jobId+'-cmp-'+side:jobId;
    const _pgF=RV._pdfState?.[_pgKey]?.pageNum??null;
    console.log('[APM] jobId='+jobId+' side='+side+' key='+_pgKey+' pgF='+_pgF+' allPins='+((ver?.comments||[]).filter(c=>c.pin).length));
    (ver?.comments||[]).filter(c=>c.pin).forEach(c=>console.log('[APM]  pin p:'+c.page+' vis:'+((_pgF===null?c.page==null:c.page===_pgF)?'Y':'N')+' x:'+c.x?.toFixed(1)+' y:'+c.y?.toFixed(1)));
    const comments=(ver?.comments||[]).filter(c=>
      c.pin && typeof c.x==='number' && typeof c.y==='number' &&
      (_pgF===null ? c.page==null : c.page===_pgF)
    );
    console.log('[APM-DRAW] '+comments.length+' pins to draw in svg id=rv-draw-'+_svgJobP+_sfxP+' svgInDom='+!!document.getElementById('rv-draw-'+_svgJobP+_sfxP));
    comments.forEach((c,i)=>{
      const g=document.createElementNS('http://www.w3.org/2000/svg','g');
      g.setAttribute('class','rv-pin-marker');
      g.setAttribute('data-cid',c.id);
      g.setAttribute('style','cursor:pointer');
      const circle=document.createElementNS('http://www.w3.org/2000/svg','circle');
      const _svgW=+svg.getAttribute('width')||svg.clientWidth||500;
      const _svgH=+svg.getAttribute('height')||svg.clientHeight||500;
      const _cx=c.x/100*_svgW; const _cy=c.y/100*_svgH;
      circle.setAttribute('cx',_cx); circle.setAttribute('cy',_cy);
      console.log('[APM-PIN] cx='+_cx.toFixed(1)+'px cy='+_cy.toFixed(1)+'px ('+c.x+'% '+c.y+'%) svgW='+_svgW+' svgH='+_svgH);
      circle.setAttribute('r','12'); circle.setAttribute('fill','#ED7209');
      circle.setAttribute('stroke','#fff'); circle.setAttribute('stroke-width','2');
      const num=document.createElementNS('http://www.w3.org/2000/svg','text');
      num.setAttribute('x',_cx); num.setAttribute('y',_cy);
      num.setAttribute('text-anchor','middle'); num.setAttribute('dominant-baseline','central');
      num.setAttribute('fill','#fff'); num.setAttribute('font-size','9');
      num.setAttribute('font-weight','700'); num.textContent=String(i+1);
      g.appendChild(circle); g.appendChild(num);
      g.addEventListener('click',()=>RV.highlightComment(c.id));
      g.addEventListener('click',e=>{e.stopPropagation();RV.highlightComment(c.id);});
      svg.appendChild(g);
    });
  },

  showReviewQueue(btn){
    const isClient=S.user?.role==='client';
    const allowed=this._getAllowedClients();
    // Role-aware: admins see internal review queue; clients see client review queue
    const readyStatuses=isClient?['cr:ready']:['ir:ready'];
    const jobs=RV_DB._jobs.filter(j=>{
      if(isClient&&!allowed.includes(j.clientId)) return false;
      if(j.archived) return false;
      return readyStatuses.includes(j.status);
    });
    // Use proper routing — go() handles show/hide of all views
    this.go('rv-review', btn);
    const qEl=document.getElementById('rv-review-queue-content');
    if(!qEl) return;
    // Populate client filter (admin only)
    const clientSel=document.getElementById('rv-rq-filter-client');
    if(clientSel&&!isClient){
      const clients=DB.getParents();
      clientSel.innerHTML='<option value="">All clients</option>'+clients.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
      clientSel.closest('div')?.querySelectorAll('select')[0]?.parentElement?.style;
    } else if(clientSel){ clientSel.parentElement?.parentElement?.style&&(clientSel.style.display='none'); }
    // Populate folder filter from visible jobs
    const folderSel=document.getElementById('rv-rq-filter-folder');
    if(folderSel){
      const folders=[...new Set(jobs.map(j=>j.folder).filter(Boolean))];
      folderSel.innerHTML='<option value="">All folders</option>'+folders.map(f=>`<option value="${f}">${f}</option>`).join('');
    }
    if(!jobs.length){
      qEl.innerHTML='<div style="text-align:center;padding:48px;color:var(--t2)"><svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.5" width="36" height="36" style="display:block;margin:0 auto 12px;opacity:.4"><circle cx="16" cy="16" r="13"/><polyline points="10 16 14 20 22 12"/></svg><div style="font-size:14px;font-weight:600;margin-bottom:4px">No items to review</div><div style="font-size:12px;opacity:.6">All caught up!</div></div>';
      return;
    }
    // Group jobs by folder
    const byFolder={};
    jobs.forEach(j=>{
      const folder=j.folder||'Unfoldered';
      if(!byFolder[folder]) byFolder[folder]=[];
      byFolder[folder].push(j);
    });
    const jobCard=j=>{
      const c=DB.getClient(j.clientId);
      const statCol=RV_DB.STATUS_COLS[j.status]||'#94A3B8';
      const due=j.due?new Date(j.due):null;
      const isOverdue=due&&due<new Date();
      const thumb=j.versions?.[j.versions.length-1]?.files?.[0]?.url||'';
      return `<div onclick="RV.openJob('${j.id}')" data-job-id="${j.id}" style="background:var(--bg1);border:1px solid var(--bd1);border-radius:10px;overflow:hidden;cursor:pointer;transition:border-color .15s,transform .15s" onmouseover="this.style.borderColor='var(--o)';this.style.transform='translateY(-2px)'" onmouseout="this.style.borderColor='var(--bd1)';this.style.transform=''">`
        +`<div style="height:80px;background:var(--bg2);display:flex;align-items:center;justify-content:center;border-bottom:1px solid var(--bd1);position:relative">`
        +`${thumb?`<img src="${thumb}" style="width:100%;height:100%;object-fit:cover" onerror="this.style.display='none'">`:`<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.2" width="28" height="28" style="opacity:.2"><rect x="4" y="4" width="24" height="24" rx="3"/><path d="M4 20l7-7 5 5 4-4 8 6"/><circle cx="22" cy="10" r="3"/></svg>`}`
        +`<div style="position:absolute;top:6px;right:6px;background:${statCol};color:#fff;font-size:9px;font-weight:700;padding:2px 6px;border-radius:10px;text-transform:uppercase;letter-spacing:.4px">${(RV_DB.STATUS_LABELS[j.status]||j.status).replace('Ready for ','')}</div>`
        +`</div><div style="padding:10px 12px">`
        +`${c?`<div style="display:flex;align-items:center;gap:5px;margin-bottom:5px"><div style="width:12px;height:12px;border-radius:2px;background:${c.brand_colour};flex-shrink:0"></div><span style="font-size:10px;color:var(--t2);font-weight:600">${c.name}</span></div>`:''}`
        +`<div style="font-size:13px;font-weight:600;margin-bottom:6px;line-height:1.3;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical">${j.title}</div>`
        +`${due?`<div style="font-size:10.5px;color:${isOverdue?'#E84545':'var(--t2)'}">Due ${due.toLocaleDateString('en-GB',{day:'numeric',month:'short'})}</div>`:''}` 
        +`</div></div>`;
    };
    let html=`<div style="font-size:12.5px;color:var(--t2);margin-bottom:16px">${jobs.length} item${jobs.length!==1?'s':''} awaiting review</div>`;
    Object.entries(byFolder).sort(([a],[b])=>a==='Unfoldered'?1:b==='Unfoldered'?-1:a.localeCompare(b)).forEach(([folder,fjobs])=>{
      html+=`<div style="margin-bottom:22px">`;
      html+=`<div style="font-size:10px;font-weight:700;color:var(--t2);text-transform:uppercase;letter-spacing:.8px;margin-bottom:10px;padding-bottom:7px;border-bottom:1px solid var(--bd0)">${folder} <span style="font-weight:400;opacity:.6">${fjobs.length}</span></div>`;
      html+=`<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px">`;
      fjobs.forEach(j=>{ html+=jobCard(j); });
      html+=`</div></div>`;
    });
    qEl.innerHTML=html;
  },

  _updateReviewBadge(){
    const isClient=S.user?.role==='client';
    const allowed=this._getAllowedClients();
    const reviewStatuses=isClient?['cr:ready']:['ir:ready'];
    const count=RV_DB._jobs.filter(j=>{
      if(isClient&&!allowed.includes(j.clientId)) return false;
      if(j.archived) return false;
      return reviewStatuses.includes(j.status);
    }).length;
    const badge=document.getElementById('rvsb-review-badge');
    if(badge){badge.textContent=count;badge.style.display=count>0?'':'none';}
  },

  reopenJob(jobId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    const wasClient=j.status==='cr:signed_off';
    j.status=wasClient?'cr:amend':'ir:amend';
    j.archived=false; j.archivedAt=null; j.archivedBy=null;
    RV_DB.logActivity(jobId,S.user?.name||'Admin','Job reopened for amendments','↩');
    this._updateReviewBadge(); this.buildKanban();
    this.buildDashboard(); this.openJob(jobId);
  },

  _cmpGetTargetVer(jobId){
    const sel=document.getElementById('rv-cmp-side-'+jobId);
    const side=sel?.value||'a';
    const overlay=document.getElementById('rv-compare-overlay');
    if(!overlay) return null;
    const selA=document.getElementById('rv-cmp-a');
    const selB=document.getElementById('rv-cmp-b');
    const j=RV_DB.getJob(jobId); if(!j) return null;
    const idxA=parseInt(selA?.value||'0');
    const idxB=parseInt(selB?.value||'1');
    return side==='b'?(j.versions[idxB]?.id):(j.versions[idxA]?.id);
  },

  uploadVersionFile(jobId,versionId,inputEl){
    const file=inputEl?.files?.[0]; if(!file) return;
    const j=RV_DB.getJob(jobId); if(!j) return;
    const ver=j.versions.find(v=>v.id===versionId); if(!ver) return;
    const ft=file.type.startsWith('video')?'video':file.type.startsWith('image')?'image':'pdf';
    const sz=(file.size/1024/1024).toFixed(1)+' MB';
    const reader=new FileReader();
    reader.onload=e=>{
      ver.files=[{name:file.name,type:ft,url:e.target.result,size:sz}];
      RV_DB.logActivity(jobId,S.user?.name||'User','Uploaded '+file.name,'',{type:'upload',detail:'Uploaded file +file.name+'});
      this.openJob(jobId,versionId);
    };
    reader.readAsDataURL(file);
  },

  deleteVersion(jobId,versionId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    // Show proper confirmation modal instead of browser confirm/alert
    const existing=document.getElementById('rv-del-ver-modal');
    if(existing) existing.remove();
    const modal=document.createElement('div');
    modal.id='rv-del-ver-modal';
    modal.style.cssText='position:fixed;inset:0;z-index:900;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.6)';
    const ver=j.versions.find(v=>v.id===versionId);
    const verLabel=ver?ver.label:'this version';
    const canDelete=j.versions.length>1;
    modal.innerHTML=`<div style="background:var(--bg1);border-radius:10px;padding:24px 28px;max-width:380px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,.5)">
      <div style="font-size:15px;font-weight:700;margin-bottom:8px">${canDelete?'Delete version':'Cannot delete'}</div>
      <div style="font-size:13px;color:var(--t2);margin-bottom:20px;line-height:1.5">${canDelete?'Delete <strong style="color:var(--t0)">'+verLabel+'</strong>? This will permanently remove the file and all annotations. This cannot be undone.':'You cannot delete the only version on a job. Upload a replacement version first, then delete this one.'}</div>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button class="btn btn-g btn-sm" onclick="document.getElementById('rv-del-ver-modal').remove()">Cancel</button>
        ${canDelete?`<button class="btn btn-r btn-sm" onclick="document.getElementById('rv-del-ver-modal').remove();RV._doDeleteVersion('${jobId}','${versionId}')">Delete version</button>`:''}
      </div>
    </div>`;
    document.body.appendChild(modal);
  },

  _doDeleteVersion(jobId,versionId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    j.versions=j.versions.filter(v=>v.id!==versionId);
    RV_DB.logActivity(jobId,S.user?.name||'User','Deleted a version','🗑');
    this.openJob(jobId);
  },

  deleteEmptyVersion(jobId,versionId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    const ver=j.versions.find(v=>v.id===versionId);
    if(!ver) return;
    if((ver.files||[]).length>0){alert('Cannot delete a version that has files.');return;}
    j.versions=j.versions.filter(v=>v.id!==versionId);
    RV_DB.logActivity(jobId,S.user?.name||'User','Deleted empty version','🗑');
    this.openJob(jobId);
  },

  archiveJob(jobId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    j.archived=true;
    j.archivedAt=new Date().toISOString();
    j.archivedBy=S.user?.name||'Admin';
    RV_DB.logActivity(jobId,S.user?.name||'Admin','Job archived','',{type:'archive',detail:'Archived job +j.title+'});
    this._updateReviewBadge();
    this.buildKanban();
    this.buildDashboard();
    this.go('rv-kanban',null);
  },

  _restoreSelected(){
    const el=document.getElementById('rv-archived-content'); if(!el) return;
    const checked=Array.from(el.querySelectorAll('.rv-arc-chk:checked')).map(function(cb){ return cb.value||cb.dataset.id; });
    console.log('[ARCHIVE RESTORE SELECTED]', checked);
    if(!checked.length) return;
    checked.forEach(function(id){
      const j=RV_DB.getJob(id); if(!j) return;
      j.archived=false; j.archivedAt=null; j.archivedBy=null;
      RV_DB.logActivity(id, (S.user&&S.user.name)||'Admin', 'Job restored', '', {type:'archive', detail:'Restored "'+j.title+'" from archive'});
    });
    RV.buildArchivedList();
    RV.buildKanban(); RV.buildDashboard(); RV._updateBadge(); RV._updateReviewBadge();
    if(checked.length===1){ RV.go('rv-job',null); RV.openJob(checked[0]); }
  },

  _restoreAndOpen(jobId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    j.archived=false; j.archivedAt=null; j.archivedBy=null;
    RV_DB.logActivity(jobId,S.user?.name||'Admin','Job restored','',{type:'archive',detail:'Restored "'+j.title+'" from archive'});
    this.buildArchivedList();
    this.buildKanban(); this.buildDashboard(); this._updateBadge(); this._updateReviewBadge();
    this.go('rv-job',null);
    this.openJob(jobId);
  },

  unarchiveJob(jobId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    j.archived=false;
    RV_DB.logActivity(jobId,S.user?.name||'Admin','Job restored','',{type:'archive',detail:'Restored job +j.title+ from archive'});
    this.buildKanban();
    this.buildDashboard();
  },

  highlightComment(commentId){
    // Scroll comment into view and briefly pulse it
    const el=document.getElementById('rv-c-'+commentId); if(!el) return;
    el.scrollIntoView({behavior:'smooth',block:'nearest'});
    el.style.transition='background .1s';
    el.style.background='rgba(237,114,9,.18)';
    setTimeout(()=>{ el.style.background=''; },900);
  },

  highlightPin(commentId, jobId){
    // Pulse the pin marker for this comment
    const svg=document.getElementById('rv-draw-'+jobId); if(!svg) return;
    const g=svg.querySelector(`.rv-pin-marker[data-cid="${commentId}"]`); if(!g) return;
    const circle=g.querySelector('circle'); if(!circle) return;
    const orig=circle.getAttribute('fill')||'#ED7209';
    circle.setAttribute('fill','#FFD600');
    setTimeout(()=>circle.setAttribute('fill',orig),700);
  },

  filterReviewQueue(){
    const clientFilter=document.getElementById('rv-rq-filter-client')?.value||'';
    const folderFilter=document.getElementById('rv-rq-filter-folder')?.value||'';
    const cards=document.querySelectorAll('#rv-review-queue-content [data-job-id]');
    cards.forEach(card=>{
      const matchClient=!clientFilter||card.dataset.clientId===clientFilter;
      const matchFolder=!folderFilter||card.dataset.folder===folderFilter;
      card.style.display=(matchClient&&matchFolder)?'':'none';
    });
  },

  archiveAllSignedOff(){
    const jobs=RV_DB._jobs.filter(j=>j.status==='cr:signed_off'&&!j.archived);
    if(!jobs.length) return;
    const board=document.getElementById('kanban-board')||document.getElementById('v-rv-kanban');
    const existing=document.getElementById('rv-archive-all-confirm');
    if(existing){ existing.remove(); return; }
    const conf=document.createElement('div');
    conf.id='rv-archive-all-confirm';
    conf.style.cssText='background:rgba(232,69,69,.08);border:1px solid rgba(232,69,69,.3);border-radius:var(--rs);padding:12px 16px;margin-bottom:14px;display:flex;align-items:center;gap:12px';
    const msg=document.createElement('span');
    msg.style.cssText='flex:1;font-size:13px;color:rgba(255,255,255,.85)';
    msg.textContent=`Archive all ${jobs.length} signed-off job${jobs.length!==1?'s':''}? They stay in Projects/Folders.`;
    const aBtn=document.createElement('button');
    aBtn.textContent='Archive all';
    aBtn.style.cssText='background:#E84545;border:none;color:#fff;border-radius:var(--rs);padding:6px 16px;cursor:pointer;font-size:12px;font-family:var(--fn);white-space:nowrap';
    aBtn.onclick=()=>{
      jobs.forEach(j=>{
        j.archived=true;
        j.archivedAt=new Date().toISOString();
        j.archivedBy=S.user?.name||'Admin';
        RV_DB.logActivity(j.id,S.user?.name||'Admin','Job archived','');
      });
      conf.remove();
      this.buildKanban();
    };
    const cBtn=document.createElement('button');
    cBtn.textContent='Cancel';
    cBtn.style.cssText='background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.6);border-radius:var(--rs);padding:6px 14px;cursor:pointer;font-size:12px;font-family:var(--fn)';
    cBtn.onclick=()=>conf.remove();
    conf.appendChild(msg);
    conf.appendChild(aBtn);
    conf.appendChild(cBtn);
    if(board) board.insertAdjacentElement('afterbegin',conf);
  },

  refreshBoards(){
    this.buildKanban();
    this.buildJobsList();
    this.buildDashboard();
  },

  buildArchivedList(){
    const el=document.getElementById('rv-archived-content'); if(!el) return;
    const sevenDaysAgo=new Date(Date.now()-7*24*60*60*1000);
    const archived=RV_DB._jobs.filter(j=>j.archived&&j.archivedAt&&new Date(j.archivedAt)>sevenDaysAgo);
    if(!archived.length){
      el.innerHTML='<p style="text-align:center;padding:40px;color:var(--t2);font-size:13px">No jobs archived in the last 7 days.</p>';
      return;
    }
    // Build HTML using string concat — no template literals to avoid quote conflicts
    let html='<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap">'
      +'<label style="display:flex;align-items:center;gap:6px;font-size:12px;cursor:pointer;color:var(--t2)">'
      +'<input type="checkbox" id="rv-arc-all-chk"> Select all'
      +'</label>'
      +'<button id="rv-arc-restore-btn" type="button" style="background:var(--o);color:#fff;border:none;border-radius:var(--rs);padding:5px 14px;cursor:pointer;font-size:12px;font-weight:600">&#x21A9; Restore selected</button>'
      +'<span style="font-size:11.5px;color:var(--t2)">'+archived.length+' job'+(archived.length!==1?'s':'')+' archived in last 7 days</span>'
      +'</div>';
    archived.forEach(function(j){
      const c=DB.getClient(j.clientId);
      const arDate=j.archivedAt?new Date(j.archivedAt).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}):'';
      html+='<div class="rv-arc-row" style="background:var(--bg1);border:1px solid var(--bd1);border-radius:10px;padding:14px 18px;margin-bottom:8px;display:flex;align-items:center;gap:14px">'
        +'<input type="checkbox" class="rv-arc-chk" data-id="'+j.id+'" value="'+j.id+'" style="width:16px;height:16px;flex-shrink:0;cursor:pointer">'
        +'<div style="flex:1;min-width:0">'
          +(c?'<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">'
            +'<div style="width:16px;height:16px;border-radius:3px;background:'+c.brand_colour+';display:flex;align-items:center;justify-content:center;font-size:6px;font-weight:700;color:'+c.brand_text+'">'+c.initials+'</div>'
            +'<span style="font-size:10px;color:var(--t2);font-weight:600;text-transform:uppercase">'+c.name+(j.folder?' &middot; '+j.folder:'')+'</span>'
            +'</div>':'')
          +'<div style="font-size:14px;font-weight:600;margin-bottom:3px">'+j.title+'</div>'
          +'<div style="font-size:11.5px;color:var(--t2)">Archived '+arDate+(j.archivedBy?' by '+j.archivedBy:'')+'</div>'
        +'</div>'
        +'<button class="rv-arc-restore-one" data-id="'+j.id+'" type="button" style="background:var(--o);color:#fff;border:none;border-radius:var(--rs);padding:5px 14px;cursor:pointer;font-size:12px;font-weight:600;white-space:nowrap">&#x21A9; Restore</button>'
        +'</div>';
    });
    el.innerHTML=html;
    // Wire events via addEventListener — no inline JS
    const selectAll=document.getElementById('rv-arc-all-chk');
    if(selectAll) selectAll.addEventListener('change', function(){
      el.querySelectorAll('.rv-arc-chk').forEach(function(cb){ cb.checked=selectAll.checked; });
    });
    const restoreBtn=document.getElementById('rv-arc-restore-btn');
    if(restoreBtn) restoreBtn.addEventListener('click', function(){ RV._restoreSelected(); });
    el.querySelectorAll('.rv-arc-restore-one').forEach(function(btn){
      btn.addEventListener('click', function(){ RV._restoreAndOpen(btn.dataset.id); });
    });
  },

  _vidFmt(s){ const m=Math.floor((s||0)/60),sec=Math.floor((s||0)%60); return`${m}:${sec<10?'0'+sec:sec}`; },
  _vidTogglePlay(jobId){
    const v=document.getElementById('rv-vid-'+jobId); if(!v) return;
    const btn=document.getElementById('rv-vid-play-'+jobId);
    if(v.paused){ v.play(); if(btn) btn.textContent='⏸ Pause'; }
    else { v.pause(); if(btn) btn.textContent='▶ Play'; }
  },
  _vidOnLoad(jobId,versionId){
    const v=document.getElementById('rv-vid-'+jobId); if(!v) return;
    const dur=v.duration||0;
    const timeEl=document.getElementById('rv-vid-time-'+jobId);
    if(timeEl) timeEl.textContent=`0:00 / ${this._vidFmt(dur)}`;
    this._vidDrawMarkers(jobId,versionId);
  },
  _vidOnTimeUpdate(jobId,versionId){
    const v=document.getElementById('rv-vid-'+jobId); if(!v) return;
    const t=v.currentTime,dur=v.duration||1;
    const timeEl=document.getElementById('rv-vid-time-'+jobId);
    if(timeEl) timeEl.textContent=`${this._vidFmt(t)} / ${this._vidFmt(dur)}`;
    const ctEl=document.getElementById('rv-vid-ctime-'+jobId);
    if(ctEl) ctEl.textContent=this._vidFmt(t);
    const seekEl=document.getElementById('rv-vid-seek-'+jobId);
    if(seekEl) seekEl.value=(t/dur*100).toFixed(1);
  },
  _vidSeek(jobId,pct){
    const v=document.getElementById('rv-vid-'+jobId); if(!v) return;
    v.currentTime=(pct/100)*(v.duration||0);
  },
  _vidSpeed(jobId,rate){ const v=document.getElementById('rv-vid-'+jobId); if(v) v.playbackRate=+rate; },
  _vidSeekToMarker(jobId,versionId,ev){
    const bar=ev.currentTarget; const rect=bar.getBoundingClientRect();
    const pct=(ev.clientX-rect.left)/rect.width;
    const v=document.getElementById('rv-vid-'+jobId); if(!v) return;
    v.currentTime=pct*(v.duration||0);
  },
  _vidDrawMarkers(jobId,versionId){
    const bar=document.getElementById('rv-vid-markers-'+jobId); if(!bar) return;
    const v=document.getElementById('rv-vid-'+jobId); const dur=v?.duration||0;
    const j=RV_DB.getJob(jobId); if(!j) return;
    const ver=j.versions.find(v2=>v2.id===versionId);
    const vidCmts=(ver?.comments||[]).filter(c=>c.timestamp!=null);
    bar.innerHTML=vidCmts.map(c=>{
      const pct=dur>0?((c.timestamp/dur)*100).toFixed(1):0;
      return`<div title="${this._vidFmt(c.timestamp)}: ${c.text}" onclick="event.stopPropagation();RV._vidJumpToComment('${jobId}','${c.id}')" style="position:absolute;left:${pct}%;top:0;transform:translateX(-50%);width:10px;height:16px;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:5" onmouseover="this.querySelector('span').style.opacity=1" onmouseout="this.querySelector('span').style.opacity=0"><div style="width:3px;height:16px;background:#F59E0B;border-radius:2px;box-shadow:0 0 4px rgba(245,158,11,.6)"></div><span style="position:absolute;bottom:22px;left:50%;transform:translateX(-50%);background:#1e2a35;color:#fff;font-size:10px;white-space:nowrap;padding:3px 7px;border-radius:5px;opacity:0;transition:opacity .15s;pointer-events:none;max-width:160px;overflow:hidden;text-overflow:ellipsis;box-shadow:0 2px 8px rgba(0,0,0,.4)">${this._vidFmt(c.timestamp)}: ${c.text.length>40?c.text.slice(0,40)+'…':c.text}</span></div>`;
    }).join('');
  },
  _vidJumpToComment(jobId,commentId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    const v=document.getElementById('rv-vid-'+jobId);
    for(const ver of j.versions){
      const c=(ver.comments||[]).find(c=>c.id===commentId);
      if(c&&c.timestamp!=null&&v){ v.currentTime=c.timestamp; v.pause(); const btn=document.getElementById('rv-vid-play-'+jobId); if(btn)btn.textContent='▶ Play'; }
    }
    // Scroll the comments panel into view so the highlighted comment is visible
    const cmtPanel=document.getElementById('rv-comments-'+jobId);
    if(cmtPanel){ cmtPanel.scrollIntoView({behavior:'smooth',block:'nearest'}); }
    setTimeout(()=>this.highlightComment(commentId), 200);
  },
  _vidAddTimestampComment(jobId,versionId){
    const v=document.getElementById('rv-vid-'+jobId); if(!v) return;
    const ts=v.currentTime;
    v.pause();
    const btn=document.getElementById('rv-vid-play-'+jobId); if(btn)btn.textContent='▶ Play';
    // Show inline prompt near the controls
    const existing=document.getElementById('rv-vid-comment-input');
    if(existing) existing.remove();
    const wrap=document.getElementById('rv-vid-wrap-'+jobId); if(!wrap) return;
    const inp=document.createElement('div');
    inp.id='rv-vid-comment-input';
    inp.style.cssText='background:var(--bg1);border:1px solid var(--o);border-radius:var(--rs);padding:10px;margin-top:2px';
    inp.innerHTML=`<div style="font-size:11px;font-weight:700;color:var(--o);margin-bottom:6px">Comment at ${this._vidFmt(ts)}</div>`
      +`<textarea id="rv-vid-cmt-text" rows="2" class="fi" placeholder="What needs changing at this point?" style="font-size:12px;resize:none;margin-bottom:6px"></textarea>`
      +`<div style="display:flex;gap:6px">`
      +`<button class="btn btn-o btn-sm" style="flex:1" id="rv-vid-cmt-add">Add comment</button>`
      +`<button class="btn btn-g btn-sm" id="rv-vid-cmt-cancel">Cancel</button></div>`;
    wrap.appendChild(inp);
    inp.querySelector('#rv-vid-cmt-add').addEventListener('click',e=>{
      e.stopPropagation();
      const text=document.getElementById('rv-vid-cmt-text')?.value.trim();
      if(!text) return;
      const j=RV_DB.getJob(jobId); if(!j) return;
      const ver2=j.versions.find(v2=>v2.id===versionId);
      if(!ver2) return;
      const c={id:'c-'+Date.now(),author:S.user?.name||'User',role:S.user?.role||'admin',text,timestamp:ts,page:null,ts:new Date().toISOString(),replies:[],resolved:false};
      (ver2.comments=ver2.comments||[]).push(c);
      RV_DB.logActivity(jobId,S.user?.name||'User','Added a timestamp comment','');
      inp.remove();
      this._updateCommentsPanel(jobId,versionId);
      this._vidDrawMarkers(jobId,versionId);
    });
    inp.querySelector('#rv-vid-cmt-cancel').addEventListener('click',e=>{e.stopPropagation();inp.remove();});
    setTimeout(()=>document.getElementById('rv-vid-cmt-text')?.focus(),30);
  },

  _addCmpComment(jobId,versionId,textareaId,idxA,idxB){
    const text=document.getElementById(textareaId)?.value?.trim();if(!text)return;
    const j=RV_DB.getJob(jobId);if(!j)return;
    const ver=j.versions.find(v=>v.id===versionId);if(!ver)return;
    const c={id:'c-'+Date.now(),author:S.user?.name||'User',role:S.user?.role||'admin',text,ts:new Date().toISOString(),replies:[],resolved:false,pin:false};
    (ver.comments=ver.comments||[]).push(c);
    RV_DB.logActivity(jobId,S.user?.name||'User','Commented in compare','');
    // Clear textarea
    const ta=document.getElementById(textareaId); if(ta) ta.value='';
    // Live-update the correct comment list in the overlay (don't full re-render)
    const side=textareaId.endsWith('-b')?'b':'a';
    this._cmpRefreshComments(jobId,versionId,side,j,idxA,idxB);
  },

  _cmpJumpToPage(jobId,side,targetPage){
    // Switch the compare PDF panel to targetPage
    const _cmpPdfKey=jobId+'-cmp-'+side;
    const st=RV._pdfState[_cmpPdfKey]; if(!st) return;
    st.pageNum=+targetPage;
    this._pdfRender(_cmpPdfKey);
  },

  _cmpJumpToTimestamp(jobId,side,ts){
    // Video IDs in compare are rv-vid-cmp-a and rv-vid-cmp-b
    const _vid=document.getElementById('rv-vid-cmp-'+(side==='b'?'b':'a'));
    if(!_vid) return;
    _vid.currentTime=+ts;
    _vid.pause();
  },

  _cmpRefreshComments(jobId,versionId,side,j,idxA,idxB){
    // Update just the comment list for one side without re-rendering the whole overlay
    const listId='rv-cmp-list-'+(side||'a');
    const el=document.getElementById(listId);
    if(!el){ this._renderCompare(j,idxA,idxB); return; }
    const ver=j.versions.find(v=>v.id===versionId); if(!ver) return;
    const cmts=(ver.comments||[]);
    if(!cmts.length){ el.innerHTML='<div style="font-size:11px;color:var(--t2);padding:8px 14px">No comments yet</div>'; return; }
    el.innerHTML=cmts.slice().reverse().map(c=>{
      const _pgBadge=c.page!=null?`<span onclick="RV._cmpJumpToPage('${jobId}','${side}',${c.page})" style='font-size:8.5px;padding:2px 6px;border-radius:8px;background:rgba(99,102,241,.15);color:#6366F1;margin-left:4px;cursor:pointer'>Page ${c.page}</span>`:'';
      const _tsBadge=c.timestamp!=null?`<span onclick="RV._cmpJumpToTimestamp('${jobId}','${side}',${c.timestamp})" style='font-size:8.5px;padding:2px 6px;border-radius:8px;background:rgba(245,158,11,.15);color:#F59E0B;margin-left:4px;cursor:pointer'>▶ ${RV._vidFmt(c.timestamp)}</span>`:'';
      return`<div style="padding:8px 14px;border-bottom:1px solid var(--bd0)"><div style="display:flex;align-items:center;gap:5px;margin-bottom:3px"><div style="width:16px;height:16px;border-radius:50%;background:${getCompanyBrandColour((DB.getUsers().find(u=>u.name===c.author)||{companies:[]}).companies?.[0]||'')};color:${getContrastText(getCompanyBrandColour((DB.getUsers().find(u=>u.name===c.author)||{companies:[]}).companies?.[0]||''))}};display:flex;align-items:center;justify-content:center;font-size:7px;font-weight:700;color:#fff">${(c.author||'?')[0]}</div><span style="font-size:11px;font-weight:600">${c.author||'User'}</span>${_pgBadge}${_tsBadge}<span style="font-size:10px;color:var(--t2);margin-left:auto">${new Date(c.ts).toLocaleDateString('en-GB',{day:'numeric',month:'short'})}</span></div><div style="font-size:11.5px;line-height:1.4">${c.text}</div></div>`;
    }).join('');
  },

  _cmpAddTimestamp(jobId,versionId,side,idxA,idxB){
    const vidId=side==='b'?'rv-vid-cmp-b':'rv-vid-cmp-a';
    const vid=document.getElementById(vidId)||document.querySelector('#rv-compare-overlay video');
    const ts=vid?vid.currentTime:0;
    const fmt=this._vidFmt(ts);
    // Show inline modal instead of prompt()
    const existing=document.getElementById('rv-cmp-ts-modal');
    if(existing) existing.remove();
    const modal=document.createElement('div');
    modal.id='rv-cmp-ts-modal';
    modal.style.cssText='position:fixed;inset:0;z-index:900;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.55)';
    modal.innerHTML=`<div style="background:var(--bg1);border-radius:10px;padding:20px 24px;min-width:320px;max-width:420px;box-shadow:0 8px 32px rgba(0,0,0,.4)">
      <div style="font-size:13px;font-weight:700;margin-bottom:4px">Timestamp comment</div>
      <div style="font-size:11px;color:var(--t2);margin-bottom:12px">⏱ ${fmt} · ${side==='b'?'Right':'Left'} version</div>
      <textarea id="rv-cmp-ts-text" class="fi" rows="3" placeholder="Add your comment…" style="resize:none;margin-bottom:10px;font-size:12.5px"></textarea>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button class="btn btn-g btn-sm" onclick="document.getElementById('rv-cmp-ts-modal').remove()">Cancel</button>
        <button class="btn btn-o btn-sm" onclick="RV._cmpConfirmTimestamp('${jobId}','${versionId}','${side}',${ts},${idxA},${idxB})">Add comment</button>
      </div>
    </div>`;
    document.body.appendChild(modal);
    setTimeout(()=>document.getElementById('rv-cmp-ts-text')?.focus(),50);
  },

  _cmpConfirmTimestamp(jobId,versionId,side,ts,idxA,idxB){
    const text=document.getElementById('rv-cmp-ts-text')?.value?.trim();
    document.getElementById('rv-cmp-ts-modal')?.remove();
    if(!text) return;
    const j=RV_DB.getJob(jobId); if(!j) return;
    const ver=j.versions.find(v=>v.id===versionId); if(!ver) return;
    const c={id:'c-'+Date.now(),author:S.user?.name||'User',role:S.user?.role||'admin',text,ts:new Date().toISOString(),timestamp:ts,replies:[],resolved:false,pin:false};
    (ver.comments=ver.comments||[]).push(c);
    RV_DB.logActivity(jobId,S.user?.name||'User','Timestamp comment at '+this._vidFmt(ts),'⏱');
    this._cmpRefreshComments(jobId,versionId,side,j,idxA,idxB);
  },

  _testPin(jobId,side){
    // Draw a large red test circle directly into the compare SVG to verify layer visibility
    const _cmpSide=side==='b'?'b':'a';
    const _sfx=_cmpSide==='b'?'-b':'-cmp-a';
    const svgId='rv-draw-'+jobId+_sfx;
    const svg=document.getElementById(svgId)||(_cmpSide==='a'?document.getElementById('rv-draw-'+jobId):null);
    const _foundId=svg?svg.id:'none';
    console.log('[TESTPIN] side='+side+' svgId='+svgId+' found='+!!svg+' actualId='+_foundId);
    if(!svg){ alert('SVG not found: '+svgId); return; }
    const circ=document.createElementNS('http://www.w3.org/2000/svg','circle');
    circ.setAttribute('cx','80'); circ.setAttribute('cy','80');
    circ.setAttribute('r','20'); circ.setAttribute('fill','red');
    circ.setAttribute('stroke','white'); circ.setAttribute('stroke-width','4');
    svg.appendChild(circ);
    console.log('[TESTPIN] circle appended. svgW='+svg.getAttribute('width')+' svgH='+svg.getAttribute('height')+' svgStyle='+svg.getAttribute('style'));
    // Also log parent chain
    let el=svg; let chain='';
    for(let i=0;i<5;i++){ if(!el) break; chain+=el.tagName+(el.id?'#'+el.id:'')+(el.style?.overflow?' overflow:'+el.style.overflow:'')+(el.style?.display?' display:'+el.style.display:'')+'  '; el=el.parentElement; }
    console.log('[TESTPIN] parent chain: '+chain);
  },

  _cmpSetTool(jobId,versionId,tool,side){
    // Direct tool activation for a specific side — no dropdown ambiguity
    // Toggle off if same tool+side is already active
    if(this._annotateMode?.tool===tool&&this._annotateMode?.side===side&&this._annotateMode?.jobId===jobId){
      this._annotateMode=null; this._activeTool=null;
      this._teardownDrawing(jobId,side==='b'?'b':null);
      document.querySelectorAll('.rv-ann-btn-'+side).forEach(b=>b.classList.remove('active'));
      return;
    }
    // Teardown previous side if switching sides
    if(this._annotateMode?.side!==side){
      const prevSide=this._annotateMode?.side||null;
      this._teardownDrawing(jobId,prevSide==='b'?'b':null);
      document.querySelectorAll('.rv-ann-btn-'+(prevSide||'a')).forEach(b=>b.classList.remove('active'));
    }
    this._annotateMode={jobId,versionId,tool,side};
    this._activeTool=tool;
    // Enable SVG on correct side — 'a' = no suffix, 'b' = '-b'
    const _sfxC=side==='b'?'-b':side==='a'?'-cmp-a':'';
    const svg=document.getElementById('rv-draw-'+jobId+_sfxC)||(side==='a'?document.getElementById('rv-draw-'+jobId):null);
    if(svg) svg.style.pointerEvents='all';
    // Disable SVG on other side
    const _otherSfxC=side==='b'?'-cmp-a':'-b';
    const _otherSvg=document.getElementById('rv-draw-'+jobId+_otherSfxC);
    if(_otherSvg) _otherSvg.style.pointerEvents='none';
    // Update button states for this side only — add rv-ann-btn class for CSS active state
    document.querySelectorAll('.rv-ann-btn-'+side).forEach(b=>{
      b.classList.toggle('active', b.dataset.tool===tool);
    });
    const wrap=document.getElementById('rv-pdf-canvas-wrap-'+jobId+'-cmp-'+side)||document.getElementById('rv-canvas-'+jobId+_sfxC);
    if(wrap) wrap.style.cursor='crosshair';
    this._setupDrawing(jobId,versionId,side); // pass 'a' or 'b' always
  },

  _cmpSideChanged(jobId,sideVal,verAId,verBId){
    if(!this._annotateMode) return;
    const side=sideVal==='b'?'b':null;
    const vId=side==='b'?verBId:verAId;
    this._annotateMode.side=side==='b'?'b':'a';
    this._annotateMode.versionId=vId;
    this._setupDrawing(jobId,vId,side==='b'?'b':'a');
  },

  clearAnnotations(jobId,versionId,side){
    // Clear only drawn shapes (rect/circle/arrow/highlight/pen) — NOT pin comments
    const ver=RV_DB.getJob(jobId)?.versions.find(v=>v.id===versionId);
    const _clearPdfKey=(side==='a'||side==='b')?jobId+'-cmp-'+side:jobId;
    const _clearPg=RV._pdfState?.[_clearPdfKey]?.pageNum??null;
    if(ver){
      if(_clearPg===null) ver.shapes=[];  // non-PDF: clear all
      else ver.shapes=ver.shapes.filter(s=>s.page!==_clearPg);  // PDF: only clear current page
    }
    const _sfxC=side==='b'?'-b':side==='a'?'-cmp-a':'';
    const svg=document.getElementById('rv-draw-'+jobId+_sfxC)||(side==='a'?document.getElementById('rv-draw-'+jobId):null)||document.getElementById('rv-draw-'+jobId);
    if(svg){
      [...svg.children].forEach(el=>{
        if(!el.classList.contains('rv-pin-marker') && el.tagName.toLowerCase()!=='defs')
          el.remove();
      });
    }
    this._addPinMarker(jobId,versionId,side||null);
  },

  toggleAnnotate(jobId,versionId){
    this._annotateMode=this._annotateMode?null:{jobId,versionId,tool:'pin'};
    const canvas=document.getElementById('rv-canvas-'+jobId);
    if(canvas) canvas.style.cursor=this._annotateMode?'crosshair':'default';
  },

  canvasClick(e,jobId,versionId){
    // Don't interfere with PDF toolbar buttons/inputs
    if(e.target.tagName==='BUTTON'||e.target.tagName==='INPUT'||e.target.tagName==='SELECT'||e.target.closest('button')) return;
    if(!this._annotateMode||this._annotateMode.tool!=='pin') return;
    const img=e.currentTarget.querySelector('img')||e.currentTarget.querySelector('canvas')||e.currentTarget;
    const rect=img.getBoundingClientRect();
    const x=Math.max(0,Math.min(100,(e.clientX-rect.left)/rect.width*100));
    const y=Math.max(0,Math.min(100,(e.clientY-rect.top)/rect.height*100));
    this._pendingPin={x:+x.toFixed(2),y:+y.toFixed(2),jobId,versionId};
    this._showPinInput(+x.toFixed(2),+y.toFixed(2),e.currentTarget);
  },

  setStatus(jobId,status){
    if(S.user?.role==='client') return;
    const j=RV_DB.getJob(jobId); if(!j) return;
    j.status=status;
    RV_DB.logActivity(jobId,S.user?.name||'Admin','Status changed','',{type:'status',detail:'Status changed to +(RV_DB.STATUS_LABELS[status]||status)+'});
    RV_DB.addNotification('status',jobId,(S.user?.name||'Admin')+' moved job to '+(RV_DB.STATUS_LABELS[status]||status));
    this.buildKanban();
    this.buildDashboard();
    this._updateBadge();
    // Re-render job immediately - update stage trail and status pill directly in DOM
    const stageEls=document.querySelectorAll('.rv-stage[data-jid="'+jobId+'"]');
    stageEls.forEach(el=>{
      const s=el.dataset.status;
      const isCurrent=s===status;
      const stages=s.startsWith('cr:')?RV_DB.CLIENT_COLS:RV_DB.INTERNAL_COLS;
      const idx=stages.indexOf(s);
      const curIdx=stages.indexOf(status);
      el.classList.toggle('on', isCurrent);
      el.classList.toggle('done', !isCurrent&&idx<curIdx);
      el.classList.remove(isCurrent?'done':'on');
    });
    // Also update the status pill in the job header
    const pillEl=document.getElementById('rv-job-status-pill-'+jobId);
    if(pillEl){
      pillEl.textContent=RV_DB.STATUS_LABELS[status]||status;
      pillEl.style.background=RV_DB.STATUS_COLS[status]||'#94A3B8';
    }
    // Full re-render after short delay to ensure all updates settle
    setTimeout(()=>this.openJob(jobId), 50);
  },

  showVersion(jobId,versionId){ this.openJob(jobId,versionId); },

  // PDF.js helpers
  _pdfState:{}, // jobId → {pdf,pageNum,scale,url}
  _pdfThumbCache:{}, // pdfUrl → dataUrl

  _getPdfThumb(url,callback){
    if(this._pdfThumbCache[url]){ callback(this._pdfThumbCache[url]); return; }
    const tryRender=()=>{
      window.pdfjsLib.getDocument(url).promise.then(pdf=>{
        pdf.getPage(1).then(page=>{
          const vp=page.getViewport({scale:0.4});
          const canvas=document.createElement('canvas');
          canvas.width=vp.width; canvas.height=vp.height;
          page.render({canvasContext:canvas.getContext('2d'),viewport:vp}).promise.then(()=>{
            const dataUrl=canvas.toDataURL('image/jpeg',0.7);
            this._pdfThumbCache[url]=dataUrl;
            callback(dataUrl);
          });
        });
      }).catch(()=>callback(null));
    };
    if(window.pdfjsLib){ tryRender(); }
    else {
      const s=document.createElement('script');
      s.src='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
      s.onload=()=>{ window.pdfjsLib.GlobalWorkerOptions.workerSrc=''; tryRender(); };
      document.head.appendChild(s);
    }
  },
  pdfInit(jobId,url,versionId){
    this._pdfState[jobId]=this._pdfState[jobId]||{};
    this._pdfState[jobId].pageNum=this._pdfState[jobId].pageNum||1;
    if(versionId) this._pdfState[jobId].versionId=versionId;
    // Graceful fallback for local file:// origin restrictions
    if(url&&url.startsWith('file://')){
      const canvas=document.getElementById('rv-pdf-'+jobId);
      if(canvas){const ctx=canvas.getContext('2d');if(ctx){canvas.width=600;canvas.height=400;ctx.fillStyle='#1a2744';ctx.fillRect(0,0,600,400);ctx.fillStyle='rgba(255,255,255,.5)';ctx.font='14px system-ui';ctx.textAlign='center';ctx.fillText('PDF preview requires a server URL (not file://)',300,200);}}
      return;
    }
    if(!window.pdfjsLib){
      // Load PDF.js from CDN
      const s=document.createElement('script');
      s.src='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
      s.onload=()=>{
        window.pdfjsLib.GlobalWorkerOptions.workerSrc='';
        this._pdfLoad(jobId,url);
      };
      document.head.appendChild(s);
    } else {
      window.pdfjsLib.GlobalWorkerOptions.workerSrc='';
      this._pdfLoad(jobId,url);
    }
  },
  _pdfLoad(jobId,url){
    window.pdfjsLib.getDocument(url).promise.then(pdf=>{
      const _prevVid=RV._pdfState[jobId]?.versionId||RV_DB.getJob(jobId)?.versions.slice(-1)[0]?.id||null;
      this._pdfState[jobId]={pdf,pageNum:1,scale:1.2,url,versionId:_prevVid};
      this._pdfRender(jobId);
    }).catch(e=>{
      const canvas=document.getElementById('rv-pdf-canvas-'+jobId);
      if(canvas) canvas.insertAdjacentHTML('afterend','<div style="color:#ccc;padding:20px;text-align:center">PDF preview unavailable. <a href="'+url+'" target="_blank" style="color:#ED7209">Open in new tab</a></div>');
    });
  },
  _pdfRender(jobId){
    const st=this._pdfState[jobId]; if(!st) return;
    const canvas=document.getElementById('rv-pdf-canvas-'+jobId); if(!canvas) return;
    st.pdf.getPage(st.pageNum).then(page=>{
      const vp=page.getViewport({scale:st.scale});
      canvas.width=vp.width; canvas.height=vp.height;
      const renderTask=page.render({canvasContext:canvas.getContext('2d'),viewport:vp});
      const pg=document.getElementById('rv-pdf-pg-'+jobId);
      if(pg) pg.textContent='Page '+st.pageNum+' / '+st.pdf.numPages;
      renderTask.promise.then(()=>{
        // Sync SVG overlay dimensions to canvas
        // Map compound compare jobId to real SVG overlay id
        const _cmpMatch=jobId.match(/-cmp-([ab])$/);
        const _svgId=_cmpMatch?(jobId.replace(/-cmp-[ab]$/,'')+ (_cmpMatch[1]==='b'?'-b':'')):'rv-draw-'+jobId;
        const _svg=document.getElementById('rv-draw-'+(_cmpMatch?jobId.replace(/-cmp-[ab]$/,'')+(_cmpMatch[1]==='b'?'-b':'-cmp-a'):jobId));
        if(_svg){ _svg.setAttribute('width',canvas.width); _svg.setAttribute('height',canvas.height); _svg.style.width=canvas.width+'px'; _svg.style.height=canvas.height+'px'; }
        // Redraw annotations for current page
        const _vid=RV._pdfState[jobId]?.versionId;
        if(_vid){ RV._renderShapes(jobId,_vid); RV._addPinMarker(jobId,_vid); RV._updateCommentsPanel(jobId,_vid); RV._pdfDebug(jobId,_vid); }
      }).catch(()=>{});
    });
  },
  _jumpToPdfPage(jobId,commentId,targetPage){
    const st=RV._pdfState[jobId]; if(!st) return;
    st.pageNum=+targetPage;
    this._pdfRender(jobId);
    setTimeout(()=>this.highlightComment(commentId), 350);
  },

  pdfPage(delta,jobId){
    const st=this._pdfState[jobId]; if(!st) return;
    st.pageNum=Math.max(1,Math.min(st.pdf.numPages,st.pageNum+delta));
    this._pdfRender(jobId); // _pdfRender now calls _renderShapes + _addPinMarker after canvas renders
  },
  _pdfDebug(jobId,versionId){
    const el=document.getElementById('rv-pdf-debug-'+jobId); if(!el) return;
    const j=RV_DB.getJob(jobId.replace(/-cmp-[ab]$/,'')); if(!j) return;
    const ver=j.versions.find(v=>v.id===versionId);
    const st=RV._pdfState[jobId];
    const pgF=st?.pageNum??null;
    const allCmts=ver?.comments||[];
    const pdfPins=allCmts.filter(c=>c.pin&&c.page!=null);
    const visiblePins=pdfPins.filter(c=>c.page===pgF);
    const svg=document.getElementById('rv-draw-'+jobId.replace(/-cmp-a$/,'').replace(/-cmp-b$/,'-b'));
    let html='<b style="color:#ffd700">PDF Debug: '+jobId+'</b><br>';
    html+='page: '+pgF+' | allPins: '+pdfPins.length+' | visible: '+visiblePins.length+' | svgChildren: '+(svg?svg.children.length:0)+'<br>';
    html+='<span style="color:#ffd700">Pins:</span><br>';
    pdfPins.forEach(c=>{ const vis=c.page===pgF; html+='<span style="color:'+(vis?'#3fb950':'#f85149')+'">'+(vis?'✓':'✗')+' p:'+c.page+' x:'+c.x?.toFixed(1)+' y:'+c.y?.toFixed(1)+'</span><br>'; });
    el.innerHTML=html;
  },

  pdfZoom(delta,jobId){
    const st=this._pdfState[jobId]; if(!st) return;
    st.scale=Math.max(0.5,Math.min(3,st.scale+delta));
    this._pdfRender(jobId);
  },

  // Version compare mode — any two versions selectable
  openCompare(jobId){
    const j=RV_DB.getJob(jobId); if(!j||j.versions.length<2) return;
    const el=document.getElementById('rv-job-content'); if(!el) return;
    // Default: compare last two
    const idxA=j.versions.length-2, idxB=j.versions.length-1;
    this._renderCompare(j,idxA,idxB);
  },

  _renderCompare(j,idxA,idxB){
    const el=document.getElementById('rv-job-content'); if(!el) return;
    const existing=document.getElementById('rv-compare-overlay');
    if(existing) existing.remove();
    const vA=j.versions[idxA], vB=j.versions[idxB];
    if(!vA||!vB) return;
    const fileA=vA.files[0], fileB=vB.files[0];
    const isVidA=fileA?.type==='video', isVidB=fileB?.type==='video';
    const verOptions=j.versions.map((v,i)=>`<option value="${i}">${v.label}</option>`).join('');
    const overlay=document.createElement('div');
    overlay.id='rv-compare-overlay';
    overlay.dataset.jobid=j.id;
    overlay.dataset.verid=vA?vA.id:'';
    overlay.style.cssText='position:fixed;inset:0;background:var(--bg0);z-index:500;overflow-y:auto;padding:20px';
    overlay.innerHTML=`
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;flex-wrap:wrap">
        ← Back</button>
        <span style="font-size:14px;font-weight:700">Version comparison</span>
        <div style="display:flex;align-items:center;gap:6px;margin-left:8px">
          <label style="font-size:11.5px;color:var(--t2)">Left:</label>
          <select class="fi" id="rv-cmp-a" style="font-size:11.5px;padding:4px 8px;width:auto" onchange="RV._renderCompare(RV_DB.getJob('${j.id}'),+this.value,+document.getElementById('rv-cmp-b').value)">${verOptions}</select>
          <label style="font-size:11.5px;color:var(--t2)">Right:</label>
          <select class="fi" id="rv-cmp-b" style="font-size:11.5px;padding:4px 8px;width:auto" onchange="RV._renderCompare(RV_DB.getJob('${j.id}'),+document.getElementById('rv-cmp-a').value,+this.value)">${verOptions}</select>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:3px;background:var(--bd1)">
        <div style="background:var(--bg1)">
          <div style="padding:9px 14px;font-size:12px;font-weight:700;color:var(--t2);border-bottom:1px solid var(--bd0)">${vA.label} · ${new Date(vA.uploaded).toLocaleDateString('en-GB')} · ${vA.uploadedBy}</div>
          <div style="padding:8px 12px;border-bottom:1px solid var(--bd0);display:flex;align-items:center;gap:4px;flex-wrap:wrap;background:var(--bg2)">
            ${!isVidA?`<button class="rv-file-tool rv-ann-btn-a" data-tool="pin" data-side="a" onclick="RV._cmpSetTool('${j.id}','${vA.id}','pin','a')" style="display:flex;align-items:center;gap:3px;font-size:11.5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="11" height="11"><circle cx="8" cy="6" r="3"/><line x1="8" y1="9" x2="8" y2="14"/></svg> Pin</button>
            <button class="rv-file-tool rv-ann-btn-a" data-tool="rect" data-side="a" onclick="RV._cmpSetTool('${j.id}','${vA.id}','rect','a')" style="display:flex;align-items:center;gap:3px;font-size:11.5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="11" height="11"><rect x="3" y="3" width="10" height="10" rx="1"/></svg> Box</button>
            <button class="rv-file-tool rv-ann-btn-a" data-tool="circle" data-side="a" onclick="RV._cmpSetTool('${j.id}','${vA.id}','circle','a')" style="display:flex;align-items:center;gap:3px;font-size:11.5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="11" height="11"><circle cx="8" cy="8" r="5"/></svg> Circle</button>
            <button class="rv-file-tool rv-ann-btn-a" data-tool="highlight" data-side="a" onclick="RV._cmpSetTool('${j.id}','${vA.id}','highlight','a')" style="display:flex;align-items:center;gap:3px;font-size:11.5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" width="13" height="13"><polygon points="12,2 14,4 8,12 4,12 4,8" fill="rgba(255,214,0,.4)" stroke="#c8a600" stroke-linejoin="round"/><line x1="4" y1="12" x2="4" y2="14"/><line x1="8" y1="12" x2="4" y2="12"/></svg> Highlight</button>
            <button class="rv-file-tool rv-ann-btn-a" data-tool="arrow" data-side="a" onclick="RV._cmpSetTool('${j.id}','${vA.id}','arrow','a')" style="display:flex;align-items:center;gap:3px;font-size:11.5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="11" height="11"><line x1="2" y1="14" x2="14" y2="2"/><polyline points="6 2 14 2 14 10"/></svg> Arrow</button>
            <button class="rv-file-tool" onclick="RV.clearAnnotations('${j.id}','${vA.id}','a')" style="font-size:10.5px;color:#E84545;margin-left:4px;border-left:1px solid var(--bd1);padding-left:8px">✕ Clear</button>`:``}
            ${isVidA?`<button class='rv-file-tool' onclick="RV._cmpAddTimestamp('${j.id}','${vA.id}','a',${idxA},${idxB})" style='color:#F59E0B;font-size:11px'>⏱ Timestamp</button>`:''}
          </div>
          <div id="rv-canvas-${j.id}" style="padding:12px;min-height:400px;display:flex;align-items:flex-start;justify-content:center;overflow:visible">
            ${fileA?.url&&fileA.type==='image'?`<img src="${fileA.url}" style="max-width:100%;height:auto"><svg id="rv-draw-${j.id}" style="position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;overflow:visible;z-index:10"></svg>`:fileA?.url&&fileA.type==='pdf'?`<div id="rv-pdf-${j.id}-cmp-a" style="background:#525659;padding:8px"><div class="pdf-toolbar" style="display:flex;align-items:center;justify-content:center;gap:8px;padding:6px;background:#3d3d3d;margin-bottom:6px"><button class="rv-file-tool" onclick="RV.pdfPage(-1,'${j.id}-cmp-a')" style="color:#fff;border-color:rgba(255,255,255,.2)">‹ Prev</button><span id="rv-pdf-pg-${j.id}-cmp-a" style="font-size:11px;color:#fff;min-width:70px;text-align:center">Page 1</span><button class="rv-file-tool" onclick="RV.pdfPage(1,'${j.id}-cmp-a')" style="color:#fff;border-color:rgba(255,255,255,.2)">Next ›</button><button class="rv-file-tool" onclick="RV.pdfZoom(.1,'${j.id}-cmp-a')" style="color:#fff;border-color:rgba(255,255,255,.2)">+</button><button class="rv-file-tool" onclick="RV.pdfZoom(-.1,'${j.id}-cmp-a')" style="color:#fff;border-color:rgba(255,255,255,.2)">−</button></div><div id="rv-pdf-canvas-wrap-${j.id}-cmp-a" style="position:relative;display:block;margin:0 auto;overflow:visible"><canvas id="rv-pdf-canvas-${j.id}-cmp-a" style="display:block;max-width:100%"></canvas><svg id="rv-draw-${j.id}-cmp-a" style="position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;overflow:visible;z-index:5"></svg></div></div>`:fileA?.url&&fileA.type==='video'?`<video id="rv-vid-cmp-a" src="${fileA.url}" style="width:100%;max-height:420px;display:block;background:#000" controls></video>`:`<div style="padding:40px;text-align:center;color:var(--t2)">${fileA?.name||'No preview'}</div>`}
          </div>
          <div style="padding:10px 14px;border-top:1px solid var(--bd0)"><div id="rv-cmp-list-a" style="max-height:180px;overflow-y:auto">${(()=>{const _ac=(vA.comments||[]);return _ac.length?_ac.slice().reverse().map(c=>`<div style="padding:8px 14px;border-bottom:1px solid var(--bd0)"><div style="display:flex;align-items:center;gap:5px;margin-bottom:3px"><div style="width:16px;height:16px;border-radius:50%;background:${getCompanyBrandColour((DB.getUsers().find(u=>u.name===c.author)||{companies:[]}).companies?.[0]||'')};color:${getContrastText(getCompanyBrandColour((DB.getUsers().find(u=>u.name===c.author)||{companies:[]}).companies?.[0]||''))}};display:flex;align-items:center;justify-content:center;font-size:7px;font-weight:700;color:#fff">${(c.author||'?')[0]}</div><span style="font-size:11px;font-weight:600">${c.author||'User'}</span><span style="font-size:10px;color:var(--t2);margin-left:auto">${new Date(c.ts).toLocaleDateString('en-GB',{day:'numeric',month:'short'})}</span></div><div style="font-size:11.5px">${c.text}</div></div>`).join(''):'<div style="font-size:11px;color:var(--t2);padding:8px 14px">No comments yet</div>';})()}</div><div style="padding:8px 14px;border-top:1px solid var(--bd0)"><textarea class="fi" id="rv-cmp-cmt-a" rows="2" placeholder="Add comment…" style="font-size:11.5px;resize:none;margin-bottom:4px"></textarea><button class="btn btn-o btn-sm" style="width:100%" onclick="RV._addCmpComment('${j.id}','${vA.id}','rv-cmp-cmt-a',${idxA},${idxB})">Post</button></div></div>
        </div>
        <div style="background:var(--bg1)">
          <div style="padding:9px 14px;font-size:12px;font-weight:700;color:var(--o);border-bottom:1px solid var(--bd0)">${vB.label} · ${new Date(vB.uploaded).toLocaleDateString('en-GB')} · ${vB.uploadedBy}</div>
          <div style="padding:8px 12px;border-bottom:1px solid var(--bd0);display:flex;align-items:center;gap:4px;flex-wrap:wrap;background:var(--bg2)">
            ${!isVidB?`<button class="rv-file-tool rv-ann-btn-b" data-tool="pin" data-side="b" onclick="RV._cmpSetTool('${j.id}','${vB.id}','pin','b')" style="display:flex;align-items:center;gap:3px;font-size:11.5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="11" height="11"><circle cx="8" cy="6" r="3"/><line x1="8" y1="9" x2="8" y2="14"/></svg> Pin</button>
            <button class="rv-file-tool rv-ann-btn-b" data-tool="rect" data-side="b" onclick="RV._cmpSetTool('${j.id}','${vB.id}','rect','b')" style="display:flex;align-items:center;gap:3px;font-size:11.5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="11" height="11"><rect x="3" y="3" width="10" height="10" rx="1"/></svg> Box</button>
            <button class="rv-file-tool rv-ann-btn-b" data-tool="circle" data-side="b" onclick="RV._cmpSetTool('${j.id}','${vB.id}','circle','b')" style="display:flex;align-items:center;gap:3px;font-size:11.5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="11" height="11"><circle cx="8" cy="8" r="5"/></svg> Circle</button>
            <button class="rv-file-tool rv-ann-btn-b" data-tool="highlight" data-side="b" onclick="RV._cmpSetTool('${j.id}','${vB.id}','highlight','b')" style="display:flex;align-items:center;gap:3px;font-size:11.5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" width="13" height="13"><polygon points="12,2 14,4 8,12 4,12 4,8" fill="rgba(255,214,0,.4)" stroke="#c8a600" stroke-linejoin="round"/><line x1="4" y1="12" x2="4" y2="14"/><line x1="8" y1="12" x2="4" y2="12"/></svg> Highlight</button>
            <button class="rv-file-tool rv-ann-btn-b" data-tool="arrow" data-side="b" onclick="RV._cmpSetTool('${j.id}','${vB.id}','arrow','b')" style="display:flex;align-items:center;gap:3px;font-size:11.5px"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" width="11" height="11"><line x1="2" y1="14" x2="14" y2="2"/><polyline points="6 2 14 2 14 10"/></svg> Arrow</button>
            <button class="rv-file-tool" onclick="RV.clearAnnotations('${j.id}','${vB.id}','b')" style="font-size:10.5px;color:#E84545;margin-left:4px;border-left:1px solid var(--bd1);padding-left:8px">✕ Clear</button>`:``}
            ${isVidB?`<button class='rv-file-tool' onclick="RV._cmpAddTimestamp('${j.id}','${vB.id}','b',${idxA},${idxB})" style='color:#F59E0B;font-size:11px'>⏱ Timestamp</button>`:''}
          </div>
          <div id="rv-canvas-${j.id}-b" style="padding:12px;min-height:400px;display:flex;align-items:flex-start;justify-content:center;overflow:visible">
            ${fileB?.url&&fileB.type==='image'?`<img src="${fileB.url}" style="max-width:100%;height:auto"><svg id="rv-draw-${j.id}-b" style="position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;overflow:visible;z-index:10"></svg>`:fileB?.url&&fileB.type==='pdf'?`<div id="rv-pdf-${j.id}-cmp-b" style="background:#525659;padding:8px"><div class="pdf-toolbar" style="display:flex;align-items:center;justify-content:center;gap:8px;padding:6px;background:#3d3d3d;margin-bottom:6px"><button class="rv-file-tool" onclick="RV.pdfPage(-1,'${j.id}-cmp-b')" style="color:#fff;border-color:rgba(255,255,255,.2)">‹ Prev</button><span id="rv-pdf-pg-${j.id}-cmp-b" style="font-size:11px;color:#fff;min-width:70px;text-align:center">Page 1</span><button class="rv-file-tool" onclick="RV.pdfPage(1,'${j.id}-cmp-b')" style="color:#fff;border-color:rgba(255,255,255,.2)">Next ›</button><button class="rv-file-tool" onclick="RV.pdfZoom(.1,'${j.id}-cmp-b')" style="color:#fff;border-color:rgba(255,255,255,.2)">+</button><button class="rv-file-tool" onclick="RV.pdfZoom(-.1,'${j.id}-cmp-b')" style="color:#fff;border-color:rgba(255,255,255,.2)">−</button></div><div id="rv-pdf-canvas-wrap-${j.id}-cmp-b" style="position:relative;display:block;margin:0 auto;overflow:visible"><canvas id="rv-pdf-canvas-${j.id}-cmp-b" style="display:block;max-width:100%"></canvas><svg id="rv-draw-${j.id}-b" style="position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;overflow:visible;z-index:5"></svg></div></div>`:fileB?.url&&fileB.type==='video'?`<video id="rv-vid-cmp-b" src="${fileB.url}" style="width:100%;max-height:420px;display:block;background:#000" controls></video>`:`<div style="padding:40px;text-align:center;color:var(--t2)">${fileB?.name||'No preview'}</div>`}
          </div>
          <div style="padding:10px 14px;border-top:1px solid var(--bd0)"><div id="rv-cmp-list-b" style="max-height:180px;overflow-y:auto">${(()=>{const _bc=(vB.comments||[]);return _bc.length?_bc.slice().reverse().map(c=>`<div style="padding:8px 14px;border-bottom:1px solid var(--bd0)"><div style="display:flex;align-items:center;gap:5px;margin-bottom:3px"><div style="width:16px;height:16px;border-radius:50%;background:${getCompanyBrandColour((DB.getUsers().find(u=>u.name===c.author)||{companies:[]}).companies?.[0]||'')};color:${getContrastText(getCompanyBrandColour((DB.getUsers().find(u=>u.name===c.author)||{companies:[]}).companies?.[0]||''))}};display:flex;align-items:center;justify-content:center;font-size:7px;font-weight:700;color:#fff">${(c.author||'?')[0]}</div><span style="font-size:11px;font-weight:600">${c.author||'User'}</span><span style="font-size:10px;color:var(--t2);margin-left:auto">${new Date(c.ts).toLocaleDateString('en-GB',{day:'numeric',month:'short'})}</span></div><div style="font-size:11.5px">${c.text}</div></div>`).join(''):'<div style="font-size:11px;color:var(--t2);padding:8px 14px">No comments yet</div>';})()}</div><div style="padding:8px 14px;border-top:1px solid var(--bd0)"><textarea class="fi" id="rv-cmp-cmt-b" rows="2" placeholder="Add comment…" style="font-size:11.5px;resize:none;margin-bottom:4px"></textarea><button class="btn btn-o btn-sm" style="width:100%" onclick="RV._addCmpComment('${j.id}','${vB.id}','rv-cmp-cmt-b',${idxA},${idxB})">Post</button></div></div>
        </div>
      </div>`;
    el.insertAdjacentElement('afterbegin',overlay);
    // Initialise annotation layer on verA (the "from" version)
    setTimeout(()=>{
      const verA=j.versions[idxA];
      if(verA) this._setupDrawing(j.id, verA.id);
      if(vB){const rw=document.getElementById('rv-canvas-'+j.id+'-b');if(rw)RV._setupDrawing(j.id,vB.id,'b');}
    },150);
    // Inject annotation toolbar into compare overlay
    // Toolbars now rendered in HTML template per-side
    // Init PDFs in compare
    setTimeout(()=>{
      // Init PDFs in compare using pdfState so page controls and annotations work
      [{side:'a',f:fileA,v:vA},{side:'b',f:fileB,v:vB}].forEach(({side,f,v})=>{
        if(f?.url&&f.type==='pdf'){
          const cmpJobId=j.id+'-cmp-'+side;  // unique key per compare side
          RV._pdfState[cmpJobId]&&RV._pdfState[cmpJobId];  // keep existing state if any
          RV.pdfInit(cmpJobId,f.url,v?.id);
        }
      });
    },200);
    const selA=document.getElementById('rv-cmp-a');
    const selB=document.getElementById('rv-cmp-b');
    if(selA) selA.value=idxA;
    if(selB) selB.value=idxB;
  },

  downloadFile(jobId,versionId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    const ver=j.versions.find(v=>v.id===versionId)||j.versions[j.versions.length-1];
    if(!ver?.files?.length) return;
    RV_DB.logActivity(jobId,S.user?.name||'User','Downloaded '+ver.label,'⬇');
    // In a real system this would trigger a file download
    alert('Download: '+ver.files.map(f=>f.name).join(', '));
  },

  _populateAssignedUsers(clientId, preSelected){
    const pre=Array.isArray(preSelected)?preSelected:(preSelected||'').split(',').map(s=>s.trim()).filter(Boolean);
    const mkItem=(u,wrap)=>`<label style="display:flex;align-items:center;gap:8px;padding:5px 8px;border-radius:var(--rs);cursor:pointer;font-size:12px;color:var(--t0)" onmouseover="this.style.background='var(--bg2)'" onmouseout="this.style.background=''">`
      +`<input type="checkbox" data-name="${u.name}" value="${u.name}" ${pre.includes(u.name)?'checked':''} style="width:13px;height:13px;cursor:pointer;accent-color:var(--o)">`
      +`<div style="width:20px;height:20px;border-radius:50%;background:${getCompanyBrandColour((u.companies||[u.company].filter(Boolean))[0]||u.id)};display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:700;color:#fff;flex-shrink:0">${u.initials||u.name[0]}</div>`
      +`<span>${u.name}</span>`
      +`</label>`;
    // Internal (Karbon) team — kc company admins
    const intWrap=document.getElementById('rvj-assigned-wrap');
    const kcUsers=DB.getUsers().filter(u=>u.role==='admin'&&(u.companies||[u.company].filter(Boolean)).includes('kc'));
    const intUsers=kcUsers.length?kcUsers:DB.getUsers().filter(u=>u.role==='admin');
    if(intWrap) intWrap.innerHTML=intUsers.length?intUsers.map(u=>mkItem(u,'int')).join(''):'<div style="font-size:11px;color:var(--t2);padding:6px">No internal users</div>';
    // Client users — belonging to the selected client's company
    const cliWrap=document.getElementById('rvj-client-assigned-wrap');
    if(cliWrap){
      const clientCo=DB.getCompanies().find(co=>(co.clientIds||[]).includes(clientId));
      const cliUsers=clientCo?DB.getUsers().filter(u=>u.role==='client'&&(u.companies||[u.company].filter(Boolean)).includes(clientCo.id)):[];
      cliWrap.innerHTML=cliUsers.length?cliUsers.map(u=>mkItem(u,'cli')).join(''):'<div style="font-size:11px;color:var(--t2);padding:6px">No client users for this company</div>';
    }
    // Populate company filter dropdown
    const coSel=document.getElementById('rvj-assign-company');
    if(coSel&&coSel.options.length<=1) DB.getCompanies().forEach(co=>{coSel.innerHTML+=`<option value="${co.id}">${co.name}</option>`;});
  },
  _getAssignedFromCheckboxes(){
    const all=[];
    document.querySelectorAll('#rvj-assigned-wrap input[type="checkbox"]:checked,#rvj-client-assigned-wrap input[type="checkbox"]:checked').forEach(cb=>all.push(cb.value));
    return all.join(', ');
  },
  onClientChange(){
    const clientId=document.getElementById('rvj-client')?.value;
    const existing=this._getAssignedFromCheckboxes();
    // Reset company filter when client changes
    const coSel=document.getElementById('rvj-assign-company');
    if(coSel){
      coSel.innerHTML='<option value="">All team members</option>'
        +DB.getCompanies().map(co=>`<option value="${co.id}">${co.name}</option>`).join('');
      coSel.value='';
    }
    this._populateAssignedUsers(clientId, existing.split(',').map(s=>s.trim()).filter(Boolean));
  },

  onAssignCompanyChange(){
    const clientId=document.getElementById('rvj-client')?.value;
    const coId=document.getElementById('rvj-assign-company')?.value;
    const existing=this._getAssignedFromCheckboxes();
    // Filter users by selected company (or all if empty)
    const admins=DB.getUsers().filter(u=>u.role==='admin');
    const filtered=coId?admins.filter(u=>(u.companies||[u.company].filter(Boolean)).includes(coId)):admins;
    const pre=existing.split(',').map(s=>s.trim()).filter(Boolean);
    const wrap=document.getElementById('rvj-assigned-wrap'); if(!wrap) return;
    wrap.innerHTML=(filtered.length?filtered:admins).map(u=>`<label style="display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:var(--rs);cursor:pointer;font-size:12.5px;color:var(--t0);transition:background .13s" onmouseover="this.style.background='var(--bg2)'" onmouseout="this.style.background=''">`
      +`<input type="checkbox" value="${u.name}" ${pre.includes(u.name)?'checked':''} style="width:14px;height:14px;cursor:pointer;accent-color:var(--o)">`
      +`<div style="width:22px;height:22px;border-radius:50%;background:${getCompanyBrandColour((u.companies||[u.company].filter(Boolean))[0]||u.id)};display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:700;color:#fff;flex-shrink:0">${u.initials||u.name[0]}</div>`
      +`<span>${u.name}</span><span style="font-size:10px;color:var(--t2);margin-left:auto">${(u.companies||[]).map(cid=>DB.getCompanies().find(c=>c.id===cid)?.name||cid).join(', ')}</span>`
      +`</label>`).join('');
  },
  onFolderSelect(val){
    const inp=document.getElementById('rvj-folder');
    if(inp){ inp.style.display=val==='__new'?'block':'none'; inp.value=''; }
  },

  newJobModal(defaultStatus, defaultClientId){
    if(S.user?.role==='client') return;
    const clientEl=document.getElementById('rvj-client');
    if(clientEl) clientEl.innerHTML='<option value="">Select Client</option>'+DB.getParents().map(c=>`<option value="${c.id}" ${c.id===defaultClientId?'selected':''}>${c.name}</option>`).join('');
    document.getElementById('rvj-title').value='';
    document.getElementById('rvj-desc').value='';
    document.getElementById('rvj-due').value='';
    document.getElementById('rvj-status').value=defaultStatus||'ir:draft';
    document.getElementById('rvj-id').value='';
    document.getElementById('rv-job-modal-title').textContent='Create new job';
    const jn=document.getElementById('rvj-jobno'); if(jn) jn.value='';
    // Populate folder dropdown with existing folders
    const folderSel=document.getElementById('rvj-folder-sel');
    if(folderSel){
      // Build folder list from both RV_DB._folders (new) and existing job folders (legacy)
      const savedFolders=RV_DB._folders?Object.values(RV_DB._folders).filter(f=>!defaultClientId||f.clientId===defaultClientId):[];
      // Build indented folder tree: root folders first, then their children
      const rootFolders=savedFolders.filter(f=>!f.parentId);
      const childFolders=savedFolders.filter(f=>f.parentId);
      const folderOpts=[];
      rootFolders.sort((a,b)=>a.name.localeCompare(b.name)).forEach(rf=>{
        folderOpts.push({id:rf.id,label:rf.name,indent:0});
        childFolders.filter(cf=>cf.parentId===rf.id).sort((a,b)=>a.name.localeCompare(b.name)).forEach(cf=>{
          folderOpts.push({id:cf.id,label:'— '+cf.name,indent:1});
        });
      });
      // Add legacy folders (string-based, not yet in _folders)
      const legacyFolderNames=[...new Set(RV_DB._jobs.filter(j=>j.folder&&(!defaultClientId||j.clientId===defaultClientId)).map(j=>j.folder))].filter(fn=>!savedFolders.find(sf=>sf.name===fn));
      legacyFolderNames.sort().forEach(fn=>folderOpts.push({id:fn,label:fn,indent:0}));
      folderSel.innerHTML='<option value="">— Select folder —</option>'
        +folderOpts.map(f=>`<option value="${f.id}">${f.label}</option>`).join('')
        +'<option value="__new">+ Create new folder…</option>';
      folderSel.value='';
    }
    const folderInp=document.getElementById('rvj-folder');
    if(folderInp){ folderInp.value=''; folderInp.style.display='none'; }
    // Populate company filter dropdown
    const coSel=document.getElementById('rvj-assign-company');
    if(coSel){
      coSel.innerHTML='<option value="">All team members</option>'
        +DB.getCompanies().map(co=>`<option value="${co.id}">${co.name}</option>`).join('');
      coSel.value='';
    }
    RV._populateAssignedUsers(defaultClientId||null, []);
    // Populate company filter dropdown for assigned-to
    const _njCoSel=document.getElementById('rvj-assign-company');
    if(_njCoSel){
      _njCoSel.innerHTML='<option value="">All team members</option>'
        +DB.getCompanies().map(co=>`<option value="${co.id}">${co.name}</option>`).join('');
      _njCoSel.value='';
    }
    RV._populateAssignedUsers(defaultClientId||null, []);
    MODAL.open('modal-rv-job');
  },

  editJobModal(id){
    const j=RV_DB.getJob(id); if(!j) return;
    // Populate client dropdown
    const clientEl=document.getElementById('rvj-client');
    if(clientEl) clientEl.innerHTML=DB.getParents().map(c=>`<option value="${c.id}" ${c.id===j.clientId?'selected':''}>${c.name}</option>`).join('');
    // Basic fields
    document.getElementById('rvj-title').value=j.title;
    document.getElementById('rvj-desc').value=j.desc||'';
    document.getElementById('rvj-due').value=j.due||'';
    document.getElementById('rvj-status').value=j.status;
    document.getElementById('rvj-id').value=id;
    const jn=document.getElementById('rvj-jobno'); if(jn) jn.value=j.jobNo||'';
    document.getElementById('rv-job-modal-title').textContent='Edit job';
    // Folder: populate dropdown with existing folders, pre-select current
    const folderSel=document.getElementById('rvj-folder-sel');
    if(folderSel){
      const existingFolders=[...new Set(RV_DB._jobs.map(x=>x.folder).filter(Boolean))].sort();
      folderSel.innerHTML='<option value="">— Select folder —</option>'
        +existingFolders.map(f=>`<option value="${f}" ${f===j.folder?'selected':''}>${f}</option>`).join('')
        +'<option value="__new">+ Create new folder…</option>';
    }
    const folderInp=document.getElementById('rvj-folder');
    if(folderInp){ folderInp.value=''; folderInp.style.display='none'; }
    const _ejCoSel=document.getElementById('rvj-assign-company');
    if(_ejCoSel){
      _ejCoSel.innerHTML='<option value="">All team members</option>'
        +DB.getCompanies().map(co=>`<option value="${co.id}">${co.name}</option>`).join('');
      _ejCoSel.value='';
    }
    RV._populateAssignedUsers(j.clientId, (j.assignedTo||'').split(',').map(s=>s.trim()).filter(Boolean));
        MODAL.open('modal-rv-job');
  },

  saveJob(){
    const id=document.getElementById('rvj-id').value;
    const data={
      title:document.getElementById('rvj-title').value.trim(),
      jobNo:document.getElementById('rvj-jobno')?.value.trim()||null,
      clientId:document.getElementById('rvj-client').value,
      folder:(()=>{
        const sel=document.getElementById('rvj-folder-sel')?.value;
        const inp=document.getElementById('rvj-folder')?.value?.trim();
        const fv=sel&&sel!=='__new'?sel:(inp||'');
        // Try to resolve folder name from ID
        const fobj=RV_DB._folders?.[fv]||Object.values(RV_DB._folders||{}).find(f=>f.id===fv);
        return fobj?fobj.name:fv;
      })(),
      folderId:(()=>{
        const sel=document.getElementById('rvj-folder-sel')?.value;
        const fobj=RV_DB._folders?.[sel]||Object.values(RV_DB._folders||{}).find(f=>f.id===sel);
        return fobj?fobj.id:'';
      })(),
      status:document.getElementById('rvj-status').value,
      due:document.getElementById('rvj-due').value||null,
      desc:document.getElementById('rvj-desc').value.trim(),
      assignedTo:this._getAssignedFromCheckboxes(),
    };
    if(!data.title){ document.getElementById('rvj-title').focus(); return; }
    if(id){ RV_DB.updateJob(id,data); }
    else{ RV_DB.createJob(data); }
    // Notify assigned users
    if(data.assignedTo){
      data.assignedTo.split(',').map(s=>s.trim()).filter(Boolean).forEach(name=>{
        if(name&&name!==S.user?.name){
          RV_DB.addNotification('assign',id||RV_DB._jobs[RV_DB._jobs.length-1]?.id,
            (S.user?.name||'Admin')+' assigned you to "'+data.title+'"',name);
        }
      });
    }
    // Audit log
    const _auditJobId=id||RV_DB._jobs[RV_DB._jobs.length-1]?.id;
    const _auditJob=RV_DB.getJob(_auditJobId);
    RV_DB.logActivity(_auditJobId, S.user?.name||'Admin',
      id?'Job edited: '+data.title:'Job created: '+data.title,
      id?'✏️':'✨',
      {type:id?'edit':'create', detail:(id?'Edited':'Created')+' job "'+data.title+'"'+(data.folder?' in '+data.folder:'')}
    );
    MODAL.close('modal-rv-job');
    this.buildKanban();
    this.buildJobsList();
    this.buildDashboard();
    this.buildClientNav();
    this._updateBadge();
    this._updateReviewBadge();
    this._updateReviewBadge();
    // Refresh client folder view if it's currently visible
    const clientView=document.getElementById('v-rv-client');
    if(clientView?.classList.contains('on')){
      const cid=document.getElementById('rvj-client')?.value;
      if(cid) this.openClient(cid,null);
    }
    if(id){
      this.openJob(id);
    } else {
      // New job: open job view then show upload modal
      const newJob=RV_DB._jobs[RV_DB._jobs.length-1];
      if(newJob){
        this._currentJob=newJob.id;
        this.openJob(newJob.id);
        // Note: upload modal is not auto-opened to avoid state conflicts.
        // User clicks "Upload version" button after job is created.
      }
    }
  },

  _uploadState:{jobId:null,files:[],label:''},

  uploadModal(jobId){
    const id=jobId||this._currentJob;
    if(!id){ console.warn('uploadModal: no jobId'); return; }
    // Reset state fresh every time
    this._uploadState={jobId:id,files:[],label:'V'+((RV_DB.getJob(id)?.versions.length||0)+1)};
    this._currentJob=id;
    // Populate modal fields
    const rjid=document.getElementById('rvu-job-id');
    const rlbl=document.getElementById('rvu-label');
    const rnot=document.getElementById('rvu-notes');
    const rlst=document.getElementById('rvu-file-list');
    if(!rjid||!rlbl){ console.error('uploadModal: modal DOM missing'); return; }
    rjid.value=id;
    rlbl.value=this._uploadState.label;
    if(rnot) rnot.value='';
    if(rlst) rlst.innerHTML='';
    this._pendingFiles=[]; // keep in sync for handleFileSelect compatibility
    const dz=document.getElementById('rvu-dropzone');
    if(dz){ dz.style.borderColor=''; dz.style.background=''; }
    MODAL.open('modal-rv-upload');
  },

  handleFileSelect(input){
    const files=[...(input.files||[])];
    console.log('[UPLOAD] handleFileSelect files='+files.length);
    this._pendingFiles=files;
    if(this._uploadState) this._uploadState.files=files;
    // Reset input value so same file can be re-selected and onchange fires again
    if(input.value!==undefined) try{ input.value=''; }catch(e){}
    const list=document.getElementById('rvu-file-list');
    list.innerHTML=this._pendingFiles.map(f=>`
      <div style="display:flex;align-items:center;gap:6px;background:var(--bg2);border-radius:var(--rs);padding:5px 8px;font-size:11.5px">
        <span>${/\.(jpg|jpeg|png|svg|gif)$/i.test(f.name)?'🖼':/\.pdf$/i.test(f.name)?'📄':/\.(mp4|mov)$/i.test(f.name)?'🎥':'📁'}</span>
        <span>${f.name}</span>
        <span style="color:var(--t2);margin-left:auto">${(f.size/1024/1024).toFixed(1)}MB</span>
      </div>`).join('');
    // Set up dropzone drag-drop
    const dz=document.getElementById('rvu-dropzone');
    if(dz){ dz.style.borderColor='var(--o)'; dz.style.background='rgba(237,114,9,.04)'; }
  },

  uploadVersion(){
    const st=this._uploadState||{};
    const jobId=st.jobId||document.getElementById('rvu-job-id')?.value;
    const label=(document.getElementById('rvu-label')?.value||'').trim()||st.label||'New version';
    const notes=(document.getElementById('rvu-notes')?.value||'').trim();
    const files=st.files||this._pendingFiles||[];
    console.log('[UPLOAD] uploadVersion jobId='+jobId+' files='+files.length+' label='+label);
    // BLOCK if no files selected
    if(!files.length){
      const rlst=document.getElementById('rvu-file-list');
      if(rlst) rlst.innerHTML='<div style="color:#E84545;font-size:12px;padding:6px 0">Please select a file before uploading.</div>';
      return;
    }
    if(!jobId){ console.error('uploadVersion: no jobId'); return; }
    // Convert files to data URLs
    const filePromises=files.map(f=>new Promise(res=>{
      if(/\.(jpg|jpeg|png|svg|gif)$/i.test(f.name)){
        const r=new FileReader(); r.onload=e=>res({name:f.name,type:'image',url:e.target.result,size:(f.size/1024/1024).toFixed(1)+'MB'}); r.readAsDataURL(f);
      } else if(/\.pdf$/i.test(f.name)){
        const r=new FileReader(); r.onload=e=>res({name:f.name,type:'pdf',url:e.target.result,size:(f.size/1024/1024).toFixed(1)+'MB'}); r.readAsDataURL(f);
      } else if(/\.(mp4|mov|webm|avi|mkv)$/i.test(f.name)){
        const r=new FileReader(); r.onload=e=>res({name:f.name,type:'video',url:e.target.result,size:(f.size/1024/1024).toFixed(1)+'MB'}); r.readAsDataURL(f);
      } else {
        res({name:f.name,type:'doc',url:'',size:(f.size/1024/1024).toFixed(1)+'MB'});
      }
    }));
    Promise.all(filePromises).then(resolvedFiles=>{
      const newVer=RV_DB.addVersion(jobId,{label,notes,files:resolvedFiles.filter(f=>f&&f.name)});
      RV_DB.logActivity(jobId, (S.user&&S.user.name)||'User', 'Version uploaded', '', {
        type:'upload', detail:'Uploaded '+resolvedFiles.filter(f=>f&&f.name).length+' file(s) — '+label
      });
      const _uj=RV_DB.getJob(jobId);
      if(_uj?.assignedTo) _uj.assignedTo.split(',').map(s=>s.trim()).filter(Boolean).forEach(name=>{
        if(name&&name!==S.user?.name) RV_DB.addNotification('upload',jobId,(S.user?.name||'Admin')+' uploaded '+label+' to "'+(_uj.title||'a job')+'"',name);
      });
      this._uploadState={jobId:null,files:[],label:''};
      this._pendingFiles=[];
      MODAL.close('modal-rv-upload');
      this.openJob(jobId);
      this.buildKanban();
      this._updateBadge();
    });
  },

  decisionModal(jobId,action){
    document.getElementById('rv-dec-job-id').value=jobId;
    document.getElementById('rv-dec-action').value=action;
    document.getElementById('rv-dec-notes').value='';
    const j=RV_DB.getJob(jobId);
    if(action==='approve'){
      document.getElementById('rv-dec-title').textContent='Approve this job';
      document.getElementById('rv-dec-body').textContent='Are you happy with the latest version? Approving will move this job to Approved status.';
      document.getElementById('rv-dec-confirm').textContent=' Approve';
      document.getElementById('rv-dec-confirm').className='btn btn-o';
    } else {
      document.getElementById('rv-dec-title').textContent='Request changes';
      document.getElementById('rv-dec-body').textContent='Please describe the changes needed. This will move the job to Amendments status.';
      document.getElementById('rv-dec-confirm').textContent='✏️ Send for amendments';
      document.getElementById('rv-dec-confirm').className='btn btn-r';
    }
    MODAL.open('modal-rv-decision');
  },

  shareJob(jobId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    const c=DB.getClient(j.clientId);
    document.getElementById('sj-job-id').value=jobId;
    document.getElementById('sj-job-info').innerHTML='<strong>'+j.title+'</strong> <span style="color:var(--t2);font-size:11.5px">'+( c?.name||'')+(j.folder?' · '+j.folder:'')+'</span>';
    const clientUsers=(DB._users||[]).filter(u=>u.role==='client'&&(u.client_ids||[]).includes(j.clientId));
    document.getElementById('sj-users').innerHTML=clientUsers.length
      ?clientUsers.map(u=>'<div style="display:flex;align-items:center;gap:8px;padding:6px 8px;background:var(--bg1);border-radius:var(--rs);font-size:12.5px"><div style="width:24px;height:24px;border-radius:50%;background:${getCompanyBrandColour((u.companies||[u.company].filter(Boolean))[0]||u.id)};color:${getContrastText(getCompanyBrandColour((u.companies||[u.company].filter(Boolean))[0]||u.id))};display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700">'+u.name[0]+'</div>'+u.name+'</div>').join('')
      :'<div style="font-size:12.5px;color:var(--t2)">No client users assigned to this client yet.</div>';
    document.getElementById('sj-move-status').checked=true;
    MODAL.open('modal-share-job');
  },
  confirmShare(){
    const jobId=document.getElementById('sj-job-id').value; if(!jobId) return;
    if(document.getElementById('sj-move-status').checked){
      const j=RV_DB.getJob(jobId); if(j&&j.status!=='cr:signed_off') j.status='cr:ready';
    }
    RV_DB.logActivity(jobId,S.user?.name||'Admin','Shared with client','');
    MODAL.close('modal-share-job');
    this.openJob(jobId); this.buildKanban(); this._updateBadge();
  },
  confirmDecision(){
    const jobId=document.getElementById('rv-dec-job-id').value;
    const action=document.getElementById('rv-dec-action').value;
    const notes=document.getElementById('rv-dec-notes').value.trim();
    const newStatus=action==='approve'?'approved':'amendments';
    RV_DB.updateJob(jobId,{status:newStatus});
    if(notes) RV_DB.addComment(jobId,null,{text:notes});
    RV_DB.logActivity(jobId,S.user?.name||'Client',action==='approve'?'Approved the job':'Requested amendments',action==='approve'?'':'✏️');
    MODAL.close('modal-rv-decision');
    this.openJob(jobId);
    this.buildKanban();
    this._updateBadge();
  },

  buildBrandChecker(){
    const el=document.getElementById('rv-brand-content'); if(!el) return;
    const terms=RV_DB._brand_terms;
    el.innerHTML=`
      <p style="font-size:13px;color:var(--t1);margin-bottom:18px">Define brand terminology rules. The AI checker will scan uploaded copy and flag any violations before client submission.</p>
      <div style="display:flex;gap:8px;margin-bottom:18px">
        <button class="btn btn-o btn-sm" onclick="RV.addBrandTermModal()">+ Add rule</button>
      </div>
      <div style="margin-bottom:18px">
        ${terms.length?terms.map(t=>`
          <div class="rv-flag ${t.severity}" style="margin-bottom:8px">
            <div style="flex:1">
              <div style="font-size:12.5px;font-weight:600">"${t.term}" ${t.replace?'→ "'+t.replace+'"':''}</div>
              <div style="font-size:11px;color:var(--t2);margin-top:2px">${{error:'Must fix',warn:'Should fix',info:'Suggestion'}[t.severity]||t.severity}${t.clientId?' · '+( DB.getClient(t.clientId)?.name||t.clientId):' · All clients'}</div>
            </div>
            <button onclick="RV_DB._brand_terms=RV_DB._brand_terms.filter(x=>x.id!=='${t.id}');RV.buildBrandChecker()" style="background:none;border:none;cursor:pointer;color:var(--r);font-size:12px;padding:0">✕</button>
          </div>`).join('')
        :'<div class="ins a"><p>No brand rules defined yet. Add rules to enable the copy checker.</p></div>'}
      </div>
      <div style="border-top:1px solid var(--bd0);padding-top:18px">
        <div style="font-size:13px;font-weight:600;margin-bottom:10px">Check copy text</div>
        <textarea class="fi" id="rv-check-text" rows="5" placeholder="Paste copy or document text here to check for brand violations…" style="resize:vertical"></textarea>
        <button class="btn btn-o btn-sm" style="margin-top:8px" onclick="RV.runBrandCheck()">Run check</button>
        <div id="rv-check-results" style="margin-top:12px"></div>
      </div>`;
  },

  addBrandTermModal(){
    const el=document.getElementById('rvbt-client');
    if(el) el.innerHTML='<option value="">All clients</option>'+DB.getParents().map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
    document.getElementById('rvbt-term').value='';
    document.getElementById('rvbt-replace').value='';
    document.getElementById('rvbt-severity').value='warn';
    MODAL.open('modal-rv-brand-term');
  },

  saveBrandTerm(){
    const term=document.getElementById('rvbt-term').value.trim(); if(!term) return;
    RV_DB._brand_terms.push({
      id:'bt-'+Date.now(),
      term,
      replace:document.getElementById('rvbt-replace').value.trim(),
      severity:document.getElementById('rvbt-severity').value,
      clientId:document.getElementById('rvbt-client').value
    });
    MODAL.close('modal-rv-brand-term');
    this.buildBrandChecker();
  },

  runBrandCheck(){
    const text=document.getElementById('rv-check-text')?.value||'';
    const el=document.getElementById('rv-check-results'); if(!el) return;
    if(!text.trim()){ el.innerHTML='<div class="ins a"><p>Enter some text above to check.</p></div>'; return; }
    const flags=[];
    RV_DB._brand_terms.forEach(rule=>{
      const regex=new RegExp(rule.term.replace(/[.*+?^${}()|\[\]\\]/g,'\$&'),'gi');
      const matches=[...text.matchAll(regex)];
      if(matches.length){
        flags.push({...rule,count:matches.length});
      }
    });
    if(!flags.length){
      el.innerHTML='<div class="ins g"><p> No brand violations found. The copy looks clean.</p></div>';
    } else {
      el.innerHTML='<div style="font-size:12px;font-weight:700;color:var(--t2);text-transform:uppercase;letter-spacing:.6px;margin-bottom:8px">'+flags.length+' issue'+( flags.length>1?'s':'')+' found</div>'
        +flags.map(f=>`<div class="rv-flag ${f.severity}">
          <div style="flex:1">
            <div style="font-size:12.5px;font-weight:600">"${f.term}" — found ${f.count}×</div>
            ${f.replace?`<div style="font-size:11.5px;color:var(--t2);margin-top:2px">Suggestion: use "${f.replace}" instead</div>`:''}
          </div>
          <span class="kb-pill ${f.severity==='error'?'overdue':f.severity==='warn'?'amend':'review'}">${f.severity}</span>
        </div>`).join('');
    }
  },

  buildActivity(){
    const el=document.getElementById('rv-activity-list'); if(!el) return;
    const isClient=S.user?.role==='client';
    const allowed=this._getAllowedClients();
    const jobs=RV_DB._jobs.filter(j=>!isClient||allowed.includes(j.clientId));
    const allActivity=jobs.flatMap(j=>j.activity.map(a=>({...a,jobTitle:j.title,jobId:j.id}))).sort((a,b)=>new Date(b.ts)-new Date(a.ts));
    el.innerHTML=allActivity.length?allActivity.slice(0,50).map(a=>`
      <div class="rv-activity-item" onclick="RV.openJob('${a.jobId}')" style="cursor:pointer">
        <div class="rv-activity-ico">${a.icon}</div>
        <div style="flex:1">
          <div class="rv-activity-text"><strong>${a.user}</strong> ${a.action}</div>
          <div style="font-size:10.5px;color:var(--t2);margin-top:2px">${a.jobTitle}</div>
        </div>
        <div class="rv-activity-time">${new Date(a.ts).toLocaleDateString('en-GB',{day:'numeric',month:'short'})}</div>
      </div>`).join('')
    :'<div class="ins a"><p>No activity yet.</p></div>';
  },

  async runJobAIReview(jobId){
    const el=document.getElementById('rv-brand-job-'+jobId); if(!el) return;
    const j=RV_DB.getJob(jobId); if(!j) return;
    el.style.display='block';
    el.innerHTML='<div style="font-size:12px;color:var(--t2);padding:8px">Analysing content…</div>';
    // Collect all text from job: title, desc, comments, + any text embedded in filenames/labels
    const textSources=[];
    textSources.push('Job title: '+j.title);
    if(j.desc) textSources.push('Description: '+j.desc);
    j.comments.forEach(c=>textSources.push('Comment: '+c.text));
    j.versions.forEach(v=>{
      v.files.forEach(f=>textSources.push('File: '+f.name));
      v.comments.forEach(c=>textSources.push('Version comment: '+c.text));
      if(v.notes) textSources.push('Version notes: '+v.notes);
    });
    const inputText=textSources.join('\n');
    // Brand/restricted term check (local, fast)
    const clientTerms=RV_DB._brand_terms.filter(t=>!t.clientId||t.clientId===j.clientId);
    const localFlags=[];
    clientTerms.forEach(rule=>{
      const regex=new RegExp(rule.term.replace(/[.*+?^${}()|\[\]\\]/g,'\$&'),'gi');
      const matches=[...inputText.matchAll(regex)];
      if(matches.length) localFlags.push('• "'+rule.term+'" found '+matches.length+'× — '+({error:'Must fix',warn:'Should fix',info:'Suggestion'}[rule.severity]||rule.severity)+(rule.replace?' → "'+rule.replace+'"':''));
    });
    // AI analysis via Anthropic API
    try{
      const resp=await fetch('https://api.anthropic.com/v1/messages',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
          model:'claude-sonnet-4-20250514',max_tokens:800,
          messages:[{role:'user',content:`You are a senior marketing copywriter reviewing creative work. Analyse the following text from a review job and identify issues. Check for:
1. British English spelling (flag American English: color→colour, center→centre, analyze→analyse, etc.)
2. Placeholder copy (lorem ipsum, [INSERT], TBC, PLACEHOLDER, etc.)
3. Grammar or punctuation issues
4. Tone inconsistencies
5. URL or formatting issues
6. Repetitive or unclear copy

Be specific and concise. List each issue on a new line with its severity (ERROR/WARNING/SUGGESTION). If no issues found, say "No issues detected."

TEXT TO REVIEW:
${inputText.slice(0,2000)}`}]
        })
      });
      const data=await resp.json();
      const aiText=data?.content?.[0]?.text||'No response from AI.';
      const lines=aiText.split('\n').filter(l=>l.trim());
      const formatted=lines.map(l=>{
        const sev=l.startsWith('ERROR')?'error':l.startsWith('WARNING')?'warn':l.startsWith('SUGGESTION')?'info':'';
        return`<div class="rv-flag ${sev}" style="padding:6px 10px;margin-bottom:5px;font-size:11.5px">${l}</div>`;
      }).join('');
      el.innerHTML=(localFlags.length?'<div style="font-size:10.5px;font-weight:700;color:var(--o);margin-bottom:6px">Brand rules:</div>'+localFlags.map(f=>'<div class="rv-flag warn" style="padding:5px 9px;margin-bottom:4px;font-size:11px">'+f+'</div>').join(''):'')
        +'<div style="font-size:10.5px;font-weight:700;color:var(--t2);margin-bottom:6px;margin-top:'+(localFlags.length?'10':0)+'px">AI review:</div>'
        +(formatted||'<span style="color:#16A34A;font-size:11.5px"> No issues detected.</span>');
    }catch(err){
      // Fallback to local checks only
      el.innerHTML=(localFlags.length?localFlags.map(f=>'<div class="rv-flag warn" style="padding:5px 9px;margin-bottom:4px;font-size:11px">'+f+'</div>').join('')
        :'<div class="ins g" style="font-size:11.5px"><p> No brand issues found. AI analysis unavailable offline.</p></div>');
    }
  },

  runJobBrandCheck(jobId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    const el=document.getElementById('rv-brand-job-'+jobId); if(!el) return;
    // Collect all text from job title, desc, comments
    const text=[j.title,j.desc,...j.comments.map(c=>c.text),...j.versions.flatMap(v=>v.comments.map(c=>c.text))].join(' ');
    const clientTerms=RV_DB._brand_terms.filter(t=>!t.clientId||t.clientId===j.clientId);
    const flags=[];
    clientTerms.forEach(rule=>{
      const regex=new RegExp(rule.term.replace(/[.*+?^${}()|\[\]\\]/g,'\$&'),'gi');
      const matches=[...text.matchAll(regex)];
      if(matches.length) flags.push({...rule,count:matches.length});
    });
    if(!flags.length){
      el.innerHTML='<div class="ins g" style="font-size:11.5px;padding:8px 10px"><p> No brand issues found.</p></div>';
    } else {
      el.innerHTML=flags.map(f=>`<div class="rv-flag ${f.severity}" style="padding:7px 10px;margin-bottom:5px">
        <div style="font-size:11.5px"><strong>"${f.term}"</strong> — ${f.count}× ${f.replace?'→ "'+f.replace+'"':''}</div>
      </div>`).join('');
    }
  },

  async runSpellCheck(jobId){
    const j=RV_DB.getJob(jobId); if(!j) return;
    const el=document.getElementById('rv-brand-job-'+jobId); if(!el) return;
    el.style.display='block';
    el.innerHTML='<div style="font-size:12px;color:var(--t2);padding:8px">Extracting text from file…</div>';
    const latestVer=j.versions[j.versions.length-1];
    const file=latestVer?.files[0];
    const isImg=file?.url&&(file?.type==='image'||/\.(jpg|jpeg|png|gif)$/i.test(file?.name||''));
    let messages;
    if(isImg){
      const b64=file.url.includes(',')?(file.url.split(',')[1]||''):file.url;
      const mt=(/\.png$/i.test(file.name||''))?'image/png':(/\.gif$/i.test(file.name||''))?'image/gif':'image/jpeg';
      messages=[{role:'user',content:[
        {type:'image',source:{type:'base64',media_type:mt,data:b64}},
        {type:'text',text:'You are a British English proofreader reviewing marketing artwork. Extract ALL visible text from this image. Then identify: 1) Spelling mistakes (including American spellings — flag color→colour, center→centre etc.) 2) Grammar errors 3) Punctuation issues 4) Repeated words 5) Placeholder text (TBC, Lorem ipsum, INSERT, [X]) 6) Missing apostrophes 7) Incorrect capitalisation. For each issue output exactly: TYPE | Found: "text" | Suggest: "correction". If no issues, say only: No issues found.'}
      ]}];
    } else {
      const parts=[j.title,j.desc||'',...j.comments.map(c=>c.text),...j.versions.flatMap(v=>[v.notes||'',...v.comments.map(c=>c.text)])];
      const text=parts.filter(Boolean).join(' ');
      messages=[{role:'user',content:'British English proofreader. Check this marketing copy for spelling, grammar, punctuation, repeated words, placeholders, missing apostrophes. For each issue: TYPE | Found: "text" | Suggest: "correction". If none, say: No issues found. Copy: '+text}];
    }
    el.innerHTML='<div style="font-size:12px;color:var(--t2);padding:8px">Analysing with AI…</div>';
    try{
      const resp=await fetch('https://api.anthropic.com/v1/messages',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({model:'claude-sonnet-4-20250514',max_tokens:1000,messages})
      });
      const data=await resp.json();
      const result=(data?.content?.[0]?.text||'').trim();
      if(!result||result.toLowerCase().startsWith('no issues')){
        el.innerHTML='<div style="font-size:12px;color:#16A34A;padding:10px;display:flex;align-items:center;gap:6px"><svg viewBox="0 0 16 16" fill="none" stroke="#16A34A" stroke-width="1.8" width="14" height="14"><polyline points="3 8 6 11 13 4"/></svg> No issues found.</div>';
      } else {
        const lines=result.split('\n').filter(l=>l.trim());
        const issueLines=lines.filter(l=>l.includes('|'));
        el.innerHTML='<div style="font-size:11px;font-weight:700;color:var(--o);padding:6px 9px;border-bottom:1px solid var(--bd0)">Spell &amp; Grammar Check</div>'
          +(issueLines.length?issueLines.map(line=>{
            const parts=(line+'||').split('|').map(s=>s.replace(/^(Found:|Suggest:)/i,'').replace(/^"|"$/g,'').trim());
            const[type,found,sug]=parts;
            const col=/spell/i.test(type)?'#E84545':/gram/i.test(type)?'#ED7209':'#3B82F6';
            return'<div style="padding:7px 9px;border-bottom:1px solid var(--bd0);font-size:12px">'
              +'<span style="color:'+col+';font-size:10px;font-weight:700;text-transform:uppercase;display:block;margin-bottom:2px">'+type+'</span>'
              +(found?'<span style="color:var(--t1)">'+found+'</span>':'')+( sug?' <span style="color:var(--t2)">→</span> <strong>'+sug+'</strong>':'')+'</div>';
          }).join(''):'<div style="padding:8px;font-size:12px;color:var(--t1)">'+result+'</div>');
      }
    }catch(e){
      el.innerHTML='<div style="font-size:12px;color:#E84545;padding:8px">Spell check unavailable — check API connection.</div>';
    }
    const input=null;
    // Simple British English checks (common errors)
    const britishFixes=[
      [/\bcolor\b/gi,'colour'],[/\bcenter\b/gi,'centre'],[/\banalyze\b/gi,'analyse'],
      [/\borganize\b/gi,'organise'],[/\brealize\b/gi,'realise'],[/\bmaximize\b/gi,'maximise'],
      [/\bminimize\b/gi,'minimise'],[/\boptimize\b/gi,'optimise'],[/\bcustomize\b/gi,'customise'],
      [/\brecognize\b/gi,'recognise'],[/\bauthorize\b/gi,'authorise'],[/\bpractice\b/gi,'practise (verb)'],
    ];
    const found=[];
    britishFixes.forEach(([rx,sug])=>{ const m=text.match(rx); if(m) found.push({word:m[0],suggest:sug}); });
    if(!found.length){
      el.innerHTML='<span style="color:#16A34A;font-size:11.5px"> No spelling issues found.</span>';
    } else {
      el.innerHTML='<div style="font-size:11px;font-weight:700;color:var(--o);margin-bottom:4px">Possible issues:</div>'
        +found.map(f=>`<div style="font-size:11.5px;padding:3px 0;border-bottom:1px solid var(--bd0)">"${f.word}" → ${f.suggest}</div>`).join('');
    }
  },

  _addCmpComment(jobId,versionId,inputId,idxA,idxB){
    const inp=document.getElementById(inputId); if(!inp) return;
    const text=inp.value.trim(); if(!text) return;
    RV_DB.addComment(jobId,versionId,{text,x:0,y:0});
    inp.value='';
    const j=RV_DB.getJob(jobId); if(j) this._renderCompare(j,idxA,idxB);
  },

  filterComments(jobId,filter){
    const j=RV_DB.getJob(jobId); if(!j) return;
    const ver=j.versions[j.versions.length-1];
    const all=[...(ver?.comments||[]),...j.comments];
    const filtered=filter==='open'?all.filter(c=>!c.resolved):filter==='resolved'?all.filter(c=>c.resolved):all;
    const el=document.getElementById('rv-comments-'+jobId); if(!el) return;
    el.innerHTML=this._renderComments({...j,comments:filtered},{...ver,comments:[]});
  }
};

/* ══ RV EVENT DELEGATION ══
   Single document-level click handler for all Review Area actions.
   Data attributes on elements — no onclick, no timing issues.
═══════════════════════════════════════════════════════════════ */
document.addEventListener('click', function(e){
  // Walk up from click target to find a data-action element
  const el = e.target.closest('[data-action]');
  if(!el) return;
  const action = el.dataset.action;
  const jid    = el.dataset.jid;
  if(!action || !action.startsWith('rv-')) return;

  e.preventDefault();
  e.stopPropagation();

  console.log('[RV delegation] action='+action+' jid='+jid);

  switch(action){
    // rv-upload handled directly via onclick on button
    case 'rv-edit':    RV.editJobModal(jid);               break;
    case 'rv-share':   RV.shareJob(jid);                   break;
    case 'rv-approve': RV.decisionModal(jid,'approve');    break;
    case 'rv-reject':  RV.decisionModal(jid,'reject');     break;
    case 'rv-status':  RV.setStatus(jid,el.dataset.status);break;
  }
}, true); // capture phase — fires before any element handler

/* Area system boot — intercept ALL users and show area chooser */

export { RV_DB, RV };
