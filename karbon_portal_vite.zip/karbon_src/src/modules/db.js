import { getContrastText, safeBrandText, getCompanyBrandColour, _isInheritedColour } from "./helpers.js";

const F = {
  val(m){
    if(m.value_text) return m.value_text;
    const v=m.value_number; if(v===null||v===undefined) return '—';
    switch(m.unit){
      case'currency_gbp': return v>=1e6?`£${(v/1e6).toFixed(2)}M`:v>=1000?`£${(v/1000).toFixed(0)}k`:`£${v.toLocaleString()}`;
      case'percentage': return `${v}%`;
      case'count': return v>=1e6?`${(v/1e6).toFixed(1)}M`:v>=1000?`${(v/1000).toFixed(0)}k`:v.toLocaleString();
      case'number': return String(v);
      default: return v.toLocaleString();
    }
  },
  short(v,u){
    if(!v&&v!==0) return'—';
    if(u==='currency_gbp') return v>=1000?`£${(v/1000).toFixed(0)}k`:`£${v}`;
    if(u==='percentage') return`${v}%`;
    if(u==='count') return v>=1000?`${(v/1000).toFixed(0)}k`:v.toLocaleString();
    return String(v);
  },
  pct(a,b){ if(!b||b===0) return null; return Math.round((a-b)/Math.abs(b)*100); },
  date(iso){ if(!iso) return'—'; return new Date(iso).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}); },
};

/* COLOUR UTILITIES */
function contrastColour(hex){
  // Returns '#fff' or '#00192B' based on luminance of hex
  const r=parseInt(hex.slice(1,3),16);
  const g=parseInt(hex.slice(3,5),16);
  const b=parseInt(hex.slice(5,7),16);
  const L=0.2126*(r/255)**2.2+0.7152*(g/255)**2.2+0.0722*(b/255)**2.2;
  return L>0.179?'#00192B':'#fff';
}

/* LOGO */
const LP=`<path fill="var(--lc,#fff)" d="M51.4,6.91h5.32v19.54c0-7.65,1.22-10.57,4.83-14.99l3.76-4.56h6.29l-7.75,9.6,8.17,14.74h-6.22l-5.56-10.19c-2.68,3.83-3.51,6.82-3.51,10.19h-5.32V6.91Z"/><path fill="var(--lc,#fff)" d="M72,25.9c0-3.34,2.47-5.32,6.02-5.63l5.22-.45v-.07c0-1.63-1.29-2.75-3.03-2.75-1.98,0-2.75,1.32-2.92,2.19l-4.59-1.25c.97-3.44,3.76-5.29,7.51-5.29,5.63,0,8.03,3.86,8.03,7.37v11.23h-5.04v-5.32c0,3.83-2.12,5.77-5.46,5.77-3.09,0-5.74-2.12-5.74-5.81ZM79.37,27.64c2.5,0,3.86-1.36,3.86-3.41v-.59l-4.1.38c-1.11.1-2.05.63-2.05,1.81,0,1.01.87,1.81,2.3,1.81Z"/><path fill="var(--lc,#fff)" d="M91.47,13.1h5.15v7.09c.21-5.67,3.27-7.3,6.29-7.3v5.42h-3.16c-1.91,0-3.13,1.36-3.13,3.13v9.81h-5.15V13.1Z"/><path fill="var(--lc,#fff)" d="M109.64,24.37v6.89h-5.15V6.91h5.15v12.76c.63-4.56,3.37-7.02,6.54-7.02,4.56,0,7.48,3.83,7.48,9.53,0,5.36-2.92,9.53-7.48,9.53-3.16,0-5.91-2.26-6.54-7.34ZM113.88,27.01c2.5,0,4.52-1.95,4.52-4.83s-2.02-4.83-4.52-4.83c-2.36,0-4.49,1.95-4.49,4.83s2.12,4.83,4.49,4.83Z"/><path fill="var(--lc,#fff)" d="M124.76,22.18c0-5.46,4.21-9.53,9.91-9.53,5.36,0,9.91,4.07,9.91,9.53s-4.56,9.53-9.91,9.53c-5.7,0-9.91-4.03-9.91-9.53ZM134.67,27.01c2.57,0,4.69-1.84,4.69-4.83s-2.12-4.83-4.69-4.83-4.69,1.95-4.69,4.83,2.12,4.83,4.69,4.83Z"/><path fill="var(--lc,#fff)" d="M146.71,13.1h5.15v6.19c0-4.73,2.75-6.64,5.53-6.64,3.93,0,5.81,2.92,5.81,6.09v12.52h-5.15v-10.47c0-1.77-1.22-3.13-3.06-3.13s-3.13,1.36-3.13,3.13v10.47h-5.15V13.1Z"/><path fill="var(--lc,#fff)" d="M172.37,19.09c0-7.09,5.36-12.62,12.9-12.62,5.63,0,9.46,2.78,11.41,6.85l-4.9,2.54c-1.01-2.61-3.44-4.17-6.5-4.17-3.96,0-7.34,2.92-7.34,7.41s3.37,7.41,7.34,7.41c3.23,0,6.09-1.91,6.99-5.08l4.94,2.26c-1.6,4.59-5.91,8.03-11.96,8.03-7.55,0-12.87-5.46-12.87-12.62Z"/><path fill="var(--lc,#fff)" d="M199.36,13.1h5.15v7.09c.21-5.67,3.27-7.3,6.29-7.3v5.42h-3.16c-1.91,0-3.13,1.36-3.13,3.13v9.81h-5.15V13.1Z"/><path fill="var(--lc,#fff)" d="M211.48,22.18c0-5.32,3.76-9.53,9.56-9.53s9.04,4.24,9.04,8.59c0,1.22-.14,2.4-.28,3.03h-13.11c.73,2.02,2.5,2.99,4.49,2.99,1.67,0,3.41-1.01,3.93-1.81l3.76,2.54c-1.5,2.09-4.14,3.72-8.03,3.72-5.01,0-9.35-3.48-9.35-9.53ZM225.11,20.23c-.17-1.56-1.63-3.23-4.1-3.23-2.09,0-3.72,1.22-4.35,3.23h8.45Z"/><path fill="var(--lc,#fff)" d="M231.12,25.9c0-3.34,2.47-5.32,6.02-5.63l5.22-.45v-.07c0-1.63-1.29-2.75-3.03-2.75-1.98,0-2.75,1.32-2.92,2.19l-4.59-1.25c.97-3.44,3.76-5.29,7.51-5.29,5.63,0,8.03,3.86,8.03,7.37v11.23h-5.04v-5.32c0,3.83-2.12,5.77-5.46,5.77-3.09,0-5.74-2.12-5.74-5.81ZM238.5,27.64c2.5,0,3.86-1.36,3.86-3.41v-.59l-4.1.38c-1.11.1-2.05.63-2.05,1.81,0,1.01.87,1.81,2.29,1.81Z"/><path fill="var(--lc,#fff)" d="M252.02,25.45v-7.82h-3.34v-4.52h3.41v-4.03h4.97v4.03h4.9v4.52h-4.9v7.23c0,1.25.59,1.7,1.67,1.7h2.78v4.69h-3.2c-3.65,0-6.29-1.36-6.29-5.81Z"/><path fill="var(--lc,#fff)" d="M264.15,5.87h5.29v5.32h-5.29v-5.32ZM264.22,13.1h5.15v18.15h-5.15V13.1Z"/><path fill="var(--lc,#fff)" d="M270.51,13.1h5.53l4.24,17.73,4.07-17.73h5.6l-4.69,18.15h-10.05l-4.69-18.15Z"/><path fill="var(--lc,#fff)" d="M289.95,22.18c0-5.32,3.76-9.53,9.56-9.53s9.04,4.24,9.04,8.59c0,1.22-.14,2.4-.28,3.03h-13.11c.73,2.02,2.5,2.99,4.49,2.99,1.67,0,3.41-1.01,3.93-1.81l3.76,2.54c-1.5,2.09-4.14,3.72-8.03,3.72-5.01,0-9.35-3.48-9.35-9.53ZM303.58,20.23c-.17-1.56-1.63-3.23-4.1-3.23-2.09,0-3.72,1.22-4.35,3.23h8.45Z"/><path fill="#FFD600" d="M9.97,22.67c0-2.43.94-4.14,1.88-5.56l6.75-10.19h6.43l-7.93,11.51c1.29-1.84,2.89-3.09,4.76-3.09,3.83,0,6.64,3.44,6.64,7.34,0,5.7-4.14,9.04-9.28,9.04-4.73,0-9.25-3.62-9.25-9.04ZM19.22,26.63c2.19,0,3.96-1.5,3.96-3.96,0-2.3-1.77-3.93-3.96-3.93s-3.96,1.63-3.96,3.93c0,2.47,1.77,3.96,3.96,3.96Z"/><path fill="#FFD600" d="M19.42,38.85C8.71,38.85,0,30.14,0,19.42S8.71,0,19.42,0s19.42,8.71,19.42,19.42-8.71,19.42-19.42,19.42ZM19.42,2.41C10.05,2.41,2.41,10.05,2.41,19.42s7.63,17.01,17.01,17.01,17.01-7.63,17.01-17.01S28.8,2.41,19.42,2.41Z"/>`;
function Logo(h=22,lc='#fff'){ return`<svg viewBox="0 0 308.55 38.85" xmlns="http://www.w3.org/2000/svg" height="${h}" style="display:block;--lc:${lc}">${LP}</svg>`; }
function LogoFaded(h=16){ return`<svg viewBox="0 0 308.55 38.85" xmlns="http://www.w3.org/2000/svg" height="${h}" style="display:block;opacity:.3;--lc:currentColor">${LP}</svg>`; }

/* APP STATE */
const S = {
  user:null, clientId:'cl-bl', year:2026, month:'Feb',
  cmpActive:false, activeTab:'overview', charts:{},
};
// Scooby AI Assistant config — configurable
const SCOOBY_CONFIG = {
  name: 'Scooby',
  tagline: 'Ask Scooby',
  avatar: null, // base64 or URL — null = use dog emoji
  emoji: '🐶',
  description: 'Your Karbon Creative report assistant (Rhodesian Ridgeback)',
};

/* AUTH */
const DB = (() => {

  /* CLIENTS */
  const _clients = [
    { id:'cl-bl', parent_id:null, name:'Blendini Motorsport', slug:'blendini', initials:'BM',
      brand_colour:'#95C123', brand_text:getContrastText('#95C123'), logo:null,
      reporting_year_start:1, report_frequency:'monthly', email_provider:'mailerlite', contact_email:'client@blendini.com', is_active:true,
      parent_report_mode:'summary', // 'summary'|'custom'
      modules:{overview:true,kpis:true,social:true,paid_advertising:true,website:true,email:true,creative_assets:false,tasks:false},
      data_sources:[
        {provider:'google_analytics_4',label:'Car Chase Heroes GA4',active:false},
        {provider:'meta',label:'Car Chase Heroes Meta',active:false},
        {provider:'mailerlite',label:'MailerLite',active:false},
        {provider:'manual',label:'KK Revenue (manual)',active:true},
      ]
    },
    { id:'cl-cch', parent_id:'cl-bl', name:'Car Chase Heroes', slug:'car-chase-heroes', initials:'CC',
      brand_colour:'#FFD600', brand_text:'#00192B', logo:null,
      reporting_year_start:1, report_frequency:'monthly', email_provider:'mailerlite', contact_email:'client@blendini.com', is_active:true,
      modules:{overview:true,kpis:true,social:true,paid_advertising:true,website:true,email:true,creative_assets:true,tasks:true},
      data_sources:[]
    },
    { id:'cl-kk', parent_id:'cl-bl', name:'Kart Kingdom', slug:'kart-kingdom', initials:'KK',
      brand_colour:'#FFD600', brand_text:'#00192B', logo:null,
      reporting_year_start:1, email_provider:'mailerlite', contact_email:'client@blendini.com', is_active:true,
      modules:{overview:true,kpis:false,social:false,paid_advertising:true,website:true,email:true,creative_assets:false,tasks:true},
      data_sources:[]
    },
    { id:'cl-gt', parent_id:null, name:'GT Towing', slug:'gt-towing', initials:'GT',
      brand_colour:'#015093', brand_text:getContrastText('#015093'), logo:null,
      reporting_year_start:4, report_frequency:'monthly', email_provider:'mailchimp', contact_email:'client@gttowing.co.uk', is_active:true,
      modules:{overview:true,kpis:true,social:true,paid_advertising:true,website:true,email:true,creative_assets:true,tasks:true},
      data_sources:[
        {provider:'google_analytics_4',label:'GT Towing GA4',active:false},
        {provider:'meta',label:'GT Towing Meta',active:false},
        {provider:'mailchimp',label:'Mailchimp',active:false},
      ]
    },
    { id:'cl-td', parent_id:null, name:'Topaz Detailing', slug:'topaz-detailing', initials:'TD',
      brand_colour:'#ec1d24', brand_text:'#fff', logo:null,
      reporting_year_start:1, report_frequency:'monthly', email_provider:'system', contact_email:'nabil@topazdetailing.com', is_active:true,
      modules:{overview:true,kpis:true,social:true,paid_advertising:true,website:true,email:true,creative_assets:true,tasks:true},
      data_sources:[
        {provider:'manual',label:'Topaz Detailing (manual)',active:true},
      ]
    },
  ];

  /* USERS */
  const _users = [
    { id:'u-admin', name:'Karbon Creative', initials:'KC', email:'admin@karboncreative.co.uk', pass:'admin123',
      role:'admin', portals:['reporting','review'], companies:['kc'], client_ids:['cl-bl','cl-cch','cl-kk','cl-gt','cl-td'], avatar:null,
      email_provider:'microsoft_365', signature:'<p style="font-size:12px;color:#555"><strong>Karbon Creative</strong> · karboncreative.co.uk</p>' },
    {id:'u-charles', name:'Charles Cumberlidge', initials:'CC', email:'charles@karboncreative.co.uk', pass:'admin123', role:'admin', portals:['reporting','review'], companies:['kc'], client_ids:[]},
    {id:'u-rikki', name:'Rikki Cove', initials:'RC', email:'rikki@karboncreative.co.uk', pass:'admin123', role:'admin', portals:['reporting','review'], companies:['kc'], client_ids:[]},
    { id:'u-bl', name:'Blendini Motorsport', initials:'BM', email:'client@blendini.com', pass:'client123', portals:['reporting','review'], companies:['bl'],
      role:'client', client_ids:['cl-bl','cl-cch','cl-kk'], avatar:null, email_provider:'system', signature:'' },
    { id:'u-gt', name:'GT Towing', initials:'GT', email:'client@gttowing.co.uk', pass:'towing123', portals:['review'], companies:['gt'],
      role:'client', client_ids:['cl-gt'], avatar:null, email_provider:'system', signature:'' },
    { id:'u-td', name:'Nabil Naamo', initials:'NN', email:'nabil@topazdetailing.com', pass:'topaz123', portals:['reporting','review'], companies:['td'],
      role:'client', client_ids:['cl-td'], avatar:null, email_provider:'system', signature:'' },
  ];

  const _emailLog = [];

  /* METRIC BUILDER */
  let _mid=0;
  function M(key,label,val,unit,o={}) {
    return { _id:++_mid, key, label,
      value_number:typeof val==='number'?val:null,
      value_text:typeof val==='string'?val:null,
      unit, // 'currency_gbp'|'percentage'|'count'|'duration'|'number'
      data_type:o.type||'manual', // 'auto'|'manual'|'manual_override'
      is_kpi:!!o.kpi, show_overview:!!o.ov,
      target:o.target??null, prev:o.prev??null,
      lower:!!o.lower, section:o.sec||null, sort:o.sort||_mid,
    };
  }

  /* REPORTS — each report has: status, insights, metrics[], tasks, assets[], blocks[], video */
  /* blocks[] = the flexible builder structure. Each block has: id, type, config, data */
  const _reports = {
    'cl-bl':{ 2026:{
      Jan:{
        status:'published', published_at:'2026-02-01T09:00:00Z', internal_notes:null, video:null,
        insights:{
          overview:{text:'January marked a natural reset following the peak Q4 trading period. Performance settling into a healthier baseline after Christmas. Engagement quality improved across all key channels.',tone:'g'},
          kpis:{text:'KPI tracking underway against draft 2026 targets — not yet formally agreed. Revenue and conversion metrics are tracking well. Review rating remains the primary area requiring attention.',tone:'a'},
          social:{text:'Social performance stabilised following festive peaks. Vehicle-led Reels and short-form content drove the strongest engagement across all platforms.',tone:'g'},
          paid_advertising:{text:'Cost-efficient month across both CCH Meta and Kart Kingdom PPC. KK delivered 224 conversions at £4.03 cost-per-conversion — down 17% month-on-month.',tone:'g'},
          website:{text:'Traffic normalised after December highs but user behaviour strengthened. Session duration up 25%, bounce rate down 4% — visitors arriving with clearer purchase intent.',tone:'g'},
          email:{text:'CTR surged 147% for CCH and 206% for Kart Kingdom — the highest-intent email performance of the year so far.',tone:'g'},
        },
        metrics:[
          M('revenue_cch','CCH + UD Revenue',243332,'currency_gbp',{kpi:1,ov:1,target:2292678,sec:'overview',sort:1}),
          M('conversion_rate','CCH Conversion Rate',7.75,'percentage',{kpi:1,ov:1,sec:'overview',sort:2}),
          M('revenue_kk_ytd','KK Revenue (YTD)',72349,'currency_gbp',{kpi:1,ov:1,target:630000,type:'manual',sec:'overview',sort:3}),
          M('review_rating','Avg Review Rating',3.67,'number',{kpi:1,ov:1,target:4.2,type:'manual',sec:'overview',sort:4}),
          M('unsubscribes','Monthly Unsubscribes',3308,'count',{kpi:1,ov:1,target:5600,lower:1,sec:'overview',sort:5}),
          M('social_views','Social Views (Group)',418000,'count',{kpi:1,ov:1,target:7500000,sec:'overview',sort:6}),
          M('fb_followers','Facebook Followers',87653,'count',{sec:'social',sort:10}),
          M('fb_eng','Facebook Engagements',1574,'count',{sec:'social',sort:11}),
          M('fb_imp','Facebook Impressions',335233,'count',{sec:'social',sort:12}),
          M('fb_rate','Facebook Eng Rate',1.5,'percentage',{sec:'social',sort:13}),
          M('ig_followers','Instagram Followers',21113,'count',{sec:'social',sort:20}),
          M('ig_eng','Instagram Engagements',1904,'count',{sec:'social',sort:21}),
          M('ig_imp','Instagram Impressions',83551,'count',{sec:'social',sort:22}),
          M('tt_followers','TikTok Followers',18427,'count',{sec:'social',sort:30}),
          M('tt_eng','TikTok Engagements',609,'count',{sec:'social',sort:31}),
          M('tt_views','TikTok Views',11466,'count',{sec:'social',sort:32}),
          M('li_followers','LinkedIn Followers',350,'count',{sec:'social',sort:40}),
          M('li_eng','LinkedIn Engagements',25,'count',{sec:'social',sort:41}),
          M('li_imp','LinkedIn Impressions',876,'count',{sec:'social',sort:42}),
          M('cch_spend','CCH Meta Spend',255,'currency_gbp',{sec:'paid_advertising',sort:50}),
          M('cch_fol','CCH Meta Followers Gained',155,'count',{sec:'paid_advertising',sort:51}),
          M('cch_cpe','CCH Meta Cost/Eng',0.01,'currency_gbp',{sec:'paid_advertising',sort:52}),
          M('cch_imp','CCH Meta Impressions',114703,'count',{sec:'paid_advertising',sort:53}),
          M('kk_spend','KK PPC Spend',803.56,'currency_gbp',{sec:'paid_advertising',sort:60}),
          M('kk_conv','KK PPC Conversions',224,'count',{sec:'paid_advertising',sort:61}),
          M('kk_rev','KK PPC Revenue',13410,'currency_gbp',{sec:'paid_advertising',sort:62}),
          M('kk_cpc','KK PPC Cost/Conv',4.03,'currency_gbp',{lower:1,sec:'paid_advertising',sort:63}),
          M('web_users','Total Users',43011,'count',{sec:'website',sort:70}),
          M('web_sessions','Sessions',59135,'count',{sec:'website',sort:71}),
          M('web_bounce','Bounce Rate',59,'percentage',{lower:1,sec:'website',sort:72}),
          M('web_dur','Avg Session Duration','4:23','duration',{sec:'website',sort:73}),
          M('v_sold','Vouchers Sold',164,'count',{sec:'website',sort:80}),
          M('v_rev','Vouchers Revenue',15704,'currency_gbp',{sec:'website',sort:81}),
          M('carts','Add to Carts',859,'count',{sec:'website',sort:82}),
          M('conv_off','Offers Conv Rate',19.0,'percentage',{sec:'website',sort:83}),
          M('ch_direct','Direct Traffic',28393,'count',{sec:'website',sort:90}),
          M('ch_organic','Organic Search',5754,'count',{sec:'website',sort:91}),
          M('ch_paid','Paid Social',1601,'count',{sec:'website',sort:92}),
          M('ch_ref','Referral',4792,'count',{sec:'website',sort:93}),
          M('ch_email','Email Traffic',1818,'count',{sec:'website',sort:94}),
          M('cch_e_cmp','CCH Campaigns',4,'count',{sec:'email',sort:100}),
          M('cch_e_sent','CCH Total Sent',577498,'count',{sec:'email',sort:101}),
          M('cch_e_opens','CCH Unique Opens',248258,'count',{sec:'email',sort:102}),
          M('cch_e_open','CCH Open Rate',43.0,'percentage',{sec:'email',sort:103}),
          M('cch_e_clicks','CCH Unique Clicks',647,'count',{sec:'email',sort:104}),
          M('cch_e_ctr','CCH CTR',1.04,'percentage',{sec:'email',sort:105}),
          M('kk_e_cmp','KK Campaigns',1,'count',{sec:'email',sort:110}),
          M('kk_e_sent','KK Total Sent',8012,'count',{sec:'email',sort:111}),
          M('kk_e_opens','KK Unique Opens',2943,'count',{sec:'email',sort:112}),
          M('kk_e_open','KK Open Rate',36.73,'percentage',{sec:'email',sort:113}),
          M('kk_e_clicks','KK Unique Clicks',72,'count',{sec:'email',sort:114}),
          M('kk_e_ctr','KK CTR',2.4,'percentage',{sec:'email',sort:115}),
        ],
        tasks:{
          done:[
            {t:'4x CCH Newsletters',lb:'Car Chase Heroes'},{t:'1x KK Newsletter',lb:'Kart Kingdom'},
            {t:'Join The Team Page',lb:'Car Chase Heroes'},{t:'Update All Cars on the Website',lb:'Car Chase Heroes'},
            {t:"Valentine's Day Artwork",lb:'Car Chase Heroes'},{t:'Update Database ×4',lb:null},
            {t:'Swing Signs',lb:'Car Chase Heroes'},{t:'KK Championship Flyer',lb:'Kart Kingdom'},
            {t:'Meta awareness ad creative updates',lb:'Car Chase Heroes'},{t:'CCH Website Updates',lb:'Car Chase Heroes'},
            {t:'2025 Yearly performance overview',lb:null},{t:'2026 Marketing strategy',lb:null},
            {t:'Tockwith Low Attendance Plan',lb:'Car Chase Heroes'},{t:'Castle Combe Low Attendance Plan',lb:'Car Chase Heroes'},
            {t:'Llandow content shoot day',lb:null},{t:'Shared social media guidelines',lb:null},
          ],
          upcoming:[
            {t:'January Promotion',lb:null},{t:'Newsletters ×4',lb:'Car Chase Heroes'},
            {t:'Kart Kingdom Email ×1',lb:'Kart Kingdom'},{t:'Update Database ×4',lb:null},
            {t:'Set up shared media bank',lb:null},{t:'Shared content calendar',lb:null},
            {t:'Castle Combe organic and paid content plan',lb:'Car Chase Heroes'},{t:'Influencer management plan',lb:null},
          ],
        },
        assets:[
          {title:"Valentine's Day Artwork",desc:"Full suite — hero, social formats, ad variations.",brand:'Car Chase Heroes',icon:'🖼',img:null},
          {title:'Event Swing Signs',desc:'12 swing signs across all activity zones.',brand:'Car Chase Heroes',icon:'🖼',img:null},
          {title:'KK Championship Flyer',desc:'2026 Kart Kingdom Championship — 6 rounds.',brand:'Kart Kingdom',icon:'🖼',img:null},
          {title:'Join the Team Page',desc:'Desktop and mobile design — Driver Coach and Hospitality roles.',brand:'Car Chase Heroes',icon:'🖼',img:null},
        ],
        /* blocks[] — flexible per-section builder data */
        blocks:{},
      },

      Feb:{
        status:'published', published_at:'2026-03-01T09:00:00Z',
        internal_notes:'Bot traffic spike: 43k sessions from China/Singapore excluded from conversion rate. Adjusted 10.01%, raw 4.79%.',
        video:null,
        insights:{
          overview:{text:"February saw strong overall traffic growth alongside a shift in customer behaviour following the Christmas redemption period. A short spike in international bot traffic inflated volumes — excluding this, core UK traffic remained stable.",tone:'g'},
          kpis:{text:"The website conversion rate was skewed by 43k bot sessions from China and Singapore — the adjusted rate of 10.01% has been calculated with these removed. Note: 2026 KPIs have not yet been formally agreed.",tone:'a'},
          social:{text:"Social visibility continued to expand across all platforms through short-form video and vehicle-led content. TikTok engagement up 16%, Instagram impressions up 34%, Facebook impressions up 43%.",tone:'g'},
          paid_advertising:{text:"CCH Meta spend up significantly — impressions up 200%, followers gained up 43%. KK PPC: £10.5k revenue from £849 spend. Performance Max driving conversions at a lower CPA.",tone:'g'},
          website:{text:"Traffic increase influenced by the international bot traffic spike. Core UK engagement remained healthy. Calendar and Booking pages saw strong growth from Christmas redemption activity. Valentine's promotion underperformed vs 2025.",tone:'a'},
          email:{text:"February maintained similar send volume to January. Open rate held at 41.2% for CCH — only 4% below January. CTR at 0.95%, healthy for the broader seasonal campaigns.",tone:'g'},
        },
        metrics:[
          M('revenue_cch','CCH + UD Revenue',444952,'currency_gbp',{kpi:1,ov:1,target:2292678,prev:243332,sec:'overview',sort:1}),
          M('conversion_rate','CCH Conversion Rate',10.01,'percentage',{kpi:1,ov:1,prev:7.75,sec:'overview',sort:2}),
          M('revenue_kk_ytd','KK Revenue (YTD)',147281,'currency_gbp',{kpi:1,ov:1,target:630000,prev:72349,type:'manual',sec:'overview',sort:3}),
          M('review_rating','Avg Review Rating',3.64,'number',{kpi:1,ov:1,target:4.2,prev:3.67,type:'manual',sec:'overview',sort:4}),
          M('unsubscribes','Monthly Unsubscribes',2427,'count',{kpi:1,ov:1,target:5600,lower:1,prev:3308,sec:'overview',sort:5}),
          M('social_views','Social Views (Group)',1030000,'count',{kpi:1,ov:1,target:7500000,prev:418000,sec:'overview',sort:6}),
          M('fb_followers','Facebook Followers',82451,'count',{prev:87653,sec:'social',sort:10}),
          M('fb_eng','Facebook Engagements',1403,'count',{prev:1574,sec:'social',sort:11}),
          M('fb_imp','Facebook Impressions',480102,'count',{prev:335233,sec:'social',sort:12}),
          M('fb_rate','Facebook Eng Rate',1.5,'percentage',{prev:1.5,sec:'social',sort:13}),
          M('ig_followers','Instagram Followers',21070,'count',{prev:21113,sec:'social',sort:20}),
          M('ig_eng','Instagram Engagements',1304,'count',{prev:1904,sec:'social',sort:21}),
          M('ig_imp','Instagram Impressions',107200,'count',{prev:83551,sec:'social',sort:22}),
          M('tt_followers','TikTok Followers',18440,'count',{prev:18427,sec:'social',sort:30}),
          M('tt_eng','TikTok Engagements',708,'count',{prev:609,sec:'social',sort:31}),
          M('tt_views','TikTok Views',12724,'count',{prev:11466,sec:'social',sort:32}),
          M('li_followers','LinkedIn Followers',358,'count',{prev:350,sec:'social',sort:40}),
          M('li_eng','LinkedIn Engagements',19,'count',{prev:25,sec:'social',sort:41}),
          M('li_imp','LinkedIn Impressions',829,'count',{prev:876,sec:'social',sort:42}),
          M('cch_spend','CCH Meta Spend',623,'currency_gbp',{prev:255,sec:'paid_advertising',sort:50}),
          M('cch_fol','CCH Meta Followers Gained',223,'count',{prev:155,sec:'paid_advertising',sort:51}),
          M('cch_cpe','CCH Meta Cost/Eng',0.01,'currency_gbp',{prev:0.01,sec:'paid_advertising',sort:52}),
          M('cch_imp','CCH Meta Impressions',344602,'count',{prev:114703,sec:'paid_advertising',sort:53}),
          M('kk_spend','KK PPC Spend',849,'currency_gbp',{prev:803.56,sec:'paid_advertising',sort:60}),
          M('kk_conv','KK PPC Conversions',179,'count',{prev:224,sec:'paid_advertising',sort:61}),
          M('kk_rev','KK PPC Revenue',10507,'currency_gbp',{prev:13410,sec:'paid_advertising',sort:62}),
          M('kk_cpc','KK PPC Cost/Conv',5.33,'currency_gbp',{lower:1,prev:4.03,sec:'paid_advertising',sort:63}),
          M('web_users','Total Users',65530,'count',{prev:43011,sec:'website',sort:70}),
          M('web_sessions','Sessions',82673,'count',{prev:59135,sec:'website',sort:71}),
          M('web_bounce','Bounce Rate',68,'percentage',{lower:1,prev:59,sec:'website',sort:72}),
          M('web_dur','Avg Session Duration','2:55','duration',{sec:'website',sort:73}),
          M('v_sold','Vouchers Sold',142,'count',{prev:164,sec:'website',sort:80}),
          M('v_rev','Vouchers Revenue',15660,'currency_gbp',{prev:15704,sec:'website',sort:81}),
          M('carts','Add to Carts',859,'count',{prev:859,sec:'website',sort:82}),
          M('conv_off','Offers Conv Rate',16.5,'percentage',{prev:19.0,sec:'website',sort:83}),
          M('ch_direct','Direct Traffic',49336,'count',{prev:28393,sec:'website',sort:90}),
          M('ch_organic','Organic Search',6142,'count',{prev:5754,sec:'website',sort:91}),
          M('ch_paid','Paid Social',4633,'count',{prev:1601,sec:'website',sort:92}),
          M('ch_ref','Referral',4253,'count',{prev:4792,sec:'website',sort:93}),
          M('ch_email','Email Traffic',901,'count',{prev:1818,sec:'website',sort:94}),
          M('cch_e_cmp','CCH Campaigns',4,'count',{prev:4,sec:'email',sort:100}),
          M('cch_e_sent','CCH Total Sent',567194,'count',{prev:577498,sec:'email',sort:101}),
          M('cch_e_opens','CCH Unique Opens',234159,'count',{prev:248258,sec:'email',sort:102}),
          M('cch_e_open','CCH Open Rate',41.2,'percentage',{prev:43.0,sec:'email',sort:103}),
          M('cch_e_clicks','CCH Unique Clicks',556,'count',{prev:647,sec:'email',sort:104}),
          M('cch_e_ctr','CCH CTR',0.95,'percentage',{prev:1.04,sec:'email',sort:105}),
          M('kk_e_cmp','KK Campaigns',0,'count',{sec:'email',sort:110}),
        ],
        tasks:{
          done:[
            {t:'4x CCH Newsletters',lb:'Car Chase Heroes'},{t:'1x KK Newsletter',lb:'Kart Kingdom'},
            {t:'Update Database ×4',lb:null},{t:'Swing Signs (updated)',lb:'Car Chase Heroes'},
            {t:'CCH Website Updates',lb:'Car Chase Heroes'},{t:'Castle Combe Lightboxes',lb:'Car Chase Heroes'},
            {t:'Castle Combe Event Signage Plan',lb:'Car Chase Heroes'},{t:'Social Series Branding',lb:'Car Chase Heroes'},
            {t:'Updating social media banner images',lb:null},{t:'Influencer sourcing for summer campaigns',lb:null},
            {t:'Kart Kingdom PPC optimisations',lb:'Kart Kingdom'},{t:'Creating shared content calendar',lb:null},
            {t:'Updating social media awareness ads',lb:null},{t:'Set up shared media bank for social',lb:null},
            {t:'Creating influencer guidelines',lb:null},{t:'Castle Combe social media content',lb:'Car Chase Heroes'},
          ],
          upcoming:[
            {t:"Mother's Day / Monthly Promotion",lb:null},{t:'Newsletters ×4',lb:'Car Chase Heroes'},
            {t:'Kart Kingdom Email ×1',lb:'Kart Kingdom'},{t:'Update Database ×4',lb:null},
            {t:'Castle Combe Leaflet Drop Plan',lb:'Car Chase Heroes'},{t:'Begin YouTube reporting',lb:null},
            {t:'Short form social media content shoot',lb:null},{t:'Influencer outreach and collaboration',lb:null},
            {t:'Local META awareness ads for upcoming events',lb:null},
          ],
        },
        assets:[
          {title:'Swing Signs (Updated)',desc:"New 'We're Back Soon' and 'Event This Way' variants.",brand:'Car Chase Heroes',icon:'🖼',img:null},
          {title:'Castle Combe Lightboxes',desc:'Portrait, landscape, and banner formats.',brand:'Car Chase Heroes',icon:'🖼',img:null},
          {title:'Social Series Branding',desc:'Torque Talk, Hero of the Week, Track Tips, Full Send Trivia.',brand:'Car Chase Heroes',icon:'🖼',img:null},
          {title:'CCH Website Updates',desc:'Content and page updates across carchaseheroes.com.',brand:'Car Chase Heroes',icon:'🖼',img:null},
        ],
        blocks:{},
      },
    }},

    /* ── CAR CHASE HEROES — Feb 2026 (separate child report) ── */
    'cl-cch':{ 2026:{
      Feb:{
        status:'published', published_at:'2026-03-01T09:00:00Z', internal_notes:null, video:null,
        insights:{
          overview:{text:"February was a strong month for Car Chase Heroes. Valentine's drove significant website revenue and voucher sales. Meta ad spend up significantly with impressive reach and follower growth.",tone:'g'},
          social:{text:"Short-form video and vehicle-led Reels continue to be the strongest content format. Facebook impressions up 43% month on month. Instagram content views up 34%.",tone:'g'},
          paid_advertising:{text:'Meta awareness spend up significantly — impressions up 200%, followers gained up 43%. Cost per engagement remained at £0.01.',tone:'g'},
          website:{text:'Bot traffic spike from China/Singapore inflated sessions — adjusted conversion rate of 10.01% calculated with these removed. Core UK engagement remained healthy.',tone:'a'},
          email:{text:'Open rate maintained at 41.2% despite high send volume. 4 campaigns delivered across CCH database. CTR slightly down month on month at 0.95%.',tone:'g'},
          kpis:{text:'Revenue ahead of expected monthly pace. Conversion rate strong at 10.01% adjusted. Unsubscribes below target — positive.',tone:'g'},
          tasks:{text:'16 key tasks delivered this month including lightbox design, social branding series, and KK PPC optimisations.',tone:'g'},
        },
        metrics:[
          M('revenue_cch','CCH + UD Revenue',444952,'currency_gbp',{kpi:1,ov:1,target:2292678,prev:243332,sec:'overview',sort:1}),
          M('conversion_rate','CCH Conversion Rate',10.01,'percentage',{kpi:1,ov:1,prev:7.75,sec:'overview',sort:2}),
          M('unsubscribes','Monthly Unsubscribes',2427,'count',{kpi:1,ov:1,target:5600,lower:1,prev:3308,sec:'overview',sort:3}),
          M('fb_followers','Facebook Followers',82451,'count',{prev:87653,sec:'social',sort:10}),
          M('fb_eng','Facebook Engagements',1403,'count',{prev:1574,sec:'social',sort:11}),
          M('fb_imp','Facebook Impressions',480102,'count',{prev:335233,sec:'social',sort:12}),
          M('ig_followers','Instagram Followers',21070,'count',{prev:21113,sec:'social',sort:20}),
          M('ig_eng','Instagram Engagements',1304,'count',{prev:1904,sec:'social',sort:21}),
          M('ig_imp','Instagram Impressions',107200,'count',{prev:83551,sec:'social',sort:22}),
          M('tt_followers','TikTok Followers',18440,'count',{prev:18427,sec:'social',sort:30}),
          M('tt_eng','TikTok Engagements',708,'count',{prev:609,sec:'social',sort:31}),
          M('cch_spend','CCH Meta Spend',623,'currency_gbp',{prev:255,sec:'paid_advertising',sort:50}),
          M('cch_fol','CCH Meta Followers Gained',223,'count',{prev:155,sec:'paid_advertising',sort:51}),
          M('cch_imp','CCH Meta Impressions',344602,'count',{prev:114703,sec:'paid_advertising',sort:52}),
          M('web_users','Total Users',65530,'count',{prev:43011,sec:'website',sort:70}),
          M('web_sessions','Sessions',82673,'count',{prev:59135,sec:'website',sort:71}),
          M('web_bounce','Bounce Rate',68,'percentage',{lower:1,prev:59,sec:'website',sort:72}),
          M('web_dur','Avg Session Duration','2:55','duration',{sec:'website',sort:73}),
          M('v_sold','Vouchers Sold',142,'count',{prev:164,sec:'website',sort:80}),
          M('v_rev','Vouchers Revenue',15660,'currency_gbp',{prev:15704,sec:'website',sort:81}),
          M('cch_e_cmp','CCH Campaigns',4,'count',{prev:4,sec:'email',sort:100}),
          M('cch_e_sent','CCH Total Sent',567194,'count',{prev:577498,sec:'email',sort:101}),
          M('cch_e_open','CCH Open Rate',41.2,'percentage',{prev:43.0,sec:'email',sort:103}),
          M('cch_e_ctr','CCH CTR',0.95,'percentage',{prev:1.04,sec:'email',sort:105}),
        ],
        tasks:{
          done:[
            {t:'4x CCH Newsletters',lb:'Car Chase Heroes'},{t:'Castle Combe Lightboxes',lb:'Car Chase Heroes'},
            {t:'Social Series Branding',lb:'Car Chase Heroes'},{t:'Swing Signs (updated)',lb:'Car Chase Heroes'},
            {t:'CCH Website Updates',lb:'Car Chase Heroes'},{t:'Updating social media awareness ads',lb:null},
            {t:'Set up shared media bank',lb:null},{t:'Creating influencer guidelines',lb:null},
            {t:'Castle Combe social media content',lb:'Car Chase Heroes'},{t:'Influencer sourcing',lb:null},
          ],
          upcoming:[
            {t:"Mother's Day promotion",lb:null},{t:'Newsletters x4',lb:'Car Chase Heroes'},
            {t:'Castle Combe Leaflet Drop',lb:'Car Chase Heroes'},{t:'Influencer outreach',lb:null},
            {t:'Local META awareness ads',lb:'Car Chase Heroes'},
          ],
        },
        assets:[
          {title:'Swing Signs (Updated)',desc:"New 'We're Back Soon' and 'Event This Way' variants.",brand:'Car Chase Heroes',icon:'🖼',img:null,tags:['Print','Organic social']},
          {title:'Castle Combe Lightboxes',desc:'Portrait, landscape and banner formats.',brand:'Car Chase Heroes',icon:'🖼',img:null,tags:['Print']},
          {title:'Social Series Branding',desc:'Torque Talk, Hero of the Week, Track Tips, Full Send Trivia.',brand:'Car Chase Heroes',icon:'🖼',img:null,tags:['Organic social','Top performing campaign']},
        ],
        blocks:{}, _builderBlocks:[],
      },
    }},

    /* ── KART KINGDOM — Feb 2026 (separate child report) ── */
    'cl-kk':{ 2026:{
      Feb:{
        status:'published', published_at:'2026-03-01T09:00:00Z', internal_notes:null, video:null,
        insights:{
          overview:{text:"February was a productive month for Kart Kingdom. PPC delivered strong revenue at £10,507 from £849 spend. Email campaign paused this month.",tone:'g'},
          paid_advertising:{text:'Performance Max continuing to drive the majority of conversions. Slight decrease in conversions (224 → 179) but cost per conversion remains competitive at £5.33.',tone:'a'},
          website:{text:'KK website traffic supporting PPC conversions. Booking and Calendar pages remain high-traffic landing points.',tone:'g'},
          email:{text:'No KK email campaigns sent in February. Planned for March onwards.',tone:'a'},
          tasks:{text:'PPC optimisations delivered. KK Championship Flyer updated for upcoming events.',tone:'g'},
        },
        metrics:[
          M('revenue_kk_ytd','KK Revenue (YTD)',147281,'currency_gbp',{kpi:1,ov:1,target:630000,prev:72349,sec:'overview',sort:1}),
          M('kk_spend','KK PPC Spend',849,'currency_gbp',{prev:803.56,sec:'paid_advertising',sort:10}),
          M('kk_conv','KK PPC Conversions',179,'count',{prev:224,sec:'paid_advertising',sort:11}),
          M('kk_rev','KK PPC Revenue',10507,'currency_gbp',{prev:13410,sec:'paid_advertising',sort:12}),
          M('kk_cpc','KK PPC Cost/Conv',5.33,'currency_gbp',{lower:1,prev:4.03,sec:'paid_advertising',sort:13}),
          M('kk_e_cmp','KK Email Campaigns',0,'count',{sec:'email',sort:20}),
        ],
        tasks:{
          done:[
            {t:'Kart Kingdom PPC optimisations',lb:'Kart Kingdom'},{t:'1x KK Newsletter',lb:'Kart Kingdom'},
            {t:'Creating shared content calendar',lb:null},{t:'KK Championship Flyer update',lb:'Kart Kingdom'},
          ],
          upcoming:[
            {t:'KK Newsletter x1',lb:'Kart Kingdom'},{t:'Local event PPC push',lb:'Kart Kingdom'},
            {t:'Championship season promotion',lb:'Kart Kingdom'},
          ],
        },
        assets:[
          {title:'KK Championship Flyer (Updated)',desc:'2026 Kart Kingdom Championship — 6 rounds, 3 categories.',brand:'Kart Kingdom',icon:'🖼',img:null,tags:['Print','Email']},
        ],
        blocks:{}, _builderBlocks:[],
      },
    }},

    /* ── GT TOWING — Feb 2026 ── */
    'cl-gt':{ 2026:{
      Feb:{
        status:'published', published_at:'2026-03-01T09:00:00Z', internal_notes:null, video:null,
        insights:{
          overview:{text:"February continued the positive momentum from January. Revenue grew strongly by 21.4% to £28,510, driven primarily by a 20.4% increase in average order value rather than transaction volume.",tone:'g'},
          kpis:{text:"KPI tracking against 2025/26 financial year targets (April–March). Social engagement significantly ahead of target at 122%. Website sessions tracking behind at 80% — a focus area. Email contacts list growth needs acceleration.",tone:'a'},
          social:{text:"Significant visibility growth across Facebook (impressions +80%) and Instagram (content views +147%). Humour-led workshop content performing exceptionally well. LinkedIn engagement rate of 7.4%.",tone:'g'},
          paid_advertising:{text:"Instagram awareness campaign highly cost-efficient: 15,021 impressions, 11,000+ reach, 733 profile visits at £0.06 per result.",tone:'g'},
          website:{text:"February built positively on January's momentum. Organic search dominates at 75%+ of traffic. Bounce rate improved to 44.8%. Average order value up 20.4%.",tone:'g'},
          email:{text:"Strong uplift: unique opens up 27.6%, total clicks up 72.9%. Resend strategy working well. 'We Buy Your Trailer' and camping gear campaigns both achieved ~49% open rates.",tone:'g'},
        },
        metrics:[
          M('revenue_web','Website Revenue',28510,'currency_gbp',{kpi:1,ov:1,sec:'overview',sort:1}),
          M('transactions','Transactions',244,'count',{ov:1,sec:'overview',sort:2}),
          M('avg_order','Avg Order Value',117.3,'currency_gbp',{ov:1,sec:'overview',sort:3}),
          M('new_followers','New Followers (YTD)',2634,'count',{kpi:1,ov:1,target:3007,sec:'overview',sort:4}),
          M('social_eng','Social Engagement (YTD)',10349,'count',{kpi:1,ov:1,target:8500,sec:'overview',sort:5}),
          M('sessions_ytd','Website Sessions (YTD)',315220,'count',{kpi:1,ov:1,target:391000,sec:'overview',sort:6}),
          M('email_contacts','Email Contacts',12789,'count',{kpi:1,ov:1,target:20000,type:'manual',sec:'overview',sort:7}),
          M('fb_followers','Facebook Followers',8390,'count',{sec:'social',sort:10}),
          M('fb_eng','Facebook Engagement',262,'count',{sec:'social',sort:11}),
          M('fb_imp','Facebook Impressions',32472,'count',{sec:'social',sort:12}),
          M('fb_rate','Facebook Eng Rate',1.1,'percentage',{sec:'social',sort:13}),
          M('ig_followers','Instagram Followers',2712,'count',{sec:'social',sort:20}),
          M('ig_eng','Instagram Engagement',702,'count',{sec:'social',sort:21}),
          M('ig_views','Instagram Content Views',49999,'count',{sec:'social',sort:22}),
          M('li_followers','LinkedIn Followers',527,'count',{sec:'social',sort:30}),
          M('li_eng','LinkedIn Engagement',34,'count',{sec:'social',sort:31}),
          M('li_imp','LinkedIn Impressions',1459,'count',{sec:'social',sort:32}),
          M('tw_followers','X (Twitter) Followers',1118,'count',{sec:'social',sort:40}),
          M('tw_eng','X (Twitter) Engagement',6,'count',{sec:'social',sort:41}),
          M('meta_spend','META Ad Spend',100,'currency_gbp',{sec:'paid_advertising',sort:50}),
          M('meta_fol','META New Followers',194,'count',{sec:'paid_advertising',sort:51}),
          M('meta_visits','META Profile Visits',733,'count',{sec:'paid_advertising',sort:52}),
          M('meta_imp','META Impressions',22758,'count',{sec:'paid_advertising',sort:53}),
          M('web_users','Total Users',22341,'count',{sec:'website',sort:60}),
          M('web_sessions','Sessions',30774,'count',{sec:'website',sort:61}),
          M('web_bounce','Bounce Rate',44.8,'percentage',{lower:1,sec:'website',sort:62}),
          M('web_dur','Avg Session Duration','2:58','duration',{sec:'website',sort:63}),
          M('conv_rate','Conversion Rate',0.79,'percentage',{sec:'website',sort:64}),
          M('ch_organic','Organic Search',16795,'count',{sec:'website',sort:70}),
          M('ch_direct','Direct',4846,'count',{sec:'website',sort:71}),
          M('ch_email','Email',342,'count',{sec:'website',sort:72}),
          M('ch_ref','Referral',173,'count',{sec:'website',sort:73}),
          M('e_sends','Campaigns',3,'count',{sec:'email',sort:80}),
          M('e_sent','Total Sent',40768,'count',{sec:'email',sort:81}),
          M('e_opens','Unique Opens',18837,'count',{sec:'email',sort:82}),
          M('e_open','Open Rate',40.7,'percentage',{sec:'email',sort:83}),
          M('e_clicks','Total Clicks',415,'count',{sec:'email',sort:84}),
          M('e_ctr','CTR',0.9,'percentage',{sec:'email',sort:85}),
        ],
        tasks:{
          done:[
            {t:'SEO audit — 13/21 tasks complete',lb:null},{t:'Arcos Hire newsletter',lb:null},
            {t:'We Buy Your Trailer newsletter',lb:null},{t:'Tents & Camping Gear newsletter',lb:null},
            {t:'Blog: Trailer Maintenance Guide',lb:null},{t:'Optimonk Setup & Optimisation',lb:null},
            {t:'Email Automation – Commercial ×2',lb:null},{t:'Email Automation – Adventure ×2',lb:null},
            {t:'Lead Magnet – Adventure',lb:null},{t:'Lead Magnet – Commercial',lb:null},
            {t:'Trailer Maintenance Guide PDF',lb:null},{t:'Trailer Wiring Diagram PDF',lb:null},
            {t:'Towbar Gallery Redesign',lb:null},{t:'CMS: Trailer Hire',lb:null},
            {t:'Trailer Configurator Plan',lb:null},{t:'Update Database',lb:null},
          ],
          upcoming:[
            {t:'Continue working through SEO checklist',lb:null},{t:'Technical SEO: non-indexed pages',lb:null},
            {t:'On-page SEO optimisations',lb:null},{t:'Email newsletter ×3',lb:null},
            {t:'Blog post / Resource ×2',lb:null},{t:'Lead Magnet: Trailer Maintenance Guide',lb:null},
            {t:'Trailer Configurator Implementation',lb:null},{t:'Remaining CMS tasks',lb:null},
            {t:'Complete remaining SEO tasks',lb:null},{t:'Yearly planning and strategy',lb:null},
          ],
        },
        assets:[
          {title:'Trailer Wiring Diagram PDF',desc:'7 Pin, 8 Pin & 13 Pin reference. Commercial lead magnet.',brand:'GT Towing',icon:'📄',img:null},
          {title:'Trailer Maintenance Guide',desc:'The Ultimate UK Trailer Maintenance Guide — multi-page PDF.',brand:'GT Towing',icon:'📄',img:null},
          {title:'Lead Magnet Designs',desc:'Commercial and Adventure popup and confirmation designs.',brand:'GT Towing',icon:'🖼',img:null},
          {title:'Towbar Gallery Redesign',desc:'New towbar fitting gallery — vehicle model selector.',brand:'GT Towing',icon:'🖼',img:null},
        ],
        blocks:{},
      },
    }},
  
    'cl-td':{ 2026:{
      Apr:{
        status:'published', published_at:'2026-05-05T09:00:00Z', internal_notes:null, video:null,
        insights:{
          overview:{text:'April delivered solid growth across digital channels. Paid social enquiries remained strong at 288 despite a 37% reduction in Studios ad spend — a strong signal of improving efficiency. Shop revenue grew 8.7% month-on-month to £8,359.',tone:'g'},
          kpis:{text:'Studios ad spend fell 37% to £2,967 while paid social enquiries held steady at 288. Shop revenue reached £8,359 across 70 orders. Decals category led with £6,749 revenue — up 24.8% on March. HubSpot marketing contacts grew 45% to 1,425.',tone:'g'},
          social:{text:'Social audience remained stable across all platforms. YouTube was the standout performer — views up 34.5% to 69,598 and watch time up 51.9% to 2,801 hours. LinkedIn engagements fell 19.9% to 539.',tone:'g'},
          paid_advertising:{text:'Combined ad spend of £4,064 across Studios and Shop — down significantly from March. Paid social enquiries of 288 with improved cost efficiency across both Studio and Shop campaigns.',tone:'g'},
          website:{text:'Studio website users grew 27.2% to 9,636 with sessions up 22.4%. Shop website traffic fell 39.8% likely reflecting the reduced Shop ad spend. Studio conversion rate dipped to 1.19%.',tone:'a'},
          email:{text:'One marketing email deployed in April. Open rate of 14.17% and click-through rate of 0.97%. Automated flows continued to run in the background throughout the month.',tone:'a'},
        },
        metrics:[
          M('td_shop_rev','Shop Revenue',8359.38,'currency_gbp',{kpi:1,ov:1,target:10000,sec:'overview',sort:1,prev:7691.41}),
          M('td_shop_orders','Shop Orders',70,'count',{kpi:1,ov:1,target:100,sec:'overview',sort:2,prev:88}),
          M('td_studio_spend','Studios Ad Spend',2967.47,'currency_gbp',{kpi:1,ov:1,lower:1,sec:'overview',sort:3,prev:4728.31}),
          M('td_shop_spend','Shop Ad Spend',1096.40,'currency_gbp',{kpi:1,ov:1,lower:1,sec:'overview',sort:4,prev:2778.52}),
          M('td_decals_rev','Decals Revenue',6749.13,'currency_gbp',{kpi:1,ov:1,sec:'overview',sort:5,prev:5409.70}),
          M('td_care_rev','Car Care Revenue',1610.25,'currency_gbp',{sec:'overview',sort:6,prev:2281.71}),
          M('td_hs_contacts','New HubSpot Contacts',1864,'count',{kpi:1,ov:1,target:2000,sec:'overview',sort:7,prev:1781}),
          M('td_hs_mkt','Marketing Contacts',1425,'count',{kpi:1,ov:1,target:2000,sec:'overview',sort:8,prev:982}),
          M('td_paid_enq','Paid Social Enquiries',288,'count',{sec:'overview',sort:9,prev:297}),
          M('td_web_enq','Website Enquiries',115,'count',{sec:'overview',sort:10,prev:164}),
          M('td_ig_fol','Instagram Followers',304946,'count',{kpi:1,ov:1,target:350000,sec:'social',sort:20,prev:304751}),
          M('td_ig_views','Instagram Views',1311899,'count',{sec:'social',sort:21,prev:1408243}),
          M('td_fb_fol','Facebook Followers',69889,'count',{sec:'social',sort:22,prev:69814}),
          M('td_yt_subs','YouTube Subscribers',230432,'count',{kpi:1,ov:1,target:250000,sec:'social',sort:23,prev:230444}),
          M('td_yt_views','YouTube Views',69598,'count',{kpi:1,ov:1,sec:'social',sort:24,prev:51744}),
          M('td_yt_watch','YouTube Watch Hours',2801,'count',{sec:'social',sort:25,prev:1844}),
          M('td_li_fol','LinkedIn Followers',3850,'count',{sec:'social',sort:26,prev:3754}),
          M('td_li_eng','LinkedIn Engagements',539,'count',{sec:'social',sort:27,prev:673}),
          M('td_studio_spend2','Studios Ad Spend',2967.47,'currency_gbp',{sec:'paid_advertising',sort:50,prev:4728.31}),
          M('td_shop_spend2','Shop Ad Spend',1096.40,'currency_gbp',{sec:'paid_advertising',sort:51,prev:2778.52}),
          M('td_paid_social_enq','Paid Social Enquiries',288,'count',{sec:'paid_advertising',sort:52,prev:297}),
          M('td_phone_enq','Phone Enquiries',17,'count',{sec:'paid_advertising',sort:53,prev:15}),
          M('td_web_users_s','Studio Website Users',9636,'count',{kpi:1,ov:1,target:12000,sec:'website',sort:70,prev:7573}),
          M('td_web_sess_s','Studio Sessions',12092,'count',{sec:'website',sort:71,prev:9877}),
          M('td_web_cvr_s','Studio Conversion Rate',1.19,'percentage',{lower:0,sec:'website',sort:72,prev:2.17}),
          M('td_web_users_sh','Shop Website Users',4270,'count',{sec:'website',sort:73,prev:7093}),
          M('td_web_sess_sh','Shop Sessions',5555,'count',{sec:'website',sort:74,prev:8440}),
          M('td_web_cvr_sh','Shop Conversion Rate',1.64,'percentage',{sec:'website',sort:75,prev:1.24}),
          M('td_email_sent','Emails Sent',1,'count',{sec:'email',sort:100,prev:0}),
          M('td_email_open','Email Open Rate',14.17,'percentage',{sec:'email',sort:101}),
          M('td_email_ctr','Email CTR',0.97,'percentage',{sec:'email',sort:102}),
        ],
        tasks:{done:[],upcoming:[]},
        assets:[],
        blocks:{},
      },
      Mar:{
        status:'published', published_at:'2026-04-03T09:00:00Z', internal_notes:null, video:null,
        insights:{
          overview:{text:'March establishes the baseline for Topaz Detailing reporting. Solid shop performance with 88 orders generating £7,691 revenue. Decals category led at £5,410. Strong social audience across all platforms heading into spring.',tone:'g'},
          kpis:{text:'Studios paid advertising spend of £4,728 in March. Shop revenue reached £7,691 across 88 orders. Decals generated £5,410 with Car Care at £2,282. 1,781 new HubSpot contacts added.',tone:'a'},
          social:{text:'Instagram reach of 1.4M views across all Topaz accounts with 304,751 followers. YouTube delivered 51,744 views and 1,844 watch hours. LinkedIn at 3,754 followers with 673 engagements.',tone:'g'},
          paid_advertising:{text:'Studios paid advertising spend of £4,728 and Shop spend of £2,779 in the baseline month. 297 paid social enquiries recorded. Website enquiries at 164 through Shogun form.',tone:'a'},
          website:{text:'Studio website recorded 7,573 users across 9,877 sessions with a 2.17% conversion rate. Shop website had 7,093 users across 8,440 sessions with 1.24% conversion rate.',tone:'g'},
          email:{text:'No marketing emails sent in March. Baseline established for future comparison. Automated email flows active in background.',tone:'a'},
        },
        metrics:[
          M('td_shop_rev','Shop Revenue',7691.41,'currency_gbp',{kpi:1,ov:1,target:10000,sec:'overview',sort:1}),
          M('td_shop_orders','Shop Orders',88,'count',{kpi:1,ov:1,target:100,sec:'overview',sort:2}),
          M('td_studio_spend','Studios Ad Spend',4728.31,'currency_gbp',{kpi:1,ov:1,lower:1,sec:'overview',sort:3}),
          M('td_shop_spend','Shop Ad Spend',2778.52,'currency_gbp',{kpi:1,ov:1,lower:1,sec:'overview',sort:4}),
          M('td_decals_rev','Decals Revenue',5409.70,'currency_gbp',{kpi:1,ov:1,sec:'overview',sort:5}),
          M('td_care_rev','Car Care Revenue',2281.71,'currency_gbp',{sec:'overview',sort:6}),
          M('td_hs_contacts','New HubSpot Contacts',1781,'count',{kpi:1,ov:1,target:2000,sec:'overview',sort:7}),
          M('td_hs_mkt','Marketing Contacts',982,'count',{kpi:1,ov:1,target:2000,sec:'overview',sort:8}),
          M('td_paid_enq','Paid Social Enquiries',297,'count',{sec:'overview',sort:9}),
          M('td_web_enq','Website Enquiries',164,'count',{sec:'overview',sort:10}),
          M('td_ig_fol','Instagram Followers',304751,'count',{kpi:1,ov:1,target:350000,sec:'social',sort:20}),
          M('td_ig_views','Instagram Views',1408243,'count',{sec:'social',sort:21}),
          M('td_fb_fol','Facebook Followers',69814,'count',{sec:'social',sort:22}),
          M('td_yt_subs','YouTube Subscribers',230444,'count',{kpi:1,ov:1,target:250000,sec:'social',sort:23}),
          M('td_yt_views','YouTube Views',51744,'count',{kpi:1,ov:1,sec:'social',sort:24}),
          M('td_yt_watch','YouTube Watch Hours',1844,'count',{sec:'social',sort:25}),
          M('td_li_fol','LinkedIn Followers',3754,'count',{sec:'social',sort:26}),
          M('td_li_eng','LinkedIn Engagements',673,'count',{sec:'social',sort:27}),
          M('td_studio_spend2','Studios Ad Spend',4728.31,'currency_gbp',{sec:'paid_advertising',sort:50}),
          M('td_shop_spend2','Shop Ad Spend',2778.52,'currency_gbp',{sec:'paid_advertising',sort:51}),
          M('td_paid_social_enq','Paid Social Enquiries',297,'count',{sec:'paid_advertising',sort:52}),
          M('td_phone_enq','Phone Enquiries',15,'count',{sec:'paid_advertising',sort:53}),
          M('td_web_users_s','Studio Website Users',7573,'count',{kpi:1,ov:1,target:12000,sec:'website',sort:70}),
          M('td_web_sess_s','Studio Sessions',9877,'count',{sec:'website',sort:71}),
          M('td_web_cvr_s','Studio Conversion Rate',2.17,'percentage',{sec:'website',sort:72}),
          M('td_web_users_sh','Shop Website Users',7093,'count',{sec:'website',sort:73}),
          M('td_web_sess_sh','Shop Sessions',8440,'count',{sec:'website',sort:74}),
          M('td_web_cvr_sh','Shop Conversion Rate',1.24,'percentage',{sec:'website',sort:75}),
          M('td_email_sent','Emails Sent',0,'count',{sec:'email',sort:100}),
        ],
        tasks:{done:[],upcoming:[]},
        assets:[],
        blocks:{},
      },
    }},
  
  };

  /* 2025 BLENDINI TEST DATA — year-on-year comparison */
  (() => {
    function M25(key,label,val,unit,o={}) {
      return {_id:++_mid,key,label,value_number:typeof val==='number'?val:null,value_text:typeof val==='string'?val:null,unit,data_type:o.type||'manual',is_kpi:!!o.kpi,show_overview:!!o.ov,target:o.target??null,prev:o.prev??null,lower:!!o.lower,section:o.sec||null,sort:o.sort||_mid};
    }
    const blank={status:'published',published_at:null,internal_notes:null,video:null,insights:{},tasks:{done:[],upcoming:[]},assets:[],blocks:{},_builderBlocks:[]};
    const jan25={...blank,published_at:'2025-02-01T09:00:00Z',
      insights:{
        overview:{text:"January 2025 — steady start. Revenue tracking behind pace but early conversion data encouraging.",tone:'a'},
        social:{text:'Social footprint growing across all platforms. TikTok showing strongest early momentum.',tone:'g'},
        website:{text:'January traffic down seasonally but session quality strong. Bounce rate improvement noted.',tone:'g'},
        email:{text:"New year campaigns performing above industry benchmarks for open rate.",tone:'g'},
        paid_advertising:{text:'Efficient month. KK PPC maintaining strong cost-per-conversion.',tone:'g'},
        kpis:{text:'2025 KPI targets set. Early tracking cautiously positive across most metrics.',tone:'a'},
      },
      metrics:[
        M25('revenue_cch','CCH + UD Revenue',198450,'currency_gbp',{kpi:1,ov:1,target:2100000,sec:'overview',sort:1}),
        M25('conversion_rate','CCH Conversion Rate',6.2,'percentage',{kpi:1,ov:1,sec:'overview',sort:2}),
        M25('revenue_kk_ytd','KK Revenue (YTD)',58200,'currency_gbp',{kpi:1,ov:1,target:580000,sec:'overview',sort:3}),
        M25('review_rating','Avg Review Rating',3.71,'number',{kpi:1,ov:1,target:4.0,sec:'overview',sort:4}),
        M25('unsubscribes','Monthly Unsubscribes',3840,'count',{kpi:1,ov:1,target:5600,lower:1,sec:'overview',sort:5}),
        M25('social_views','Social Views (Group)',328000,'count',{kpi:1,ov:1,target:6500000,sec:'overview',sort:6}),
        M25('fb_followers','Facebook Followers',84200,'count',{sec:'social',sort:10}),
        M25('fb_eng','Facebook Engagements',1320,'count',{sec:'social',sort:11}),
        M25('fb_imp','Facebook Impressions',274000,'count',{sec:'social',sort:12}),
        M25('ig_followers','Instagram Followers',19800,'count',{sec:'social',sort:20}),
        M25('ig_eng','Instagram Engagements',1620,'count',{sec:'social',sort:21}),
        M25('ig_imp','Instagram Impressions',71000,'count',{sec:'social',sort:22}),
        M25('tt_followers','TikTok Followers',14200,'count',{sec:'social',sort:30}),
        M25('tt_eng','TikTok Engagements',480,'count',{sec:'social',sort:31}),
        M25('tt_views','TikTok Views',9200,'count',{sec:'social',sort:32}),
        M25('web_users','Total Users',38400,'count',{sec:'website',sort:70}),
        M25('web_sessions','Sessions',51200,'count',{sec:'website',sort:71}),
        M25('web_bounce','Bounce Rate',63,'percentage',{lower:1,sec:'website',sort:72}),
        M25('web_dur','Avg Session Duration','3:48','duration',{sec:'website',sort:73}),
        M25('cch_e_cmp','CCH Campaigns',3,'count',{sec:'email',sort:100}),
        M25('cch_e_sent','CCH Total Sent',548000,'count',{sec:'email',sort:101}),
        M25('cch_e_open','CCH Open Rate',38.4,'percentage',{sec:'email',sort:103}),
        M25('cch_e_ctr','CCH CTR',0.88,'percentage',{sec:'email',sort:105}),
        M25('kk_spend','KK PPC Spend',710,'currency_gbp',{sec:'paid_advertising',sort:60}),
        M25('kk_conv','KK PPC Conversions',188,'count',{sec:'paid_advertising',sort:61}),
        M25('kk_rev','KK PPC Revenue',11200,'currency_gbp',{sec:'paid_advertising',sort:62}),
        M25('kk_cpc','KK PPC Cost/Conv',3.77,'currency_gbp',{lower:1,sec:'paid_advertising',sort:63}),
        M25('cch_spend','CCH Meta Spend',198,'currency_gbp',{sec:'paid_advertising',sort:50}),
        M25('cch_imp','CCH Meta Impressions',88400,'count',{sec:'paid_advertising',sort:53}),
      ]
    };
    const feb25={...blank,published_at:'2025-03-01T09:00:00Z',
      insights:{
        overview:{text:"February 2025 — Valentine's campaign drove strong revenue uplift. Social engagement growing. Email delivered best CTR in six months.",tone:'g'},
        social:{text:"Vehicle-led and Valentine's creative outperformed benchmarks. Instagram Reels driving discovery.",tone:'g'},
        website:{text:"Traffic up month-on-month driven by Valentine's campaign and improved organic position.",tone:'g'},
        email:{text:"Valentine's campaign delivered 43.8% open rate — highest in six months. CTR of 1.02% beating industry benchmarks.",tone:'g'},
        paid_advertising:{text:'CCH Meta boosting Valentine campaigns. KK PPC conversions up month on month — solid performance.',tone:'g'},
        kpis:{text:'Revenue ahead of expected pace through month 2. Unsubscribes remain below target threshold — positive signal.',tone:'g'},
      },
      metrics:[
        M25('revenue_cch','CCH + UD Revenue',387000,'currency_gbp',{kpi:1,ov:1,target:2100000,prev:198450,sec:'overview',sort:1}),
        M25('conversion_rate','CCH Conversion Rate',8.4,'percentage',{kpi:1,ov:1,prev:6.2,sec:'overview',sort:2}),
        M25('revenue_kk_ytd','KK Revenue (YTD)',118000,'currency_gbp',{kpi:1,ov:1,target:580000,prev:58200,sec:'overview',sort:3}),
        M25('review_rating','Avg Review Rating',3.68,'number',{kpi:1,ov:1,target:4.0,prev:3.71,sec:'overview',sort:4}),
        M25('unsubscribes','Monthly Unsubscribes',2980,'count',{kpi:1,ov:1,target:5600,lower:1,prev:3840,sec:'overview',sort:5}),
        M25('social_views','Social Views (Group)',782000,'count',{kpi:1,ov:1,target:6500000,prev:328000,sec:'overview',sort:6}),
        M25('fb_followers','Facebook Followers',85100,'count',{prev:84200,sec:'social',sort:10}),
        M25('fb_eng','Facebook Engagements',1490,'count',{prev:1320,sec:'social',sort:11}),
        M25('fb_imp','Facebook Impressions',334000,'count',{prev:274000,sec:'social',sort:12}),
        M25('ig_followers','Instagram Followers',20200,'count',{prev:19800,sec:'social',sort:20}),
        M25('ig_eng','Instagram Engagements',1780,'count',{prev:1620,sec:'social',sort:21}),
        M25('ig_imp','Instagram Impressions',79800,'count',{prev:71000,sec:'social',sort:22}),
        M25('tt_followers','TikTok Followers',15600,'count',{prev:14200,sec:'social',sort:30}),
        M25('tt_eng','TikTok Engagements',542,'count',{prev:480,sec:'social',sort:31}),
        M25('tt_views','TikTok Views',11200,'count',{prev:9200,sec:'social',sort:32}),
        M25('web_users','Total Users',52100,'count',{prev:38400,sec:'website',sort:70}),
        M25('web_sessions','Sessions',68400,'count',{prev:51200,sec:'website',sort:71}),
        M25('web_bounce','Bounce Rate',61,'percentage',{lower:1,prev:63,sec:'website',sort:72}),
        M25('web_dur','Avg Session Duration','4:02','duration',{sec:'website',sort:73}),
        M25('cch_e_cmp','CCH Campaigns',4,'count',{prev:3,sec:'email',sort:100}),
        M25('cch_e_sent','CCH Total Sent',562000,'count',{prev:548000,sec:'email',sort:101}),
        M25('cch_e_open','CCH Open Rate',43.8,'percentage',{prev:38.4,sec:'email',sort:103}),
        M25('cch_e_ctr','CCH CTR',1.02,'percentage',{prev:0.88,sec:'email',sort:105}),
        M25('kk_spend','KK PPC Spend',768,'currency_gbp',{prev:710,sec:'paid_advertising',sort:60}),
        M25('kk_conv','KK PPC Conversions',206,'count',{prev:188,sec:'paid_advertising',sort:61}),
        M25('kk_rev','KK PPC Revenue',12400,'currency_gbp',{prev:11200,sec:'paid_advertising',sort:62}),
        M25('kk_cpc','KK PPC Cost/Conv',3.73,'currency_gbp',{lower:1,prev:3.77,sec:'paid_advertising',sort:63}),
        M25('cch_spend','CCH Meta Spend',312,'currency_gbp',{prev:198,sec:'paid_advertising',sort:50}),
        M25('cch_imp','CCH Meta Impressions',198000,'count',{prev:88400,sec:'paid_advertising',sort:53}),
      ]
    };
    if(!_reports['cl-bl']) _reports['cl-bl']={};
    _reports['cl-bl'][2025]={Jan:jan25,Feb:feb25};
  })();

  /* KPI HEALTH — uses client's reporting_year_start */
  const MO = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  function kpiHealth(clientId, metric, month) {
    if (!metric.target||metric.value_number===null) return null;
    const c = _clients.find(x=>x.id===clientId); if (!c) return null;
    const mi = MO.indexOf(month);
    const ys = c.reporting_year_start - 1;
    const pos = ((mi - ys + 12) % 12) + 1;
    const exp = pos / 12;
    const act = metric.lower
      ? Math.max(0,(metric.target - metric.value_number)/metric.target + 1)
      : metric.value_number / metric.target;
    const ratio = act / exp;
    return ratio >= 0.95 ? 'ahead' : ratio >= 0.80 ? 'track' : 'attn';
  }
  function kpiExpected(clientId, month) {
    const c = _clients.find(x=>x.id===clientId); if (!c) return 1/12;
    const mi = MO.indexOf(month), ys = c.reporting_year_start - 1;
    return (((mi - ys + 12) % 12) + 1) / 12;
  }

  return {
    MONTHS: MO,
    ML:{Jan:'January',Feb:'February',Mar:'March',Apr:'April',May:'May',Jun:'June',Jul:'July',Aug:'August',Sep:'September',Oct:'October',Nov:'November',Dec:'December'},
    MODL:{overview:'Overview',kpis:'KPIs',social:'Social Media',paid_advertising:'Paid Advertising',website:'Website',email:'Email Marketing',creative_assets:'Creative Assets',tasks:'Tasks',forecast:'Forecasting'},
    MODO:['overview','kpis','social','paid_advertising','website','email','creative_assets','tasks','forecast'],
    FREQS:[
      {v:'weekly',l:'Weekly'},
      {v:'mid_month',l:'Mid-month (twice monthly)'},
      {v:'monthly',l:'Monthly'},
      {v:'quarterly',l:'Quarterly (future)'},
    ],
    PROVS:[
      {v:'manual',l:'Manual only',impl:true},{v:'google_analytics_4',l:'Google Analytics 4',impl:false},
      {v:'google_ads',l:'Google Ads',impl:false},{v:'meta',l:'Meta (Facebook/Instagram)',impl:false},
      {v:'mailerlite',l:'MailerLite',impl:false},{v:'mailchimp',l:'Mailchimp',impl:false},
      {v:'hubspot',l:'HubSpot',impl:false},{v:'klaviyo',l:'Klaviyo',impl:false},
    ],

    // Auth
    findUser(e,p){ return _users.find(u=>u.email===e&&u.pass===p)||null; },
    getUser(id){ return _users.find(u=>u.id===id)||null; },
    getUsers(){ return [..._users]; },
    getUsersByCompany(cid){ return _users.filter(u=>(u.companies||[u.company]).includes(cid)); },
    _companies: [
      {id:'kc',name:'Karbon Creative',clientIds:[],colour:'#FFD600',portals:['reporting','review']},
      {id:'bl',name:'Blendini Motorsport',clientIds:['cl-bl','cl-cch','cl-kk'],colour:'#95C123',portals:['reporting','review']},
      {id:'gt',name:'GT Towing',clientIds:['cl-gt'],colour:'#015093',portals:['reporting','review']},
      {id:'td',name:'Topaz Detailing',clientIds:['cl-td'],colour:'#ec1d24',email:'nabil@topazdetailing.com',portals:['reporting','review']},
    ],
    getCompanies(){ return this._companies; },
    // Sync company colours to their linked _clients for consistent rendering
    syncCompanyColours(){
      // Push company.colour into linked _clients.brand_colour
      // For parent companies only — children resolve via getCompanyBrandColour at render time
      (this._companies||[]).forEach(co=>{
        if(!co.colour) return;
        (co.clientIds||[]).forEach(cid=>{
          const cl=this.getClient(cid);
          if(!cl) return;
          // Only sync if this client is a PARENT (parent_id===null)
          // Child clients should NOT get colour directly pushed — they inherit at render time
          if(!cl.parent_id){
            cl.brand_colour=co.colour;
            cl.brand_text=getContrastText(co.colour);
          }
        });
      });
    },
    createUser(data){
      const u={id:'u-'+Date.now(),name:data.name||'New User',
        initials:(data.name||'U').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase(),
        email:data.email||'',pass:data.pass||'karbon123',role:data.role||'admin',
        portals:data.portals||['reporting','review'],
        companies:data.companies||[],
        client_ids:data.client_ids||[],avatar:null,signature:''};
      _users.push(u); return u;
    },
    updateUser(id,data){
      const u=_users.find(x=>x.id===id); if(!u) return;
      Object.assign(u,data);
      if(data.name) u.initials=data.name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
    },
    deleteUser(id){ const i=_users.findIndex(u=>u.id===id); if(i>=0) _users.splice(i,1); },
    addUser(d){ _users.push({id:'u-'+Date.now(),name:d.name,initials:d.name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase(),email:d.email,pass:d.pass,role:d.role||'client',client_ids:d.client_ids||[],avatar:null,email_provider:'system',signature:d.sig||''}); },
    updateUser(id,d){ const u=_users.find(x=>x.id===id); if(!u)return; Object.assign(u,d); },

    // Clients
    getClients(){ return [..._clients]; },
    getClient(id){ return _clients.find(c=>c.id===id)||null; },
    getParents(){ return _clients.filter(c=>!c.parent_id); },
    getChildren(pid){ return _clients.filter(c=>c.parent_id===pid); },
    getClientForUser(u){ if(u.role==='admin') return this.getParents(); return this.getParents().filter(c=>u.client_ids.includes(c.id)); },
    addClient(d){
      const nc={id:'cl-'+Date.now(),parent_id:d.parent||null,name:d.name,slug:d.slug||d.name.toLowerCase().replace(/\s+/g,'-'),
        initials:d.name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase(),
        brand_colour:d.colour||'#FFD600',brand_text:safeBrandText(d.colour||'#FFD600'),logo:d.logo||null,
        reporting_year_start:parseInt(d.yr)||1,email_provider:d.eprov||'manual',
        contact_email:d.email||'',is_active:true,
        modules:{overview:true,kpis:true,social:true,paid_advertising:true,website:true,email:true,creative_assets:true,tasks:true},
        data_sources:[]};
      _clients.push(nc); _reports[nc.id]={}; return nc;
    },
    toggleModule(cid,mod,val){ const c=this.getClient(cid); if(c) c.modules[mod]=val; },
    setClientLogo(cid,logo){ const c=this.getClient(cid); if(c){ c.logo=logo; } },
    broadcastLogoUpdate(cid){
      // Called after logo change — update all rendered elements
      const c=this.getClient(cid); if(!c) return;
      // Update client card avatars
      document.querySelectorAll(`[data-cid="${cid}"]`).forEach(el=>{
        el.innerHTML=c.logo?`<img src="${c.logo}" alt="" style="width:100%;height:100%;object-fit:contain;padding:2px">`:`<span style="color:${c.brand_text}">${c.initials}</span>`;
      });
    },
    updateClient(cid,d){ const c=this.getClient(cid); if(c) Object.assign(c,d); },

    // Reports
    getReport(cid,yr,mon){ return _reports[cid]?.[yr]?.[mon]||null; },
    getMonths(cid,yr){ return Object.keys(_reports[cid]?.[yr]||{}); },
    getYears(cid){ return Object.keys(_reports[cid]||{}).map(Number); },
    setStatus(cid,yr,mon,s){ const r=this.getReport(cid,yr,mon); if(r){r.status=s;if(s==='published')r.published_at=new Date().toISOString();} },
    setInsight(cid,yr,mon,sec,text,tone){ const r=this.getReport(cid,yr,mon); if(r) r.insights[sec]={text,tone}; },
    setMetric(cid,yr,mon,key,val){ const r=this.getReport(cid,yr,mon); if(!r)return; const m=r.metrics.find(x=>x.key===key); if(m){m.data_type='manual_override';typeof val==='number'?m.value_number=val:m.value_text=val;} },
    addMetric(cid,yr,mon,metric){ const r=this.getReport(cid,yr,mon); if(r) r.metrics.push(metric); },
    removeMetric(cid,yr,mon,key){ const r=this.getReport(cid,yr,mon); if(r) r.metrics=r.metrics.filter(m=>m.key!==key); },
    setVideo(cid,yr,mon,url){ const r=this.getReport(cid,yr,mon); if(r) r.video=url; },
    addAsset(cid,yr,mon,asset){ const r=this.getReport(cid,yr,mon); if(r) r.assets.push(asset); },
    getAllSummaries(){
      const out=[];
      for(const [cid,yrs] of Object.entries(_reports))
        for(const [yr,mons] of Object.entries(yrs))
          for(const [mon,rep] of Object.entries(mons))
            out.push({client_id:cid,client_name:this.getClient(cid)?.name,year:+yr,month:mon,status:rep.status,published_at:rep.published_at});
      return out;
    },

    // Metrics helpers
    getMetrics(cid,yr,mon,sec=null){ const r=this.getReport(cid,yr,mon); if(!r)return[]; return sec?r.metrics.filter(m=>m.section===sec):r.metrics; },
    kpiHealth, kpiExpected,
    getAllAlerts(){
      const out=[];
      for(const [cid,yrs] of Object.entries(_reports))
        for(const [yr,mons] of Object.entries(yrs))
          for(const [mon,rep] of Object.entries(mons))
            for(const m of rep.metrics.filter(x=>x.is_kpi&&x.target&&x.value_number!==null)){
              const h=kpiHealth(cid,m,mon);
              const exp=kpiExpected(cid,mon);
              const act=m.lower?Math.max(0,(m.target-m.value_number)/m.target+1):m.value_number/m.target;
              out.push({client_id:cid,client_name:this.getClient(cid)?.name,year:+yr,month:mon,key:m.key,label:m.label,actual:m.value_number,target:m.target,health:h,exp_pct:Math.round(exp*100),act_pct:Math.round(act*100)});
            }
      return out.sort((a,b)=>({attn:0,track:1,ahead:2}[a.health]||1)-({attn:0,track:1,ahead:2}[b.health]||1));
    },

    // Reports
    createReport(cid, yr, mon, opts={}){
      if(!_reports[cid]) _reports[cid]={};
      if(!_reports[cid][yr]) _reports[cid][yr]={};
      // Always start completely blank — no inherited blocks
      let base={
        status:'ir:draft', published_at:null, internal_notes:null, video:null,
        insights:{}, metrics:[], tasks:{done:[],upcoming:[]}, assets:[], blocks:{},
        _builderBlocks:[], // persistent block order for BUILDER
      };
      // Copy from template if requested (metrics/structure only, NOT builder blocks)
      if(opts.copyFrom){
        const src=this.getReport(opts.copyFrom.cid,opts.copyFrom.yr,opts.copyFrom.mon);
        if(src){
          // Deep copy metrics — reset all values, keep schema/labels/targets
          base.metrics=src.metrics.map(m=>({...m,_id:++_mid,value_number:null,value_text:null,prev:null,data_type:'manual'}));
          // Copy upcoming tasks only (not completed — start fresh)
          base.tasks={done:[],upcoming:(src.tasks?.upcoming||[]).map(t=>({...t}))};
          base.assets=[]; // no assets in copy
          // Copy insight structure but clear text
          base.insights=Object.fromEntries(Object.entries(src.insights||{}).map(([k,v])=>([k,{text:'',tone:v.tone||'g'}])));
          // Do NOT copy blocks — builder blocks are per-report
        }
      }
      // For blank mode (no copyFrom), explicitly ensure all arrays are truly empty
      if(!opts.copyFrom){
        base.metrics=[];
        base.tasks={done:[],upcoming:[]};
        base.assets=[];
        base.insights={};
        base.blocks={};
        base._builderBlocks=[];
      }
      _reports[cid][yr][mon]=base;
      return base;
    },

    // Email log
    logEmail(e){ _emailLog.push({...e,sent_at:new Date().toISOString()}); },
    getLog(){ return[..._emailLog]; },
  };
})();

/* FORMATTERS */

export { DB, F, LP, S, SCOOBY_CONFIG };
