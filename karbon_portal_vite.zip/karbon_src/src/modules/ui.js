import { DB, S, F } from "./db.js";
import { getCompanyBrandColour, getContrastText, renderAvatar } from "./helpers.js";
import { AUTH } from "./auth.js";

const NAV = {
  go(view,btn){
    document.querySelectorAll('.view').forEach(v=>v.classList.remove('on'));
    document.querySelectorAll('.sbtn').forEach(b=>b.classList.remove('on'));
    const el=document.getElementById('v-'+view);
    if(el) el.classList.add('on');
    if(btn) btn.classList.add('on');
    if(view==='yearview') YV.build();
    if(view==='kpialerts') ADMIN.buildKpiHealth();
    if(view==='users') ADMIN.buildUsers();
    if(view==='emaillog') EMAIL.buildLog();
    if(view==='settings') SETTINGS.load();
    if(view==='forecast') INTEL.buildForecast();
    if(view==='anomalies') INTEL.buildAnomalies();
    if(view==='metrics-lib') INTEL.buildMetricLib();
    if(view==='audit') INTEL.buildAudit();
    if(view==='opportunities') OPPS.build();
    if(view==='client-health') SNAPSHOT.build();
    if(view==='timeline') TIMELINE.build();
    if(view==='workspace') WORKSPACE.build();
    if(view==='strategy-pdfs') STRAT.build();
    if(view==='templates') TEMPLATES.build();
  },
  openReport(clientId){
    S.clientId=clientId;
    const yrs=DB.getYears(clientId);
    if(!yrs.length){
      // No reports exist — show prompt
      this.go('report',document.getElementById('sb-report'));
      const rcp=document.getElementById('rcp');
      const htitle=document.getElementById('htitle');
      const c=DB.getClient(clientId);
      if(htitle) htitle.innerHTML=`${c?.name||'Client'} <span>Reports</span>`;
      if(rcp) rcp.innerHTML=`<div style="padding:40px 0;text-align:center">
        <div style="font-size:32px;margin-bottom:14px"></div>
        <div style="font-size:18px;font-weight:600;margin-bottom:8px">No reports yet for ${c?.name||'this client'}</div>
        <div style="font-size:13px;color:var(--t1);margin-bottom:22px">Create the first report to get started.</div>
        <button class="btn btn-y" onclick="MODAL.addReport('${clientId}')">+ Create first report</button>
      </div>`;
      document.getElementById('mbtnrow').innerHTML='';
      document.getElementById('abar-ctx').textContent=`${c?.name||''} — No reports`;
      return;
    }
    S.year=yrs[yrs.length-1];
    const mons=DB.getMonths(clientId,S.year);
    S.month=mons[mons.length-1]||'Jan';
    S.activeTab='overview';
    REPORT.buildMonthBtns();
    REPORT.render();
    this.go('report',document.getElementById('sb-report'));
    document.getElementById('abar-ctx').textContent=`${DB.getClient(clientId)?.name} — ${DB.ML[S.month]||S.month} ${S.year}`;
  },
};

/* ADMIN */
const MODAL = {
  open(id){
    const el=document.getElementById(id); if(!el) return;
    if(el.parentElement!==document.body) document.body.appendChild(el);
    el.style.cssText='display:flex!important;z-index:999999!important;position:fixed!important;inset:0!important;background:rgba(0,0,0,.62)!important;align-items:center!important;justify-content:center!important;';
    el.classList.add('on');
  },
  close(id){
    const el=document.getElementById(id); if(!el) return;
    el.classList.remove('on');
    el.style.cssText='';
  },
  addClient(){
    document.getElementById('nc-parent').innerHTML='<option value="">— Standalone client —</option>'+DB.getParents().map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
    ['nc-name','nc-slug','nc-email','nc-cname','nc-pass'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
    document.getElementById('nc-colour').value='#FFD600';
    // Populate modules checkboxes
    const mc=document.getElementById('nc-modules');
    if(mc) mc.innerHTML=DB.MODO.map(m=>`<label style="display:flex;align-items:center;gap:6px;font-size:12px"><input type="checkbox" checked value="${m}"> ${DB.MODL[m]}</label>`).join('');
    // Populate copy source
    const cs=document.getElementById('nc-copy-src');
    if(cs) cs.innerHTML=DB.getAllSummaries().map(s=>`<option value="${s.client_id}|${s.year}|${s.month}">${s.client_name} — ${s.month} ${s.year}</option>`).join('');
    const fr=document.getElementById('nc-firstreport');
    if(fr) fr.onchange=()=>{ document.getElementById('nc-copy-wrap').style.display=(fr.value==='copy')?'':'none'; };
    document.getElementById('nc-err').style.display='none';
    this.open('modal-client');
  },
  autoSlug(){ document.getElementById('nc-slug').value=document.getElementById('nc-name').value.toLowerCase().replace(/\s+/g,'-').replace(/[^a-z0-9-]/g,''); },
  saveClient(){
    const name=document.getElementById('nc-name').value.trim();
    const email=document.getElementById('nc-email').value.trim();
    if(!name){ document.getElementById('nc-err').textContent='Client name is required.'; document.getElementById('nc-err').style.display='block'; return; }
    const slug=document.getElementById('nc-slug').value.trim()||name.toLowerCase().replace(/\s+/g,'-');
    const modules={};
    document.querySelectorAll('#nc-modules input[type=checkbox]').forEach(cb=>{ modules[cb.value]=cb.checked; });
    const logoFile=document.getElementById('nc-logo').files[0];
    const doSave=(logo)=>{
      const nc=DB.addClient({name,slug,parent:document.getElementById('nc-parent').value,yr:document.getElementById('nc-yr').value,colour:document.getElementById('nc-colour').value,eprov:document.getElementById('nc-eprov').value,email,logo,modules});
      // Create user account if email + password provided
      const cname=document.getElementById('nc-cname').value.trim();
      const cpass=document.getElementById('nc-pass').value.trim();
      if(email && cpass){
        DB.addUser({name:cname||name,email,pass:cpass,role:'client',client_ids:[nc.id],sig:''});
      }
      // Create first report if requested
      const fr=document.getElementById('nc-firstreport').value;
      const now=new Date(); const monIdx=now.getMonth(); const yr=now.getFullYear();
      const mon=DB.MONTHS[monIdx];
      if(fr==='blank'){ DB.createReport(nc.id,yr,mon,{}); }
      else if(fr==='template'){
        // Apply template modules to the client then create blank report
        const t=TEMPLATES.getAll().find(x=>x.id===templateId);
        if(t){ DB.MODO.forEach(m=>nc.modules[m]=false); t.modules.forEach(m=>nc.modules[m]=true); }
        DB.createReport(nc.id,yr,mon,{});
        INTEL.record('Report created from template',t?.name||'');
      }
      else if(fr==='copy'){
        const rv=document.getElementById('nc-copy-src').value;
        if(rv){const[sc,sy,sm]=rv.split('|'); DB.createReport(nc.id,yr,mon,{copyFrom:{cid:sc,yr:parseInt(sy),mon:sm}});}
      }
      this.close('modal-client'); ADMIN.buildClients(); ADMIN.buildUsers();
      if(fr) NAV.openReport(nc.id);
    };
    if(logoFile){ const r=new FileReader(); r.onload=e=>doSave(e.target.result); r.readAsDataURL(logoFile); } else doSave(null);
  },
  addUser(){
    document.getElementById('nu-clist').innerHTML=DB.getParents().map(c=>`<label style="display:flex;align-items:center;gap:8px;font-size:12.5px"><input type="checkbox" value="${c.id}"> ${c.name}</label>`).join('');
    document.getElementById('nu-name').value=''; document.getElementById('nu-email').value=''; document.getElementById('nu-pw').value=''; document.getElementById('nu-sig').value='';
    this.open('modal-user');
  },
  roleChange(){ document.getElementById('nu-cw').style.display=document.getElementById('nu-role').value==='admin'?'none':''; },
  saveUser(){
    const name=document.getElementById('nu-name').value.trim();
    const email=document.getElementById('nu-email').value.trim();
    const pass=document.getElementById('nu-pw').value;
    if(!name||!email||!pass) return;
    const role=document.getElementById('nu-role').value;
    const cids=role==='admin'?DB.getParents().map(c=>c.id):[...document.querySelectorAll('#nu-clist input:checked')].map(i=>i.value);
    DB.addUser({name,email,pass,role,client_ids:cids,sig:document.getElementById('nu-sig').value});
    RV_DB.audit('User created: '+name, S.user?.name||'Admin', {icon:'',area:'Users & Access',type:'user',detail:'Created user '+name+' ('+email+')'});
    this.close('modal-user'); ADMIN.buildUsers();
  },
  editKpi(key,label,val,unit,target,prev,lower,isKpi){
    document.getElementById('ek-key').value=key;
    document.getElementById('ek-label').value=label;
    document.getElementById('ek-val').value=val||0;
    document.getElementById('ek-unit').value=unit;
    document.getElementById('ek-target').value=target||'';
    document.getElementById('ek-prev').value=prev||'';
    document.getElementById('ek-kpi').checked=!!isKpi;
    document.getElementById('ek-lower').checked=!!lower;
    const rep2=DB.getReport(S.clientId,S.year,S.month);
    const m2=rep2?.metrics.find(x=>x.key===key);
    if(document.getElementById('ek-link')) document.getElementById('ek-link').value=m2?.source_link||'';
    this.open('modal-editkpi');
  },
  addReport(preselectedClientId){
    // Populate client dropdowns — all clients including children
    const clients=DB.getClients();
    const allClients=clients.map(c=>{
      const isChild=!!c.parent_id;
      const parent=isChild?DB.getClient(c.parent_id):null;
      return `<option value="${c.id}">${isChild?'  └ ':''} ${c.name}${parent?' ('+parent.name+')':''}</option>`;
    }).join('');
    document.getElementById('ar-client').innerHTML=allClients;
    document.getElementById('ar-src-client').innerHTML=allClients;
    if(preselectedClientId) document.getElementById('ar-client').value=preselectedClientId;
    document.getElementById('ar-mode').value='blank';
    document.getElementById('ar-copy-source').style.display='none';
    document.getElementById('ar-err').style.display='none';
    document.getElementById('ar-mode').onchange=()=>{
      const m=document.getElementById('ar-mode').value;
      document.getElementById('ar-copy-source').style.display=(m==='copy_other')?'':'none';
      document.getElementById('ar-template-source').style.display=(m==='template')?'':'none';
      if(m==='template'){
        const tSel=document.getElementById('ar-template-sel');
        if(tSel) tSel.innerHTML=TEMPLATES.getAll().map(t=>`<option value="${t.id}">${t.name} — ${t.modules.length} modules</option>`).join('');
      }
    };
    this.arSrcClientChange();
    this.open('modal-addreport');
  },
  addModule(){
    document.getElementById('am-name').value='';
    document.getElementById('am-type').value='custom';
    document.getElementById('am-icon').value='';
    this.open('modal-add-module');
  },
  arClientChange(){
    const cid=document.getElementById('ar-client')?.value;
    const c=DB.getClient(cid);
    if(!c) return;
    const freq=c.report_frequency||'monthly';
    const freqLabel={'weekly':'Weekly','mid_month':'Mid-month','monthly':'Monthly','quarterly':'Quarterly'}[freq]||'Monthly';
    // Update month label hint
    const hint=document.getElementById('ar-freq-hint');
    if(hint) hint.textContent=`Reporting frequency: ${freqLabel}`;
  },
  arSrcClientChange(){
    const cid=document.getElementById('ar-src-client')?.value;
    const sel=document.getElementById('ar-src-report'); if(!sel) return;
    const sums=DB.getAllSummaries().filter(s=>!cid||s.client_id===cid);
    sel.innerHTML=sums.map(s=>`<option value="${s.client_id}|${s.year}|${s.month}">${s.client_name} — ${s.month} ${s.year}</option>`).join('');
  },
  saveReport(){
    const cid=document.getElementById('ar-client').value;
    const yr=parseInt(document.getElementById('ar-year').value);
    const mon=document.getElementById('ar-month').value;
    const mode=document.getElementById('ar-mode').value;
    const templateId=document.getElementById('ar-template-sel')?.value;
    const err=document.getElementById('ar-err');
    if(DB.getReport(cid,yr,mon)){
      err.textContent=`Report already exists for ${mon} ${yr}. Choose a different month.`;
      err.style.display='block'; return;
    }
    err.style.display='none';
    let opts={};
    if(mode==='copy_prev'){
      // Find most recent prior report for same client
      const mons=DB.getMonths(cid,yr); const allMons=DB.MONTHS;
      const monIdx=allMons.indexOf(mon);
      const prev=mons.filter(m=>allMons.indexOf(m)<monIdx).pop();
      if(prev) opts={copyFrom:{cid,yr,mon:prev}};
    } else if(mode==='copy_other'){
      const rv=document.getElementById('ar-src-report').value;
      if(rv){const[sc,sy,sm]=rv.split('|'); opts={copyFrom:{cid:sc,yr:parseInt(sy),mon:sm}};}
    }
    DB.createReport(cid,yr,mon,opts);
    this.close('modal-addreport');
    ADMIN.buildClients();
    NAV.openReport(cid);
    // Switch to the new month
    S.clientId=cid; S.year=yr; S.month=mon;
    REPORT.buildMonthBtns(); REPORT.render();
  },
  deleteMetric(){
    const key=document.getElementById('ek-key').value.trim();
    if(!key) return;
    if(!confirm('Remove this metric from the report?')) return;
    DB.removeMetric(S.clientId,S.year,S.month,key);
    this.close('modal-editkpi');
    REPORT.render();
  },
  saveKpi(){
    const key=document.getElementById('ek-key').value.trim();
    const val=parseFloat(document.getElementById('ek-val').value)||0;
    const target=parseFloat(document.getElementById('ek-target').value)||null;
    const prev=parseFloat(document.getElementById('ek-prev').value)||null;
    const label=document.getElementById('ek-label').value;
    const link=document.getElementById('ek-link')?.value||null;
    DB.setMetric(S.clientId,S.year,S.month,key,val);
    // Also update label and target in metric object
    const rep=DB.getReport(S.clientId,S.year,S.month);
    if(rep){ const m=rep.metrics.find(x=>x.key===key); if(m){ m.label=label; m.target=target; m.prev=prev; m.lower=document.getElementById('ek-lower').checked; m.is_kpi=document.getElementById('ek-kpi').checked; if(link) m.source_link=link; } }
    this.close('modal-editkpi'); REPORT.render();
  },
};
document.querySelectorAll('.mbg').forEach(el=>el.addEventListener('click',e=>{ if(e.target===el) el.classList.remove('on'); }));

/* INTEL — Forecasting, Anomaly Detection, Metric Library, Audit */
const UI = {
  toggleSidebar(){
    const sb=document.getElementById('sidebar');
    const collapsed=sb.classList.toggle('collapsed');
    try{ localStorage.setItem('sb-collapsed',collapsed?'1':'0'); }catch(e){}
  },
  theme(t){
    document.documentElement.setAttribute('data-theme',t);
    CHARTS._applyTheme();
    document.getElementById('thb-dark').classList.toggle('on',t==='dark');
    document.getElementById('thb-light').classList.toggle('on',t==='light');
    CHARTS.destroyAll();
    const rep=DB.getReport(S.clientId,S.year,S.month);
    const c=DB.getClient(S.clientId);
    if(rep&&c&&document.getElementById('v-report').classList.contains('on')) setTimeout(()=>REPORT._charts(rep,c),50);
    if(document.getElementById('v-yearview').classList.contains('on')) setTimeout(()=>YV._render(),50);
  },
};


/* ══════════════════════════════════════════════════════════
   AREA SYSTEM — dual-portal routing
══════════════════════════════════════════════════════════ */
const AREA = {
  current: 'home', // 'home' | 'reporting' | 'review'

  showHome(){
    ['asw-home','asw-reporting','asw-review'].forEach(id=>{const b=document.getElementById(id);if(b){b.style.background=id==='asw-home'?'rgba(255,255,255,.15)':'none';b.style.color=id==='asw-home'?'#fff':'rgba(255,255,255,.5)';}});
    document.getElementById('area-home').classList.add('on');
    document.getElementById('app').classList.remove('on');
    // Populate home screen
    document.getElementById('area-home-logo').innerHTML=Logo(20);
    const u=S.user;
    const repCard=document.getElementById('area-card-rep');
    if(repCard) repCard.style.display=u?.role==='client'?'none':'';
    const usersCard=document.getElementById('area-card-users');
    if(usersCard) usersCard.style.display=u?.role==='admin'?'':'none';
    // 3-col grid for admins, 2-col for clients
    const aGrid=document.getElementById('area-grid');
    if(aGrid) aGrid.style.gridTemplateColumns=u?.role==='admin'?'1fr 1fr 1fr':'1fr';
    if(u) document.getElementById('area-home-user').textContent='Signed in as '+u.name;
    // Show the area switcher in topbar and set home as active
    const sw=document.getElementById('area-switcher');
    if(sw) sw.style.display='flex';
    document.getElementById('asw-home')?.classList.add('on');
    document.getElementById('asw-reporting')?.classList.remove('on');
    document.getElementById('asw-review')?.classList.remove('on');
    this.current='home';
  },

  enter(area){
    // Always hide users panel when entering an area
    const up=document.getElementById('users-panel');
    if(up) up.style.display='none';
    // Check portal access
    const portals=S.user?.portals||['reporting','review'];
    if(!portals.includes(area)){
      this.showHome(); return;
    }
    this.current=area;
    document.getElementById('area-home').classList.remove('on');
    document.getElementById('app').classList.add('on');
    // Update switcher active states
    ['asw-home','asw-reporting','asw-review'].forEach(id=>{const b=document.getElementById(id);if(b){b.style.background='none';b.style.color='rgba(255,255,255,.5)';}});
    const _ab=document.getElementById('asw-'+area);if(_ab){_ab.style.background='rgba(255,255,255,.15)';_ab.style.color='#fff';}
    document.getElementById('asw-reporting')?.classList.toggle('on', area==='reporting');
    document.getElementById('asw-review')?.classList.toggle('on', area==='review');
    // Update area switcher visibility based on user portals
    const _sw=document.getElementById('rv-area-switcher');
    if(_sw){
      const _portals=S.user?.portals||[];
      _sw.style.display=_portals.length>1?'flex':'none';
      document.getElementById('asw-reporting')?.classList.toggle('on',area==='reporting');
      document.getElementById('asw-review')?.classList.toggle('on',area==='review');
    }
    if(area === 'reporting'){
      document.getElementById('rv-app').classList.remove('on');
      const _bwr=document.getElementById('rv-bell-wrap');
      if(_bwr) _bwr.style.display='none';
      // Show reporting sidebar if admin
      if(S.user?.role==='admin'){
        document.getElementById('sidebar').classList.add('on');
      }
      // Show reporting main, hide review
      document.getElementById('main').classList.remove('rv-hidden');
    } else {
      // Review area — show rv-app, hide main and reporting sidebar
      document.getElementById('rv-app').classList.add('on');
      document.getElementById('sidebar').classList.remove('on');
      document.getElementById('main').classList.add('rv-hidden');
      AI.hide(); // Scooby not needed in review area
      const _bw=document.getElementById('rv-bell-wrap');
      if(_bw) _bw.style.display='flex';
      RV.boot();
    }
  },

  showUsers(){
    const panel=document.getElementById('users-panel'); if(!panel) return;
    document.getElementById('area-home').classList.remove('on');
    panel.style.display='flex';
    document.getElementById('users-panel-logo').innerHTML=Logo(18);
    // Reset filters
    const roleF=document.getElementById('up-filter-role');
    const portalF=document.getElementById('up-filter-portal');
    if(roleF) roleF.value='';
    if(portalF) portalF.value='';
    // Call directly — arrow fn preserves 'this' but let's be explicit
    AREA.renderUsers();
  },

  hideUsers(){
    const panel=document.getElementById('users-panel'); if(!panel) return;
    panel.style.display='none';
    // Return to area home screen
    this.showHome();
  },

  _usersView:'company', // 'company' | 'all'

  setUsersView(view){
    this._usersView=view;
    const btns=['company','all','companies'];
    btns.forEach(v=>{
      const btn=document.getElementById('up-view-'+v);
      if(btn){btn.style.background=view===v?'rgba(255,255,255,.15)':'none';btn.style.color=view===v?'#fff':'rgba(255,255,255,.5)';}
    });
    const filterRow=document.getElementById('up-filter-row');
    if(filterRow) filterRow.style.display=view==='all'?'flex':'none';

    this.renderUsers();
  },

  _userCard(u){
    const portals=(u.portals||['reporting','review']);
    const portalPills=portals.map(p=>`<span style="background:${p==='reporting'?'rgba(255,214,0,.15)':'rgba(237,114,9,.15)'};color:${p==='reporting'?'#FFD600':'#ED7209'};font-size:10px;font-weight:600;padding:2px 8px;border-radius:10px;text-transform:uppercase;letter-spacing:.4px">${p}</span>`).join(' ');
    const clients=DB.getParents().filter(c=>(u.client_ids||[]).includes(c.id));
    return`<div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:14px 18px;margin-bottom:8px;display:flex;align-items:center;gap:14px">${(()=>{const _uco=(u.companies||[u.company].filter(Boolean))[0];const _ubg=getCompanyBrandColour(_uco||u.id);const _utx=getContrastText(_ubg);return '<div style="width:36px;height:36px;border-radius:50%;background:'+_ubg+';color:'+_utx+';display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;flex-shrink:0">'+(u.initials||u.name[0]||'?')+'</div>';})()}
      <div style="flex:1;min-width:0">
        <div style="font-size:13px;font-weight:600;color:#fff;margin-bottom:1px">${u.name}</div>
        <div style="font-size:11.5px;color:rgba(255,255,255,.4);margin-bottom:5px">${u.email}</div>
        <div style="display:flex;align-items:center;gap:5px;flex-wrap:wrap">
          <span style="background:rgba(255,255,255,.08);color:rgba(255,255,255,.5);font-size:9.5px;font-weight:600;padding:2px 7px;border-radius:10px;text-transform:uppercase">${u.role==='admin'?'Admin':'Client'}</span>
          ${portalPills}
          ${clients.length?clients.map(c=>`<span style="background:rgba(255,255,255,.05);color:rgba(255,255,255,.35);font-size:9.5px;padding:2px 7px;border-radius:10px">${c.name}</span>`).join(''):''}
        </div>
      </div>
      <div style="display:flex;gap:7px;flex-shrink:0">
        <button onclick="AREA.editUser('${u.id}')" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.6);border-radius:var(--rs);padding:4px 11px;cursor:pointer;font-size:11.5px;font-family:var(--fn)">Edit</button>
        ${u.id!=='u-admin'?`<button onclick="AREA.confirmDeleteUser('${u.id}')" style="background:rgba(232,69,69,.1);border:1px solid rgba(232,69,69,.3);color:#E84545;border-radius:var(--rs);padding:4px 11px;cursor:pointer;font-size:11.5px;font-family:var(--fn)">Delete</button>`:''}
      </div>
    </div>`;
  },

  renderUsers(){
    const users=DB.getUsers()||[];
    // Stats
    const statsEl=document.getElementById('up-stats');
    if(statsEl){
      const total=users.length, admins=users.filter(u=>u.role==='admin').length;
      const clients=users.filter(u=>u.role==='client').length;
      const companies=DB.getCompanies();
      const stats=[
        {label:'Total users',val:total,col:'#FFD600'},
        {label:'Admin / Internal',val:admins,col:'#3B82F6'},
        {label:'Client users',val:clients,col:'#ED7209'},
        {label:'Companies',val:companies.length,col:'#16A34A'},
      ];
      statsEl.innerHTML=stats.map(s=>`<div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:16px 20px">
        <div style="font-size:24px;font-weight:700;color:${s.col};margin-bottom:4px">${s.val}</div>
        <div style="font-size:12px;color:rgba(255,255,255,.5)">${s.label}</div>
      </div>`).join('');
    }
    const listEl=document.getElementById('up-user-list');
    if(!listEl) return;

    if((this._usersView||'company')==='company'){
      // ── Company-grouped view ──
      const companies=DB.getCompanies();
      // Add an "Unassigned" group for users with no company
      const companyGroups=[...companies,{id:'__none',name:'No company assigned'}];
      let html='';
      companyGroups.forEach(co=>{
        const coUsers=users.filter(u=>{
          const uCos=u.companies||[u.company].filter(Boolean);
          return co.id==='__none'?uCos.length===0:uCos.includes(co.id);
        });
        // Company header
        html+=`<div style="margin-bottom:24px">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,.1)">
            <div style="display:flex;align-items:center;gap:10px">
              <div style="width:32px;height:32px;border-radius:8px;background:${getCompanyBrandColour(co.id)};display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:${getContrastText(getCompanyBrandColour(co.id))}">${co.id==='__none'?'?':co.name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase()}</div>
              <div>
                <div style="font-size:15px;font-weight:700;color:#fff">${co.name}</div>
                <div style="font-size:11.5px;color:rgba(255,255,255,.4)">${coUsers.length} member${coUsers.length!==1?'s':''}${(()=>{ const coClient=co.clientIds?.[0]; if(!coClient) return ''; const ch=DB.getChildren(coClient); return ch.length?' · '+ch.length+' child compan'+(ch.length===1?'y':'ies'):''; })()}</div>
              </div>
            </div>
            ${co.id!=='__none'?`<div style="display:flex;gap:6px;align-items:center">
              <button onclick="AREA.showCreateCompany('${co.id}')" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.15);color:rgba(255,255,255,.7);border-radius:6px;padding:5px 12px;cursor:pointer;font-size:11.5px;font-family:var(--fn)">Edit</button>
              <button onclick="AREA.addChildToCompany('${co.id}')" style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);color:rgba(255,255,255,.5);border-radius:6px;padding:5px 10px;cursor:pointer;font-size:11px;font-family:var(--fn)">+ Child</button>
              <button onclick="AREA.showCreateUser('${co.id}')" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.15);color:rgba(255,255,255,.7);border-radius:6px;padding:5px 12px;cursor:pointer;font-size:11.5px;font-family:var(--fn)">+ User</button>
            </div>`:''}\n         </div>
          <div style="padding-left:4px">
            ${(()=>{
              const coClient=co.clientIds?.[0];
              const children=coClient?DB.getChildren(coClient):[];
              if(!children.length) return '';
              return '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,.06)">'
                +children.map(ch=>'<div style="display:flex;align-items:center;gap:6px;padding:5px 10px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:var(--rs);font-size:11.5px;cursor:pointer" onclick="AREA.editChildCompany(\''+ch.id+'\',\''+coClient+'\')">'
                  +'<div style="width:14px;height:14px;border-radius:3px;background:'+ch.brand_colour+';display:flex;align-items:center;justify-content:center;font-size:6px;font-weight:700;color:'+ch.brand_text+'">'+ch.initials+'</div>'
                  +'<span style="color:rgba(255,255,255,.7)">'+ch.name+'</span>'
                  +'</div>').join('')
                +'</div>';
            })()}
            ${coUsers.length?coUsers.map(u=>this._userCard(u)).join('')
              :`<div style="padding:16px;text-align:center;font-size:12px;color:rgba(255,255,255,.3);border:1px dashed rgba(255,255,255,.1);border-radius:8px">No members yet${co.id!=='__none'?` — <button onclick="AREA.showCreateUser('${co.id}')" style="background:none;border:none;color:var(--o);cursor:pointer;font-size:12px;font-family:var(--fn)">add one</button>`:''}
            </div>`}
          </div>
        </div>`;
      });
      listEl.innerHTML=html;
    } else if((this._usersView||'company')==='companies'){
      // ── Companies management view ──
      const cos=DB.getCompanies();
      let html='';
      cos.forEach(co=>{
        const members=DB.getUsers().filter(u=>(u.companies||[u.company].filter(Boolean)).includes(co.id));
        const initials=co.name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
        const bgCol=getCompanyBrandColour(co.id);
        const txCol=getContrastText(bgCol);
        html+=`<div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:20px 24px;margin-bottom:14px">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
            <div style="display:flex;align-items:center;gap:12px">
              <div style="width:40px;height:40px;border-radius:10px;background:${bgCol};display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:${txCol}">${initials}</div>
              <div>
                <div style="font-size:16px;font-weight:700;color:${txCol}">${co.name}</div>
                <div style="font-size:12px;color:rgba(255,255,255,.4)">${members.length} member${members.length!==1?'s':''}</div>
              </div>
            </div>
            <div style="display:flex;gap:8px">
              <button onclick="AREA.showCreateCompany('${co.id}')" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.6);border-radius:6px;padding:5px 12px;cursor:pointer;font-size:11.5px;font-family:var(--fn)">Edit</button>
              ${!['kc','bl','gt'].includes(co.id)?`<button onclick="AREA.confirmDeleteCompany('${co.id}')" style="background:rgba(232,69,69,.1);border:1px solid rgba(232,69,69,.3);color:#E84545;border-radius:6px;padding:5px 12px;cursor:pointer;font-size:11.5px;font-family:var(--fn)">Delete</button>`:''}
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:8px">
            ${members.length?members.map(u=>`<div style="display:flex;align-items:center;gap:6px;background:rgba(255,255,255,.06);border-radius:20px;padding:4px 10px 4px 4px">
              <div style="width:24px;height:24px;border-radius:50%;background:${getCompanyBrandColour((u.companies||[u.company].filter(Boolean))[0]||'')};display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:${getContrastText(getCompanyBrandColour((u.companies||[u.company].filter(Boolean))[0]||''))}">${u.initials||u.name[0]}</div>
              <span style="font-size:12px;color:rgba(255,255,255,.8)">${u.name}</span>
            </div>`).join(''):`<span style="font-size:12px;color:rgba(255,255,255,.3)">No members yet</span>`}
            <button onclick="AREA.showCreateUser('${co.id}')" style="display:flex;align-items:center;gap:4px;background:rgba(255,255,255,.04);border:1px dashed rgba(255,255,255,.15);border-radius:20px;padding:4px 10px;cursor:pointer;font-size:11.5px;color:rgba(255,255,255,.4);font-family:var(--fn)">+ Add member</button>
          </div>
        </div>`;
      });
      listEl.innerHTML=html;
    } else {
      // ── Flat all-users view with filters ──
      const roleFilter=document.getElementById('up-filter-role')?.value||'';
      const portalFilter=document.getElementById('up-filter-portal')?.value||'';
      const filtered=users.filter(u=>{
        if(roleFilter&&u.role!==roleFilter) return false;
        if(portalFilter&&!(u.portals||[]).includes(portalFilter)) return false;
        return true;
      });
      if(!filtered.length){
        listEl.innerHTML='<div style="text-align:center;padding:40px;color:rgba(255,255,255,.4)">No users found</div>';
        return;
      }
      listEl.innerHTML=filtered.map(u=>this._userCard(u)).join('');
    }
  },

  onUserRoleChange(){
    const role=document.getElementById('cu-role')?.value;
    const clientSec=document.getElementById('cu-client-section');
    if(clientSec) clientSec.style.display=role==='client'?'':'none';
    // Rebuild company selector: admin = multi-select checklist, client = single hierarchical dropdown
    const compSec=document.getElementById('cu-company-section');
    const compWrap=document.getElementById('cu-companies');
    if(!compWrap) return;
    const allClients=DB.getParents(); // parent clients
    const allChildren=allClients.flatMap(p=>DB.getChildren(p.id).map(ch=>({...ch,parentName:p.name,parentId:p.id})));
    const cos=DB.getCompanies();
    if(role==='admin'){
      // Multi-select checklist — all companies
      const lbl=compSec?.querySelector('div');
      if(lbl) lbl.textContent='Company access';
      compWrap.innerHTML=cos.map(co=>'<label style="display:flex;align-items:center;gap:8px;padding:7px 10px;background:var(--bg2);border:1px solid var(--bd0);border-radius:var(--rs);cursor:pointer;font-size:12.5px;color:var(--t0)">'
        +'<input type="checkbox" value="'+co.id+'" style="width:14px;height:14px;accent-color:var(--o);cursor:pointer">'
        +'<span style="font-weight:600">'+co.name+'</span>'
        +'</label>').join('');
    } else {
      // Single dropdown — shows parent clients + their children
      const lbl=compSec?.querySelector('div');
      if(lbl) lbl.textContent='Assign company';
      // Build options with parent/child hierarchy
      let opts='<option value="">— Select company —</option>';
      // Show all parent clients with their children indented
      allClients.forEach(p=>{
        const children=DB.getChildren(p.id);
        if(children.length){
          opts+='<optgroup label="'+p.name+'">';
          opts+='<option value="'+p.id+'">'+p.name+'</option>';
          children.forEach(ch=>{ opts+='<option value="'+ch.id+'">  — '+ch.name+'</option>'; });
          opts+='</optgroup>';
        } else {
          opts+='<option value="'+p.id+'">'+p.name+'</option>';
        }
      });
      // Standalone companies not in _clients (Karbon Creative etc)
      cos.filter(co=>co.id!=='__none'&&!allClients.find(p=>p.id===co.id)&&!allChildren.find(ch=>ch.id===co.id)).forEach(co=>{
        opts+='<option value="'+co.id+'">'+co.name+'</option>';
      });
      const _updatePortalAccess=()=>{
        const sel=document.getElementById('cu-company-single');
        if(!sel) return;
        const coId=sel.value;
        const cos=DB.getCompanies();
        const co=cos.find(c=>c.id===coId||(c.clientIds||[]).includes(coId));
        const allowed=co?.portals||['reporting','review'];
        const repChk=document.getElementById('cu-portal-reporting');
        const revChk=document.getElementById('cu-portal-review');
        if(repChk){ repChk.disabled=!allowed.includes('reporting'); if(!allowed.includes('reporting')) repChk.checked=false; }
        if(revChk){ revChk.disabled=!allowed.includes('review'); if(!allowed.includes('review')) revChk.checked=false; }
      };
      compWrap.innerHTML='<select class="fi" id="cu-company-single" style="width:100%;margin-bottom:10px">'+opts+'</select>'
        +'<div style="font-size:9.5px;font-weight:700;color:var(--o);text-transform:uppercase;letter-spacing:.8px;margin:10px 0 7px">Access scope</div>'
        +'<div style="display:flex;flex-direction:column;gap:6px">'
        +'<label style="display:flex;align-items:center;gap:8px;padding:7px 10px;background:var(--bg2);border:1px solid var(--bd0);border-radius:var(--rs);cursor:pointer;font-size:12px"><input type="radio" name="cu-access-scope" value="parent_only" checked style="accent-color:var(--o)"> Parent company only</label>'
        +'<label style="display:flex;align-items:center;gap:8px;padding:7px 10px;background:var(--bg2);border:1px solid var(--bd0);border-radius:var(--rs);cursor:pointer;font-size:12px"><input type="radio" name="cu-access-scope" value="parent_and_children" style="accent-color:var(--o)"> Parent + all child companies</label>'
        +'<label style="display:flex;align-items:center;gap:8px;padding:7px 10px;background:var(--bg2);border:1px solid var(--bd0);border-radius:var(--rs);cursor:pointer;font-size:12px"><input type="radio" name="cu-access-scope" value="parent_only" style="accent-color:var(--o);display:none"> Selected child companies</label>'
        +'</div>';
    }
  },

  _populateCompanyCheckboxes(preSelected){
    const el=document.getElementById('cu-companies'); if(!el) return;
    const cos=DB.getCompanies();
    const pre=Array.isArray(preSelected)?preSelected:(preSelected?[preSelected]:[]);
    el.innerHTML=cos.map(co=>`<label style="display:flex;align-items:center;gap:8px;padding:7px 10px;background:var(--bg2);border:1px solid var(--bd0);border-radius:var(--rs);cursor:pointer;font-size:12.5px;color:var(--t0)">`
      +`<input type="checkbox" value="${co.id}" ${pre.includes(co.id)?'checked':''} style="width:14px;height:14px;accent-color:var(--o);cursor:pointer">`
      +`<span style="font-weight:600">${co.name}</span>`
      +`</label>`).join('');
  },

  showCreateUser(preCompanyId){
    document.getElementById('cu-title').textContent='Create user';
    document.getElementById('cu-id').value='';
    document.getElementById('cu-name').value='';
    document.getElementById('cu-email').value='';
    document.getElementById('cu-pass').value='';
    // If launched from a company context, default to Client User role
    const fromCompany=!!preCompanyId;
    document.getElementById('cu-role').value=fromCompany?'client':'admin';
    document.getElementById('cu-portal-reporting').checked=true;
    document.getElementById('cu-portal-review').checked=true;
    this.onUserRoleChange(); // builds correct company UI for the role
    this._populateClientCheckboxes([]);
    // Pre-select the company after UI is built
    if(fromCompany){
      setTimeout(()=>{
        // For client role: set the single dropdown
        const sel=document.getElementById('cu-company-single');
        if(sel){
          // Try matching by company id directly
          if([...sel.options].some(o=>o.value===preCompanyId)){
            sel.value=preCompanyId;
          } else {
            // preCompanyId might be a client id — find its company
            const co=DB.getCompanies().find(c=>(c.clientIds||[]).includes(preCompanyId)||c.id===preCompanyId);
            if(co) sel.value=co.clientIds?.[0]||co.id;
            // Or it might be a child client id — use it directly if in options
            if([...sel.options].some(o=>o.value===preCompanyId)) sel.value=preCompanyId;
          }
        }
      },60);
    }
    MODAL.open('modal-create-user');
  },

  editUser(userId){
    const u=DB.getUser(userId); if(!u) return;
    document.getElementById('cu-title').textContent='Edit user';
    document.getElementById('cu-id').value=userId;
    document.getElementById('cu-name').value=u.name;
    document.getElementById('cu-email').value=u.email;
    document.getElementById('cu-pass').value='';
    const portals=u.portals||['reporting','review'];
    document.getElementById('cu-portal-reporting').checked=portals.includes('reporting');
    document.getElementById('cu-portal-review').checked=portals.includes('review');
    // Set role then build correct company UI
    document.getElementById('cu-role').value=u.role||'admin';
    this.onUserRoleChange();
    // Pre-select company based on role
    setTimeout(()=>{
      if((u.role||'admin')!=='admin'){
        const sel=document.getElementById('cu-company-single');
        if(sel&&(u.companies||[])[0]) sel.value=(u.companies||[])[0];
      } else {
        document.getElementById('cu-companies')?.querySelectorAll('input[type="checkbox"]').forEach(cb=>{
          cb.checked=(u.companies||[]).includes(cb.value);
        });
      }
    },50);
    MODAL.open('modal-create-user');
  },

  saveUser(){
    const id=document.getElementById('cu-id').value;
    const name=document.getElementById('cu-name').value.trim();
    const email=document.getElementById('cu-email').value.trim();
    if(!name||!email){ const v=document.getElementById('cu-validation')||Object.assign(document.createElement('div'),{id:'cu-validation'}); v.style.cssText='color:#E84545;font-size:12px;margin-bottom:8px;padding:8px 12px;background:rgba(232,69,69,.1);border-radius:var(--rs);border:1px solid rgba(232,69,69,.3)'; v.textContent='Name and email are required.'; document.getElementById('cu-name').closest('.mbox').insertBefore(v,document.getElementById('cu-name').closest('.mbox').querySelector('.mfoot')); return; }
    // Get raw portal selection
    const _rawPortals=[
      ...(document.getElementById('cu-portal-reporting').checked?['reporting']:[]),
      ...(document.getElementById('cu-portal-review').checked?['review']:[]),
    ];
    // Intersect with company's allowed portals
    const _compPortals=(()=>{
      const _sel=document.getElementById('cu-company-single')?.value||'';
      if(!_sel) return ['reporting','review'];
      const _cos=DB.getCompanies();
      const _co=_cos.find(c=>c.id===_sel||(c.clientIds||[]).includes(_sel));
      return _co?.portals||['reporting','review'];
    })();
    const portals=_rawPortals.filter(p=>_compPortals.includes(p));
    const role=document.getElementById('cu-role').value;
    const client_ids=[]; // managed at company level now
    let companies;
    if(role==='admin'){
      companies=[...document.getElementById('cu-companies').querySelectorAll('input[type="checkbox"]:checked')].map(cb=>cb.value);
    } else {
      const single=document.getElementById('cu-company-single');
      companies=single&&single.value?[single.value]:[];
    }
    const pass=document.getElementById('cu-pass').value.trim();
    if(id){
      // Resolve client_ids from companies on update too
      let _update_cids=[];
      const _cos2=DB.getCompanies();
      companies.forEach(coId=>{
        const directClient=DB.getClient(coId);
        if(directClient&&!_update_cids.includes(coId)) _update_cids.push(coId);
        const _co=_cos2.find(c=>c.id===coId);
        if(_co?.clientIds) _co.clientIds.forEach(cid=>{if(!_update_cids.includes(cid))_update_cids.push(cid);});
      });
      const updates={name,email,role,portals,companies,client_ids:_update_cids.length?_update_cids:client_ids};
      if(pass) updates.pass=pass;
      DB.updateUser(id,updates);
    } else {
      // Auto-populate client_ids from selected companies, respecting access scope
      const _accessScope=document.querySelector('input[name="cu-access-scope"]:checked')?.value||'parent_only';
      let _auto_cids=[...client_ids];
      const _cos=DB.getCompanies();
      companies.forEach(coId=>{
        // Check if coId matches a DB._client directly (child or parent)
        const directClient=DB.getClient(coId);
        if(directClient&&!_auto_cids.includes(coId)) _auto_cids.push(coId);
        // Also check _companies clientIds list
        const _co=_cos.find(c=>c.id===coId);
        if(_co?.clientIds) _co.clientIds.forEach(cid=>{if(!_auto_cids.includes(cid))_auto_cids.push(cid);});
      });
      // If parent_and_children, also add all children of any parent clients
      if(_accessScope==='parent_and_children'){
        [..._auto_cids].forEach(cid=>{
          DB.getChildren(cid).forEach(ch=>{if(!_auto_cids.includes(ch.id))_auto_cids.push(ch.id);});
        });
      }
      DB.createUser({name,email,pass:pass||'karbon123',role,portals,companies,client_ids:_auto_cids});
    }
    RV_DB.audit((id?'User updated':'User created')+': '+name, S.user?.name||'Admin', {
      icon:'', area:'Users & Access', type:'user',
      detail:(id?'Updated':'Created')+' user '+name+' ('+email+') — role: '+role
    });
    MODAL.close('modal-create-user');
    this.renderUsers();
    setTimeout(()=>{
      if(typeof OPPS!=='undefined') OPPS.build();
      if(typeof INTEL!=='undefined'){ INTEL.buildForecast(); INTEL.buildAnomalies(); }
      if(typeof SNAPSHOT!=='undefined') SNAPSHOT.build();
    },150);
  },

  // ── Company management ──
  _companies: null, // lazily initialised from DB.getCompanies()
  _getCompanies(){ return DB.getCompanies(); },

  showCreateCompany(editId){
    const cos=this._getCompanies();
    const editing=editId?cos.find(c=>c.id===editId):null;
    document.getElementById('cc-id').value=editId||'';
    document.getElementById('cc-parent-id').value='';
    document.getElementById('cc-name').value=editing?.name||'';
    if(document.getElementById('cc-email')) document.getElementById('cc-email').value=editing?.email||'';
    if(document.getElementById('cc-colour')) document.getElementById('cc-colour').value=editing?.colour||'#ED7209';
    document.getElementById('cc-title').textContent=editing?'Edit company':'Create company';
    if(document.getElementById('cc-email')) document.getElementById('cc-email').value=editing?.email||'';
    if(document.getElementById('cc-colour')) document.getElementById('cc-colour').value=editing?.colour||'#ED7209';
    // Portal access checkboxes
    const portals=editing?.portals||['review'];
    document.getElementById('cc-portal-reporting').checked=portals.includes('reporting');
    document.getElementById('cc-portal-review').checked=portals.includes('review');
    // Client access checkboxes
    const ccWrap=document.getElementById('cc-clients-wrap');
    if(ccWrap){
      const clients=DB.getParents();
      const preClients=editing?.clientIds||[];
      ccWrap.innerHTML=clients.map(c=>`<label style="display:flex;align-items:center;gap:8px;padding:5px 8px;border-radius:var(--rs);cursor:pointer;font-size:12.5px;color:var(--t0);transition:background .12s" onmouseover="this.style.background='var(--bg2)'" onmouseout="this.style.background=''">`
        +`<input type="checkbox" value="${c.id}" ${preClients.includes(c.id)?'checked':''} style="width:14px;height:14px;accent-color:var(--o);cursor:pointer">`
        +`<div style="width:16px;height:16px;border-radius:3px;background:${c.brand_colour};display:flex;align-items:center;justify-content:center;font-size:7px;font-weight:700;color:${c.brand_text};flex-shrink:0">${c.initials}</div>`
        +`<span>${c.name}</span>`
        +`</label>`).join('');
    }
    // Children section — show only when editing
    const childSec=document.getElementById('cc-children-section');
    const childList=document.getElementById('cc-children-list');
    document.getElementById('cc-parent-id').value='';
    if(editId&&childSec&&childList){
      childSec.style.display='';
      const parentClient=DB.getClient(editing?.clientIds?.[0])||null;
      const children=parentClient?DB.getChildren(parentClient.id):[];
      childList.innerHTML=children.length?children.map(ch=>`
        <div style="display:flex;align-items:center;gap:10px;padding:8px 10px;background:var(--bg2);border:1px solid var(--bd0);border-radius:var(--rs)">
          <div style="width:24px;height:24px;border-radius:5px;background:${ch.brand_colour};display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:700;color:${ch.brand_text};flex-shrink:0">${ch.initials}</div>
          <div style="flex:1;min-width:0">
            <div style="font-size:12.5px;font-weight:600">${ch.name}</div>
            <div style="font-size:10.5px;color:var(--t2)">${ch.contact_email||'No email set'}</div>
          </div>
          <button class="btn btn-g btn-sm" onclick="AREA.editChildCompany('${ch.id}','${parentClient.id}')">Edit</button>
          <button class="btn btn-r btn-sm" onclick="AREA.removeChildCompany('${ch.id}','${parentClient.id}')">Remove</button>
        </div>`).join(''):'<div style="font-size:12px;color:var(--t2);padding:8px 0">No child companies yet.</div>';
    } else if(childSec){
      childSec.style.display='none';
    }
    MODAL.open('modal-create-company');
  },

  editCompany(id){
    const cos=DB.getCompanies(); const co=cos.find(c=>c.id===id); if(!co) return;
    document.getElementById('cc-title').textContent='Edit company';
    document.getElementById('cc-id').value=id;
    document.getElementById('cc-name').value=co.name||'';
    document.getElementById('cc-email').value=co.email||'';
    if(document.getElementById('cc-colour')) document.getElementById('cc-colour').value=co.colour||'#ED7209';
    if(document.getElementById('cc-portal-reporting')) document.getElementById('cc-portal-reporting').checked=(co.portals||[]).includes('reporting');
    if(document.getElementById('cc-portal-review')) document.getElementById('cc-portal-review').checked=(co.portals||[]).includes('review');
    const wrap=document.getElementById('cc-clients-wrap');
    if(wrap) wrap.querySelectorAll('input[type="checkbox"]').forEach(cb=>{ cb.checked=(co.clientIds||[]).includes(cb.value); });
    MODAL.open('modal-create-company');
  },

    addChildToCompany(coId){
    // Open company edit modal then immediately switch to add child mode
    this.showCreateCompany(coId);
    setTimeout(()=>this.addChildCompany(),100);
  },

  addChildCompany(){
    // Pre-fill modal for creating a child company under the current parent
    const parentId=document.getElementById('cc-id').value;
    const parentClientId=DB.getCompanies().find(c=>c.id===parentId)?.clientIds?.[0]||null;
    // Save current modal state and switch to child creation mode
    document.getElementById('cc-title').textContent='Add child company';
    document.getElementById('cc-parent-id').value=parentId;
    document.getElementById('cc-id').value=''; // new child
    document.getElementById('cc-name').value='';
    document.getElementById('cc-email').value='';
    document.getElementById('cc-colour').value='#94A3B8';
    document.getElementById('cc-portal-reporting').checked=true;
    document.getElementById('cc-portal-review').checked=true;
    document.getElementById('cc-children-section').style.display='none';
  },

  editChildCompany(clientId, parentClientId){
    const ch=DB.getClient(clientId); if(!ch) return;
    document.getElementById('cc-title').textContent='Edit child company';
    document.getElementById('cc-id').value='child:'+clientId; // signals child mode
    document.getElementById('cc-parent-id').value=parentClientId;
    document.getElementById('cc-name').value=ch.name||'';
    document.getElementById('cc-email').value=ch.contact_email||'';
    document.getElementById('cc-colour').value=ch.brand_colour||'#94A3B8';
    const portals=ch._portals||['reporting','review'];
    document.getElementById('cc-portal-reporting').checked=portals.includes('reporting');
    document.getElementById('cc-portal-review').checked=portals.includes('review');
    document.getElementById('cc-children-section').style.display='none';
  },

  removeChildCompany(clientId, parentClientId){
    if(!confirm('Remove this child company? This will not delete its reports.')) return;
    // Remove parent_id from the client so it becomes standalone
    const ch=DB.getClient(clientId);
    if(ch) ch.parent_id=null;
    // Remove from parent _companies.clientIds
    const parentCo=DB.getCompanies().find(c=>(c.clientIds||[]).includes(parentClientId));
    if(parentCo) parentCo.clientIds=parentCo.clientIds.filter(id=>id!==clientId);
    // Re-open parent
    const parentCoId=document.getElementById('cc-id').value||document.getElementById('cc-parent-id').value;
    this.showCreateCompany(parentCoId);
  },

  saveCompany(){
    const rawId=document.getElementById('cc-id').value;
    const parentId=document.getElementById('cc-parent-id').value;
    const isChildMode=rawId.startsWith('child:');
    const childClientId=isChildMode?rawId.replace('child:',''):null;
    const id=isChildMode?'':rawId;
    const name=document.getElementById('cc-name').value.trim();
    if(!name) return;
    const email=document.getElementById('cc-email')?.value.trim()||'';
    const colour=document.getElementById('cc-colour')?.value||'#ED7209';
    const portals=[];
    if(document.getElementById('cc-portal-reporting')?.checked) portals.push('reporting');
    if(document.getElementById('cc-portal-review')?.checked) portals.push('review');

    // ── Child company mode ──
    if(isChildMode && childClientId){
      // Editing existing child client
      const ch=DB.getClient(childClientId);
      if(ch){ ch.name=name; ch.contact_email=email; ch.brand_colour=colour; ch.brand_text=DB.safeBrandText?.(colour)||'#fff'; ch._portals=portals; ch.initials=name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase(); }
      DB.syncCompanyColours();
      MODAL.close('modal-create-company');
      this.renderUsers();
      return; // stay in companies view after saving child
    }
    if(!isChildMode && !id && parentId){
      // Creating new child company
      const parentClient=DB.getClient(DB.getCompanies().find(c=>c.id===parentId)?.clientIds?.[0]);
      const newChild=DB.addClient({name,colour,email,eprov:'manual',yr:1,parent:parentClient?.id||null});
      newChild._portals=portals;
      // Add to parent company's clientIds
      const parentCo=DB.getCompanies().find(c=>c.id===parentId);
      if(parentCo&&!parentCo.clientIds.includes(newChild.id)) parentCo.clientIds.push(newChild.id);
      RV_DB.audit('Child company created: '+name,'System',{icon:'',area:'Users & Access',type:'company',detail:'Created child company "'+name+'" under '+(parentCo?.name||'parent')});
      MODAL.close('modal-create-company');
      this.renderUsers();
      setTimeout(()=>this.showCreateCompany(parentId),100);
      return;
    }

    const clientIds=[...document.getElementById('cc-clients-wrap').querySelectorAll('input[type="checkbox"]:checked')].map(cb=>cb.value);
    const cos=DB.getCompanies();
    if(id){
      const co=cos.find(c=>c.id===id);
      if(co){ co.name=name; co.email=email; co.colour=colour; co.portals=portals; co.clientIds=clientIds; }
    } else {
      // Create the internal company record
      const newCoId='co-'+Date.now();
      // Also create a DB._client entry so the company gets a reporting/review area
      const newClient=DB.addClient({
        name, colour, email,
        slug:name.toLowerCase().replace(/[^a-z0-9]+/g,'-'),
        eprov:'manual', yr:1,
      });
      // Link the company to its new client
      cos.push({id:newCoId, name, email, colour, portals, clientIds:[newClient.id]});
      // Initialise an empty report year
      if(!DB._reports) DB._reports={};
      // Create a draft report for the current month so it appears in the portal
      DB.createReport(newClient.id, S.year||new Date().getFullYear(),
        ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][new Date().getMonth()],
        {}
      );
    }
    // Propagate colour change to DB clients that belong to this company
    if(id){
      const updatedCo=cos.find(c=>c.id===id);
      if(updatedCo?.colour){
        (updatedCo.clientIds||[]).forEach(cid=>{
          const dbClient=DB.getClient(cid);
          if(dbClient&&!dbClient._customColour) dbClient.brand_colour=updatedCo.colour;
        });
      }
    }
    RV_DB.audit((id?'Company updated':'Company created')+': '+name, S.user?.name||'Admin', {
      icon:'', area:'Users & Access', type:'company',
      detail:(id?'Updated':'Created')+' company "'+name+'"'
    });
    DB.syncCompanyColours();
    MODAL.close('modal-create-company');
    this.renderUsers();
    // Rebuild reporting client list to reflect new colour
    if(typeof ADMIN!=='undefined') setTimeout(()=>{ ADMIN.buildClients(); ADMIN.buildUsers(); },100);
    // Trigger engine rebuilds so new company appears in all areas
    setTimeout(()=>{
      if(typeof OPPS!=='undefined') OPPS.build();
      if(typeof INTEL!=='undefined'){
        INTEL.buildForecast();
        INTEL.buildAnomalies();
      }
      if(typeof SNAPSHOT!=='undefined') SNAPSHOT.build();
    }, 100);
  },

  confirmDeleteCompany(coId){
    const cos=DB.getCompanies();
    const co=cos.find(c=>c.id===coId); if(!co) return;
    const listEl=document.getElementById('up-user-list');
    const existing=document.getElementById('del-co-confirm-'+coId);
    if(existing){ existing.remove(); return; }
    const conf=document.createElement('div');
    conf.id='del-co-confirm-'+coId;
    conf.style.cssText='background:rgba(232,69,69,.08);border:1px solid rgba(232,69,69,.3);border-radius:10px;padding:14px 20px;margin-bottom:10px;display:flex;align-items:center;gap:12px;';
    conf.innerHTML=`<span style="flex:1;color:rgba(255,255,255,.8);font-size:13px">Delete ${co.name}? Users will be unassigned.</span>`;
    const delBtn=document.createElement('button');
    delBtn.textContent='Delete'; delBtn.style.cssText='background:#E84545;border:none;color:#fff;border-radius:var(--rs);padding:6px 16px;cursor:pointer;font-size:12px;font-family:var(--fn)';
    delBtn.onclick=()=>{ const i=cos.indexOf(co); if(i>=0) cos.splice(i,1); DB.getUsers().forEach(u=>{ u.companies=(u.companies||[]).filter(cid=>cid!==coId); }); this.renderUsers(); };
    const cancelBtn=document.createElement('button');
    cancelBtn.textContent='Cancel'; cancelBtn.style.cssText='background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.6);border-radius:var(--rs);padding:6px 14px;cursor:pointer;font-size:12px;font-family:var(--fn)';
    cancelBtn.onclick=()=>conf.remove();
    conf.appendChild(delBtn); conf.appendChild(cancelBtn);
    if(listEl) listEl.insertAdjacentElement('afterbegin',conf);
  },

  // ── Populate company checkboxes in client access (show/hide per role) ──
  _populateClientCheckboxes(preSelected){
    const wrap=document.getElementById('cu-clients-wrap'); if(!wrap) return;
    const clients=DB.getParents();
    const pre=Array.isArray(preSelected)?preSelected:(preSelected||[]);
    wrap.innerHTML=clients.map(c=>`<label style="display:flex;align-items:center;gap:8px;padding:5px 8px;border-radius:var(--rs);cursor:pointer;font-size:12.5px;color:var(--t0);transition:background .13s" onmouseover="this.style.background='var(--bg2)'" onmouseout="this.style.background=''">`
      +`<input type="checkbox" value="${c.id}" ${pre.includes(c.id)?'checked':''} style="width:14px;height:14px;accent-color:var(--o);cursor:pointer">`
      +`<div style="width:18px;height:18px;border-radius:4px;background:${c.brand_colour};display:flex;align-items:center;justify-content:center;font-size:7px;font-weight:700;color:${c.brand_text};flex-shrink:0">${c.initials}</div>`
      +`<span>${c.name}</span>`
      +`</label>`).join('');
  },

  confirmDeleteUser(userId){
    const u=DB.getUser(userId); if(!u) return;
    // Inline confirm via a simple non-native UI
    const listEl=document.getElementById('up-user-list');
    const existing=document.getElementById('del-confirm-'+userId);
    if(existing){ existing.remove(); return; }
    const el=document.getElementById('up-user-list')?.querySelector(`[data-uid="${userId}"]`);
    const confirm=document.createElement('div');
    confirm.id='del-confirm-'+userId;
    confirm.style.cssText='background:rgba(232,69,69,.08);border:1px solid rgba(232,69,69,.3);border-radius:10px;padding:14px 20px;margin-bottom:10px;display:flex;align-items:center;gap:12px;';
    confirm.innerHTML=`<span style="flex:1;color:rgba(255,255,255,.8);font-size:13px">Delete ${u.name}? This cannot be undone.</span>`;
    const delBtn=document.createElement('button');
    delBtn.textContent='Delete';
    delBtn.style.cssText='background:#E84545;border:none;color:#fff;border-radius:var(--rs);padding:6px 16px;cursor:pointer;font-size:12px;font-family:var(--fn)';
    delBtn.onclick=()=>{ DB.deleteUser(userId); this.renderUsers(); };
    const cancelBtn=document.createElement('button');
    cancelBtn.textContent='Cancel';
    cancelBtn.style.cssText='background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.6);border-radius:var(--rs);padding:6px 14px;cursor:pointer;font-size:12px;font-family:var(--fn)';
    cancelBtn.onclick=()=>confirm.remove();
    confirm.appendChild(delBtn);
    confirm.appendChild(cancelBtn);
    if(listEl) listEl.insertAdjacentElement('afterbegin',confirm);
  },

  // Called from reporting boot — decide where to go
  postLogin(user){
    if(user.role === 'client'){
      // Clients go straight to home screen to choose area
      this.showHome();
    } else {
      // Admins go straight into reporting by default (existing behaviour)
      this.enter('reporting');
    }
  }
};

/* ══════════════════════════════════════════════════════════
   REVIEW DATA STORE
══════════════════════════════════════════════════════════ */
const CLIENT = {
  switchTo(clientId){
    S.clientId=clientId;
    const u=S.user;
    const yrs=DB.getYears(clientId);
    S.year=yrs[yrs.length-1];
    const mons=DB.getMonths(clientId,S.year).filter(m=>{
      const r=DB.getReport(clientId,S.year,m);
      return r?.status==='published';
    });
    S.month=mons[mons.length-1]||DB.getMonths(clientId,S.year).slice(-1)[0];
    S.activeTab='overview';
    // Update switcher buttons
    document.querySelectorAll('#client-switcher .mbtn').forEach(b=>{
      b.classList.toggle('on', b.getAttribute('onclick')?.includes(clientId));
    });
    REPORT.buildMonthBtns();
    REPORT.render();
  },
};

/* AI ASSISTANT — client-facing report Q&A */
const USAGE = {
  _log:[],
  trackView(clientId,year,month){
    const existing=this._log.find(e=>e.cid===clientId&&e.year===year&&e.month===month);
    if(existing){ existing.views++; existing.last_opened=new Date().toISOString(); }
    else this._log.push({cid:clientId,client_name:DB.getClient(clientId)?.name,year,month,views:1,first_opened:new Date().toISOString(),last_opened:new Date().toISOString()});
  },
  getLog(){ return[...this._log]; },
};

/* ══════════════════════════════════════════════════════════
   OPPORTUNITIES ENGINE
══════════════════════════════════════════════════════════ */

export { NAV, MODAL, AREA, CLIENT };
